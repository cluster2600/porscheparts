# Prototypes originaux d’atelier

Coupon de galerie 100 × 50 × 24 mm et support de présentation de soupape
64 × 42 × 19 mm avec passage de conception de 8,6 mm. Usage de revue hors
moteur ; aucun montage, procédé métal ou dépoudrage validé. Les formes
sont indépendantes du scan de culasse. Les STEP sont prioritaires et les
STL sont des maillages concept-only.

Le code est dans source/. Dans un environnement déjà équipé de build123d
0.11.1, NumPy, trimesh et rtree :

    python3 -B source/build.py --original-only --project-root . --output replay-new
    python3 -B -m unittest discover -s source -p test_geometry.py -v

--original-only ne lit pas de source de culasse. Les paramètres head servent
uniquement à la sensibilité hydraulique hypothétique. Aucun champ thermique
ou mécanique n’a été calculé pour ces prototypes.

La licence du dépôt, jointe dans LICENSE, réserve les droits. La publication
ne constitue pas une autorisation de fabrication ou de réutilisation.
