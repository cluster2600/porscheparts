"""Fixed level1 saved-table association check; no producer imports or native calls."""
from pathlib import Path
import csv,hashlib,itertools,json,math,struct
ROOT=Path(__file__).resolve().parents[3];BASE=ROOT/'work/962-engineering';HERE=Path(__file__).resolve().parent
ACTUAL=BASE/'cp1-oneway-thermoelastic-level1-data-execution-prep-001/actual-contract.json'
CLOSED=BASE/'cp1-oneway-thermoelastic-level1-data-root-execution-001/closed-result.json'
SOURCE=BASE/'cp1-assumed-thermal-birth-linear-level1-001';OUTPUT=BASE/'cp1-oneway-thermoelastic-level1-inputs-001'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
load=lambda p:json.loads(p.read_text())
assert sha(ACTUAL)=='eb44c6a55700f0c3a72aa0179bdf7afbc4f42be84dd715aed1e24236cecf86fb'
assert sha(CLOSED)=='97ab28821670baea2393e5f0bc4ef0be84c1b5bf6b1e37a55df287d5527d6689'
assert not (HERE/'independent-saved-check.json').exists() and not (HERE/'independent-saved-check.json').is_symlink()
a=load(ACTUAL);closed=load(CLOSED);auth=load(CLOSED.with_name('authorization.json'));manifest=load(OUTPUT/'transfer-manifest.json')
assert closed['schema']=='962-level1-data-root-closed/v1' and auth['schema']=='962-level1-data-root-authorization/v1'
assert closed['authorization']=={'path':str(CLOSED.with_name('authorization.json').relative_to(ROOT)),'sha256':sha(CLOSED.with_name('authorization.json')),'bytes':CLOSED.with_name('authorization.json').stat().st_size}
assert auth['actual']=={'path':str(ACTUAL.relative_to(ROOT)),'sha256':sha(ACTUAL),'bytes':ACTUAL.stat().st_size}
assert auth['index']['sha256']==sha(ROOT/auth['index']['path']) and auth['index']['path']=='work/962-engineering/cp1-oneway-thermoelastic-level1-data-execution-prep-001/index.json'
assert auth['command']==[a['selected_python'],'-I','-B',str(ROOT/a['source']),str(ACTUAL),sha(ACTUAL)]
assert a['source_sha256']==sha(ROOT/a['source']) and auth['controls']==a['ordinary_controls']
assert closed['returncode']==0 and closed['stop_reason'] is None and closed['signals']==[]
assert type(closed['root_owned_pid']) is int and closed['root_owned_pid']>0 and closed['root_owned_pid']==closed['root_owned_pgid']
assert closed['waited_and_reaped'] is True and closed['owned_group_observed_absent_after_wait'] is True and closed['descendant_universal_absence_claim'] is False
assert closed['native_process_executed'] is False and closed['conversion_completed'] is True and closed['result_accepted'] is False
assert closed['inputs_before_after_exact'] is True and auth['before_inputs']==closed['after_inputs']
assert closed['after_python']==auth['selected_python'] and closed['after_python']['sha256']==a['selected_python_sha256']
# Recorded interpreter-only link exception; no interpreter body is read here.
assert auth['selected_python']['symlink'] is True and auth['selected_python']['link']=='python3.12'
assert auth['selected_python']['resolved'].endswith('/cpython-3.12.11-macos-aarch64-none/bin/python3.12')
assert auth['preflight_history']=='Initial inline preflight refused the selected venv Python symlink before any write or launch. Corrected interpreter-only descriptor now records both link and exact resolved target. Inputs still refuse symlinks.'
assert auth['fresh_input_count']==215 and auth['fresh_csv_count']==162
assert set(auth['before_inputs'])==set(a['input_sha256']) and {k:v['sha256'] for k,v in auth['before_inputs'].items()}==a['input_sha256']
for k,v in auth['before_inputs'].items():assert v['path']==k and type(v['bytes']) is int and v['bytes']>=0
for stream in ['stdout','stderr']:
 p=CLOSED.with_name(stream+'.log');assert closed[stream]=={'path':str(p.relative_to(ROOT)),'sha256':sha(p),'bytes':p.stat().st_size}
assert set(p.name for p in OUTPUT.iterdir())==set(closed['outputs'])=={'old-end.grid','born-end.grid','born-begin40.grid','transfer-manifest.json'}
pins=dict(a['input_sha256']);assert len(pins)==215
peerpath=BASE/'cp1-oneway-thermoelastic-level1-data-child-peer-001/review.json';peerbindings=peerpath.with_name('bindings.json')
for key,p in [('independent_child',peerpath),('independent_child_bindings',peerbindings)]:assert auth[key]=={'path':str(p.relative_to(ROOT)),'sha256':sha(p),'bytes':p.stat().st_size}
assert load(peerpath)['decision']=='CLEAR_EXACT_DATA_ONLY_BINDINGS_PENDING_FRESH_ROOT_PREFLIGHT'
assert load(peerpath)['actual']['sha256']==sha(ACTUAL) and load(peerpath)['bindings']['sha256']==sha(peerbindings)
assert a['data_preparation_authorized'] is True and auth['native_or_assessor_authorized'] is False and closed['native_authority'] is False
for k in ['native_execution_authorized','head_execution_authorized','engineering_accepted','physics_qualified','material_qualified','process_calibrated','manufacturing_authorized','automatic_retry']:assert a[k] is False
assert manifest['schema']=='962-oneway-thermoelastic-prepared-transfer/v1'
for p in [ACTUAL,ROOT/auth['index']['path'],peerpath,peerbindings,CLOSED,CLOSED.with_name('authorization.json'),CLOSED.with_name('stdout.log'),CLOSED.with_name('stderr.log')]:
 assert p.is_file() and not p.is_symlink();pins[str(p.relative_to(ROOT))]=sha(p)
for name,row in closed['outputs'].items():
 p=OUTPUT/name;assert row['path']==str(p.relative_to(ROOT)) and p.is_file() and not p.is_symlink() and p.stat().st_size==row['bytes'] and sha(p)==row['sha256'];pins[str(p.relative_to(ROOT))]=row['sha256']
assert sum(r['bytes'] for r in closed['outputs'].values())==closed['output_total_bytes']==677459
held=load(HERE/'held-preparation.json');assert held['schema']=='962-held-fixed-level1-data-result-check/v1'
assert all(pins.get(k,v)==v for k,v in held['input_sha256'].items());pins.update(held['input_sha256'])
pins[str((HERE/'held-preparation.json').relative_to(ROOT))]=sha(HERE/'held-preparation.json')
for name,d in pins.items():
 p=ROOT/name;assert p.is_file() and not p.is_symlink() and sha(p)==d,name
receipt=load(SOURCE/'native-execution.json');index=load(BASE/'cp1-oneway-thermoelastic-level1-prep-001/thermal-input-index.json')
expected=[(0,'end','thermal_end_0000.csv')]+[(n,p,f'thermal_{p}_{n:04d}.csv') for n in range(1,81) for p in ['begin','end']]
assert [(r['step'],r['phase'],r['filename']) for r in index['selected']]==expected
assert manifest['selected161']==index['selected'] and manifest['source_receipt_sha256']==sha(SOURCE/'native-execution.json') and manifest['data_actual_sha256']==sha(ACTUAL)
fields={};body_rows=0
for item in index['selected']:
 filename=item['filename'];path=SOURCE/filename;assert sha(path)==item['sha256']==receipt['artifact_sha256'][filename]
 with path.open(newline='') as f:
  reader=csv.DictReader(f);assert reader.fieldnames==['id','temperature','x','y','z'];rows={};previous=-1
  for r in reader:
   assert set(r)==set(reader.fieldnames) and str(int(r['id']))==r['id'];tag=int(r['id']);assert tag>previous;previous=tag
   xyz=tuple(float(r[k]) for k in ['x','y','z']);t=float(r['temperature']);assert all(math.isfinite(v) for v in [*xyz,t])
   rows[tag]=(xyz,r['temperature'],t);body_rows+=1
 fields[item['step'],item['phase']]=rows
alias=index['additional_initial_BEGIN_alias'];assert sha(SOURCE/alias['filename'])==receipt['artifact_sha256'][alias['filename']]==index['selected'][0]['sha256']
coords={t:r[0] for t,r in fields[80,'end'].items()};xs=tuple(i/8 for i in range(17));ys=zs=tuple(i/4 for i in range(5))
assert len(coords)==425 and set(coords.values())==set(itertools.product(xs,ys,zs));inverse={v:k for k,v in coords.items()}
old={t for t,p in coords.items() if p[0]<=1};born={t for t,p in coords.items() if p[0]>=1};shared=old&born;new=born-old
assert tuple(map(len,[old,born,shared,new]))==(225,225,25,200)
assert coords[0]==(0.,0.,0.) and coords[32]==(1.,0.,0.) and coords[137]==(0.,1.,0.)
previous=fields[0,'end'];assert set(previous)==old and all(r[2]==400 for r in previous.values());maximum=0.
for step in range(81):
 for phase in (['end'] if step==0 else ['begin','end']):
  rows=fields[step,phase];assert set(rows)==(old if step<40 else set(coords))
  assert all(struct.pack('<3d',*r[0])==struct.pack('<3d',*coords[t]) for t,r in rows.items())
 if step:
  begin=fields[step,'begin'];error=max(abs(begin[t][2]-r[2]) for t,r in previous.items());assert error<=1e-10;maximum=max(maximum,error)
  if step==40:assert all(begin[t][2]==350 for t in new)
  previous=fields[step,'end']
expected_map=[{'source_node_id':t,'coordinates_m':list(p),'binary64_hex':[v.hex() for v in p],'old2':t in old,'born3':t in born,'shared':t in shared} for t,p in sorted(coords.items())]
assert manifest['node_rows']==expected_map and manifest['maximum_previous_END_to_BEGIN_error_K']==maximum
for k,value in [('old_node_count',225),('born_reference_DOF_count',225),('shared_node_count',25),('genuinely_new_node_count',200)]:assert manifest[k]==value
counts={};table_identities={}
for filename,steps,xaxis,phase in [('old-end.grid',range(81),xs[:9],'end'),('born-end.grid',range(40,81),xs[8:],'end'),('born-begin40.grid',[40],xs[8:],'begin')]:
 raw=(OUTPUT/filename).read_text();lines=raw.splitlines();axis_names=['X','Y','Z']+([] if filename=='born-begin40.grid' else ['T']);axes=[xaxis,ys,zs]+([] if filename=='born-begin40.grid' else [tuple(i/200 for i in steps)])
 for j,(name,expected_axis) in enumerate(zip(axis_names,axes)):
  assert lines[2*j]=='AXIS '+name;observed=[float(v) for v in lines[2*j+1].split()];assert observed==list(expected_axis) and all(x<y for x,y in zip(observed,observed[1:]))
 assert lines[2*len(axes)]=='DATA';tokens=[v for row in lines[2*len(axes)+1:] for v in row.split()]
 wanted=[fields[s,phase][inverse[x,y,z]][1] for s in steps for z in zs for y in ys for x in xaxis]
 assert tokens==wanted and len(tokens)==math.prod(map(len,axes)) and all(math.isfinite(float(v)) for v in tokens)
 assert sha(OUTPUT/filename)==manifest['table_sha256'][filename];counts[filename]=len(tokens);table_identities[filename]={'sha256':sha(OUTPUT/filename),'values':len(tokens),'axes':axis_names,'all_original_temperature_tokens_exact':True}
assert counts==manifest['table_value_counts']=={'old-end.grid':18225,'born-end.grid':9225,'born-begin40.grid':225}
assert sum(counts.values())==27675
assert manifest['native_connectivity_or_ID_bijection_proven'] is False and manifest['same_native_geometry_association_still_required'] is True
for k in ['source_off_cooling_history_present','native_execution_authorized','engineering_accepted','physics_qualified','material_qualified','process_calibrated','manufacturing_authorized']:assert manifest[k] is False
for name,d in pins.items():assert sha(ROOT/name)==d,name
result={'schema':'962-level1-oneway-data-complete-saved-check/v1','passed':True,'source_fields':161,'original_CSV_identities_including_initial_alias':162,'parsed_selected_CSV_rows':body_rows,'coordinates':425,'old':225,'born_reference':225,'shared':25,'new':200,'maximum_previous_END_to_BEGIN_error_K':maximum,'complete_table_tokens':27675,'tables':table_identities,'all_before_after_saved_pins':pins,'all_inputs_outputs_unchanged':True,'own_source_sha256':sha(Path(__file__)),'native_ID_connectivity_or_solver_labels_proven':False,'producer_or_native_import_or_call':False,'lifecycle_scope':'Saved root authorization/closure owns wait/reap and observed group absence; no current process observer, interpreter-body read or universal descendant claim.'}
(HERE/'independent-saved-check.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ['all_before_after_saved_pins']}))
