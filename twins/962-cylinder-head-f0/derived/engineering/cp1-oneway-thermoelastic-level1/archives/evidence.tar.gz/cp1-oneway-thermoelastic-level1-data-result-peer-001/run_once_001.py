"""One authorized saved-data comparator invocation; no producer/native imports."""
from pathlib import Path
import datetime, hashlib, json, os, signal, subprocess, time

ROOT = Path(__file__).resolve().parents[3]
BASE = ROOT / 'work/962-engineering'
HERE = Path(__file__).resolve().parent
PREP = BASE / 'cp1-oneway-thermoelastic-level1-data-result-check-prep-001'
SOURCE = PREP / 'check_saved_001.py'
PYTHON = Path('runtime-role://controller/python')
HELD = PREP / 'held-preparation.json'
SOURCE_PEER = BASE / 'cp1-oneway-thermoelastic-level1-data-result-check-source-peer-001/review.json'
SOURCE_BINDINGS = SOURCE_PEER.with_name('bindings.json')
ROOT_REVIEW = BASE / 'cp1-oneway-thermoelastic-level1-data-result-check-root-source-001/review.json'
RESULT = PREP / 'independent-saved-check.json'

def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1048576), b''):
            h.update(block)
    return h.hexdigest()

def record(path):
    assert path.is_file() and not path.is_symlink(), str(path)
    return {'path': str(path.relative_to(ROOT)), 'sha256': digest(path), 'bytes': path.stat().st_size}

def save(name, value):
    path = HERE / name
    assert not path.exists() and not path.is_symlink(), name
    path.write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')

assert digest(SOURCE) == '091d53bfffdcddb81f51a9bfec950739258bbfc11f89e933bc00faa6a4b39b84'
assert digest(HELD) == 'ba12a77874d4f9d47d340705dd5570eb7e9feedcd29ded2093dbc5e1903e576f'
assert digest(SOURCE_PEER) == '36fb5e74583786a676088e9796d898e63ef29c9dfc36407f912bb067ef6f8fe1'
assert digest(SOURCE_BINDINGS) == '0f3df11d68c9a8245d1786f7d087b589363e08ecf864f59ed870dc7d5868f672'
assert digest(ROOT_REVIEW) == 'f29e378952b8e2eea55e3eac7fa863c1a74b66d59cf392bd2027cbaf68b8f73d'
assert json.loads(SOURCE_PEER.read_text())['decision'] == 'CLEAR_SOURCE_HELD_SAVED_COMPARATOR_ONLY'
assert not RESULT.exists() and not RESULT.is_symlink()
held = json.loads(HELD.read_text())
expected = dict(held['input_sha256'])
assert len(expected) == 235
for path in [HELD, SOURCE_PEER, SOURCE_BINDINGS, ROOT_REVIEW, Path(__file__)]:
    expected[str(path.relative_to(ROOT))] = digest(path)
before = {name: record(ROOT / name) for name in expected}
assert all(before[name]['sha256'] == value for name, value in expected.items())
resolved = PYTHON.resolve(strict=True)
assert str(resolved) == 'runtime-role://controller/resolved-python3.12'
python_before = {'configured': str(PYTHON), 'symlink': PYTHON.is_symlink(), 'link': os.readlink(PYTHON), 'resolved': str(resolved), 'bytes': resolved.stat().st_size, 'sha256': digest(resolved)}
assert python_before['link'] == 'python3.12' and python_before['sha256'] == '1699bf8aa705a8bb71613bef5cdd7d7c8c9d9a188a841f41679aa9b5830b8f60'
command = [str(PYTHON), '-I', '-B', str(SOURCE)]
save('authorization.json', {'schema': '962-level1-saved-comparator-owned-authorization/v1', 'root_authorization': 'After frozen CLEAR source peer, execute comparator091d exactly once with60s wall/TERM8verified-own-groupKILLwait; fresh235+held+peer+rootreview+selectedPython beforeafter. Saved CSV/table metadata/token reads only; no converter/scientific/native/assessor/head.', 'command': command, 'cwd': str(ROOT), 'timeout_seconds': 60, 'term_grace_seconds': 8, 'new_session': True, 'automatic_retry': False, 'before': before, 'python': python_before})
signals = []
stop_reason = None
started_utc = datetime.datetime.now(datetime.timezone.utc).isoformat()
start = time.monotonic()
with (HERE / 'stdout.log').open('xb') as stdout, (HERE / 'stderr.log').open('xb') as stderr:
    process = subprocess.Popen(command, cwd=ROOT, stdout=stdout, stderr=stderr, start_new_session=True)
    owned_pid = process.pid
    owned_pgid = os.getpgid(owned_pid)
    assert owned_pgid == owned_pid
    save('launch.json', {'command': command, 'owned_pid': owned_pid, 'owned_pgid': owned_pgid, 'new_session_verified_by_getpgid': True, 'started_utc': started_utc})
    try:
        rc = process.wait(timeout=60)
    except subprocess.TimeoutExpired:
        stop_reason = 'ordinary_wall_timeout'
        assert os.getpgid(owned_pid) == owned_pgid == owned_pid
        os.killpg(owned_pgid, signal.SIGTERM)
        signals.append('SIGTERM')
        try:
            rc = process.wait(timeout=8)
        except subprocess.TimeoutExpired:
            assert os.getpgid(owned_pid) == owned_pgid == owned_pid
            os.killpg(owned_pgid, signal.SIGKILL)
            signals.append('SIGKILL')
            rc = process.wait(timeout=8)
elapsed = time.monotonic() - start
def absent(target, group=False):
    try:
        (os.killpg if group else os.kill)(target, 0)
    except ProcessLookupError:
        return True
    return False
after = {name: record(ROOT / name) for name in expected}
python_after = {'configured': str(PYTHON), 'symlink': PYTHON.is_symlink(), 'link': os.readlink(PYTHON), 'resolved': str(PYTHON.resolve(strict=True)), 'bytes': resolved.stat().st_size, 'sha256': digest(resolved)}
execution = {'schema': '962-level1-saved-comparator-owned-execution/v1', 'authorization': record(HERE / 'authorization.json'), 'launch': record(HERE / 'launch.json'), 'checker': record(SOURCE), 'launcher': record(Path(__file__)), 'command': command, 'started_utc': started_utc, 'elapsed_seconds': elapsed, 'returncode': rc, 'stop_reason': stop_reason, 'signals': signals, 'ordinary_timeout_seconds': 60, 'term_grace_seconds': 8, 'hard_quota_claimed': False, 'owned_pid': owned_pid, 'owned_pgid': owned_pgid, 'waited_and_reaped': process.returncode is not None, 'owned_leader_observed_absent_after_wait': absent(owned_pid), 'owned_group_observed_absent_after_wait': absent(owned_pgid, True), 'universal_descendant_absence_claim': False, 'before': before, 'after': after, 'all_inputs_unchanged': before == after, 'python_before': python_before, 'python_after': python_after, 'python_unchanged': python_before == python_after, 'stdout': record(HERE / 'stdout.log'), 'stderr': record(HERE / 'stderr.log'), 'result': record(RESULT) if RESULT.is_file() and not RESULT.is_symlink() else None, 'native_or_scientific_or_converter_or_assessor_executed': False, 'automatic_retry': False}
save('execution.json', execution)
print(json.dumps({k:execution[k] for k in ['returncode','elapsed_seconds','stop_reason','signals','all_inputs_unchanged','python_unchanged','owned_leader_observed_absent_after_wait','owned_group_observed_absent_after_wait','result']}))
