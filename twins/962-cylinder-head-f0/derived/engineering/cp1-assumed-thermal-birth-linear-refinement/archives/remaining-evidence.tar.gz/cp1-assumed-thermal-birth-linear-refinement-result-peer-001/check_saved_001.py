"""One saved-JSON association/arithmetic check; no evaluator/field/native imports."""
from pathlib import Path
import hashlib
import json
import math

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
W = 'work/962-engineering/'
A = W + 'cp1-assumed-thermal-birth-linear-refinement-execution-prep-001/'
E = W + 'cp1-assumed-thermal-birth-linear-refinement-root-execution-001/'
P = W + 'cp1-assumed-thermal-birth-linear-refinement-prep-003/'
D = W + 'cp1-assumed-thermal-birth-linear-refinement-001/'
C = W + 'cp1-assumed-thermal-birth-linear-refinement-child-peer-001/'
FLAGS = ['engineering_accepted','physics_qualified','material_qualified','process_calibrated','manufacturing_authorized']
EXPECTED = {
 A+'actual-contract.json':'04c3af29ae58c01a9b4bc699ae502ddddf17fbb2d0512b90c2d2930cea12669f',
 A+'completed-manifest.json':'ad0453851bdee2198e309b89a2977ea36d63b827ce648bd381025be628d7e58b',
 E+'closed-result.json':'a7e16f883c81eff15fe5ef0497edc42534d27b6a9569015736cee0246222ed79',
 E+'result-review.json':'774e956bc02a307c314ffe68a5e3aae3ef207991b950aa6235e20d008cb1ddb2',
 E+'launch.json':'b3f482e7ccaa0a1a01f607bb9b2dcd76bca6e7f404410acc8ca9a4aa24a09686',
 C+'review.json':'a458fcdbff273cac783a3119e1725e87e6e899c048a6d2010a8e57a899b55c34',
 D+'refinement-assessment.json':'8283998df2f742ff80414c6da70b2d33142e04a3728b3bada6a61abc2c8dfa8e',
 P+'assess_refinement.py':'13934e6e8ae5bb1ada1b6bbc29172855441e72b04e34752d4132c530bc69138c',
}
def raw(rel):
    p = ROOT / rel
    assert not Path(rel).is_absolute() and '..' not in Path(rel).parts
    assert p.is_file() and not p.is_symlink() and p.resolve() == p
    return p.read_bytes()
def sha(rel):
    return hashlib.sha256(raw(rel)).hexdigest()
def load(rel):
    return json.loads(raw(rel))
def same(a,b):
    return json.dumps(a,sort_keys=True,allow_nan=False) == json.dumps(b,sort_keys=True,allow_nan=False)

actual = load(A+'actual-contract.json')
assert actual['input_count'] == len(actual['input_sha256']) == 80
pins = dict(actual['input_sha256'])
for path,digest in EXPECTED.items():
    assert path not in pins or pins[path] == digest
    pins[path] = digest
for path in [E+'child-peer-acceptance.json',E+'stdout.log',E+'stderr.log',str(Path(__file__).resolve().relative_to(ROOT))]:
    pins[path] = sha(path)
before = {p:sha(p) for p in pins}
assert before == pins
manifest = load(A+'completed-manifest.json')
report = load(D+'refinement-assessment.json')
closed = load(E+'closed-result.json')
root_review = load(E+'result-review.json')
launch = load(E+'launch.json')
child = load(C+'review.json')
root_child = load(E+'child-peer-acceptance.json')
assert manifest['status'] == 'BOUND_THREE_ACCEPTED_LEVELS' and manifest['ready_for_evaluation'] is True
assert child['blockers'] == [] and child['decision'].startswith('CLEAR_')
assert root_child['peer_sha256'] == EXPECTED[C+'review.json'] and root_child['actual_sha256'] == EXPECTED[A+'actual-contract.json']
assert root_child['all80_inputs_and_interpreter_current'] is True
assert actual['source'] == P+'assess_refinement.py' and actual['source_sha256'] == EXPECTED[P+'assess_refinement.py']
assert actual['completed_manifest'] == {'path':A+'completed-manifest.json','sha256':EXPECTED[A+'completed-manifest.json']}
assert actual['refinement_evaluation_authorized'] is True
for key in ['native_execution_authorized','assessment_execution_authorized','head_execution_authorized','automatic_retry','threshold_changes','original_level2_rerun_or_reassociation_authorized']+FLAGS:
    assert actual[key] is False
for obj in [manifest,report,closed,root_review]:
    assert all(obj[k] is False for k in FLAGS)
assert all(manifest[k] is False for k in ['native_execution_authorized','assessment_execution_authorized','refinement_evaluation_authorized','head_execution_authorized'])
assert report['classification'] == 'HYPOTHETICAL_SOFTWARE_VERIFICATION_ONLY' and report['whole_head_lpbf_complete'] is False
shared = manifest['shared']
for record in shared.values():
    assert actual['input_sha256'][record['path']] == record['sha256']
card = load(shared['card']['path'])
assert card['selected_time_level'] == 2 and card['cp_slope_J_kgK2'] == 0
assert all(x is None for x in card['assumed_material']['measured_matched'].values())
old_manifest = load(P+'refinement-manifest.json')
assert same(old_manifest['shared'],shared) and same(old_manifest['levels'][2],manifest['levels'][2])
levels = []
errors = []
assert len(manifest['levels']) == len(report['native_levels']) == len(actual['assessment_records']) == 3
for i,row in enumerate(manifest['levels']):
    assert row['level'] == i
    for key,record in row.items():
        if key == 'level': continue
        assert set(record) == {'path','sha256'} and actual['input_sha256'][record['path']] == record['sha256']
    assessment = load(row['assessment']['path'])
    ref = load(row['numerical_reference']['path'])
    native = load(row['native_receipt']['path'])
    peer = load(row['assessment_result_peer']['path'])
    accepted = load(row['root_assessment_acceptance']['path'])
    assert actual['assessment_records'][i] == row['assessment']
    assert ref['selected_level_only'] == i and ref['level_input_sha256'] == {str(i):row['time_input']['sha256']}
    assert ref['time_level_inputs'] == {str(i):raw(row['time_input']['path']).decode()}
    assert ref['card_sha256'] == shared['card']['sha256'] and same(ref['card'],card)
    assert ref['input_sha256']['thermal-birth.i'] == shared['deck']['sha256'] and ref['assessor_sha256'] == shared['assessor']['sha256']
    dt = card['time_steps_s'][i]
    count = round(card['end_time_s']/dt)
    assert assessment['passed'] is True and assessment['failed_checks'] == 0 and assessment['level'] == i
    assert assessment['classification'] == report['classification'] and assessment['dt_s'] == dt
    assert assessment['frozen_contract_sha256'] == row['numerical_reference']['sha256']
    assert assessment['assessor_sha256'] == shared['assessor']['sha256'] and assessment['native_receipt_sha256'] == row['native_receipt']['sha256']
    assert native['level'] == i and native['physics_contract_sha256'] == row['numerical_reference']['sha256']
    assert native['returncode'] == 0 and native['native_execution_completed'] is True and native['process_reaped'] is True
    assert native['inputs_unchanged'] is True and native['binary_and_runtime_unchanged'] is True and native['stop_reason'] is None
    assert native['jobs'] == [{'name':'native','returncode':0,'process_reaped':True}]
    assert peer['blockers'] == [] and peer['decision'].startswith('CLEAR_')
    assert accepted['passed_single_level_software_assessment'] is True and accepted['assessment_sha256'] == row['assessment']['sha256'] and accepted['peer_sha256'] == row['assessment_result_peer']['sha256']
    assert all(accepted[k] is False for k in FLAGS)
    traces = assessment['traces']
    assert assessment['native_steps'] == len(traces) == count
    assert [x['step'] for x in traces] == list(range(1,count+1))
    values = [x['relative_continuous_energy_error'] for x in traces]
    assert all(type(x) in (int,float) and math.isfinite(x) for x in values)
    error = max(abs(x) for x in values)
    assert error == assessment['max_continuous_relative_energy_error'] and error >= 0
    expected_native = {'level':i,'checks_count':assessment['checks_count'],'max_error_by_check':assessment['max_error_by_check'],'native_receipt_sha256':row['native_receipt']['sha256'],'final_state':traces[-1],'assessment_path':row['assessment']['path'],'assessment_sha256':row['assessment']['sha256']}
    assert same(report['native_levels'][i],expected_native)
    assert traces[-1]['step'] == count and traces[-1]['time_s'] == card['end_time_s']
    errors.append(error)
    levels.append({'level':i,'dt_s':dt,'steps':count,'assessment':row['assessment'],'reference':row['numerical_reference'],'native_receipt':row['native_receipt'],'peer':row['assessment_result_peer'],'root_acceptance':row['root_assessment_acceptance'],'checks_count':assessment['checks_count'],'negative_signed_trace_count':sum(x<0 for x in values),'MAXABS_relative_error':error,'error_binary64_hex':error.hex(),'all_reported_maxima_and_final_trace_exact_typed_copy':True,'final_trace':traces[-1]})
assert errors == report['max_continuous_relative_energy_errors']
assert all(math.isfinite(x) and x >= 0 for x in errors) and all(x != 0 for x in errors[1:])
ratios = [errors[i]/errors[i+1] for i in range(2)]
assert all(math.isfinite(x) for x in ratios) and ratios == report['successive_error_ratios']
limits = card['predeclared_tolerances']
assert report['predeclared_minimum_error_ratio'] == limits['minimum_refinement_error_ratio'] == 1.4
assert report['predeclared_finest_energy_limit'] == limits['finest_continuous_energy_relative'] == .01
passed = all(x >= 1.4 for x in ratios) and errors[-1] <= .01
assert passed is True and report['passed'] is True
assert report['time_steps_s'] == card['time_steps_s'] and report['numerical_reference_sha256s'] == [x['numerical_reference']['sha256'] for x in manifest['levels']]
assert report['refinement_manifest_sha256'] == EXPECTED[A+'completed-manifest.json'] and report['refinement_assessor_sha256'] == actual['source_sha256']
assert root_review['MAXABS_relative_energy_errors'] == errors and root_review['successive_error_ratios'] == ratios and root_review['passed_energy_error_time_refinement_gate'] is True
assert root_review['closed_sha256'] == EXPECTED[E+'closed-result.json'] and root_review['refinement_assessment_sha256'] == EXPECTED[D+'refinement-assessment.json']
assert closed['actual_sha256'] == EXPECTED[A+'actual-contract.json'] and closed['child_peer_sha256'] == EXPECTED[C+'review.json'] and closed['root_launch_sha256'] == EXPECTED[E+'launch.json']
assert launch['actual_sha256'] == closed['actual_sha256'] and launch['child_peer_sha256'] == closed['child_peer_sha256'] and launch['argv'] == actual['argv']
assert launch['query_pid'] == launch['query_pgid'] == closed['query_pid'] and launch['owned_new_session'] is True
assert closed['returncode'] == 0 and closed['stop_reason'] is None and closed['error'] is None
assert closed['query_reaped'] is True and closed['observed_leader_absent'] is True and closed['fallback_SIGKILL'] is False and closed['universal_descendant_absence_claimed'] is False
assert closed['all80_inputs_actual_peer_python_before_after_unchanged'] is True and closed['native_or_0548_assessor_replayed'] is False
bounds = actual['resource_bounds']
assert bounds == {'wall_seconds':60,'sampled_owned_leader_RSS_bytes':1073741824,'output_directory_bytes_plus_stdout_stderr':33554432,'root_sample_interval_seconds':.1,'owned_new_session':True,'TERM_then_KILL_wait_seconds':2,'RSS_is_sampled_not_true_peak':True,'not_OS_quota_or_network_sandbox':True}
assert 0 < closed['wall_seconds'] < bounds['wall_seconds']
assert closed['maximum_sampled_owned_leader_RSS_bytes'] == max(x['RSS_bytes'] for x in closed['RSS_samples']) < bounds['sampled_owned_leader_RSS_bytes'] and closed['true_peak'] is False
assert sorted(p.name for p in (ROOT/D).iterdir()) == ['refinement-assessment.json']
assert closed['output_files'] == {'refinement-assessment.json':{'sha256':EXPECTED[D+'refinement-assessment.json'],'bytes':len(raw(D+'refinement-assessment.json'))}}
assert sha(E+'stdout.log') == closed['stdout_sha256'] and sha(E+'stderr.log') == closed['stderr_sha256'] and raw(E+'stderr.log') == b''
assert load(E+'stdout.log') == {'passed':True,'max_continuous_relative_energy_errors':errors,'successive_error_ratios':ratios}
assert closed['output_plus_logs_bytes'] == sum(len(raw(p)) for p in [D+'refinement-assessment.json',E+'stdout.log',E+'stderr.log']) < bounds['output_directory_bytes_plus_stdout_stderr']
after = {p:sha(p) for p in pins}
assert after == before
ledger = {'schema':'962-independent-saved-fixed3-LINEAR-refinement-check/v1','passed_saved_association_and_error_refinement':True,'input_count':80,'all_input_and_additional_closed_evidence_before_after_unchanged':True,'all_checked_records_count':len(pins),'sha256_before':before,'sha256_after':after,'levels':levels,'MAXABS_relative_energy_errors':errors,'successive_error_ratios':ratios,'ratio_binary64_hex':[x.hex() for x in ratios],'minimum_ratio':1.4,'finest_limit':.01,'reported_checks_total':sum(x['checks_count'] for x in levels),'trace_rows_total':sum(x['steps'] for x in levels),'root_lifecycle_attribution':{'returncode':closed['returncode'],'wall_seconds':closed['wall_seconds'],'no_stop_or_error':True,'waited_reaped_observed_leader_absent':True,'maximum_sampled_leader_RSS_bytes':closed['maximum_sampled_owned_leader_RSS_bytes'],'true_peak':False,'universal_descendant_absence_claimed':False,'runtime_Python_body_freshness_attributed_to_root':True},'resource_bounds':bounds,'original_level2_reference_and_assessment_unchanged':True,'scope':'Saved trace maxima, binary64 ratios, output copies and byte/provenance closure only; no production evaluator/0548/Gaussian/HEX/PDE/native replay; no full-field/spatial/Newton/head/material/process/LPBF qualification.'}
with (OUT/'independent-saved-check.json').open('x') as f:
    json.dump(ledger,f,indent=2,allow_nan=False);f.write('\n')
print(json.dumps({'passed_saved_association':True,'levels':3,'trace_rows':sum(x['steps'] for x in levels),'input_count':80,'MAXABS_errors':errors,'ratios':ratios,'unchanged_gate_passed':passed}))
