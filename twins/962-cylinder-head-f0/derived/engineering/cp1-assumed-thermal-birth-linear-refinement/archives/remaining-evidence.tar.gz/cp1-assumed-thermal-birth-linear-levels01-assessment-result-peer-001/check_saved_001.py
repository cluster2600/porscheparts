"""Review saved assessment arithmetic/closure; no assessor import or physics replay."""
import hashlib
import json
import math
from pathlib import Path
import struct

ROOT=Path(__file__).resolve().parents[3]
HERE=Path(__file__).resolve().parent
E='work/962-engineering/'
CHILD=E+'cp1-assumed-thermal-birth-linear-levels01-assessment-child-peer-001/review.json'
INDEX=E+'cp1-assumed-thermal-birth-linear-levels01-assessment-prep-001/index.json'
MASTER=E+'cp1-assumed-thermal-birth-linear-levels01-assessment-root-execution-001/closed-result.json'
ROOT_REVIEW=E+'cp1-assumed-thermal-birth-linear-levels01-assessment-root-execution-001/result-review.json'
DONOR=E+'cp1-assumed-thermal-birth-linear-assessment-result-peer-001/check_saved_001.py'
ACTUAL=OUT=RUN=NATIVE=None
EXPECTED={CHILD:'5ac80c9e21c7dfea53a64e00f6e16beef98a954c37bd1f3ae794fead61f70196',INDEX:'09f407b71a0fe086d9c28566231265f7c0672baf36694f4cf77ff0f79171160d',MASTER:'1bd4fcca6da5f1d1f3d65a13561dcc57419e18cd860a400f2e906197bde9a4ec',ROOT_REVIEW:'c490bad9f0ed5a9e71a90d1dd8a9c536d9dc91075851cd5388cc36d6308c492d',DONOR:'c79bd0c45326bf760cca392cbeaf72370f3f55936526dc259ad7e71dbbd161f3'}

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load(p):return json.loads((ROOT/p).read_text())
def need(v,label):
    if not v:raise AssertionError(label)
def bits(v):return struct.pack('>d',v)

def check_case(spec):
    global ACTUAL,OUT,RUN,NATIVE
    level=spec['level'];steps_count=spec['steps'];birth=spec['birth'];dt=spec['dt']
    ACTUAL=E+f'cp1-assumed-thermal-birth-linear-levels01-assessment-prep-001/level{level}-actual-contract.json'
    OUT=E+f'cp1-assumed-thermal-birth-linear-level{level}-assessment-001/'
    RUN=E+f'cp1-assumed-thermal-birth-linear-levels01-assessment-root-execution-001/level{level}/'
    NATIVE=E+f'cp1-assumed-thermal-birth-linear-level{level}-001/'
    actual=load(ACTUAL);closed=load(RUN+'closed-result.json');launch=load(RUN+'launch.json');assessment=load(OUT+'assessment.json')
    pins=dict(actual['input_sha256']);need(len(pins)==spec['pins'],'per-level saved inputs')
    pins.update(EXPECTED)
    pins[ACTUAL]=spec['actual_sha256'];pins[OUT+'assessment.json']=spec['assessment_sha256'];pins[RUN+'closed-result.json']=spec['closed_sha256']
    for name in ['launch.json','stdout.log','stderr.log']:pins[RUN+name]=sha(ROOT/RUN/name)
    pins[str(Path(__file__).relative_to(ROOT))]=sha(Path(__file__))
    before={}
    for name,digest in pins.items():
        p=ROOT/name;need(p.is_file() and not p.is_symlink() and p.suffix not in ['.msh','.bin','.so','.dylib'],'explicit saved file')
        before[name]=sha(p);need(before[name]==digest,'digest '+name)
    need(set(p.name for p in (ROOT/OUT).iterdir())=={'assessment.json'},'one output file')
    need((ROOT/OUT/'assessment.json').stat().st_size==spec['assessment_bytes'] and closed['assessment_output_files']=={'assessment.json':{'sha256':spec['assessment_sha256'],'bytes':spec['assessment_bytes']}},'result inventory')
    native_inventory=actual['native_output_inventory'];need(len(native_inventory)==spec['native_files'] and sum(r['bytes'] for r in native_inventory.values())==spec['native_bytes'],'native closure')
    for name,row in native_inventory.items():need(before[NATIVE+name]==row['sha256'] and (ROOT/NATIVE/name).stat().st_size==row['bytes'],'native immutable inventory')
    need(closed['actual_sha256']==spec['actual_sha256'] and closed['child_peer_sha256']==EXPECTED[CHILD] and closed['root_launch_sha256']==sha(ROOT/RUN/'launch.json'),'root joins')
    need(launch['actual_sha256']==spec['actual_sha256'] and launch['child_peer_sha256']==EXPECTED[CHILD] and launch['argv']==actual['argv'],'launch argv')
    need(launch['new_owned_session'] is True and launch['assessment_pid']==launch['assessment_pgid']==closed['assessment_pid'],'owned process association')
    need(closed['returncode']==0 and closed['assessment_reaped'] is True and closed['observed_leader_absent'] is True and closed['stop_reason'] is None and closed['error'] is None,'root lifecycle')
    need(closed['universal_descendant_absence_claimed'] is False and closed['all_inputs_actual_peer_python_before_after_unchanged'] is True and closed['all_original_native_output_files_unchanged'] is True,'root limited observations')
    for stream in ['stdout','stderr']:need(closed[stream+'_sha256']==sha(ROOT/RUN/(stream+'.log')),'stream hash')
    need(closed['output_plus_logs_bytes']==spec['assessment_bytes']+sum((ROOT/RUN/n).stat().st_size for n in ['stdout.log','stderr.log'])==spec['output_plus_logs'],'output/log count')
    samples=closed['RSS_samples'];need(len(samples)==spec['RSS_samples'] and max(r['RSS_bytes'] for r in samples)==closed['maximum_sampled_owned_leader_RSS_bytes']==spec['RSS_max'] and closed['true_peak'] is False,'sampled RSS')
    need(all(closed[k] is False for k in ['automatic_retry','engineering_accepted','physics_qualified','material_qualified','process_calibrated','manufacturing_authorized']),'closed authority limits')
    card=load(NATIVE+'card.json');contract=load(NATIVE+'frozen-contract.json');native=load(NATIVE+'native-execution.json')
    need(assessment['native_receipt_sha256']==sha(ROOT/NATIVE/'native-execution.json')==spec['native_receipt_sha256'],'receipt identity')
    need(assessment['frozen_contract_sha256']==actual['numerical_reference_sha256']==sha(ROOT/NATIVE/'frozen-contract.json')==spec['reference_sha256'],'reference')
    need(assessment['assessor_sha256']==actual['assessor_sha256']==contract['assessor_sha256']=='0548fcbf6eba737aaaf816abbfbfd0511b5b8fb266aa10c34a1f5817eef0e338','assessor')
    need(contract['card']==card and assessment['classification']==card['classification']=='HYPOTHETICAL_SOFTWARE_VERIFICATION_ONLY','hypothetical card')
    need(native['passed'] is False and native['independent_assessment_performed'] is False,'old native receipt unchanged')
    need(assessment['passed'] is True and assessment['failed_checks']==[] and assessment['level']==level and assessment['dt_s']==dt and assessment['native_steps']==steps_count,'saved passed coarse level')
    traces=assessment['traces'];need(len(traces)==steps_count and [r['step'] for r in traces]==list(range(1,steps_count+1)),'complete ordered traces')
    expected_fields={'step','time_s','active_volume_m3','enthalpy_J','birth_enthalpy_J','centered_step_enthalpy_increment_J','cumulative_centered_heat_response_J','continuous_source_energy_J','continuous_energy_error_J','relative_continuous_energy_error','finite_box_power_W','quadrature_power_W','BE_capacity_correction_J','temperature_min_K','temperature_max_K'}
    increments=[];trace_rows=[];continuous=[];energy_errors=[];box_errors=[]
    for i,row in enumerate(traces,1):
        need(set(row)==expected_fields and all(type(v) in (float,int) and math.isfinite(v) for v in row.values()),'trace finite field closure')
        need(bits(row['time_s'])==bits(i*dt) and row['active_volume_m3']==(1 if i<birth else 2),'time/declared active volume')
        need(row['BE_capacity_correction_J']==0 and row['continuous_source_energy_J']>0 and row['finite_box_power_W']>0 and row['quadrature_power_W']>0,'saved finite source fields')
        need(card['predeclared_tolerances']['temperature_lower_K']<=row['temperature_min_K']<=row['temperature_max_K']<=card['predeclared_tolerances']['temperature_upper_K'],'recorded temperature bounds')
        increments.append(row['centered_step_enthalpy_increment_J']);need(bits(math.fsum(increments))==bits(row['cumulative_centered_heat_response_J']),'saved cumulative arithmetic')
        defect=row['cumulative_centered_heat_response_J']-row['continuous_source_energy_J'];relative=defect/max(abs(row['continuous_source_energy_J']),1e-12)
        need(bits(defect)==bits(row['continuous_energy_error_J']) and bits(relative)==bits(row['relative_continuous_energy_error']),'saved defect/normalization arithmetic')
        energy=row['centered_step_enthalpy_increment_J']-dt*row['quadrature_power_W']+row['BE_capacity_correction_J'];box=(row['quadrature_power_W']-row['finite_box_power_W'])/row['finite_box_power_W']
        continuous.append(abs(relative));energy_errors.append(abs(energy));box_errors.append(abs(box))
        need(row['birth_enthalpy_J']==(0 if i<birth else traces[birth-1]['birth_enthalpy_J']),'stored birth accounting transition')
        trace_rows.append(dict(step=i,continuous_relative_abs=abs(relative),saved_step_energy_abs_J=abs(energy),saved_finite_box_relative_abs=abs(box)))
    maximums=assessment['max_error_by_check'];tol=card['predeclared_tolerances']
    thresholds={'initial_temperature':tol['node_history_K'],'active_node_count':0,'existing_nodal_history':tol['node_history_K'],'new_node_count':0,'new_node_birth_temperature':tol['node_history_K'],'k_T_element_average':tol['material_property_absolute'],'cp_T_element_average':tol['material_property_absolute'],'moving_source_element_average':tol['source_cell_average_relative'],'finite_box_gaussian_power':tol['finite_box_power_relative'],'nonlinear_BE_enthalpy_identity':tol['corrected_step_energy_absolute_J'],'nonuniform_final_temperature':0,'finest_continuous_energy_error':tol['finest_continuous_energy_relative']}
    del thresholds['finest_continuous_energy_error']
    need(set(maximums)==set(thresholds) and all(type(v) in (float,int) and math.isfinite(v) and 0<=v<=thresholds[k] for k,v in maximums.items()),'all12 reported maxima within exact card thresholds')
    need(bits(max(continuous))==bits(assessment['max_continuous_relative_energy_error']),'saved continuous maximum')
    need(bits(max(energy_errors))==bits(maximums['nonlinear_BE_enthalpy_identity']) and bits(max(box_errors))==bits(maximums['finite_box_gaussian_power']),'saved per-step/box maxima')
    property_rows=(birth-1)*128+(steps_count-birth+1)*256
    check_count=1+steps_count*4+property_rows*3+2+1
    need(check_count==assessment['checks_count']==spec['checks'],'source-derived per-level count')
    printed=load(RUN+'stdout.log');need(printed=={k:assessment[k] for k in ['passed','level','dt_s','checks_count','failed_checks','max_continuous_relative_energy_error']},'stdout summary exact')
    root_review=load(ROOT_REVIEW);rr=root_review['levels'][level]
    need(root_review['master_closed_sha256']==EXPECTED[MASTER] and rr['assessment_sha256']==spec['assessment_sha256'] and rr['checks_count']==spec['checks'] and rr['failed_checks']==0,'root result association')
    negative=sum(r['relative_continuous_energy_error']<0 for r in traces)
    need(negative==rr['signed_negative_trace_count']==spec['negative_traces'] and bits(rr['max_absolute_trace_continuous_relative_energy_error'])==bits(max(continuous)),'signed traces/MAXABS distinction')
    need(bits(rr['max_step_energy_defect_J'])==bits(max(energy_errors)) and bits(rr['max_finite_box_power_relative_error'])==bits(max(box_errors)),'root saved maxima association')
    after={name:sha(ROOT/name) for name in pins};need(before==after,'all saved pins stable')
    result=dict(schema='962-cp1-LINEAR-assessment-independent-saved-result-check/v1',status='PASS_SAVED_ASSESSMENT_BINDINGS_AND_TRACE_ARITHMETIC',input_sha256=before,input_sha256_after=after,all_saved_inputs_unchanged=True,
      assessment_output_inventory=closed['assessment_output_files'],native_files_unchanged=spec['native_files'],native_bytes_unchanged=spec['native_bytes'],actual_map_verified=True,trace_count=steps_count,reported_check_count=spec['checks'],derived_count_formula='1 initial +steps*4 base step checks +3*((birth-1)*128+(steps-birth+1)*256) material/source samples +2 birth +1 coarse final check',
      exact_card_thresholds=thresholds,reported_maxima=maximums,all_reported_maxima_within_unchanged_thresholds=True,all_saved_trace_arithmetic=trace_rows,
      independently_checked='Full byte/source/actual/receipt/root/CLI/lifecycle associations; complete trace shape/time/volume/finite values; saved cumulative/defect/relative/per-step energy/box-power arithmetic; reported11 coarse-level maxima against unchanged card thresholds and count formula. No raw-field Gaussian/HEX/enthalpy integration or continuous-source quadrature recomputation.',
      assessor_attribution='The reported individual checks and raw-field source/energy computations are outputs of the bound unchanged0548 assessor, not independently repeated here. This checker checks complete saved summaries/traces and provenance only.',
      root_lifecycle_attribution=dict(returncode=0,reaped=True,observed_leader_absent=True,universal_descendant_absence=False,wall_seconds=closed['wall_seconds'],RSS_sample_count=spec['RSS_samples'],maximum_sampled_owned_leader_RSS_bytes=spec['RSS_max'],true_peak=False),
      one_level_only_no_temporal_convergence=True,original_Newton_nonlinear_criterion_not_checked=True,assessor_imported_or_rerun=False,native_or_PDE_replay=False,engineering_accepted=False,physics_qualified=False,material_qualified=False,process_calibrated=False,manufacturing_authorized=False)
    result['signed_negative_trace_count']=negative
    result['reported_continuous_summary_is_MAXABS']=True
    result['finest_continuous_point01_gate_not_applicable_to_coarse_levels']=True
    output=HERE/f'level{level}-saved-check.json';need(not output.exists(),'fresh checker output');output.write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
    return result

def main():
    master=load(MASTER);index=load(INDEX)
    need(master['root_error'] is None and master['index_sha256']==EXPECTED[INDEX] and master['child_peer_sha256']==EXPECTED[CHILD] and master['original_level2_not_rerun_or_reassociated'] is True and master['native_execution_authorized'] is False and master['temporal_convergence_established'] is False,'master joins/scope')
    specs=[dict(level=0,steps=40,birth=20,dt=.01,pins=314,native_files=142,native_bytes=1615306,assessment_bytes=29080,output_plus_logs=29229,checks=23588,negative_traces=13,RSS_samples=13,RSS_max=28114944,actual_sha256='e2e5023b3f893077f4baf79284f1907ff6329452583767ff6bc59a58484ef412',closed_sha256='a9c7954c3c9d599d4c8fc7a00820f8bfe423eac98d2e5a48324153625e5db40d',assessment_sha256='931c5debdd98aca173c238109c04cac3e482ba80882328f0452785aca1cf50f9',native_receipt_sha256='b0086eb887f8b422940a99326b70fd24ffad6a8685ffd8795f90681985ea6a89',reference_sha256='7607afa5fd41e7df2b867aa4f2d6342e9adf03e2ee81b84085dedfed3e972535'),dict(level=1,steps=80,birth=40,dt=.005,pins=434,native_files=262,native_bytes=3040300,assessment_bytes=56923,output_plus_logs=57073,checks=46788,negative_traces=27,RSS_samples=25,RSS_max=34127872,actual_sha256='14e93acef115b632a30b26018dea1d646bdc0000783b2052acdcf79019b9c72a',closed_sha256='2bfbd218477d36543c0f63e544d89738b28e670d89381efc99d6d4428c5e21df',assessment_sha256='7f58e87f02c495f6547b52f07379b8bf77d34382f482d0ce5960d2e5c0dda647',native_receipt_sha256='f4d42b557ff4915764374994bf3af26782ca935d51d48571c85212086a98e2ec',reference_sha256='047471049c96bfb3c28fd74395998748eb5ca5c91feb24495449ce78f9f5ad47')]
    results=[]
    for spec,entry,item in zip(specs,master['levels'],index['actuals']):
        need(spec['level']==entry['level']==item['level'] and spec['closed_sha256']==entry['sha256'] and spec['assessment_sha256']==entry['assessment_sha256'] and spec['actual_sha256']==item['sha256'],'two exact case bindings')
        result=check_case(spec);results.append(dict(level=spec['level'],check_file=f"level{spec['level']}-saved-check.json",check_sha256=sha(HERE/f"level{spec['level']}-saved-check.json"),trace_count=spec['steps'],checks_count=spec['checks'],signed_negative_trace_count=result['signed_negative_trace_count'],summary_MAXABS=max(x['continuous_relative_abs'] for x in result['all_saved_trace_arithmetic']),max_saved_step_energy_abs_J=max(x['saved_step_energy_abs_J'] for x in result['all_saved_trace_arithmetic']),reported_maxima=result['reported_maxima'],thresholds=result['exact_card_thresholds'],lifecycle=result['root_lifecycle_attribution']))
    summary=dict(schema='962-two-coarse-0548-independent-stopped-saved-result-check/v1',status='PASS_SAVED_ASSESSMENT_BINDINGS_AND_TRACE_ARITHMETIC',master_sha256=EXPECTED[MASTER],levels=results,complete_saved_traces=120,native_files_unchanged=404,assessor_rerun=False,Gaussian_HEX_or_PDE_replayed=False,temporal_convergence_established=False,engineering_accepted=False,physics_qualified=False,material_qualified=False,process_calibrated=False,manufacturing_authorized=False)
    output=HERE/'independent-saved-check.json';need(not output.exists(),'fresh summary');output.write_text(json.dumps(summary,indent=2,allow_nan=False)+'\n')
    print(json.dumps(dict(status=summary['status'],levels=2,traces=120,checks=[23588,46788],signed_negative=[13,27],assessor_rerun=False)))

if __name__=='__main__':main()
