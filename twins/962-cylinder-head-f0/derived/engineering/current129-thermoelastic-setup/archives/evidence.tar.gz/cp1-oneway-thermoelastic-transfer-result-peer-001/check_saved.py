"""Independent stopped-file association check only; no producer or assessor imports."""
import hashlib
import json
import math
from pathlib import Path
import stat

ROOT = Path(__file__).resolve().parents[3]
E = ROOT / "work/962-engineering"
HERE = Path(__file__).resolve().parent
OUT = E / "cp1-oneway-thermoelastic-transfer-001"
RUN = E / "cp1-oneway-thermoelastic-transfer-root-execution-001"
PREP = E / "cp1-oneway-thermoelastic-transfer-prep-001"
EX = E / "cp1-oneway-thermoelastic-transfer-execution-prep-001"
PEER = E / "cp1-oneway-thermoelastic-transfer-child-peer-001"


def sha(p):
    h = hashlib.sha256()
    with p.open("rb") as f:
        for b in iter(lambda: f.read(1024 * 1024), b""):
            h.update(b)
    return h.hexdigest()


def read(p):
    return json.loads(p.read_text())


def rel(p):
    return str(p.relative_to(ROOT))


def identities(paths):
    result = {}
    for p in sorted(set(paths)):
        assert p.is_file() and not p.is_symlink() and p.resolve() == p
        result[rel(p)] = {"sha256": sha(p), "bytes": p.stat().st_size}
    return result


def main():
    actual = read(EX / "actual-contract.json")
    index = read(EX / "index-002.json")
    closed = read(RUN / "closed-result.json")
    launch = read(RUN / "launch.json")
    accept = read(RUN / "child-peer-acceptance.json")
    native = read(OUT / "native-execution.json")
    initial = read(OUT / "launch.json")
    held = read(PREP / "held-preparation.json")
    physics = read(PREP / "case-contract.json")
    pins = actual["input_sha256"]
    assert len(pins) == actual["input_count"] == index["input_count"] == 402
    assert all(not Path(n).is_absolute() and ".." not in Path(n).parts for n in pins)
    files = sorted(p for p in OUT.rglob("*") if p.is_file())
    assert not any(p.is_symlink() for p in OUT.rglob("*"))
    extras = [EX / "actual-contract.json", EX / "index-002.json", PEER / "review.json",
              PEER / "bindings.json", RUN / "closed-result.json", RUN / "launch.json",
              RUN / "child-peer-acceptance.json", RUN / "result-review.json",
              RUN / "adapter.stdout.log", RUN / "adapter.stderr.log"]
    before = identities([ROOT / p for p in pins] + files + extras)
    assert all(before[p]["sha256"] == h for p, h in pins.items())
    assert closed["input_matches"] == {p: True for p in pins}
    observed = {str(p.relative_to(OUT)): {"sha256": sha(p), "bytes": p.stat().st_size}
                for p in files}
    assert observed == closed["complete_recursive_output_inventory"]
    assert len(observed) == 22 and sum(r["bytes"] for r in observed.values()) == 2691348
    assert all(stat.S_IMODE(p.stat().st_mode) == 0o444 for p in files)
    all_hashes = {p: r["sha256"] for p, r in observed.items()}
    complete = {p: h for p, h in all_hashes.items() if p != "native-execution.json"}
    flat = {p: h for p, h in complete.items() if Path(p).name == p}
    materialized = {p: h for p, h in all_hashes.items()
                    if p not in ("native-execution.json", "native.log", "launch.json")}
    assert native["complete_artifact_sha256"] == complete and len(complete) == 21
    assert native["artifact_sha256"] == flat and len(flat) == 10
    assert initial["input_sha256"] == native["input_sha256"] == materialized
    assert len(materialized) == 19
    snapshots = {p: p.removeprefix("source-snapshots/") for p in all_hashes
                 if p.startswith("source-snapshots/")}
    assert len(snapshots) == 11
    assert all(before[v]["sha256"] == all_hashes[k] for k, v in snapshots.items())
    assert (OUT / "actual-contract.json").read_bytes() == (EX / "actual-contract.json").read_bytes()
    assert (OUT / "frozen-contract.json").read_bytes() == (PREP / "case-contract.json").read_bytes()
    assert physics["card"] == read(OUT / "card.json")
    assert physics["card_sha256"] == actual["card_sha256"] == all_hashes["card.json"]
    assert physics["source_input_sha256"]["thermoelastic-birth.i"] == actual["deck_sha256"] == all_hashes["thermoelastic-birth.i"]
    assert actual["source_physics_contract_sha256"] == all_hashes["frozen-contract.json"]
    manifest = read(OUT / "transfer-manifest.json")
    assert actual["transfer_manifest_sha256"] == native["transfer_manifest_sha256"] == all_hashes["transfer-manifest.json"]
    assert all(all_hashes[p] == h for p, h in manifest["table_sha256"].items())
    for p in ("card.json", "thermoelastic-birth.i"):
        assert all_hashes[p] == pins[rel(PREP / p)]
    for p in ("old-end.grid", "born-end.grid", "born-begin80.grid", "transfer-manifest.json"):
        assert all_hashes[p] == pins[rel(E / "cp1-oneway-thermoelastic-transfer-inputs-001" / p)]
    actual_sha = sha(EX / "actual-contract.json")
    assert actual_sha == "7ab4ee5b5fdbb85997c64e091644697105641cc887b434bb7af1cbfff2246395"
    assert sha(RUN / "closed-result.json") == "2465d95798953f3b71c7c682d43d1911df8c1499e6953cf1c83e4b3c4d84c111"
    assert sha(OUT / "native-execution.json") == "ad8f8811f35125125b7af0d5c402cdd13e389910d94fdcca1e3f41ff3c3180ad"
    assert index["actual"]["sha256"] == closed["actual_sha256"] == launch["actual_sha256"] == actual_sha
    assert closed["selected_index_sha256"] == accept["selected_index_sha256"] == sha(EX / "index-002.json")
    assert closed["exact_child_peer_sha256"] == launch["exact_child_peer_sha256"] == sha(PEER / "review.json")
    assert accept["peer_bindings_sha256"] == sha(PEER / "bindings.json")
    assert closed["root_launch_sha256"] == sha(RUN / "launch.json")
    assert index["planned_adapter_argv"] == launch["argv"]
    assert launch["argv"][3] == str(ROOT / actual["source"])
    assert launch["argv"][-3:] == ["--contract-sha256", actual_sha, "--execute"]
    assert native["actual_contract_sha256"] == native["contract_sha256"] == actual_sha
    assert native["physics_contract_sha256"] == all_hashes["frozen-contract.json"]
    assert initial["command"] == native["command"]
    assert native["command"][1:] == ["-skip_petscrc", "--n-threads=1", "-i", "thermoelastic-birth.i"]
    assert len(actual["runtime_sha256s"]) == 19 and len(actual["runtime_symlinks"]) == 13
    for key in ("runtime_sha256s", "runtime_symlinks"):
        assert actual[key] == held[key] == native[key] == initial[key]
    assert closed["runtime_regular_matches"] == {p: True for p in actual["runtime_sha256s"]}
    assert closed["runtime_link_matches"] == {p: True for p in actual["runtime_symlinks"]}
    assert native["binary_sha256"] == actual["runtime_sha256s"]["bin/combined-opt"]
    assert native["resources"] == actual["resources"] == launch["inner_resources"]
    assert actual["resources"] == {"wall_seconds": 100, "sampled_RSS_stop_bytes": 2147483648,
                                   "sampled_output_stop_bytes": 536870912}
    assert actual["environment"] == launch["native_environment"] and len(actual["environment"]) == 7
    assert actual["outer_wall_seconds"] == launch["outer_wall_seconds"] == 115
    samples = native["RSS_samples"]
    assert len(samples) == 32 and all(s["job"] == "native" and type(s["RSS_bytes"]) is int
                                    and s["RSS_bytes"] >= 0 and math.isfinite(s["wall_seconds"]) for s in samples)
    assert all(a["wall_seconds"] <= b["wall_seconds"] for a, b in zip(samples, samples[1:]))
    assert native["max_observed_RSS_bytes"] == max(s["RSS_bytes"] for s in samples) == 143572992
    assert native["final_output_bytes_before_receipt"] == sum(r["bytes"] for p, r in observed.items() if p != "native-execution.json")
    assert native["wall_seconds"] < 100 and closed["wall_seconds"] < 115
    assert closed["adapter_returncode"] == closed["native_returncode"] == native["returncode"] == 1
    assert native["jobs"] == [{"name": "native", "returncode": 1, "process_reaped": True}]
    assert native["controller_error"] == "ValueError: Native command incomplete; preserve outputs without retry"
    assert closed["root_stop_reason"] is None and closed["root_error"] is None and not closed["signals_sent"]
    assert not closed["root_fallback_SIGKILL"] and native["stop_reason"] is None
    assert not native["controller_SIGTERM_requested"]
    assert closed["adapter_pid"] == launch["adapter_pid"] == launch["adapter_pgid"]
    assert closed["adapter_wait_reaped"] and closed["observed_owned_adapter_leader_absent"]
    assert not closed["native_PID_directly_observed"] and not closed["universal_descendant_absence_claimed"]
    assert native["process_reaped"] and closed["native_cleanup_attributed_to_exact_adapter_finally_and_receipt"]
    assert sha(RUN / "adapter.stdout.log") == closed["adapter_stdout_sha256"]
    assert sha(RUN / "adapter.stderr.log") == closed["adapter_stderr_sha256"]
    for key in ("passed", "native_execution_completed", "independent_assessment_performed", "automatic_retry", "head_input_read"):
        assert native[key] is False
    assert native["inputs_unchanged"] and native["binary_and_runtime_unchanged"]
    for key in ("head_authorized", "head_execution_authorized", "engineering_accepted", "physics_qualified",
                "material_qualified", "process_calibrated", "manufacturing_authorized",
                "automatic_assessor_authorized", "assessment_execution_authorized", "automatic_retry"):
        assert actual[key] is False
    assert not any(p.suffix == ".csv" or p.suffix == ".e" or "_fields_" in p.name for p in files)
    log = (OUT / "native.log").read_text()
    error = "The initial condition 'temperature_moose' is being defined on a block that already has an initial condition defined with the same variable and state."
    assert error in log and "MPI_Abort" in log and "Time Step " not in log
    lines = (OUT / "thermoelastic-birth.i").read_text().splitlines()
    assert lines[73:75] == ["    block = '2 3'", "    initial_condition = 400"]
    assert lines[124:129] == ["  [born_temperature]", "    type = FunctionIC", "    variable = temperature",
                             "    function = born_begin80", "    block = 3"]
    assert identities([ROOT / p for p in pins] + files + extras) == before
    result = {
        "schema": "962-oneway-thermoelastic-independent-failed-capture-saved-check/v1",
        "status": "PASS_COMPLETE_FAILED_CAPTURE_ASSOCIATIONS_ONLY",
        "checked_inputs": before,
        "external_actual_pin_count": 402,
        "output_inventory": observed,
        "output_count": 22, "output_bytes": 2691348,
        "receipt_map_counts": {"recursive_artifacts_excluding_receipt": 21, "flat_artifacts_excluding_receipt": 10,
                               "materialized_input_artifacts": 19, "nested_source_snapshot_files": 11},
        "snapshot_to_original": snapshots,
        "runtime_metadata": {"regular_files": 19, "raw_links": 13, "maps_match_actual_held_launch_receipt": True,
                             "root_all_before_after_matches_true": True, "bodies_independently_read": False,
                             "python_sha256_root_attributed": actual["controller_interpreter"]["sha256"]},
        "sampled_native_owned_leader_RSS": {"samples": 32, "max_bytes": 143572992, "true_peak_claimed": False},
        "lifecycle": {"adapter_RC": 1, "native_RC": 1, "root_wall_seconds": closed["wall_seconds"],
                      "native_adapter_wall_seconds": native["wall_seconds"], "root_stop": None, "inner_stop": None,
                      "adapter_wait_reap_and_owned_leader_absence_root_observed": True,
                      "native_wait_reap_source_and_receipt_attributed": True,
                      "native_PID_directly_observed": False, "universal_descendant_absence_claimed": False},
        "diagnosis": {"native_error": error, "deck_global_temperature_IC_lines": [71, 74, 75],
                      "deck_born_temperature_IC_lines": [125, 126, 127, 128, 129],
                      "overlapping_block": 3, "scope": "Setup duplicate-IC rejection before timestep/field capture; no convergence or constitutive inference."},
        "native_completed": False, "original_passed": False, "assessment_performed": False,
        "retry_performed": False, "CSV_or_Exodus_fields_present": False,
        "before_after_all_checked_files_unchanged": True,
        "no_producer_helper_assessor_native_or_scientific_import_or_replay": True
    }
    dest = HERE / "independent-saved-check.json"
    with dest.open("x") as f:
        json.dump(result, f, indent=2, allow_nan=False); f.write("\n")
    print(json.dumps({"status": result["status"], "sha256": sha(dest), "bytes": dest.stat().st_size,
                      "files": 22, "external_pins": 402}))


if __name__ == "__main__":
    main()
