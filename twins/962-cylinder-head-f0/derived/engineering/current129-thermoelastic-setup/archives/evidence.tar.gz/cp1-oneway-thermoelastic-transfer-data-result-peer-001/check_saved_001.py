"""Independent fixed saved-table association check; no producer imports or native calls."""
from pathlib import Path
import csv,hashlib,itertools,json,math,struct
ROOT=Path(__file__).resolve().parents[3];BASE=ROOT/'work/962-engineering';HERE=Path(__file__).resolve().parent
ACTUAL=BASE/'cp1-oneway-thermoelastic-transfer-data-execution-prep-001/actual-contract.json'
CLOSED=BASE/'cp1-oneway-thermoelastic-transfer-data-root-execution-001/closed-result.json'
SOURCE=BASE/'cp1-assumed-thermal-birth-linear-001';OUTPUT=BASE/'cp1-oneway-thermoelastic-transfer-inputs-001'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
load=lambda p:json.loads(p.read_text())
assert sha(ACTUAL)=='ca5d42d050bfa53a599bde36dfbc09c9b10dc9eb22371c8c2b873aa7c1963037'
assert sha(CLOSED)=='25cadf2911ae8e66b1636f1661815590ba98d400bffd9ca81db46182b715c1af'
a=load(ACTUAL);closed=load(CLOSED);launch=load(CLOSED.with_name('launch.json'));manifest=load(OUTPUT/'transfer-manifest.json')
assert closed['actual_sha256']==sha(ACTUAL) and sha(CLOSED.with_name('launch.json'))==closed['launch_sha256']
assert launch['actual_sha256']==sha(ACTUAL) and launch['query_pid']==launch['query_pgid']==closed['query_pid']==closed['query_pgid']
assert launch['argv'][1:3]==['-I','-B'] and launch['argv'][-1]==sha(ACTUAL)
assert closed['returncode']==0 and closed['stop_reason'] is None and closed['fallback_SIGKILL'] is False
assert closed['query_waited_reaped'] and closed['observed_query_leader_absent'] and not closed['universal_descendant_absence_claimed']
assert closed['all370_input_actual_python_unchanged'] is True
assert sha(CLOSED.with_name('stdout.log'))==closed['stdout_sha256'] and sha(CLOSED.with_name('stderr.log'))==closed['stderr_sha256']
assert set(p.name for p in OUTPUT.iterdir())==set(closed['output_files'])=={'old-end.grid','born-end.grid','born-begin80.grid','transfer-manifest.json'}
pins=dict(a['input_sha256']);assert len(pins)==370
peerpath=BASE/'cp1-oneway-thermoelastic-transfer-data-child-peer-001/review.json';peerbindings=peerpath.with_name('bindings.json');accept=load(CLOSED.with_name('child-peer-acceptance.json'))
assert closed['exact_child_peer_sha256']==launch['exact_child_peer_sha256']==sha(peerpath)==accept['peer_sha256']
assert accept['actual_sha256']==sha(ACTUAL) and accept['peer_bindings_sha256']==sha(peerbindings)
pins[str(peerpath.relative_to(ROOT))]=sha(peerpath);pins[str(peerbindings.relative_to(ROOT))]=sha(peerbindings)
assert launch['controls']==a['ordinary_controls'] and a['data_preparation_authorized'] is True
for k in ['native_execution_authorized','head_execution_authorized','engineering_accepted','physics_qualified','material_qualified','process_calibrated','manufacturing_authorized','automatic_retry']:assert a[k] is False
assert manifest['schema']=='962-oneway-thermoelastic-prepared-transfer/v1'
pins[str(ACTUAL.relative_to(ROOT))]=sha(ACTUAL)
for p in CLOSED.parent.iterdir():
 assert p.is_file() and not p.is_symlink();pins[str(p.relative_to(ROOT))]=sha(p)
for name,row in closed['output_files'].items():
 p=OUTPUT/name;assert p.is_file() and not p.is_symlink() and p.stat().st_size==row['bytes'] and sha(p)==row['sha256'];pins[str(p.relative_to(ROOT))]=row['sha256']
for name,d in pins.items():assert sha(ROOT/name)==d,name
receipt=load(SOURCE/'native-execution.json');index=load(BASE/'cp1-oneway-thermoelastic-transfer-prep-001/thermal-input-index.json')
expected=[(0,'end','thermal_end_0000.csv')]+[(n,p,f'thermal_{p}_{n:04d}.csv') for n in range(1,161) for p in ['begin','end']]
assert [(r['step'],r['phase'],r['filename']) for r in index['selected']]==expected
assert manifest['selected321']==index['selected'] and manifest['source_receipt_sha256']==sha(SOURCE/'native-execution.json') and manifest['data_actual_sha256']==sha(ACTUAL)
fields={};body_rows=0
for item in index['selected']:
 filename=item['filename'];path=SOURCE/filename;assert sha(path)==item['sha256']==receipt['artifact_sha256'][filename]
 with path.open(newline='') as f:
  reader=csv.DictReader(f);assert reader.fieldnames==['id','temperature','x','y','z'];rows={};previous=-1
  for r in reader:
   assert set(r)==set(reader.fieldnames) and str(int(r['id']))==r['id'];tag=int(r['id']);assert tag>previous;previous=tag
   xyz=tuple(float(r[k]) for k in ['x','y','z']);t=float(r['temperature']);assert all(math.isfinite(v) for v in [*xyz,t])
   rows[tag]=(xyz,r['temperature'],t);body_rows+=1
 fields[item['step'],item['phase']]=rows
alias=index['additional_initial_BEGIN_alias'];assert sha(SOURCE/alias['filename'])==receipt['artifact_sha256'][alias['filename']]==index['selected'][0]['sha256']
coords={t:r[0] for t,r in fields[160,'end'].items()};xs=tuple(i/8 for i in range(17));ys=zs=tuple(i/4 for i in range(5))
assert len(coords)==425 and set(coords.values())==set(itertools.product(xs,ys,zs));inverse={v:k for k,v in coords.items()}
old={t for t,p in coords.items() if p[0]<=1};born={t for t,p in coords.items() if p[0]>=1};shared=old&born;new=born-old
assert tuple(map(len,[old,born,shared,new]))==(225,225,25,200)
assert coords[0]==(0.,0.,0.) and coords[32]==(1.,0.,0.) and coords[137]==(0.,1.,0.)
previous=fields[0,'end'];assert set(previous)==old and all(r[2]==400 for r in previous.values());maximum=0.
for step in range(161):
 for phase in (['end'] if step==0 else ['begin','end']):
  rows=fields[step,phase];assert set(rows)==(old if step<80 else set(coords))
  assert all(struct.pack('<3d',*r[0])==struct.pack('<3d',*coords[t]) for t,r in rows.items())
 if step:
  begin=fields[step,'begin'];error=max(abs(begin[t][2]-r[2]) for t,r in previous.items());assert error<=1e-10;maximum=max(maximum,error)
  if step==80:assert all(begin[t][2]==350 for t in new)
  previous=fields[step,'end']
expected_map=[{'source_node_id':t,'coordinates_m':list(p),'binary64_hex':[v.hex() for v in p],'old2':t in old,'born3':t in born,'shared':t in shared} for t,p in sorted(coords.items())]
assert manifest['node_rows']==expected_map and manifest['maximum_previous_END_to_BEGIN_error_K']==maximum
for k,value in [('old_node_count',225),('born_reference_DOF_count',225),('shared_node_count',25),('genuinely_new_node_count',200)]:assert manifest[k]==value
counts={};table_identities={}
for filename,steps,xaxis,phase in [('old-end.grid',range(161),xs[:9],'end'),('born-end.grid',range(80,161),xs[8:],'end'),('born-begin80.grid',[80],xs[8:],'begin')]:
 raw=(OUTPUT/filename).read_text();lines=raw.splitlines();axis_names=['X','Y','Z']+([] if filename=='born-begin80.grid' else ['T']);axes=[xaxis,ys,zs]+([] if filename=='born-begin80.grid' else [tuple(i/400 for i in steps)])
 for j,(name,expected_axis) in enumerate(zip(axis_names,axes)):
  assert lines[2*j]=='AXIS '+name;observed=[float(v) for v in lines[2*j+1].split()];assert observed==list(expected_axis) and all(x<y for x,y in zip(observed,observed[1:]))
 assert lines[2*len(axes)]=='DATA';tokens=[v for row in lines[2*len(axes)+1:] for v in row.split()]
 wanted=[fields[s,phase][inverse[x,y,z]][1] for s in steps for z in zs for y in ys for x in xaxis]
 assert tokens==wanted and len(tokens)==math.prod(map(len,axes)) and all(math.isfinite(float(v)) for v in tokens)
 assert sha(OUTPUT/filename)==manifest['table_sha256'][filename];counts[filename]=len(tokens);table_identities[filename]={'sha256':sha(OUTPUT/filename),'values':len(tokens),'axes':axis_names,'all_original_temperature_tokens_exact':True}
assert counts==manifest['table_value_counts']=={'old-end.grid':36225,'born-end.grid':18225,'born-begin80.grid':225}
assert sum(counts.values())==54675
assert manifest['native_connectivity_or_ID_bijection_proven'] is False and manifest['same_native_geometry_association_still_required'] is True
for k in ['source_off_cooling_history_present','native_execution_authorized','engineering_accepted','physics_qualified','material_qualified','process_calibrated','manufacturing_authorized']:assert manifest[k] is False
for name,d in pins.items():assert sha(ROOT/name)==d,name
result={'schema':'962-oneway-data-independent-complete-saved-check/v1','passed':True,'source_fields':321,'original_CSV_identities_including_initial_alias':322,'parsed_selected_CSV_rows':body_rows,'coordinates':425,'old':225,'born_reference':225,'shared':25,'new':200,'maximum_previous_END_to_BEGIN_error_K':maximum,'complete_table_tokens':54675,'tables':table_identities,'all_before_after_saved_pins':pins,'all_inputs_outputs_unchanged':True,'own_source_sha256':sha(Path(__file__)),'native_ID_connectivity_or_solver_labels_proven':False,'producer_or_native_import_or_call':False,'lifecycle_scope':'Exact saved root launch/controller identifiers, wait/reap/observed-leader absence; no current process observer or universal descendant claim.'}
(HERE/'independent-saved-check.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ['all_before_after_saved_pins']}))
