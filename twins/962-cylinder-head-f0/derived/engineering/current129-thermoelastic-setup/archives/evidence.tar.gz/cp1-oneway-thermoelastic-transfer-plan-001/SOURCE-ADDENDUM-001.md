# Standard SI transfer and birth-ordering addendum

Source evidence only; original NOTE SHA28d1589f2bee9693be0954d3200cdc722f5a3fd597435a7db427103a8644f5b6
is preserved. No deck, data conversion, runner, evaluator, guard, test, native
call or actual was authored/executed. This proposes a supported standard-object
composition; it is not selected or runtime-validated.

**Prefer SI.** Keep the existing metre coordinates/topology and temperatures/time.
Use E=71e9 Pa, nu=.33, displacement m, stress Pa and reaction N. The elasticity
source accepts Real E/nu and forms C without a Pa↔MPa conversion; stress-divergence
uses stress times shape gradient. Thus consistent SI follows dimensionally; no
1000-coordinate transform is needed [elastic,residual]. This does not expand the
25°C assumed card into a qualified temperature law. Any equivalent donor checks
must explicitly relabel/convert units:1e-9mm→1e-12m,1e-7MPa→.1Pa, force remains N;
no tolerance relaxation or old mm/MPa assessor reuse is implied.

**Supported import, not direct CSV ingestion.** `PiecewiseMultilinear` reads1–4D
rectangular gridded data. `PiecewiseMultiInterpolation` requires independent,
strictly increasing axes and specifies X/Y/Z/T and first-axis-fastest DATA order;
`GriddedData` checks product cardinality. These are structured text tables, not
arbitrary NodalValueSampler CSVs [table,format]. FunctionIC evaluates its Function
at current time/point; nodal FunctionAux does likewise [IC,Aux]. A future small
data-only conversion therefore can use existing standard objects, without a
custom compiled importer. No table is created here.

One4D function cannot encode different begin/end values at an identical t:
duplicate T-axis entries are rejected. Standard interpolation also clamps outside
its range [interpolation,table]. No nearest-time shortcut, epsilon-shifted time,
prebirth padding or undocumented phase axis is acceptable. Proposed smallest
composition is three tables: old-region END(x,y,z,t), born-region END(x,y,z,t),
and born-region BEGIN80(x,y,z) as a fixed3D birth-reference table. Old end history
covers t0..0.4; new end covers t.2..0.4. For nonbirth steps the accepted begin
fields equal the previous end; keep those saved associations and all321 original
CSV hashes. Separate old/new tables avoid inventing absent prebirth temperatures.
The same captured shared-node END values must join across both tables. A future
manifest must reject out-of-domain evaluation rather than rely on clamping.

**Source-supported phase/reference composition.** Retain the exact geometry,
cell/node association and activation time. Give old and born material separate
mechanical block identities (for example old2, inactive1→born3), with an explicit
thermal-block↔mechanical-block map; this changes no geometry or source artifact.
Both active blocks share the same displacement and temperature field.

1. Keep old reference400 K. Give the born block its own coupled nodal reference
   field initialized by BEGIN80; old material does not couple this reference
   variable. This avoids a subtle interface conflict: a single shared continuous
   reference cannot simultaneously equal old400 K and the actual evolved shared
   birth temperature on both sides. The thermal eigenstrain API accepts a coupled
   stress_free_temperature field and computes alpha*(T−Tref) [thermal-ref,thermal-law].
2. Explicitly force the birth modifier into PRE_AUX (`force_preaux=true`), with
   TIMESTEP_BEGIN. UserObjectBase supports that flag; FEProblemBase executes
   PRE_AUX, then Aux calculations, then POST_AUX [preaux,ordering]. A negative
   execution_order_group alone does not establish ordering across these categories.
3. During the modifier, use standard IC reinitialization for new displacements,
   temperature and the born reference. Temperature IC uses BEGIN80; reference IC
   uses the same table. Preserve old/shared displacement and temperature DOFs;
   do not restore a nonexistent old-block birth-reference field. The modifier
   applies IC/restoration, sets old/older solution states, then initializes
   stateful properties only on reinitialized elements [birth].
4. After the modifier, FunctionAux supplies END(t) to each active block before
   equilibrium. The shared endpoint data must agree. Begin and END at step80
   remain distinct source phases; do not use END80 to initialize the birth state.
   Use BEGIN80 explicitly for any birth-reference capture; a later sampler after
   Aux sees the transferred END field and must be labelled accordingly.

**Important material correction.** Eigenstrain initialization zeros its history;
it does not sample and remember an arbitrary birth-temperature field [eigen-init].
Incremental strain starts with zero mechanical/total strain and subtracts current
minus old eigenstrain [increment]. Therefore the explicit new reference above is
necessary; initializing only temperature does not prove zero newborn stress.
Stress base initialization is zero [stress-init]. Use an incremental-compatible
elastic stress object: `ADComputeLinearElasticStress` explicitly rejects a
strain_increment property [incompatible-linear]. Its source directs this case to
`ADComputeFiniteStrainElasticStress`, which consumes incremental/old elastic strain
[compatible-incremental]. With SMALL incremental strain, the rotation increment
is identity [small-strain]; that object's name is not a selection of finite
geometry. This source-level reasoning still needs independent case review and
native field checks before any pass claim.

**Remaining bounded checks.** A future source freeze must verify exact native
node/cell/block bijection, original table/CSV hashes, axis order/time coverage,
old/shared history, new-reference initialization and explicit Aux/category order.
At stored coordinates/times, compare every transferred value with source using
the existing1e-10 K threshold and phase/ID negative controls. Weighted interpolation
can perform floating arithmetic even at a knot: source bytes stay exact, but
native bit-identical output is not established. Verify newborn pre-equilibrium
stress/strain and old-state preservation, then all-DOF weak-form residual,
Hooke/tensor relations and force/moment balance in SI with predeclared limits.
No separate coupling framework or repeated witness is needed. Source-off cooling
remains absent, as in the original NOTE. Runtime object availability, complete
ABI and source-to-installed-build equivalence remain separate root preconditions.

## Evidence identity and primary locators

The local revision association is frozen in
`work/962-engineering/cp1-assumed-thermal-birth-root-primary-context-002/sources.json`
(SHA f59807f9155c22ff0171ad652c3c0c8d3880f53ef2c5299d6981a3dd1bd87141):
it resolves printed7c06bdcefd to the full public revision below, without claiming
source/build equivalence. Historical167ee mechanical source bodies remain exact
local prior evidence; they are not substituted for current-revision API evidence.
Official primary source was read live2026-10-18 at the pinned full revision.
No upstream source bodies were copied into this addendum or local runtime.

Pinned public revision: `7c06bdcefd02f9f31f4508839f21f410561309a4`.

- [elastic](https://raw.githubusercontent.com/idaholab/moose/7c06bdcefd02f9f31f4508839f21f410561309a4/modules/solid_mechanics/src/materials/ComputeIsotropicElasticityTensor.C) — L15–25,74–81.
- [residual](https://raw.githubusercontent.com/idaholab/moose/7c06bdcefd02f9f31f4508839f21f410561309a4/modules/solid_mechanics/src/kernels/ADStressDivergenceTensors.C) — L70–87.
- [table](https://raw.githubusercontent.com/idaholab/moose/7c06bdcefd02f9f31f4508839f21f410561309a4/framework/src/functions/PiecewiseMultiInterpolation.C) — L15–52,58–80,94–122.
- [interpolation](https://raw.githubusercontent.com/idaholab/moose/7c06bdcefd02f9f31f4508839f21f410561309a4/framework/src/functions/PiecewiseMultilinear.C) — L13–23,43–101.
- [format](https://raw.githubusercontent.com/idaholab/moose/7c06bdcefd02f9f31f4508839f21f410561309a4/framework/src/utils/GriddedData.C) — L103–193.
- [IC](https://raw.githubusercontent.com/idaholab/moose/7c06bdcefd02f9f31f4508839f21f410561309a4/framework/src/ics/FunctionIC.C) — L14–34.
- [Aux](https://raw.githubusercontent.com/idaholab/moose/7c06bdcefd02f9f31f4508839f21f410561309a4/framework/src/auxkernels/FunctionAux.C) — L14–33.
- [ordering](https://raw.githubusercontent.com/idaholab/moose/7c06bdcefd02f9f31f4508839f21f410561309a4/framework/src/problems/FEProblemBase.C) — L4807–4834.
- [preaux](https://raw.githubusercontent.com/idaholab/moose/7c06bdcefd02f9f31f4508839f21f410561309a4/framework/src/userobjects/UserObjectBase.C) — L32–49.
- [birth](https://raw.githubusercontent.com/idaholab/moose/7c06bdcefd02f9f31f4508839f21f410561309a4/framework/src/meshmodifiers/ElementSubdomainModifierBase.C) — L299–354,700–731,810–813.
- [eigen-init](https://raw.githubusercontent.com/idaholab/moose/7c06bdcefd02f9f31f4508839f21f410561309a4/modules/solid_mechanics/src/materials/ComputeEigenstrainBase.C) — L35–55.
- [thermal-ref](https://raw.githubusercontent.com/idaholab/moose/7c06bdcefd02f9f31f4508839f21f410561309a4/modules/solid_mechanics/src/materials/ComputeThermalExpansionEigenstrainBase.C) — L15–40.
- [thermal-law](https://raw.githubusercontent.com/idaholab/moose/7c06bdcefd02f9f31f4508839f21f410561309a4/modules/solid_mechanics/src/materials/ComputeThermalExpansionEigenstrain.C) — L14–35.
- [increment](https://raw.githubusercontent.com/idaholab/moose/7c06bdcefd02f9f31f4508839f21f410561309a4/modules/solid_mechanics/src/materials/ADComputeIncrementalStrainBase.C) — L23–37,54–68.
- [small-strain](https://raw.githubusercontent.com/idaholab/moose/7c06bdcefd02f9f31f4508839f21f410561309a4/modules/solid_mechanics/src/materials/ADComputeIncrementalStrain.C) — L63–90.
- [stress-init](https://raw.githubusercontent.com/idaholab/moose/7c06bdcefd02f9f31f4508839f21f410561309a4/modules/solid_mechanics/src/materials/ADComputeStressBase.C) — L44–50.
- [incompatible-linear](https://raw.githubusercontent.com/idaholab/moose/7c06bdcefd02f9f31f4508839f21f410561309a4/modules/solid_mechanics/src/materials/ADComputeLinearElasticStress.C) — L32–39.
- [compatible-incremental](https://raw.githubusercontent.com/idaholab/moose/7c06bdcefd02f9f31f4508839f21f410561309a4/modules/solid_mechanics/src/materials/ADComputeFiniteStrainElasticStress.C) — L25–40,51–83.

All execution/head/engineering/physics/material/process/LPBF/manufacturing authority remains false.
