# One-way thermal-history → thermoelastic-birth research proposal

Status: source-only proposal, not a deck, execution contract or authority. No
native run, evaluator/guard/test, field conversion, new mesh, runner or external
request was made. Existing thermal, mechanical and failed evidence stays intact.

## Smallest new study

Reuse the **same accepted synthetic 2×1×1 m, 16×4×4 HEX8 coupon** and the accepted
finest thermal history. Add a separate quasi-static, small-strain, one-way elastic
response to its spatially nonuniform temperatures and material birth. This is a
new field-transfer/coupling question, not another reproduction of the four-HEX
serial-bar witness or a thermal solve. Keep temperature independent of mechanical
strain/displacement: no thermo-mechanical feedback, melting, plasticity, annealing,
support release, head, powder layers or LPBF-scale/calibrated-process claim.

The available history is **0≤t≤0.4 s, dt=0.0025 s**, with birth at t=0.2 s.
The deck's moving source remains on until the calculation ends. There is **no
later source-off cooling history**. The colder born region and local redistribution
do not constitute a declared build cooldown. A later cooling study needs its own
source-off time, thermal boundary conditions, duration and separately accepted
thermal fields; those inputs and a cooling transfer verdict remain null here.
Do not append an invented constant temperature or reuse the donor bar's260 K step.

## Exact transfer association

1. Keep the thermal topology, geometry and block split unchanged: old x≤1 m,
   initially128 active cells/225 nodes; full256 cells/425 nodes. Birth adds128 cells
   and200 genuinely new nodes;25 interface nodes are shared. These counts follow
   the fixed regular grid and must also be verified from actual captured IDs and
   coordinates before any mechanics run. No node/cell numbering equivalence or
   native connectivity capture is assumed from CSV coordinates alone.
2. The native receipt below binds321 selected temperature CSVs:
   `thermal_end_0000.csv` plus `thermal_begin_NNNN.csv` and
   `thermal_end_NNNN.csv` for steps1..160. Preserve every source file/digest and
   original row/ID/coordinate/temperature value. Retain the complete native
   artifact map; do not replace these histories by assessment trace extrema or
   the Gaussian formula. The old assessor's coordinate-rounding convenience is
   not sufficient proof of a new ID/field mapping.
3. Key the future transfer by **(step, phase, source node ID, coordinates)**, not
   just a float time. Initial end0000 is400 K on the old region. Begin step80
   contains the birth field: shared/old temperatures retain previous values;
   genuinely new nodes are350 K. End step80 contains the thermal solution after
   that step. Do not conflate these two arrays at the same ending-time label.
   No temporal or spatial interpolation is needed at the stored native grid and
   solve times. Any standard importer's interpolation must reproduce these exact
   endpoint/phase values and fail on missing, duplicated or out-of-order rows.
4. Recommended mechanical units are mm, MPa, N, K, seconds, matching the verified
   mechanics donors: x_mech=1000*x_thermal, u in mm, stress in MPa, reactions in N;
   temperature/time are unchanged. This is a unit transform of the same coupon,
   not a new geometry. Check the full node/HEX8 connectivity/block bijection and
   exact rational1000 coordinate transform before field use. Heat densities,
   rho/cp/k and metre-based source parameters remain thermal inputs; they are not
   copied into a mechanical deck in incompatible units.

## Proposed assumptions, clearly separate from measured CP1

- For the future conditional study, propose E=71000 MPa andnu=0.33 as constant
  isotropic elastic hypotheses from the separate assumed card. Extending that
  card's single25°C scope to the recorded approximately350–400 K history is an
  **additional unqualified constant-property hypothesis**, not matched E(T)/nu(T)
  evidence or silent authorization by the old card. Keep measured properties,
  temperature/direction/state correspondence and strength allowables null.
- Propose alpha=1e-5/K **only as the explicit hypothetical mechanical-bar donor
  scalar**, not a measured/related CP1 expansion value. No yield law is used in
  this first elastic transfer. Plasticity/yield(T), hardening, phase changes,
  annealing and calibrated residual-stress interpretation remain null/unclaimed.
- Initially old material is displacement/stress-free at its400 K field. At birth,
  retain all old/shared displacement/material history. Propose zero displacement
  IC only on genuinely new nodes, restoring shared DOFs, and initialize **only
  new material** stress/incremental strain relative to that inherited displacement
  field and its actual begin-temperature field. The new material's interpolated
  birth temperature is not uniformly350 K at shared nodes. Do not reset old
  material or treat one global stress_free_temperature scalar as proof that this
  reference rule has been implemented.
- Proposed minimum research supports are six rigid-mode constraints on always
  active old-region nodes: all three components at(0,0,0)m, transverse y/z at
  (1,0,0)m and z at(0,1,0)m. All other exterior surfaces are traction-free;
  no pressure, gravity, contact or support release. This3-2-1 anchoring is an
  explicit numerical hypothesis, not a plate, physical clamp or OEM load path.
  The future case must freeze exact IDs/components and verify the constraint set
  admits stress-free homogeneous thermal expansion. No production BC/null field
  is filled by this proposal.

These are proposed new-case hypotheses; no existing material/card/contract is
edited. They require root/peer source review and a separately frozen actual.

## Reuse boundaries and the real wiring gate

Reuse unchanged thermal cards/deck, references,321 recorded temperatures and
accepted assessments as input evidence; do not rerun or reassociate them. Reuse
Mac adapter lifecycle/TCP environment/input/runtime/resource/cleanup logic when a
future case adapter is reviewed; do not create another runner/framework. The
thermal20-object registry is not a mechanical-birth semantic/ABI proof. Existing
runtime identities remain root observations requiring future fresh pins.

The mechanical donor supplies incremental SMALL-strain, `TimedSubdomainModifier`
with `restore_overridden_dofs`, begin/end history sampling, full2×2×2 quadrature
six-component tensor exports and reaction capture. Its1×1×20 mm four-cell mesh,
seven-step temperature/preload/support schedule, perfect-J2 material and serial-bar
analytic assessor **cannot** be reused as this coupon's input or numerical oracle.
The historical167ee native/API lineage also is not interchangeable with the
current Mac7c06 runtime merely because object names match.

Before code, resolve the smallest existing **standard file-backed temperature
Function/Aux mechanism** against pinned local source, and its ordering relative
to activation/stateful material initialization. No importer/API is asserted here:
the accepted deck exports CSV, not a saved Exodus solution that may be assumed
loadable by SolutionUserObject. Preserve phase-keyed begin/end tables. Prove that
new eigenstrain/material reference initialization sees the begin birth field,
then equilibrium consumes the end field, while old history is retained. If the
existing mechanisms cannot express that sequence safely, stop for a focused
source design; do not substitute a custom generalized coupling framework or
silently initialize new stress from the wrong thermal phase.

## Independent gates before a future execution

Freeze one new assumption/reference card and full transfer manifest (321 source
CSV hashes from the retained receipt, source-to-mechanics ID/coordinate/cell/block
maps, per-step phase labels, units, birth/support/reference policy and native
source/runtime pins). Reject changed/omitted/reordered fields, wrong units/time,
wrong birth phase and reset old/shared values. Preserve originals and no retries.

Prepare source-stage known-zero-temperature-change and uniform-temperature free
expansion references, plus a phase/ID-swapped or omitted-transfer negative control;
these are targeted mapping/reference checks, not repeated native bar witnesses.
Before acceptance, require complete active-node begin/end history, all six strain,
eigenstrain and stress components at every active HEX8 Gauss point, new material
zero-stress reference before equilibrium, and no old-state reset. Independently
check Hooke's law, full weak-form equilibrium residual at every free DOF, reactions
and total force/moment balance using the explicit unit map. The existing bar's
closed-form solution is not a reference for a nonuniform3D field. Freeze suitable
numerical thresholds and checks before the run; do not tune them to returned
results. Retain thermal energy checks unchanged as upstream evidence, not as a
substitute for mechanical equilibrium or work/reference consistency.

The passed thermal refinement establishes its stated energy-error time criterion,
not mechanical time/spatial convergence. Assess mechanical discretization/time
sensitivity before accepting conditional predictions. Cooling/release and full
build sequencing remain separate future scopes. No engineering/physics/material/
process/LPBF/manufacturing qualification follows from this proposal.

## Bound source and accepted evidence

Private paths below are relative to the frozen engineering worktree; `twins/...`
paths were read from the current publisher checkout. SHA256 values bind exact
bodies, not an installation or execution grant.

| Role | File | SHA256 |
|---|---|---|
| Current assumed thermal card | `work/962-engineering/cp1-assumed-thermal-birth-linear-prep-001/card.json` | `4e07cbb997c831bac2c0abd43092148c5518b6c7aa04d7b3d287779f9e700986` |
| Current LINEAR thermal deck | `work/962-engineering/cp1-assumed-thermal-birth-linear-prep-001/thermal-birth.i` | `ffe9b19786d534a8b4ad60e78290c7d3698a2dcb6b7ddf183f100321b02df1aa` |
| Accepted level2 reference | `work/962-engineering/cp1-assumed-thermal-birth-linear-prep-001/case-contract.json` | `13a12dc586cf773a0a4b0a2777276d062d60d2e7c67aa7357e6581fd83f4fddd` |
| Unchanged thermal assessor | `work/962-engineering/cp1-assumed-thermal-birth-linear-prep-001/assess.py` | `0548fcbf6eba737aaaf816abbfbfd0511b5b8fb266aa10c34a1f5817eef0e338` |
| Current Mac coupon adapter | `work/962-engineering/cp1-assumed-thermal-birth-linear-macos-prep-001/run_mac.py` | `fde48211a11066c8406076621b5cd1c2898e0353956a4e6ec879754e7452c9d3` |
| Accepted thermal receipt/inventory | `work/962-engineering/cp1-assumed-thermal-birth-linear-001/native-execution.json` | `a210f0ef6d41686ce795b76d7d43fc17aa320038cfabd601d0250ae8feb2b673` |
| Accepted level2 assessment | `work/962-engineering/cp1-assumed-thermal-birth-linear-assessment-001/assessment.json` | `198ae20f6baa27a726b17f3924659b8c1e0613e9a5b1e161ad8f6ef3b5107dbf` |
| Completed three-level refinement | `work/962-engineering/cp1-assumed-thermal-birth-linear-refinement-001/refinement-assessment.json` | `8283998df2f742ff80414c6da70b2d33142e04a3728b3bada6a61abc2c8dfa8e` |
| Stopped refinement peer | `work/962-engineering/cp1-assumed-thermal-birth-linear-refinement-result-peer-001/review.json` | `e54bf1bef02d51b0abad061011c95a102b3944c8af2730a32971fdb8ef051d10` |
| Separate assumed isothermal card | `twins/962-cylinder-head-f0/engineering/cp1-isothermal-assumed-card.json` | `5bfd9b40fffd047931ab7409a02b6edb5b92af917d5e2d8e4ba47948f7a86ca7` |
| Mechanical birth deck donor | `twins/962-cylinder-head-f0/source/physics_witness/mechanical_birth/mechanical-birth.i` | `df2a23db9281f8c12b3afc6b002aeaf352040592a440f2bae31f1cfb6e89f99f` |
| Mechanical birth card donor | `twins/962-cylinder-head-f0/source/physics_witness/mechanical_birth/card.json` | `214c08f4667fd93dc608faf7cf7755468086002307f5b5b829f3801eee17f94e` |
| Mechanical birth assessor donor | `twins/962-cylinder-head-f0/source/physics_witness/mechanical_birth/assess.py` | `d8c37e544bdd6d231bfd3a12cce54da61d7ca3de68b01d840502f2560b0063c3` |
| Mechanical primary-semantics bindings | `twins/962-cylinder-head-f0/source/physics_witness/mechanical_birth/primary-semantics.json` | `72e82c4c17399b630922c596b39a303b8b0516c78754a254643f744dc15d87fe` |
