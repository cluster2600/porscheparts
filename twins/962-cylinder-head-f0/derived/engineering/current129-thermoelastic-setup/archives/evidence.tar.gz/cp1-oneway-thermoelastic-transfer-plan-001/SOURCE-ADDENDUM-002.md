# Plan clarification002: born-reference scope and history

PLAN ONLY. This clarifies the preserved NOTE and SOURCE-ADDENDUM001 in response
to source peer eec7015c; it creates no deck, data tables, code, guard, test,
registry query, actual, native execution or authority.

The preferred proposal remains SI(m,Pa,N,K,s), E=71e9Pa/nu=.33 as an explicitly
unqualified constant-property extension, and three separate standard tables:
old END4D, born END4D, born BEGIN80 3D. No source-off cooling exists in the saved
0–0.4s history. Existing assumptions, source/binary-equivalence limits and
independent transfer/equilibrium gates remain as previously stated.

## Concrete proposed restrictions and aligned flags

Keep the same256HEX8 geometry/IDs under an explicit thermal→mechanics block map:
old2 remains old2; inactive1 becomes born3 at0.2s. Predeclare the initially empty
born3 using `Mesh/add_subdomain_ids`; any chosen block name must map explicitly
to3. This is mesh metadata, not added geometry. A future source freeze must use
the pinned standard subdomain declaration before constructing block-restricted
variables/objects.

Declare **both** the nodal FIRST LAGRANGE variable `born_reference_temperature`
**and its BEGIN80 FunctionIC on block3 only**. Old material uses its separate
constant400K reference and never couples this variable. At birth initialize the
reference on **all225 born-region nodal DOFs**, including those on the25 shared
geometric interface nodes, not only the200 globally new nodes. A reference value
on a shared geometric node is not the old material's constant reference. Do not
attach a later AuxKernel to this reference; its birth field remains fixed.

Freeze this proposed order and these aligned per-variable values, rather than
a scalar restoration flag:

| reinitialize_variables order | reinitialization_strategy | restore_overridden_dofs |
|---|---|---|
| disp_x | IC | true |
| disp_y | IC | true |
| disp_z | IC | true |
| temperature | IC | true |
| born_reference_temperature | IC | false |

Thus the literal restoration vector is `true true true true false`, with five
entries aligned to the five named variables. Reinitialize only born3. The
current temperature and born-reference IC both read the exact BEGIN80 table;
new displacement IC is the separately proposed zero value. Restore selected
current old/shared u/T after IC projection. Do **not** restore the born reference,
which has no old2 variable scope; otherwise the shared-node reference can be
incorrectly inherited. At future concrete deck review, also account for the
modifier's handling of any other added variables; do not let an omitted variable
silently inherit an unintended IC/reset policy.

Force birth into PRE_AUX at TIMESTEP_BEGIN. Its IC/restoration and new-element
material initialization precede the Aux END transfer. END FunctionAux updates
`temperature` only, on old2/born3, with identical saved shared endpoint values.
Material properties are initialized only for reinitialized born elements. Keep
compatible incremental SMALL elastic material/property names and reference mesh.
No implementation or native behavior is established by this table.

## Corrected history statement

The promised invariants are **selected current shared u/T restoration** and
**retention of old-element stateful material properties during birth**. They are
not a promise that entire old/older solution vectors remain byte-identical.
After restoration, the modifier intentionally copies current values into old
and older states on the reinitialized-element DOFs, including affected shared
DOFs. That rebasing supplies the proposed one-step incremental reference. It
must be documented and checked separately from old-element stress/strain state.
Later temperature transfer/equilibrium naturally updates current fields. Do not
label a saved rebased old/older vector as unchanged original history.

Before any future run: check full425-node/256-cell geometry and phase associations,
225 reference DOFs including25 shared, exact five-variable/vector alignment,
only-born property initialization, current-value restoration, intentional
old/older rebase, no reference Aux update, all-node1e-10K transfer calibration,
newborn pre-equilibrium reference stress/strain, old-material state and complete
SI equilibrium/constitutive/reaction checks. Source-supported composition still
requires a reviewed concrete case and fresh runtime bindings; it is not a new
witness, process calibration, head or manufacturing approval.

## Exact bindings and primary evidence

The following immutable files were reread/hash-checked for this clarification:

- `work/962-engineering/cp1-oneway-thermoelastic-transfer-plan-001/NOTE.md` — SHA256 `28d1589f2bee9693be0954d3200cdc722f5a3fd597435a7db427103a8644f5b6`.
- `work/962-engineering/cp1-oneway-thermoelastic-transfer-plan-001/SOURCE-ADDENDUM-001.md` — SHA256 `2543896774c3d1235114062d61609ccd9d5b13a5d835b86671cb38fd0c03293d`.
- `work/962-engineering/cp1-oneway-thermoelastic-transfer-source-peer-001/review.json` — SHA256 `eec7015c23864c114d3579991fe18d145282221d915377a903e5ab8e18faf8c0`.
- `work/962-engineering/cp1-oneway-thermoelastic-transfer-source-peer-001/local-bindings.json` — SHA256 `a40ea756c583047e0cd78f69ba91945d0aa3e0843fab7fb3e4a26cc815e8d998`.
- `work/962-engineering/cp1-oneway-thermoelastic-transfer-source-peer-001/primary-sources.json` — SHA256 `6b877013fe3a4860c4de6cd34e5e49629cd5673643ee192a024a20daea41a2eb`.

The peer's primary-source index pins that complete revision, paths and reviewed
lines; its body hashes are null because browser views are not raw-byte captures.
The relevant source was inspected, not inferred from object names:

- [empty-block metadata](https://raw.githubusercontent.com/idaholab/moose/7c06bdcefd02f9f31f4508839f21f410561309a4/framework/src/mesh/MooseMesh.C), lines145–159.
- [object/variable block containment](https://raw.githubusercontent.com/idaholab/moose/7c06bdcefd02f9f31f4508839f21f410561309a4/framework/src/interfaces/BlockRestrictable.C), lines327–349.
- [target-block lookup](https://raw.githubusercontent.com/idaholab/moose/7c06bdcefd02f9f31f4508839f21f410561309a4/framework/src/meshmodifiers/TimedSubdomainModifier.C), lines244–251.
- [per-variable restoration and old/older rebase](https://raw.githubusercontent.com/idaholab/moose/7c06bdcefd02f9f31f4508839f21f410561309a4/framework/src/meshmodifiers/ElementSubdomainModifierBase.C), lines86–92,178–247,700–731,886–931.

All execution, engineering, physics, material, process, LPBF and manufacturing flags remain false.
