"""Independent saved-domain association/Fraction check; never imports creator predicates."""
from pathlib import Path
from fractions import Fraction as F
from itertools import combinations
from collections import defaultdict, Counter
import hashlib, json, math, struct

ROOT = Path(__file__).resolve().parents[3]
B = ROOT / "work/962-engineering"
HERE = Path(__file__).resolve().parent
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
load = lambda p: json.loads(Path(p).read_text())
rat = lambda v: F(int(v["numerator"]), int(v["denominator"]))
enc = lambda v: {"numerator": str(v.numerator), "denominator": str(v.denominator)}
sub = lambda a, b: tuple(x-y for x, y in zip(a, b))
dot = lambda a, b: sum(x*y for x, y in zip(a, b))
cross = lambda a, b: (a[1]*b[2]-a[2]*b[1], a[2]*b[0]-a[0]*b[2], a[0]*b[1]-a[1]*b[0])
cycle = lambda row: min(tuple(row[i:]+row[:i]) for i in range(3))
ap = B/"apex1613790-domain-equivalence-execution-prep-001/actual-contract.json"
cp = B/"apex1613790-domain-equivalence-root-execution-001/closed-result.json"
rp = B/"apex1613790-domain-equivalence-001/report.json"
a, closed, result = load(ap), load(cp), load(rp)
ip = ap.with_name("index.json");index=load(ip)
assert sha(ap)==result["contract_sha256"]==closed["actual_before"]["sha256"]==closed["actual_after"]["sha256"]
assert sha(ip)==closed["index_before"]["sha256"]==closed["index_after"]["sha256"]
assert result["source_sha256"]==a["source_sha256"]
assert result["input_hashes"]==a["input_hashes"] and len(a["input_hashes"])==42
assert set(p.name for p in rp.parent.iterdir())=={"report.json"}
assert closed["output_files"]=={"report.json":{"bytes":rp.stat().st_size,"sha256":sha(rp)}} and closed["output_count"]==1
assert closed["returncode"]==0 and closed["root_stop_reason"] is None and closed["root_error"] is None
assert closed["SIGTERM_requested"] is False and closed["fallback_SIGKILL"] is False
assert closed["owned_query_wait_reaped"] is True and closed["query_pid_observed_absent_after_wait"] is True
assert closed["all42_before_after_exact"] is True and closed["all42_inputs_before"]==closed["all42_inputs_after"]
assert closed["selected_python_before_after_exact"] is True and closed["selected_python_before"]==closed["selected_python_after"]
assert closed["selected_python_before"]["sha256"]==a["python_sha256"]=="1699bf8aa705a8bb71613bef5cdd7d7c8c9d9a188a841f41679aa9b5830b8f60"
assert closed["native_execution_performed"] is False and closed["head_edited"] is False and closed["domain_accepted"] is False
for p,h in a["input_hashes"].items():
    f=ROOT/p;meta={"sha256":sha(f),"bytes":f.stat().st_size}
    assert meta==closed["all42_inputs_before"][p]==index["all42_current_small_input_records"][p] and h==meta["sha256"]
for name,role in [("stdout.log","stdout"),("stderr.log","stderr"),("launch.json","launch"),("preflight.json","preflight")]:
    f=cp.parent/name
    assert {"sha256":sha(f),"bytes":f.stat().st_size}==closed[role]
child=B/"apex1613790-domain-equivalence-child-peer-001"
for filename,role in [("review.json","child_review"),("bindings.json","child_bindings")]:
    f=child/filename;assert {"sha256":sha(f),"bytes":f.stat().st_size}==closed[role]
launch=load(cp.parent/"launch.json")
assert launch["argv"]==index["query_argv"] and launch["argv"][-1]==sha(ap)
assert type(launch["query_pid"]) is int and launch["query_pid"]>0 and launch["query_pgid_observed"]==launch["query_pid"]
assert launch["preflight_sha256"]==closed["preflight"]["sha256"]
assert a["ordinary_controls"]["wall_timeout_seconds"]==300 and a["ordinary_controls"]["TERM_grace_seconds"]==8
assert a["automatic_retry"] is False and a["native_execution_authorized"] is False
assert a["upstream_census_launch_deviation_sha256"]==result["upstream_census_launch_deviation_sha256"]==closed["upstream_census_launch_deviation_sha256"]=="d60fff297c6c45dc92e117262e36ffde36e2169d53fcd32ce2b79fabde5eebc3"
assert a["declared_controller_command_conformant"] is result["declared_controller_command_conformant"] is closed["declared_controller_command_conformant"] is False
obs = load(B/"direct-sicn-apex1613790-cavity-study-001/saved-star-observation.json")
shell = load(B/"direct-sicn-apex1613790-cavity-study-001/local-shell-input-001.json")
arrays = load(B/"fixed-shell-netgen-apex1613790-001/arrays.json")
worker = load(B/"fixed-shell-netgen-apex1613790-001/fixture-report.json")
prior_peer = load(B/"fixed-shell-netgen-apex1613790-result-peer-001/review.json")
assert result["source_candidate_report_sha256"] == sha(B/"fixed-shell-netgen-apex1613790-001/fixture-report.json")
assert result["source_candidate_arrays_sha256"] == sha(B/"fixed-shell-netgen-apex1613790-001/arrays.json")
assert result["source_candidate_independent_peer_sha256"] == sha(B/"fixed-shell-netgen-apex1613790-result-peer-001/review.json")
assert prior_peer["decision"]=="CLEAR_COMPLETED_LOCAL_QUALITY_SAVED_ASSOCIATIONS_ONLY"
accept_path=B/"fixed-shell-netgen-apex1613790-root-execution-001/stopped-peer-acceptance.json"
assert result["source_candidate_root_acceptance_sha256"]==sha(accept_path)
assert load(accept_path)["review"]["sha256"]==sha(B/"fixed-shell-netgen-apex1613790-result-peer-001/review.json")
assert worker["after"] == worker["saved_reopen"] and arrays["after"] == arrays["saved_reopen"]
mapping = {t: i+1 for i, t in enumerate(shell["local_to_global_node_tags"])}
mapping[1613790] = 17
assert result["original_global_to_comparison_node_tags"] == {str(k): v for k, v in mapping.items()}
assert obs["apex"] == 1613790 and len(obs["selected_node_rows"]) == 17
old_xyz = {}
for row in obs["selected_node_rows"]:
    xyz = row["coordinates_mm"]
    assert [float(v).hex() for v in xyz] == row["binary64_hex"]
    old_xyz[mapping[row["node_tag"]]] = xyz
old_cells = {row["tetrahedron_tag"]: [mapping[t] for t in row["node_tags"]] for row in obs["native_ordered_cell_rows"]}
saved = arrays["saved_reopen"]
new_xyz = dict(zip(saved["node_tags"], saved["coordinates_mm"]))
new_cells = dict(zip(saved["tetra_tags"], saved["tetra_node_tags"]))
assert set(old_xyz) == set(range(1,18)) and set(new_xyz) == set(range(1,21))
assert len(old_cells) == 28 and len(new_cells) == 44
for row in shell["vertex_rows"]:
    t = row["local_node_tag"]
    assert struct.pack("<3d", *old_xyz[t]).hex() == struct.pack("<3d", *new_xyz[t]).hex() == row["binary64_little_endian_bytes_hex"]
expected = sorted(cycle(row["local_node_tags"]) for row in shell["oriented_triangle_rows"])
assert len(expected) == len(set(expected)) == 28
reference = rat(shell["exact_enclosed_volume_mm3"])
summaries = {}
for name, xyz, cells, count, internals in [("old", old_xyz, old_cells, 378, 42), ("candidate", new_xyz, new_cells, 946, 74)]:
    assert len({struct.pack("<3d", *v) for v in xyz.values()}) == len(xyz)
    points = {t: tuple(F.from_float(float(v)) for v in row) for t, row in xyz.items()}
    stored = result[name]
    assert stored["cell_count"] == len(cells) and stored["all_exact_positive"] is True
    assert [r["tetrahedron_tag"] for r in stored["quality_rows"]] == sorted(cells)
    assert len({tuple(sorted(v)) for v in cells.values()}) == len(cells)
    assert set().union(*(set(v) for v in cells.values())) == set(points)
    incidence = defaultdict(list)
    volume = F(0)
    poor = 0
    for tag, row, qrow in [(tag, cells[tag], qrow) for tag, qrow in zip(sorted(cells), stored["quality_rows"])]:
        assert qrow["ordered_node_tags"] == row and len(set(row)) == 4
        assert type(qrow["exact_point1_gate_passed"]) is bool
        for value in [qrow["exact_determinant_mm3"],qrow["exact_SICN_squared"]]:
            assert set(value)=={"numerator","denominator"} and all(type(v) is str for v in value.values()) and int(value["denominator"])>0
            assert enc(rat(value))==value
        p = [points[t] for t in row]
        e1, e2, e3 = [sub(p[j], p[0]) for j in (1,2,3)]
        det = dot(e1, cross(e2,e3))
        b = tuple(2*y-x for x,y in zip(e1,e2))
        c = tuple(z-(x+y)/3 for x,y,z in zip(e1,e2,e3))
        N = dot(e1,e1)+dot(b,b)/3+F(3,2)*dot(c,c)
        ec, bc, ce = cross(e1,e2), cross(b,c), cross(c,e1)
        C = F(4,3)*dot(ec,ec)+F(1,2)*dot(bc,bc)+F(3,2)*dot(ce,ce)
        assert det > 0 and N > 0 and C > 0
        Q2 = 18*det*det/(N*C)
        assert rat(qrow["exact_determinant_mm3"]) == det and rat(qrow["exact_SICN_squared"]) == Q2
        assert qrow["exact_point1_gate_passed"] is (Q2 >= F(1,100))
        poor += Q2 < F(1,100)
        volume += det/6
        for pattern in [(0,2,1),(0,1,3),(0,3,2),(1,2,3)]:
            face = [row[j] for j in pattern]
            incidence[tuple(sorted(face))].append(cycle(face))
    outer, internal = [], 0
    for faces in incidence.values():
        assert len(faces) in (1,2)
        if len(faces) == 1:
            outer.append(faces[0])
        else:
            assert faces[0] == cycle(list(reversed(faces[1])))
            internal += 1
    assert internal == internals == stored["internal_face_pairs"]
    assert sorted(outer) == expected == [tuple(row) for row in stored["oriented_boundary"]]
    assert volume == reference == rat(stored["exact_signed_volume_mm3"])
    if name == "candidate":
        assert poor == 0
    pair_rows = result["pair_results"][name]
    assert len(pair_rows) == count
    dimensions, shared_counts = Counter(), Counter()
    for row, (first, second) in zip(pair_rows, combinations(sorted(cells),2)):
        assert set(row)=={"shared_node_tags","expected_simplex_dimension","plane_triples_enumerated","independent_plane_triples","intersection_vertices","illegal_intersection_vertices","all_illegal_rational_witnesses","intersection_equals_tagged_shared_simplex","tetrahedron_tags"}
        assert all(type(row[k]) is int for k in ["expected_simplex_dimension","plane_triples_enumerated","independent_plane_triples","intersection_vertices","illegal_intersection_vertices"])
        assert type(row["intersection_equals_tagged_shared_simplex"]) is bool and type(row["all_illegal_rational_witnesses"]) is list
        shared = sorted(set(cells[first]) & set(cells[second]))
        assert row["tetrahedron_tags"] == [first, second]
        assert row["shared_node_tags"] == shared and row["expected_simplex_dimension"] == len(shared)-1
        assert len(shared) <= 3 and row["plane_triples_enumerated"] == 56
        assert type(row["independent_plane_triples"]) is int and 4 <= row["independent_plane_triples"] <= 56
        assert type(row["intersection_vertices"]) is int and row["intersection_vertices"] == len(shared)
        assert row["illegal_intersection_vertices"] == 0 and row["all_illegal_rational_witnesses"] == []
        assert row["intersection_equals_tagged_shared_simplex"] is True
        dimensions[str(len(shared)-1)] += 1
        shared_counts[str(len(shared))] += 1
    assert result["pair_failures"][name] == 0
    summaries[name] = {"nodes": len(xyz), "cells": len(cells), "exact_positive_determinants": len(cells), "exact_quality_rows_equal_saved": True, "positive_cells_below_point1": int(poor), "exact_volume_mm3": enc(volume), "opposed_internal_pairs": internal, "common_oriented_boundary_faces": len(outer), "complete_pair_count": count, "pair_dimensions": dict(sorted(dimensions.items())), "pair_shared_counts": dict(sorted(shared_counts.items())), "all_saved_verdicts_true_zero_illegal_witnesses": True, "pair_geometric_predicate_independently_reexecuted": False}
assert result["old_complete_unordered_pairs"] == 378 and result["candidate_complete_unordered_pairs"] == 946
assert result["complete_unordered_pairs"] == 1324 and result["plane_triples_enumerated"] == 74144
assert all(result[k] is True for k in ["exact_common16_coordinate_words","exact_identical_oriented28_boundary","exact_signed_volume_identity","exact_old_pair_embedding","exact_candidate_pair_embedding","local_domain_equivalence_proved","bound_inputs_unchanged"])
assert result["status"] == "same_compact_oriented_local_domain"
assert all(v is False for v in result["qualification"].values()) and result["qualification"] == a["qualification"]
assert result["native_optimizer_or_meshwrite_calls"] == 0 and result["coordinates_changed"] is False
check = {"schema": "962-independent-apex1613790-domain-saved-association-check/v1", "bindings": {"report_sha256": sha(rp), "actual_sha256": sha(ap), "root_closed_sha256": sha(cp), "source_sha256": a["source_sha256"], "child_peer_sha256": closed["child_review"]["sha256"]}, "stages": summaries, "complete72_exact_det_quality_volume_and_incidence_checked": True, "all16_coordinate_words_equal_and_common28_boundary": True, "all1324_saved_pair_ids_order_shared_dimensions_and56_metadata_checked": True, "all_saved_verdicts_true_zero_illegal_witnesses": True, "geometric_intersection_predicate_independently_reexecuted": False, "upstream_census_launch_deviation_sha256":a["upstream_census_launch_deviation_sha256"], "declared_controller_command_conformant":False, "conclusion": "Completed root exact query reports both local embeddings and equal compact oriented occupied local domains. Saved associations/coverage/verdicts agree with independently reconstructed positive complexes/common shell; all-pair intersection geometry itself is source-reviewed and root-executed, not independently rerun here.", "head_stitch_or_physical_acceptance": False}
f = HERE/"independent-saved-check.json"
with f.open("x") as stream:
    json.dump(check,stream,indent=2,allow_nan=False)
    stream.write("\n")
print(json.dumps({"decision":"CLEAR_LOCAL_DOMAIN_SAVED_ASSOCIATIONS","old_cells":28,"candidate_cells":44,"pairs":1324,"check_sha256":sha(f)},sort_keys=True))
