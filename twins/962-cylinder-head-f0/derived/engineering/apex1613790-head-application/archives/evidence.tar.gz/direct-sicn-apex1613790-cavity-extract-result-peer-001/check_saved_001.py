"""Saved associations only; no geometric or certificate producer functions are used."""
import hashlib
import json
from pathlib import Path
import struct

ROOT = Path(__file__).resolve().parents[3]
E = ROOT / 'work/962-engineering'
HERE = Path(__file__).resolve().parent
OUT = E / 'direct-sicn-apex1613790-cavity-study-001'
EXEC = E / 'direct-sicn-apex1613790-cavity-extract-root-execution-001'
ACTUAL = E / 'direct-sicn-apex1613790-cavity-extract-execution-prep-001/actual-contract-001.json'
INDEX = ACTUAL.with_name('index.json')
APEX = 1613790
FACES = ((0,2,1),(0,1,3),(1,2,3),(2,0,3))

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def read(p):
    return json.loads(p.read_text())

def identity(p):
    assert p.is_file() and not p.is_symlink() and p.resolve() == p
    return dict(sha256=sha(p), bytes=p.stat().st_size)

def xyzbits(row):
    return struct.pack('<3d', *row['coordinates_mm'])

def rational(value):
    n, d = int(value['numerator']), int(value['denominator'])
    assert d > 0
    return n, d

a = read(ACTUAL); ix = read(INDEX); closed = read(EXEC / 'closed-result.json'); launch = read(EXEC / 'launch.json')
accepted = read(EXEC / 'child-peer-acceptance.json')
assert sha(ACTUAL) == '68a1b6423deaa270f95c2922930c54a3adffe73b18f3628ae48dbfef1c42c7f0'
assert sha(INDEX) == 'bcc9ff5b1fabdfe960ac41f60629e5a531aeb0a065f32d8f3c63f00cdd63c84f'
assert sha(EXEC / 'closed-result.json') == '83744b83e964b0a81b201c00af0dae7204599cd64691fa7cc50e1091fab0963f'
assert closed['actual_sha256'] == launch['actual_sha256'] == accepted['actual_sha256'] == sha(ACTUAL)
assert closed['index_sha256'] == launch['index_sha256'] == accepted['index_sha256'] == sha(INDEX)
assert closed['peer_sha256'] == launch['peer_sha256'] == accepted['peer_sha256'] == 'fe05c60c102c92f1502251eedb434e34a64bf865f58aa7ca3220635b0e0f30a9'
assert closed['bindings_sha256'] == launch['bindings_sha256'] == accepted['bindings_sha256'] == 'ccf7240cb23939ca0d3922c9230ab1b4f0f3ea89942ee99554d3f329c74c2168'
assert sha(EXEC / 'launch.json') == closed['launch_sha256'] and launch['argv'] == ix['root_planned_argv']
assert closed['all36_input_hashes_before'] == closed['all36_input_hashes_after'] == a['input_sha256'] and len(a['input_sha256']) == 36
assert closed['all36_before_after_unchanged'] is True and closed['external_records_before'] == closed['external_records_after']
paths = {ROOT / k for k in a['input_sha256']} | {ROOT / k for k in closed['external_records_before']}
paths |= {EXEC / name for name in ['closed-result.json','launch.json','child-peer-acceptance.json','stdout.log','stderr.log']}
before = {str(p.relative_to(ROOT)): identity(p) for p in sorted(paths)}
assert all(before[k]['sha256'] == v for k,v in a['input_sha256'].items())
assert all(before[k]['sha256'] == v for k,v in closed['external_records_before'].items())
assert closed['python_before'] == closed['python_after'] == a['python_sha256'] == '1699bf8aa705a8bb71613bef5cdd7d7c8c9d9a188a841f41679aa9b5830b8f60'
assert closed['returncode'] == 0 and closed['stop_reason'] is None and closed['controller_error'] is None
assert closed['SIGTERM_requested'] is False and closed['fallback_SIGKILL'] is False
assert closed['wait_reaped'] is True and closed['owned_query_observed_absent'] is True
assert closed['query_pid'] == launch['query_pid'] == launch['query_pgid'] and launch['new_owned_session'] is True
assert (EXEC/'stdout.log').stat().st_size == (EXEC/'stderr.log').stat().st_size == 0
files = {p.name:p for p in OUT.iterdir()};assert set(files) == {'receipt.json','saved-star-observation.json','local-shell-input-001.json','fixed-shell-tight-face-screen-001.json'}
inventory = {k:identity(p) for k,p in sorted(files.items())};assert inventory == closed['output_files']
assert sum(x['bytes'] for x in inventory.values()) == closed['output_bytes'] == 176472
receipt=read(files['receipt.json']);obs=read(files['saved-star-observation.json']);shell=read(files['local-shell-input-001.json']);screen=read(files['fixed-shell-tight-face-screen-001.json'])
assert receipt['outputs'] == {k:v for k,v in inventory.items() if k!='receipt.json'} and receipt['input_sha256'] == a['input_sha256']
assert receipt['contract_sha256']==sha(ACTUAL) and receipt['source_sha256']==a['source_sha256'] and receipt['returncode']==0 and receipt['all_bound_inputs_unchanged'] is True
assert receipt['native_or_meshing_calls']==0 and closed['scientific_or_native_execution'] is False
for value in [receipt,obs,shell,screen]:
    assert value['declared_controller_command_conformant'] is False
    assert value['upstream_census_launch_deviation_sha256']==a['upstream_census_launch_deviation_sha256']
    for key in ['engineering_accepted','physics_qualified','manufacturing_authorized']:
        assert value.get(key,False) is False
for value in [obs,shell,screen]: assert value['input_hashes']==a['input_sha256']
assert closed['upstream_census_declared_controller_command_conformant'] is False
censuspath=E/'head-star-current129-full-stars-001/readback-report.json';census=read(censuspath)['complete_seed_star_census']
assert obs['source_census_sha256']==sha(censuspath)
expected=sorted([row for row in census['complete_incident_tetrahedra'] if APEX in row['node_tags']], key=lambda row:row['tetrahedron_tag'])
assert len(expected)==28 and obs['native_ordered_cell_rows']==expected
assert sum(row['initially_positive_poor'] for row in expected)==2
selected={row['tetrahedron_tag']:row for row in expected};assert len(selected)==28
assert len({row['native_array_index'] for row in expected})==28
nodeids=sorted({tag for row in expected for tag in row['node_tags']});assert len(nodeids)==17
cnodes={row['node_tag']:row for row in census['unique_incident_nodes']}
assert [row['node_tag'] for row in obs['selected_node_rows']]==nodeids
nodes={row['node_tag']:row for row in obs['selected_node_rows']}
for tag,row in nodes.items():
    original=cnodes[tag];trim=dict(row);trim.pop('binary64_little_endian_bytes_hex')
    assert trim==original and xyzbits(row)==xyzbits(original)
    assert row['binary64_hex']==[float(x).hex() for x in row['coordinates_mm']]
    assert row['binary64_little_endian_bytes_hex']==xyzbits(row).hex()
assert shell['excluded_source_apex_tag']==APEX and shell['apex_not_in_shell_input'] is True
fixed=sorted(set(nodeids)-{APEX});assert len(fixed)==16 and shell['vertices']==16 and shell['local_to_global_node_tags']==fixed
inverse={str(tag):i+1 for i,tag in enumerate(fixed)};assert shell['global_to_local_node_tags']==inverse
for i,row in enumerate(shell['vertex_rows'],1):
    tag=fixed[i-1];original=nodes[tag]
    assert row['local_node_tag']==i and row['source_global_node_tag']==tag
    assert xyzbits(row)==xyzbits(original) and row['binary64_hex']==original['binary64_hex'] and row['binary64_little_endian_bytes_hex']==xyzbits(original).hex()
    assert row['original_source_boundary_node']==original['source_boundary_tag'] and row['original_source_classification']==original['freshly_proved_classification_scope']
    assert row['prospective_cavity_fixed'] is True
boundary=[t for t in fixed if nodes[t]['source_boundary_tag']];interior=[t for t in fixed if not nodes[t]['source_boundary_tag']]
assert len(boundary)==13 and len(interior)==3
assert shell['original_source_classifications']==dict(boundary_global_node_tags=boundary,other_interior_global_node_tags=interior,boundary_local_node_tags=[inverse[str(t)] for t in boundary],other_interior_local_node_tags=[inverse[str(t)] for t in interior])
assert obs['original_source_classifications']==dict(boundary_global_node_tags=boundary,other_interior_global_node_tags=interior)
owners=obs['outer_surface']['oriented_source_owner_rows'];triangles=shell['oriented_triangle_rows'];certs=screen['all_rows']
assert len(owners)==len(triangles)==len(certs)==shell['oriented_triangles']==screen['complete_face_count']==28
assert len({tuple(sorted(row['global_node_tags'])) for row in owners})==28
assert set(row['source_owner_tetrahedron_tag'] for row in owners)==set(selected)
counts=dict(strictly_above=0,equal=0,below=0)
for i,(owner,triangle,cert) in enumerate(zip(owners,triangles,certs),1):
    cell=selected[owner['source_owner_tetrahedron_tag']];corners=owner['native_corner_indices'];assert tuple(corners) in FACES
    face=[cell['node_tags'][j] for j in corners];assert APEX not in face and face==owner['global_node_tags']
    assert triangle==dict(local_face_id=i,local_node_tags=[inverse[str(t)] for t in face],source_global_node_tags=face,source_owner_tetrahedron_tag=owner['source_owner_tetrahedron_tag'],source_native_array_index=cell['native_array_index'],native_corner_indices=corners)
    assert cert['local_face_id']==i and cert['source_global_node_tags']==face
    assert struct.pack('<9d',*[x for t in face for x in nodes[t]['coordinates_mm']])==struct.pack('<9d',*[x for xyz in cert['coordinates_mm'] for x in xyz])
    assert cert['binary64_hex']==[nodes[t]['binary64_hex'] for t in face]
    q=cert['exact_triangle_SICN_squared'];assert q==cert['exact_fixed_face_certificate']['exact_triangle_SICN_squared']
    assert rational(cert['exact_threshold_squared'])==(4,841)
    n,d=rational(q);delta=841*n-4*d
    observed=dict(strictly_above=delta>0,equal=delta==0,below=delta<0)
    assert all(cert[k] is v for k,v in observed.items()) and cert['necessary_point1_face_bound_passed'] is (delta>=0)
    for k,v in observed.items(): counts[k]+=v
assert counts==screen['counts']==dict(strictly_above=28,equal=0,below=0)
assert rational(screen['exact_threshold_triangle_SICN_squared'])==(4,841) and screen['all_necessary_point1_face_bounds_passed'] is True
quality=obs['tetrahedral_complex']['quality_rows'];assert len(quality)==28
assert [x['tetrahedron_tag'] for x in quality]==[x['tetrahedron_tag'] for x in expected]
poor=[]
for row in quality:
    cell=selected[row['tetrahedron_tag']];assert row['ordered_node_tags']==cell['node_tags']
    dn,dd=rational(row['exact_determinant_mm3']);qn,qd=rational(row['exact_SICN_squared']);assert dn>0
    assert row['exact_point1_gate_passed'] is (100*qn>=qd)
    if not row['exact_point1_gate_passed']:poor.append(row['tetrahedron_tag'])
assert poor==[row['tetrahedron_tag'] for row in expected if row['initially_positive_poor']]==[28847992,28848742]
assert rational(obs['exact_volume_mm3'])==rational(obs['tetrahedral_complex']['exact_signed_volume_mm3'])==rational(shell['exact_enclosed_volume_mm3'])
assert obs['outer_surface']['vertices']==16 and obs['outer_surface']['oriented_triangles']==28 and obs['outer_surface']['edges']==42 and obs['outer_surface']['Euler']==2
assert obs['embedding_domain_and_external_owner_checks_performed'] is False
assert shell['execution_authorized'] is False and shell['native_application_authorized'] is False and shell['next_candidate'] is None and shell['native_output'] is None
assert screen['tight_decision_uses_q_squared_not_the_included_loose_certificate_flag'] is True
assert {str(p.relative_to(ROOT)):identity(p) for p in paths}==before
assert {k:identity(p) for k,p in files.items()}==inventory
result=dict(schema='962-apex1613790-independent-stopped-saved-association-check/v1',all_bound_records_before_after=before,all_bound_records_unchanged=True,output_inventory=inventory,output_bytes=176472,complete_original_star_membership=28,initial_positive_poor_tags=poor,original_nodes=17,original_coordinate_words_joined=51,prospective_shell_nodes=16,original_classification_counts=dict(boundary=13,other_interior=3),complete_oriented_face_ownership_associations=28,all28_stored_certificate_input_and_rational_threshold_associations=True,saved_tight_threshold_counts=counts,saved_volume=obs['exact_volume_mm3'],saved_complex_metadata= {k:v for k,v in obs['tetrahedral_complex'].items() if k not in ['quality_rows','oriented_boundary']},exact_determinant_or_SICN_or_face_geometry_recomputed=False,topology_embedding_domain_or_outside_geometry_recertified=False,helper_producer_scientific_or_native_executed=False,upstream_declared_controller_command_conformant=False,current_query_argv_joined=True,root_wait_reap_and_owned_leader_absence_attributed=True)
with (HERE/'independent-saved-check.json').open('x') as stream:json.dump(result,stream,indent=2,allow_nan=False);stream.write('\n')
print(json.dumps(dict(status='PASS_SAVED_ASSOCIATIONS_ONLY',cells=28,nodes=17,shell_vertices=16,faces=28,strict_above=28,exact_geometry_recertified=False)))
