"""Independent saved-association checks; no native, geometry parser or creator code."""
from pathlib import Path
import hashlib,json,math,struct

ROOT=Path(__file__).resolve().parents[3]
BASE=ROOT/'work/962-engineering'
OUT=BASE/'apex1613790-head-application-001'
HERE=Path(__file__).resolve().parent
def load(path):
    return json.loads(path.read_text())
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def jsha(value):
    return hashlib.sha256(json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()
def words(values,kind='d'):
    return struct.pack('<'+kind*len(values),*values)

ACTUAL=BASE/'apex1613790-head-application-execution-prep-001/actual-contract.json'
RUN=BASE/'apex1613790-head-application-root-execution-001'
assert sha(ACTUAL)=='d016fb42f6363995739193521db416741ff8609ef0ca12c22b3dc7e8fdfce272'
assert sha(RUN/'closed-result.json')=='e6951a0c920f88dda87efce797c111b1da83bb81f33cc2cd2c8acb900867504f'
assert not (HERE/'independent-saved-check.json').exists() and not (HERE/'independent-saved-check.json').is_symlink()
actual=load(ACTUAL);closed=load(RUN/'closed-result.json');report=load(OUT/'readback-report.json');receipt=load(OUT/'execution-receipt.json')
launch=load(RUN/'launch.json');auth=load(RUN/'authorization.json');materialized=load(RUN/'materialization.json')
assert closed['schema']=='962-apex1613790-head-root-closed/v1'
assert closed['actual']=={'path':str(ACTUAL.relative_to(ROOT)),'sha256':sha(ACTUAL),'bytes':ACTUAL.stat().st_size}
assert (OUT/'frozen-contract.json').read_bytes()==ACTUAL.read_bytes()
assert closed['authorization']=={'path':str((RUN/'authorization.json').relative_to(ROOT)),'sha256':sha(RUN/'authorization.json'),'bytes':(RUN/'authorization.json').stat().st_size}
for key in ['actual','index']:assert auth[key]==closed[key]
assert sha(ROOT/closed['index']['path'])==closed['index']['sha256']
peer=BASE/'apex1613790-head-application-child-peer-001/review.json'
for key,p in [('independent_child',peer),('independent_child_bindings',peer.with_name('bindings.json'))]:
 assert auth[key]=={'path':str(p.relative_to(ROOT)),'sha256':sha(p),'bytes':p.stat().st_size}
assert load(peer)['actual']['sha256']==sha(ACTUAL) and load(peer)['decision']=='CLEAR_EXACT_CHILD_BINDINGS_ONLY_PENDING_FRESH_ROOT_LAUNCH'
assert len(actual['input_hashes'])==actual['input_count']==58
assert materialized['exact58_inputs_before']==closed['after_inputs']
assert set(closed['after_inputs'])==set(actual['input_hashes']) and {k:v['sha256'] for k,v in closed['after_inputs'].items()}==actual['input_hashes']
future=set(actual['materialization']['future_exact_source_copies'])
assert set(auth['before56existing_inputs'])==set(actual['input_hashes'])-future
assert all(closed['after_inputs'][k]==v for k,v in auth['before56existing_inputs'].items())
assert materialized['frozen_mirror']==closed['output_files']['frozen-contract.json']
assert closed['all58inputs_and_selected_runtime_before_after_exact'] is True
assert closed['after_runtime']==auth['selected_runtime3_NumPy_controller']
runtime=dict(actual['external_runtime_hashes']);runtime[actual['numpy_init']]=actual['numpy_init_sha256'];runtime[actual['controller_interpreter_metadata']['configured_path']]=actual['controller_interpreter_metadata']['sha256']
assert set(runtime)==set(closed['after_runtime']) and all(closed['after_runtime'][k]['sha256']==v for k,v in runtime.items())
assert closed['returncode']==receipt['returncode']==2 and closed['stop_reason'] is receipt['stop_reason'] is None and closed['signals']==[]
assert closed['waited_and_reaped'] is True and closed['owned_controller_group_observed_absent'] is True and closed['native_worker_pid_observed'] is False
assert closed['root_controller_pid']==closed['root_controller_pgid']==launch['pid']==launch['pgid']
assert launch['inner_worker_PID_observed'] is False
assert closed['native_worker_cleanup_scope']=='Attributed only to exact5ab38 finally/wait and saved execution receipt; no universal descendant absence claim.'
assert closed['operation_observed_stopped'] is True and closed['procedural_or_geometry_or_physical_acceptance'] is False and closed['automatic_retry'] is False
assert launch['argv']==auth['argv']==[actual['controller_interpreter_metadata']['configured_path'],'-I','-B',str(OUT/'run_readback.py'),'--contract-sha256',sha(ACTUAL)]
assert launch['environment']==auth['environment']=={'PATH':'/usr/bin:/bin','LANG':'C','PYTHONUTF8':'1','OMP_NUM_THREADS':'2','OPENBLAS_NUM_THREADS':'2','PYTHONDONTWRITEBYTECODE':'1'}
assert launch['actual_sha256']==sha(ACTUAL) and launch['outer_wall_seconds']==1260 and launch['TERM_grace_seconds']==8
assert auth['controls']==actual['external_root_control'] and auth['inner_controls']==actual['controls']
assert set(p.name for p in OUT.iterdir())==set(closed['output_files'])=={'reader.py','run_readback.py','frozen-contract.json','native.log','readback-report.json','execution-receipt.json','head-volume.msh'}
for name,row in closed['output_files'].items():
 p=OUT/name;assert row['path']==str(p.relative_to(ROOT)) and p.is_file() and not p.is_symlink() and p.stat().st_size==row['bytes']
 if name!='head-volume.msh':assert sha(p)==row['sha256'],name
assert report['mesh_sha256']==closed['output_files']['head-volume.msh']['sha256']=='8b16732d63cc69e48af113f6b618cc6378aaf121dbe1c63920dd6dd5eab8d07a'
assert report['mesh_bytes']==closed['output_files']['head-volume.msh']['bytes']==235786462
for key in ['stdout','stderr']:
 p=RUN/(key+'.log');assert closed[key]=={'path':str(p.relative_to(ROOT)),'sha256':sha(p),'bytes':p.stat().st_size}
for field,name in [('reader_sha256','reader.py'),('runner_sha256','run_readback.py'),('contract_sha256','frozen-contract.json'),('native_log_sha256','native.log'),('readback_report_sha256','readback-report.json')]:assert receipt[field]==sha(OUT/name)
assert receipt['hard_wall_seconds']==1200 and receipt['sampled_RSS_stop_bytes']==8589934592 and receipt['sampled_output_stop_bytes']==1073741824 and receipt['threads']==2
assert receipt['final_output_bytes_before_receipt']==sum(v['bytes'] for k,v in closed['output_files'].items() if k!='execution-receipt.json')
assert receipt['max_observed_RSS_bytes']==max(s['RSS_bytes'] for s in receipt['RSS_samples'])<8589934592
assert receipt['wall_seconds']<closed['elapsed_seconds']<1200
assert receipt['counters_are_declarations'] is True and receipt['native_generate_optimize_solve_calls_declared']==0 and receipt['mesh_write_calls_declared']==1
assert receipt['hard_OS_CPU_quota_applied'] is receipt['hard_address_space_limit_applied'] is False
held=load(HERE/'held-preparation.json');assert held['schema']=='962-held-apex1613790-head-stopped-comparator/v1'
selected={ROOT/k:v for k,v in held['input_hashes'].items() if Path(k).suffix!='.msh'}
selected[HERE/'held-preparation.json']=sha(HERE/'held-preparation.json')
before_saved={str(p.relative_to(ROOT)):{'sha256':sha(p),'bytes':p.stat().st_size} for p in selected}
assert all(before_saved[str(p.relative_to(ROOT))]['sha256']==v and p.is_file() and not p.is_symlink() for p,v in selected.items())
original=load(BASE/'head-star-current204-combined-application-001/readback-report.json')
context=load(BASE/'current129-apex1613790-head-context-001/readback-report.json')
observation=load(BASE/'direct-sicn-apex1613790-cavity-study-001/saved-star-observation.json')
shell=load(BASE/'direct-sicn-apex1613790-cavity-study-001/local-shell-input-001.json')
candidate=load(BASE/'fixed-shell-netgen-apex1613790-001/fixture-report.json')
arrays=load(BASE/'fixed-shell-netgen-apex1613790-001/arrays.json')['saved_reopen']
assert report['before']==original['after']==original['saved_reopen']
assert report['before']['array_sha256s']==context['full_array_sha256s'] and report['before']['classifications']==context['full_native_classifications']
assert report['after']==report['saved_reopen'] and report['after_preservation']==report['saved_preservation']
before,after=report['before'],report['after']
assert report['procedural_checks_passed'] and report['saved_mesh_identity_exact'] and report['bound_inputs_unchanged'] and report['partial_replacement_completed'] and report['partial_replacement_attempted']
assert report['stage']=='completed_partial_repair_audits' and report['status']=='completed_partial_head_replacement_whole_head_quality_gate_applied'
assert report['call_counts_are_attempts'] is True and report['native_operation_counts']==actual['declared_operation_counts']
assert report['runtime']==actual['expected_runtime'] and report['runtime_sha256s']==actual['runtime_sha256s']
for field,rel in [('original_parent_MSH_sha256','head-star-current204-combined-application-001/head-volume.msh'),('context_sha256','current129-apex1613790-head-context-001/readback-report.json'),('local_candidate_report_sha256','fixed-shell-netgen-apex1613790-001/fixture-report.json'),('local_candidate_arrays_sha256','fixed-shell-netgen-apex1613790-001/arrays.json'),('current_local_domain_report_sha256','apex1613790-domain-equivalence-001/report.json'),('current_local_domain_peer_sha256','apex1613790-domain-equivalence-result-peer-001/review.json')]:
    assert report[field]==actual['input_hashes']['work/962-engineering/'+rel]
assert report['gmsh_warnings_errors']==[]
for stage,counts in [(before,(1097219,3621755,225488)),(after,(1097222,3621771,225491))]:
    assert (stage['total_mesh_nodes'],stage['tetrahedra'],stage['tetra_referenced_interior_nodes'])==counts
    assert stage['retained_boundary_nodes']==871731 and stage['tetra_referenced_nodes']==stage['total_mesh_nodes'] and stage['unreferenced_mesh_nodes']==0
    assert stage['volume_relative_error']<=1e-6 and stage['summed_tetra_volume_mm3']==915453.1236217882
    assert stage['actual_tetra_boundary']=={'boundary_triangles':1743878,'exact_oriented_tetra_boundary':True,'nonmanifold_volume_faces':0}
    assert stage['internal_tetra_face_orientation']['same_oriented_internal_faces']==0 and stage['internal_tetra_face_orientation']['exact_internal_orientation_balance']
    assert 4*stage['tetrahedra']==1743878+2*stage['internal_tetra_face_orientation']['internal_faces']
    assert stage['surface']==before['surface'] and stage['surface']['exact_source_coordinates'] and stage['surface']['exact_source_oriented_connectivity']
    assert stage['source_boundary_identity']==context['current_source_boundary_identity']
    assert stage['interior_node_count_establishes_thermal_resolution'] is False
    for row in stage['quality'].values():
        assert row['count']==stage['tetrahedra'] and row['nonpositive_count']==0 and 0<row['minimum']<=row['maximum']
        sequence=[row[k] for k in ['minimum','p01','p05','p50','p95','p99','maximum']]
        assert all(math.isfinite(v) for v in sequence) and sequence==sorted(sequence)
for label in ['before_preservation','after_preservation','saved_preservation']:
    snap=report[label]
    assert snap['preservation']=={k:context['future_preservation_references'][k] for k in ['outside_node_tags_u64_sha256','outside_coordinate_words_f64_sha256','outside_tetra_tags_u64_sha256','outside_ordered_tetra_connectivity_u64_sha256','outside_nodes','outside_TET4']} and snap['original_classification_projection_exact']
    for key,digest in snap['metadata_sha256s'].items():assert digest==jsha(context[key])
assert report['before_preservation']['new_nodes_on_volume1']==0 and report['after_preservation']['new_nodes_on_volume1']==3
assert report['before_preservation']['maxima']=={'node':1613974,'element_all_dimensions':32159061}
assert report['after_preservation']['maxima']=={'node':1613977,'element_all_dimensions':32159077}
assert after['classifications']['node_counts_by_classification_dimension']=={'0':0,'1':0,'2':871731,'3':225491}
assert after['source_boundary_identity']==before['source_boundary_identity']

# Worker-derived retained original set excludes only the old apex; new tags are excluded.
base_inventory={(r['dimension'],r['entity_tag']):r for r in context['full_entity_node_parameter_inventory']}
reference=report['before_preservation']['retained_original_parameter_projection']
assert reference==report['after_preservation']['retained_original_parameter_projection']==report['saved_preservation']['retained_original_parameter_projection']
assert len(reference)==len(base_inventory) and len({(r['dimension'],r['entity_tag']) for r in reference})==len(reference)
for row in reference:
 original_row=base_inventory[row['dimension'],row['entity_tag']]
 assert row['count']==original_row['count']-(1 if row['dimension']==3 and row['entity_tag']==1 else 0)
 assert row['parameter_width']==original_row['parameter_width']
 if row['parameter_width']==0:assert row['available_parameter_words_f64_sha256']==hashlib.sha256(b'').hexdigest()
 if row['dimension']==2:assert row['node_tags_u64_sha256']==original_row['node_tags_u64_sha256']
assert sum(r['count'] for r in reference)==before['total_mesh_nodes']-1
assert report['before_preservation']['expected_new_nodes']==report['after_preservation']['expected_new_nodes']==3
assert report['retained_original_parameter_scope']=='Derived from full verified native before arrays excluding only apex1613790; added nodes never enter retained reference.'
old={row['tetrahedron_tag']:row['node_tags'] for row in observation['native_ordered_cell_rows']}
assert len(old)==28 and all(len(row)==4 and len(set(row))==4 and 1613790 in row for row in old.values())
assert context['complete_old_apex_incident_rows']==[{'tetrahedron_tag':t,'node_tags':old[t]} for t in sorted(old)]
old_poor=sum(0<row['initial_native_SICN']<.1 for row in observation['native_ordered_cell_rows']);assert old_poor==2
assert arrays['node_tags']==sorted(set(arrays['node_tags'])) and arrays['tetra_tags']==sorted(set(arrays['tetra_tags']))
coords=dict(zip(arrays['node_tags'],arrays['coordinates_mm']))
assert len(coords)==len(arrays['node_tags'])==20 and len(arrays['tetra_tags'])==len(arrays['tetra_node_tags'])==44
node_map={i:t for i,t in enumerate(shell['local_to_global_node_tags'],1)}
interiors=sorted(set(coords)-set(node_map));assert interiors==[17,18,19,20]
node_map.update(zip(interiors,[1613790,1613975,1613976,1613977]))
assert len(node_map)==len(set(node_map.values()))==20 and {str(k):v for k,v in node_map.items()}==report['local_to_global_node_map']
slots=sorted(old)+list(range(32159062,32159078))
assert slots==report['replacement_element_slots'] and len(set(slots))==44
expected_rows={str(tag):[node_map[k] for k in row] for tag,row in zip(slots,arrays['tetra_node_tags'])}
assert expected_rows==report['replacement_ordered_rows'] and len(expected_rows)==44
original_words={row['node_tag']:row for row in observation['selected_node_rows']}
mapped_words={node_map[tag]:coords[tag] for tag in arrays['node_tags']}
for tag,xyz in mapped_words.items():assert len(xyz)==3 and all(type(x) is float and math.isfinite(x) for x in xyz)
for i,row in enumerate(shell['vertex_rows'],1):
 xyz=coords[i];global_tag=node_map[i]
 assert row['local_node_tag']==i and row['source_global_node_tag']==global_tag
 assert words(xyz).hex()==row['binary64_little_endian_bytes_hex']==original_words[global_tag]['binary64_little_endian_bytes_hex']
 assert [float(v).hex() for v in xyz]==original_words[global_tag]['binary64_hex']
assert len(shell['vertex_rows'])==16 and sum(row['original_source_boundary_node'] for row in shell['vertex_rows'])==13
metrics={}
for name,values in report['replacement44_native_metrics'].items():
 assert len(values)==44 and all(type(v) is float and math.isfinite(v) and v>0 for v in values)
 assert words(values)==words(arrays['native_qualities'][name])
 assert hashlib.sha256(words(values)).hexdigest()==candidate['saved_reopen']['quality'][name]['array_sha256']
 metrics[name]={'count':44,'minimum':min(values),'maximum':max(values),'array_sha256':hashlib.sha256(words(values)).hexdigest(),'all44_binary64_equal_frozen_candidate':True}
assert set(metrics)=={'SICN','Jacobian','native_volume_mm3'}
assert min(report['replacement44_native_metrics']['SICN'])==.27182687371445746 and all(v>=.1 for v in report['replacement44_native_metrics']['SICN'])
assert report['actual_replacement44_SICN_gate_passed'] is True
assert before['quality']['minimum_SICN']['below_point1_count']==129 and after['quality']['minimum_SICN']['below_point1_count']==127
assert report['actual_whole_head_positive_poor_count']==127==129-old_poor
assert report['actual_whole_head_SICN_gate_passed'] is False and after['quality']['minimum_SICN']['minimum']==.039074265058645995<.1
assert report['expected_whole_head_positive_poor_count_not_observed']==127 and report['expected_count_is_not_acceptance'] is True
for key in ['global_embedding_or_containment_proved','stronger_Mesh2_criterion_passed','engineering_accepted','physics_qualified','manufacturing_authorized']:assert report[key] is False
assert report['upstream_census_launch_deviation_sha256']==actual['upstream_census_launch_deviation_sha256']=='d60fff297c6c45dc92e117262e36ffde36e2169d53fcd32ce2b79fabde5eebc3'
assert report['declared_controller_command_conformant'] is actual['declared_controller_command_conformant'] is False
assert receipt['manufacturing_authorized'] is False
for key in ['engineering_accepted','physics_qualified','material_qualified','process_calibrated','manufacturing_authorized','head_execution_authorized','automatic_retry']:assert actual[key] is False
after_saved={str(p.relative_to(ROOT)):{'sha256':sha(p),'bytes':p.stat().st_size} for p in selected}
assert before_saved==after_saved
result={'schema':'962-apex1613790-head-independent-saved-association-check/v1','decision':'CLEAR_SAVED_PARTIAL_PROCEDURE_STRICT_WHOLE_HEAD_REJECTED',
 'all58_actual_roles_joined':True,'output_inventory':closed['output_files'],'six_small_outputs_hashed':True,'MSH_bodies_read_hashed_or_decoded':False,
 'before_equals_current_parent_after_and_saved':True,'after_equals_saved_reopen':True,'retained_original_parameter_projections_equal':True,
 'outside_and_full_metadata_hashes_joined':True,'global_native_audit_metrics_and_preservation_worker_attributed':True,
 'raw_mapping':{'nodes':20,'fixed_shell_words':16,'source_boundary_shell':13,'source_interior_shell':3,'existing_apex':1613790,'fresh_global_tags':[1613975,1613976,1613977],'old_slots':28,'fresh_slots':16,'replacement_cells':44,'mapped_coordinates_sha256':hashlib.sha256(b''.join(words(mapped_words[t]) for t in sorted(mapped_words))).hexdigest(),'ordered_rows_sha256':jsha(expected_rows)},
 'all132_local_metric_words_equal_candidate':True,'local_metrics':metrics,'before_positive_poor':129,'after_positive_poor':127,'head_minimum_SICN':after['quality']['minimum_SICN']['minimum'],'whole_head_gate_passed':False,
 'root_controller_wait_and_observed_absence_attributed':True,'native_PID_observed':False,'native_cleanup_scope':closed['native_worker_cleanup_scope'],
 'controller_sampled_max_RSS_bytes':receipt['max_observed_RSS_bytes'],'own_source_sha256':sha(Path(__file__)),'small_hashes_before':before_saved,'small_hashes_after':after_saved,
 'geometry_or_native_or_scientific_or_producer_reexecution':False,'engineering_accepted':False,'physics_qualified':False,'material_qualified':False,'process_calibrated':False,'manufacturing_authorized':False}
(HERE/'independent-saved-check.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
print(json.dumps({k:result[k] for k in ['decision','all132_local_metric_words_equal_candidate','before_positive_poor','after_positive_poor','whole_head_gate_passed']}))
