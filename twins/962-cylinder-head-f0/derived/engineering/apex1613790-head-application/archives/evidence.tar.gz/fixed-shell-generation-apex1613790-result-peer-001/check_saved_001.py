"""Independent stopped saved-association check; no geometry/native/producer replay."""
from pathlib import Path
import hashlib,json,math,struct

ROOT=Path(__file__).resolve().parents[3]
OUT=Path(__file__).resolve().parent
BASE='work/962-engineering/'
CLOSED=BASE+'fixed-shell-generation-apex1613790-root-execution-001/closed-result.json'
ACTUAL=BASE+'fixed-shell-generation-apex1613790-execution-prep-001/actual-contract-001.json'
INDEX=BASE+'fixed-shell-generation-apex1613790-execution-prep-001/index.json'
OUTPUT=ROOT/(BASE+'fixed-shell-generation-apex1613790-001')
EXPECTED_ROOT='d2f48279d8e665f28c0f6ec0f0d846312619edbe525080c42fa03d69d31d6656'
EXPECTED_ACTUAL='1ade3088410ec8381237aedf0bd89c8402e2f9dcfd933ff83ec01ab9b482ee97'
EXPECTED_INDEX='caed3f9450dc339c23e510f5e680f2521a9654a90cfd669a1eb676a84430ad17'
DEVIATION='d60fff297c6c45dc92e117262e36ffde36e2169d53fcd32ce2b79fabde5eebc3'
SELECTION='1699bf8aa705a8bb71613bef5cdd7d7c8c9d9a188a841f41679aa9b5830b8f60'

def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def need(value,message):
    if not value:raise ValueError(message)
def load(name):return json.loads((ROOT/name).read_text())
def flatten(rows):return [x for row in rows for x in row]
def typed(values,code):return hashlib.sha256(struct.pack('<'+str(len(values))+code,*values)).hexdigest()
def bits(values):return struct.pack('<'+str(len(values))+'d',*values)

need(sha(ROOT/CLOSED)==EXPECTED_ROOT and sha(ROOT/ACTUAL)==EXPECTED_ACTUAL and sha(ROOT/INDEX)==EXPECTED_INDEX,'External root/actual/index drift')
root=load(CLOSED);actual=load(ACTUAL);index=load(INDEX)
expected=dict(actual['input_hashes'])
need(len(expected)==55 and root['all55_input_hashes_before']==root['all55_input_hashes_after']==expected and root['all55_before_after_unchanged'] is True,'Complete55 source/data maps differ')
need(root['external_records_before']==root['external_records_after'] and len(root['external_records_before'])==6,'External closure maps differ')
expected.update(root['external_records_before']);expected[CLOSED]=EXPECTED_ROOT
side=Path(CLOSED).parent
for name in ['launch.json','materialization.json','child-peer-acceptance.json','controller.stdout.log','controller.stderr.log']:
    p=side/name;expected[str(p)]=sha(ROOT/p)
need(set(root['output_files'])=={p.name for p in OUTPUT.iterdir()} and len(root['output_files'])==8 and not any(p.is_symlink() or not p.is_file() for p in OUTPUT.iterdir()),'Complete eight regular outputs required')
for name,record in root['output_files'].items():
    path=OUTPUT/name;need(path.stat().st_size==record['bytes'],'Output size differs: '+name);expected[str(path.relative_to(ROOT))]=record['sha256']
need(root['output_count']==8 and root['output_bytes']==sum(r['bytes'] for r in root['output_files'].values())==76626,'Full output totals differ')
bindings=[]
for name,digest in sorted(expected.items()):
    p=ROOT/name;need(not Path(name).is_absolute() and '..' not in Path(name).parts and p.is_file() and not p.is_symlink() and p.resolve().is_relative_to(ROOT) and sha(p)==digest,'Selected saved body drift: '+name)
    bindings.append(dict(path=name,sha256=digest,bytes=p.stat().st_size))
source_before=sha(Path(__file__))
launch=load(str(side/'launch.json'));material=load(str(side/'materialization.json'));accepted=load(str(side/'child-peer-acceptance.json'))
need(launch['argv']==index['root_planned_argv'] and launch['actual_sha256']==root['actual_sha256']==EXPECTED_ACTUAL and root['index_sha256']==EXPECTED_INDEX,'Root exact invocation join differs')
need(root['launch_sha256']==sha(ROOT/side/'launch.json') and launch['controller_pid']==root['controller_pid'],'Owned controller metadata join differs')
for key in ['actual_sha256','index_sha256','serial_assessment_closed_sha256']:
    need(accepted[key]==root[key],'Child acceptance join differs: '+key)
for key,other in [('peer_sha256','child_peer_sha256'),('bindings_sha256','child_bindings_sha256')]:
    need(accepted[key]==launch[key]==root[other],'Exact child peer join differs')
need(launch['outer_wall_seconds']==40 and launch['TERM_grace_seconds']==8 and actual['outer_wall_seconds']==40 and actual['root_outer_cleanup']['grace_seconds']==8,'Outer bounds differ')
need(root['controller_returncode']==2 and root['worker_returncode']==2 and root['root_stop_reason'] is None and root['worker_stop_reason'] is None and root['root_controller_error'] is None,'Natural quality-reject route required')
need(root['SIGTERM_requested'] is False and root['fallback_SIGKILL'] is False and root['controller_wait_reaped'] is True and root['owned_controller_observed_absent'] is True and root['native_PID_directly_observed'] is False,'Root cleanup scope differs')
need(root['selected3_runtime_before']==root['selected3_runtime_after']==actual['external_runtime_hashes'] and len(root['selected3_runtime_before'])==3,'Root selected runtime metadata differs')
need(root['numpy_init_before']==root['numpy_init_after']==actual['numpy_init_sha256'] and root['python_before']==root['python_after']==SELECTION and root['selected3_runtime_NumPy_Python_before_after_unchanged'] is True,'Root NumPy/Python metadata differs')
need((OUTPUT/'frozen-contract.json').read_bytes()==(ROOT/ACTUAL).read_bytes(),'Executed actual mirror differs')
for name in ['reader.py','run_readback.py']:
    source=ROOT/actual['future_materializations'][str((OUTPUT/name).relative_to(ROOT))]['source']
    need((OUTPUT/name).read_bytes()==source.read_bytes(),'Executed source mirror differs: '+name)
for name,record in material['files'].items():
    need(sha(OUTPUT/name)==record['sha256'] and (OUTPUT/name).stat().st_size==record['bytes'],'Materialization metadata differs')
need(set(material['files'])=={'reader.py','run_readback.py','frozen-contract.json'} and material['all55_inputs_current'] is True and material['external_digest_not_self_pin'] is True,'Exact three-file materialization record required')
report=json.loads((OUTPUT/'fixture-report.json').read_text());receipt=json.loads((OUTPUT/'execution-receipt.json').read_text());arrays=json.loads((OUTPUT/'arrays.json').read_text());shell=load(actual['local_shell_input'])
need(receipt['scope']=='one_specific_apex1435493_cavity_generation_witness' and receipt['operation_counts_are_declarations_not_observed'] is True,'Historical controller label/declarations must remain explicit')
need(receipt['returncode']==2 and receipt['stop_reason'] is None and receipt['contract_sha256']==EXPECTED_ACTUAL and receipt['reader_sha256']==actual['reader_sha256'] and receipt['runner_sha256']==actual['runner_sha256'],'Receipt/source/actual route differs')
need(receipt['fixture_report_sha256']==sha(OUTPUT/'fixture-report.json') and receipt['native_log_sha256']==sha(OUTPUT/'native.log') and root['native_receipt_sha256']==sha(OUTPUT/'execution-receipt.json'),'Full report/log/receipt closure differs')
need(receipt['declared_operation_counts']==actual['declared_operation_counts']==report['native_operation_counts'] and report['call_counts_are_attempts'] is True,'One generate/write and zero forbidden counter joins differ')
need(receipt['hard_wall_seconds']==30 and receipt['sampled_RSS_stop_bytes']==1073741824 and receipt['sampled_output_stop_bytes']==16777216 and receipt['threads']==2,'Inner bounds differ')
need(receipt['final_output_bytes_before_receipt']+ (OUTPUT/'execution-receipt.json').stat().st_size==root['output_bytes'],'Receipt prewrite byte inventory differs')
need(report['status']=='completed_specific_cavity_generation_only' and report['stage']=='completed_all_local_checks' and report['fixture_procedural_checks_passed'] is True and report['actual_SICN_gate_passed'] is False and report['actual_SICN_threshold']==.1,'Completed procedural/strict reject separation required')
need(report['bound_inputs_unchanged'] is True and report['saved_mesh_identity_exact'] is True and report['exact_boundary_bits_faces_classifications'] is True and report['gmsh_warnings_errors']==[],'Saved procedural flags differ')
need(report['frozen_contract_sha256']==EXPECTED_ACTUAL and report['local_shell_sha256']==actual['local_shell_input_sha256'] and report['full_tiny_arrays_sha256']==sha(OUTPUT/'arrays.json'),'Source/report/array binding differs')
need(report['mesh_sha256']==sha(OUTPUT/'cavity.msh') and report['mesh_bytes']==2790,'Tiny MSH byte identity differs; no decode performed')
need(report['upstream_census_launch_deviation_sha256']==actual['upstream_census_launch_deviation_sha256']==root['upstream_launch_deviation_sha256']==DEVIATION and report['declared_controller_command_conformant'] is actual['declared_controller_command_conformant'] is root['upstream_declared_controller_command_conformant'] is False,'Historical census deviation must stay false')
need('declared_controller_command_conformant' not in receipt,'No new direct4963 receipt deviation field may be invented')
need(report['original_source_classifications']==shell['original_source_classifications'] and report['local_to_global_shell_node_tags']==shell['local_to_global_node_tags'] and report['all16_shell_nodes_fixed_only_for_this_cavity_generation'] is True,'Original13/3 versus prospective16-fixed labels differ')
need(report['options']==actual['options'] and report['runtime']==actual['expected_runtime'] and report['runtime_sha256s']==actual['runtime_sha256s'],'Recorded source options/runtime joins differ')
need(report['after_generation']==report['saved_reopen'] and arrays['after_generation']==arrays['saved_reopen'] and set(arrays)=={'after_generation','saved_reopen'},'Complete live/saved report and arrays differ')
metric_checks=[]
for stage,a in arrays.items():
    snap=report[stage];tags=a['node_tags'];xyz=a['coordinates_mm'];et=a['tetra_tags'];en=a['tetra_node_tags'];q=a['native_qualities']
    need(tags==list(range(1,17)) and len(xyz)==16 and et==sorted(set(et)) and len(et)==len(en)==24 and all(type(t) is int and t>0 for t in et),'Full saved16-node24-TET rows required')
    need(all(len(row)==4 and len(set(row))==4 and all(n in tags for n in row) for row in en),'Complete tagged connectivity rows required')
    need(bits(flatten(xyz))==bits(flatten([row['coordinates_mm'] for row in shell['vertex_rows']])),'All16 original binary64 shell words differ')
    for name,values,code,key in [('node_tags',tags,'Q','sorted_node_tags_sha256'),('coordinates',flatten(xyz),'d','sorted_coordinates_sha256'),('tetra_tags',et,'Q','tetra_tags_sha256'),('connectivity',flatten(en),'Q','tagged_tetra_connectivity_sha256')]:
        need(typed(values,code)==snap[key],'Stored typed-array hash differs: '+name)
    need((snap['nodes'],snap['tetrahedra'],snap['referenced_nodes'],snap['referenced_interior_nodes'],snap['unreferenced_nodes'],snap['duplicate_tetrahedra'])==(16,24,16,0,0,0),'Stored snapshot cardinalities differ')
    need(snap['node_classifications']==[[n,2] for n in tags] and snap['node_entity_classifications']==[[n,2,1] for n in tags] and snap['node_counts_by_classification_dimension']=={'0':0,'1':0,'2':16,'3':0},'Complete fixed local classification rows differ')
    need(snap['boundary_triangles']==28 and snap['internal_faces']==34 and snap['exact_oriented_tetra_boundary'] is True and snap['exact_internal_orientation_balance'] is True and snap['nonmanifold_volume_faces']==snap['same_oriented_internal_faces']==0,'Stored incidence metadata differs; not independently replayed')
    for label,values in [*q.items(),('independent_signed_volume_mm3',a['independent_signed_volume_mm3'])]:
        need(len(values)==24 and all(type(x) in (float,int) and math.isfinite(x) for x in values),'Full finite stored24 metric values required')
        summary=snap['quality'][label] if label in q else snap[label]
        need(summary['count']==24 and summary['minimum']==min(values) and summary['maximum']==max(values) and summary['nonpositive_count']==sum(x<=0 for x in values) and summary['below_point1_count']==sum(x<.1 for x in values) and summary['array_sha256']==typed(values,'d'),'Stored distribution/typed metric hash differs: '+label)
        metric_checks.append(dict(stage=stage,label=label,count=24,sha256=typed(values,'d'),minimum=min(values),nonpositive=sum(x<=0 for x in values),below_point1=sum(x<.1 for x in values)))
    need(math.fsum(a['independent_signed_volume_mm3'])==snap['independent_signed_volume_mm3']['sum'] and math.fsum(q['native_volume_mm3'])==snap['native_volume_sum_mm3'],'Stored volume sums differ; determinants not recomputed')
    need(snap['independent_signed_volume_mm3']['relative_error']<=1e-6,'Stored source volume bookkeeping bound failed')
need(min(arrays['after_generation']['native_qualities']['SICN'])==.09212681714853574 and sum(x<.1 for x in arrays['after_generation']['native_qualities']['SICN'])==2,'Observed stored strict quality rejection differs')
need(root['observed_procedure_passed'] is True and root['observed_strict_quality_passed'] is False and root['head_edited'] is False,'Root stored outcome differs')
need(all(report[k] is False for k in ['head_execution_authorized','stitching_authorized','native_head_application_authorized','engineering_accepted','physics_qualified','manufacturing_authorized','global_self_intersection_checked','geometric_tetrahedron_overlap_checked','new_interior_node_point_in_cavity_containment_checked']),'Broader qualification must stay false')
for item in bindings:need(sha(ROOT/item['path'])==item['sha256'],'Saved body changed during own check: '+item['path'])
need(sha(Path(__file__))==source_before,'Own checker changed')
result=dict(schema='962-apex1613790-generation-stopped-saved-association-check/v1',decision='CLEAR_COMPLETED_PROCEDURAL_GENERATION_STRICT_QUALITY_REJECTION',input_body_count=len(bindings),bindings=bindings,all_selected_bodies_before_after_unchanged=True,full8_output_inventory=root['output_files'],output_bytes=root['output_bytes'],source_and_actual_aliases_exact=True,stored_live_saved_reports_arrays_equal=True,fixed16_source_coordinate_words_exact=True,stored_metric_distributions_and_typed_hashes=metric_checks,stored_outcome=dict(nodes=16,tetrahedra=24,interior_nodes=0,minimum_SICN=.09212681714853574,below_point1=2,nonpositive=0,procedural_pass=True,strict_quality_pass=False),source_root_attributed_only=['Native generation, topology/orientation/no-orphan/volume determinant computations and all native metric formula evaluations.','Native selected3/NumPy/controllerPython before-after body freshness.','Native cleanup by exact4963 finally/receipt; native PID was not directly observed.'],own_scope='Saved body hashes/JSON field and binary64/typed-array associations and unchanged gate on stored quality values; no geometry/SICN/determinant/incidence replay and no MSH decode.',root_lifecycle=dict(controller_RC=2,root_stop=None,wait_reaped=True,owned_controller_absence_root_attributed=True,native_PID_directly_observed=False,native_PID_absence_claimed=False,root_wall_seconds=root['wall_seconds'],controller_wall_seconds=receipt['wall_seconds'],sampled_RSS_bytes=receipt['max_observed_RSS_bytes'],sampled_not_true_peak=True),historical_controller_label=receipt['scope'],upstream_census_launch_deviation_sha256=DEVIATION,declared_controller_command_conformant=False,prepared_functions_or_guards_or_native_imports=False,geometry_or_SICN_recalculation=False,MSH_scope='Own SHA256/size only of this2790-byte local saved MSH; no decode or other geometry body.',head_repair_or_qualification=False)
with (OUT/'independent-saved-check.json').open('x') as f:json.dump(result,f,indent=2,allow_nan=False);f.write('\n')
print(json.dumps(dict(decision=result['decision'],bodies=len(bindings),outputs=8,nodes=16,tetrahedra=24,stored_poor=2,min_stored_SICN=.09212681714853574)))
