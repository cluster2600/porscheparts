"""One fixed saved-JSON association check; no native/helper/scientific imports."""
import collections
import hashlib
import json
import math
from pathlib import Path
import re
import struct
import sys

ROOT = Path(__file__).resolve().parents[3]
HERE = Path(__file__).resolve().parent
BASE = ROOT / "work/962-engineering"
OUT = BASE / "current129-apex1613790-head-context-001"
RUN = BASE / "current129-apex1613790-head-context-root-execution-001"
ACT = BASE / "current129-apex1613790-head-context-execution-prep-001/actual-contract.json"
INDEX = ACT.with_name("index.json")
OBS = BASE / "direct-sicn-apex1613790-cavity-study-001/saved-star-observation.json"
SHELL = OBS.with_name("local-shell-input-001.json")
FIRST = BASE / "head-star-current129-full-stars-001/readback-report.json"
PARENT = BASE / "head-star-current204-combined-application-001/readback-report.json"
APEX = 1613790
FACES = ((0, 2, 1), (0, 1, 3), (1, 2, 3), (2, 0, 3))


def identity(path):
    assert path.is_file() and not path.is_symlink(), str(path)
    body = path.read_bytes()
    return {"sha256": hashlib.sha256(body).hexdigest(), "bytes": len(body)}


def load(path):
    return json.loads(path.read_text())


def json_digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()).hexdigest()


def words(row):
    xyz = row["coordinates_mm"]
    assert len(xyz) == 3 and all(type(v) in (int, float) and math.isfinite(v) for v in xyz)
    assert [float(v).hex() for v in xyz] == row["binary64_hex"]
    return struct.pack("<3d", *xyz)


def cyclic(face):
    a, b, c = face
    return {(a, b, c), (b, c, a), (c, a, b)}


bound_path = HERE / "input-bindings.json"
assert identity(bound_path)["sha256"] == sys.argv[1]
bound = load(bound_path)["records"]
before = {name: identity(ROOT / name) for name in bound}
assert before == bound
a, index = load(ACT), load(INDEX)
closed, report, receipt = load(RUN / "closed-result.json"), load(OUT / "readback-report.json"), load(OUT / "execution-receipt.json")
assert identity(ACT)["sha256"] == "c00ec1428e64e4615cbad22206c72f8a4644e2f9e616a46512ac51d4caca5cc8"
assert identity(RUN / "closed-result.json")["sha256"] == "cf7fa7cd1d2a90539c4345b2f3bd6f789cbaf904dd31d2a2bcb69201a891d218"
assert identity(OUT / "readback-report.json")["sha256"] == "035adeb6d5d4d75756c0fde9eb07de44a6e4507995c58e9f217453f3bfcbe29a"
inventory = {p.name: identity(p) for p in OUT.iterdir()}
assert set(inventory) == {"reader.py", "run_readback.py", "frozen-contract.json", "native.log", "execution-receipt.json", "readback-report.json"}
assert inventory == closed["output_files"] and closed["output_count"] == 6
assert (OUT / "frozen-contract.json").read_bytes() == ACT.read_bytes()
prep = BASE / "current129-apex1613790-head-context-prep-001"
assert (OUT / "reader.py").read_bytes() == (prep / "reader.py").read_bytes()
assert (OUT / "run_readback.py").read_bytes() == (prep / "run_readback.py").read_bytes()
assert closed["all55_inputs_before"] == closed["all55_inputs_after"] and closed["all55_inputs_before_after_exact"] is True
assert set(closed["all55_inputs_before"]) == set(a["input_hashes"]) and len(a["input_hashes"]) == 55
mesh = a["MSH"]
for name, digest in a["input_hashes"].items():
    assert closed["all55_inputs_before"][name]["sha256"] == digest
    if name != mesh:
        assert identity(ROOT / name) == closed["all55_inputs_before"][name]
assert closed["all55_inputs_before"][mesh] == {"sha256": a["MSH_sha256"], "bytes": 235785726}
assert closed["actual_before"] == closed["actual_after"] == identity(ACT)
assert closed["index_before"] == closed["index_after"] == identity(INDEX)
for field, filename in [("preflight", "preflight.json"), ("materialization", "materialization.json"), ("launch", "launch.json"), ("controller_stdout", "controller.stdout.log"), ("controller_stderr", "controller.stderr.log")]:
    assert closed[field] == identity(RUN / filename)
launch = load(RUN / "launch.json")
assert launch["argv"] == index["outer_argv"] and launch["inner_argv_source_declared"] == index["inner_argv"]
assert type(launch["controller_pid"]) is int and launch["controller_pid"] > 0 and launch["controller_pgid_observed"] == launch["controller_pid"]
assert closed["controller_returncode"] == closed["worker_returncode"] == receipt["returncode"] == 0
assert closed["root_stop_reason"] is None and closed["root_controller_error"] is None and receipt["stop_reason"] is None
assert closed["SIGTERM_requested"] is False and closed["fallback_SIGKILL"] is False
assert closed["owned_controller_wait_reaped"] is True and closed["controller_PID_observed_absent_after_wait"] is True
assert closed["native_PID_directly_observed"] is False and launch["native_PID_directly_observed"] is False
assert closed["native3_before"] == closed["native3_after"] and {k: v["sha256"] for k, v in closed["native3_before"].items()} == a["external_runtime_hashes"]
assert closed["NumPy_init_before"] == closed["NumPy_init_after"] and closed["NumPy_init_before"]["sha256"] == a["numpy_init_sha256"]
assert closed["controller_python_before"] == closed["controller_python_after"] and closed["controller_python_before"]["sha256"] == index["root_outer_controls"]["python_sha256_metadata"]
assert closed["selected_native3_NumPy_Python_before_after_exact"] is True
for field, filename in [("reader_sha256", "reader.py"), ("runner_sha256", "run_readback.py"), ("native_log_sha256", "native.log"), ("readback_report_sha256", "readback-report.json"), ("contract_sha256", "frozen-contract.json")]:
    assert receipt[field] == inventory[filename]["sha256"]
assert receipt["scope"] == "one_stopped_Delaunay_saved_mesh_read_only" and receipt["native_generate_optimize_meshwrite_solve_calls"] == 0
assert (receipt["hard_wall_seconds"], receipt["sampled_RSS_stop_bytes"], receipt["sampled_output_stop_bytes"], receipt["threads"]) == (120, 8 * 1024**3, 1024**3, 2)
assert receipt["final_output_bytes_before_receipt"] == sum(v["bytes"] for k, v in inventory.items() if k != "execution-receipt.json")
assert 0 < receipt["wall_seconds"] < 120 and receipt["wall_seconds"] <= closed["root_wall_seconds"] < 135
samples = receipt["RSS_samples"]
assert all(type(s["RSS_bytes"]) is int and 0 <= s["RSS_bytes"] < 8 * 1024**3 and 0 <= s["wall_seconds"] < receipt["wall_seconds"] for s in samples)
assert [s["wall_seconds"] for s in samples] == sorted(s["wall_seconds"] for s in samples)
assert receipt["max_observed_RSS_bytes"] == max(s["RSS_bytes"] for s in samples)
obs, shell, first, parent = load(OBS), load(SHELL), load(FIRST), load(PARENT)
prior = parent["after"]
assert prior == parent["saved_reopen"]
assert report["status"] == "complete_current129_partial_head_apex1613790_context_census" and report["stage"] == "completed"
assert report["complete_context_census"] is True and report["bound_inputs_unchanged"] is True
assert report["full_array_sha256s"] == prior["array_sha256s"]
assert all(first[k] == v for k, v in report["full_array_sha256s"].items())
assert report["full_native_classifications"] == prior["classifications"] == first["direct_fresh_classifications"]
assert (report["full_node_count"], report["full_TET4_count"]) == (1097219, 3621755)
assert report["current_source_boundary_identity"] == prior["source_boundary_identity"]
assert report["retained_current_quality_and_global_incidence"] == {k: prior[k] for k in ("quality", "actual_tetra_boundary", "internal_tetra_face_orientation")}
assert report["retained_current_quality_and_global_incidence"]["quality"]["minimum_SICN"]["below_point1_count"] == 129
deviation = a["upstream_census_launch_deviation_sha256"]
for record in (a, report, closed, obs, shell):
    assert record["upstream_census_launch_deviation_sha256"] == deviation and record["declared_controller_command_conformant"] is False
assert report["original_parent_MSH_sha256"] == a["MSH_sha256"] and report["original_parent_MSH_bytes"] == a["MSH_bytes"]
assert report["runtime"] == a["expected_runtime"] and report["runtime_sha256s"] == a["runtime_sha256s"]
old = {r["tetrahedron_tag"]: r["node_tags"] for r in obs["native_ordered_cell_rows"]}
old_saved = report["complete_old_apex_incident_rows"]
assert old_saved == [{"tetrahedron_tag": t, "node_tags": old[t]} for t in sorted(old)] and len(old) == 28
census = first["complete_seed_star_census"]
assert {r["tetrahedron_tag"]: r["node_tags"] for r in census["complete_incident_tetrahedra"] if APEX in r["node_tags"]} == old
mapping = shell["local_to_global_node_tags"]
assert len(mapping) == 16 and mapping == sorted(set(mapping)) and APEX not in mapping
assert shell["global_to_local_node_tags"] == {str(t): i + 1 for i, t in enumerate(mapping)}
expected = {tuple(sorted(r["source_global_node_tags"])): r for r in shell["oriented_triangle_rows"]}
saved = report["all28_selected_shell_face_records"]
assert len(expected) == len(saved) == 28 and [tuple(r["shell_face_key"]) for r in saved] == list(expected)
outside, owner_multiplicity, triangle_tags = {}, collections.Counter(), set()
parts = collections.Counter()
face_ledger = []
for row in saved:
    key = tuple(row["shell_face_key"])
    source = expected[key]
    face = [mapping[t - 1] for t in source["local_node_tags"]]
    assert face == row["oriented_shell_face"] == source["source_global_node_tags"] and tuple(sorted(face)) == key
    owners, triangles = row["owners"], row["parent_exterior_TRI_rows"]
    inside = [v for v in owners if v["removed_star_owner"] is True]
    other = [v for v in owners if v["removed_star_owner"] is False]
    assert len(inside) == 1 and len(other) in (0, 1) and len(owners) == 1 + len(other)
    assert inside[0]["tetrahedron_tag"] == source["source_owner_tetrahedron_tag"]
    assert inside[0]["node_tags"] == old[inside[0]["tetrahedron_tag"]]
    for owner in owners:
        tag, nodes, pattern = owner["tetrahedron_tag"], owner["node_tags"], tuple(owner["native_corner_indices"])
        assert len(nodes) == len(set(nodes)) == 4 and pattern in FACES
        assert [nodes[i] for i in pattern] == owner["oriented_face"] and tuple(sorted(owner["oriented_face"])) == key
        assert owner["dimension"] == 3 and owner["entity_tag"] == 1
    assert tuple(inside[0]["oriented_face"]) in cyclic(face)
    if other:
        assert row["interface_kind"] == "internal_with_outside_owner" and triangles == []
        owner = other[0]
        assert tuple(owner["oriented_face"]) in cyclic(list(reversed(face))) and owner["tetrahedron_tag"] not in old and APEX not in owner["node_tags"]
        if owner["tetrahedron_tag"] in outside:
            assert outside[owner["tetrahedron_tag"]] == owner["node_tags"]
        outside[owner["tetrahedron_tag"]] = owner["node_tags"]
        owner_multiplicity[owner["tetrahedron_tag"]] += 1
    else:
        assert row["interface_kind"] == "parent_exterior" and len(triangles) == 1
        triangle = triangles[0]
        assert (triangle["dimension"], triangle["entity_tag"], triangle["element_type"]) == (2, 1, 2)
        assert tuple(triangle["node_tags"]) in cyclic(face) and triangle["element_tag"] not in triangle_tags
        triangle_tags.add(triangle["element_tag"])
    parts[row["interface_kind"]] += 1
    face_ledger.append({"key": list(key), "old_owner": inside[0]["tetrahedron_tag"], "outside_owner": other[0]["tetrahedron_tag"] if other else None, "interface_kind": row["interface_kind"]})
assert report["complete_outside_owner_rows"] == [{"tetrahedron_tag": t, "node_tags": outside[t]} for t in sorted(outside)]
points = {r["node_tag"]: r for r in obs["selected_node_rows"]}
selected = report["selected17_native_node_rows"]
assert [r["node_tag"] for r in selected] == sorted(points) and len(points) == 17
entity_pairs = {(r["dimension"], r["entity_tag"]) for r in report["full_entity_metadata"]}
class_counts = collections.Counter()
for row in selected:
    tag = row["node_tag"]
    assert words(row) == words(points[tag])
    assert row["dimension"] == (2 if tag <= 871731 else 3) and (row["dimension"], row["entity_tag"]) in entity_pairs
    assert row["available_parametric_coordinates"] == [] and row["parametric_binary64_hex"] == []
    class_counts[str(row["dimension"])] += 1
    if tag != APEX:
        vertex = shell["vertex_rows"][mapping.index(tag)]
        assert words(row).hex() == vertex["binary64_little_endian_bytes_hex"]
outside_nodes = report["complete_outside_owner_coordinate_rows"]
assert [r["node_tag"] for r in outside_nodes] == sorted({t for nodes in outside.values() for t in nodes})
census_nodes = {r["node_tag"]: r for r in census["unique_incident_nodes"]}
outside_census_join = 0
for row in outside_nodes:
    raw = words(row)
    if row["node_tag"] in census_nodes:
        assert raw == words(census_nodes[row["node_tag"]])
        outside_census_join += 1
    if row["node_tag"] in points:
        assert raw == words(points[row["node_tag"]])
pres = report["future_preservation_references"]
metadata = {}
for field, label in [("full_lower_dimensional_inventory", "full_lower_dimensional_inventory"), ("full_entity_metadata", "full_entity_metadata"), ("full_physical_group_metadata", "full_physical_group_metadata"), ("full_periodic_metadata", "full_periodic_metadata")]:
    metadata[label] = json_digest(report[field])
    assert metadata[label] == pres[label + "_sha256"]
assert metadata == parent["after_preservation"]["metadata_sha256s"]
assert pres["full_classification_proof_sha256"] == json_digest(report["full_native_classifications"])
params = report["full_entity_node_parameter_inventory"]
param_keys = ["dimension", "entity_tag", "count", "parameter_width", "node_tags_u64_sha256", "available_parameter_words_f64_sha256"]
assert pres["full_original_entity_parametric_metadata_sha256"] == json_digest([{k: row[k] for k in param_keys} for row in params])
assert {(r["dimension"], r["entity_tag"]) for r in params} == entity_pairs and sum(r["count"] for r in params) == report["full_node_count"]
assert {(r["dimension"], r["count"]) for r in params} == {(2, 871731), (3, 225488)}
for row in params:
    assert row["parameter_width"] == 0 and row["available_parameter_words_f64_sha256"] == hashlib.sha256(b"").hexdigest()
    for k in ("node_tags_u64_sha256", "coordinate_words_f64_sha256"):
        assert re.fullmatch("[0-9a-f]{64}", row[k])
surface = next(r for r in params if r["dimension"] == 2)
assert surface["node_tags_u64_sha256"] == report["current_source_boundary_identity"]["source_node_tags_sha256"]
assert surface["coordinate_words_f64_sha256"] == report["current_source_boundary_identity"]["source_coordinate_bits_sha256"]
assert pres["outside_nodes"] == report["full_node_count"] - 1 and pres["outside_TET4"] == report["full_TET4_count"] - len(old)
assert report["outside_mask_scope"]["excluded_apex_tags"] == [APEX] and report["outside_mask_scope"]["excluded_original_TET4_tags"] == sorted(old)
assert all(re.fullmatch("[0-9a-f]{64}", value) for key, value in pres.items() if key.endswith("sha256"))
assert all(type(v) is int and v > 0 for v in report["independently_derived_global_maxima"].values())
assert report["quality_recomputed"] is False and report["candidate_or_MSH_written"] is False and report["global_embedding_containment_or_after_edit_preservation_proved"] is False
for field in ["optimization_authorized", "mesh_write_authorized", "generation_authorized", "head_edit_authorized", "head_execution_authorized", "stitching_authorized", "engineering_accepted", "physics_qualified", "manufacturing_authorized"]:
    assert report[field] is False
after = {name: identity(ROOT / name) for name in bound}
assert after == before
result = {"schema": "962-current129-apex1613790-independent-saved-context-check/v1", "status": "PASS_SAVED_CONTEXT_ASSOCIATIONS_ONLY", "complete6_output_inventory": inventory, "output_bytes": sum(r["bytes"] for r in inventory.values()), "current_small_records_checked": len(bound), "all_before_after_exact": True, "original28_cell_and17_node_associations": True, "complete28_face_owner_corner_orientation_and_TRI_checks": True, "face_ledger": face_ledger, "shell_interface_partition": dict(parts), "unique_outside_owner_TET4": len(outside), "outside_owner_face_multiplicities": dict(collections.Counter(owner_multiplicity.values())), "outside_coordinate_nodes": len(outside_nodes), "outside_coordinate_rows_also_joined_to_census": outside_census_join, "selected17_class_counts": dict(class_counts), "selected_coordinate_hex_and_available_parameter_words_joined": True, "four_metadata_inventory_hashes_from_complete_saved_JSON_recomputed": metadata, "full_parameter_inventory_metadata": params, "full_parameter_count": sum(r["count"] for r in params), "parameter_projection_metadata_hash_recomputed": True, "full_unsaved_native_node_parameter_words_or_global_outside_digests_reconstructed": False, "reported_global_maxima_native_attributed": report["independently_derived_global_maxima"], "d60_declared_controller_command_conformant": False, "lifecycle_scope": "Root observed controller only; native PID not observed and cleanup attributed to exact4fb finally/wait and receipt. No direct PID checks by peer.", "native_quality_global_incidence_and_runtime_body_hashes_root_worker_attributed": True, "new_geometry_or_native_or_quality_replay": False}
with (HERE / "independent-saved-check.json").open("x") as stream:
    json.dump(result, stream, indent=2, allow_nan=False)
    stream.write("\n")
print(json.dumps({"status": result["status"], "faces": len(saved), "outside_cells": len(outside), "selected_nodes": len(selected), "parameters_scope_nodes": result["full_parameter_count"], "partition": dict(parts)}))
