"""One fixed stopped-file audit. Stdlib only; no producer imports or geometry formulas."""
from pathlib import Path
from collections import defaultdict
import hashlib
import json
import math
import struct

ROOT = Path(__file__).resolve().parents[3]
PEER = Path(__file__).resolve().parent
W = 'work/962-engineering/'
OUT = W + 'fixed-shell-netgen-apex1613790-001/'
EXEC = W + 'fixed-shell-netgen-apex1613790-root-execution-001/'
ACTUAL = W + 'fixed-shell-netgen-apex1613790-execution-prep-001/actual-contract-001.json'
INDEX = W + 'fixed-shell-netgen-apex1613790-execution-prep-001/index.json'
checks = []

def require(ok, label):
    if not ok:
        raise AssertionError(label)
    checks.append(label)

def body(name):
    path = ROOT / name
    require(not Path(name).is_absolute() and path.resolve().is_relative_to(ROOT), 'relative input: ' + name)
    require(path.is_file() and not path.is_symlink(), 'regular input: ' + name)
    return path.read_bytes()

def identity(name):
    data = body(name)
    return {'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data)}

def load(name):
    return json.loads(body(name))

def flatten(rows):
    for row in rows:
        if isinstance(row, list):
            yield from flatten(row)
        else:
            yield row

def packed(rows, code):
    return b''.join(struct.pack('<' + code, x) for x in flatten(rows))

def digest(rows, code):
    return hashlib.sha256(packed(rows, code)).hexdigest()

def rotation(row):
    return min(tuple(row[i:] + row[:i]) for i in range(3))

def distribution(values):
    require(bool(values) and all(type(x) in (int, float) and math.isfinite(x) for x in values), 'finite scalar vector')
    return {'count': len(values), 'minimum': min(values), 'maximum': max(values),
            'nonpositive_count': sum(x <= 0 for x in values), 'below_point1_count': sum(x < .1 for x in values),
            'array_sha256': digest(values, 'd')}

closed = load(EXEC + 'closed-result.json')
require(identity(EXEC + 'closed-result.json')['sha256'] == '3d387bf9675673a10319a4a54d7075f926a68cfac22ada3b882518d023bb8498', 'exact root closure')
actual = load(ACTUAL)
index = load(INDEX)
report = load(OUT + 'fixture-report.json')
arrays = load(OUT + 'arrays.json')
receipt = load(OUT + 'execution-receipt.json')
launch = load(EXEC + 'launch.json')
material = load(EXEC + 'materialization.json')
accepted = load(EXEC + 'child-peer-acceptance.json')
require(identity(ACTUAL)['sha256'] == closed['actual_sha256'] == index['actual']['sha256'] == report['frozen_contract_sha256'] == receipt['contract_sha256'], 'actual whole-file digest joins')
require(identity(INDEX)['sha256'] == closed['index_sha256'] == launch['index_sha256'], 'exact index joins')
require(body(ACTUAL) == body(OUT + 'frozen-contract.json'), 'whole frozen-contract is actual')
held = load(actual['source_held']['path'])
require(all(actual['input_hashes'].get(k) == v for k, v in held['input_hashes'].items()), 'all51 held input values preserved')
require(len(held['input_hashes']) == 51 and len(actual['input_hashes']) == 63, 'held51 and actual63 roles')
require(actual['input_hashes'] == index['all63_input_identity_values'] == closed['all63_input_hashes_before'] == closed['all63_input_hashes_after'], 'all63 root before-after and actual maps exact')
pins = dict(actual['input_hashes'])
pins.update(closed['external_records_before'])
require(closed['external_records_before'] == closed['external_records_after'], 'all5 external records stable')
for name in ('closed-result.json', 'launch.json', 'materialization.json', 'child-peer-acceptance.json', 'controller.stdout.log', 'controller.stderr.log'):
    pins[EXEC + name] = identity(EXEC + name)['sha256']
for name, record in closed['output_files'].items():
    pins[OUT + name] = record['sha256']
before = {name: identity(name) for name in sorted(pins)}
require(all(before[name]['sha256'] == value for name, value in pins.items()), 'all current selected body digests exact')
require(set(p.name for p in (ROOT / OUT).iterdir()) == set(closed['output_files']), 'sole eight-file output closure')
require(len(closed['output_files']) == 8 and sum(v['bytes'] for v in closed['output_files'].values()) == 108064, 'output eight and108064 bytes')
for name, value in closed['output_files'].items():
    require(before[OUT + name] == value, 'complete output identity: ' + name)
for name, value in material['files'].items():
    require(before[OUT + name] == value, 'materialized identity: ' + name)
require(identity(EXEC + 'launch.json')['sha256'] == closed['launch_sha256'], 'launch digest joins')
require(launch['controller_pid'] == launch['controller_pgid'] == closed['controller_pid'], 'root-owned controller leader joins')
require(launch['actual_sha256'] == accepted['actual_sha256'] == closed['actual_sha256'], 'external actual acceptance joins')
for field in ('peer_sha256', 'bindings_sha256'):
    require(launch[field] == accepted[field], 'external child join: ' + field)
require(launch['peer_sha256'] == closed['child_peer_sha256'] and launch['bindings_sha256'] == closed['child_bindings_sha256'], 'child closure joins')
require(launch['argv'] == index['root_planned_argv'], 'exact root argv')
require(closed['controller_returncode'] == closed['worker_returncode'] == receipt['returncode'] == 0, 'natural RC0 controller and worker')
require(all(closed[k] is None for k in ('root_stop_reason', 'worker_stop_reason', 'root_controller_error')) and receipt['stop_reason'] is None, 'no watchdog or controller error')
require(closed['SIGTERM_requested'] is False and closed['fallback_SIGKILL'] is False and closed['controller_wait_reaped'] is True and closed['owned_controller_observed_absent'] is True, 'root-owned wait and absence with no signals')
require(launch['native_PID_directly_observed'] is False and closed['native_PID_directly_observed'] is False, 'native PID unobserved')
require(closed['all63_before_after_unchanged'] is True and closed['selected3_runtime_NumPy_Python_before_after_unchanged'] is True, 'root immutable closure attestations')
require(closed['selected3_runtime_before'] == closed['selected3_runtime_after'] == actual['external_runtime_hashes'] and len(closed['selected3_runtime_before']) == 3, 'native3 metadata joins only')
require(closed['numpy_init_before'] == closed['numpy_init_after'] == actual['numpy_init_sha256_root_observed'], 'NumPy metadata joins only')
require(closed['python_before'] == closed['python_after'] == actual['root_controller_interpreter']['sha256'], 'controller Python metadata joins only')
require(report['runtime'] == actual['expected_runtime'] and report['runtime_sha256s'] == actual['runtime_sha256s'], 'worker observed runtime metadata joins')
require(report['fixture_procedural_checks_passed'] is True and report['actual_SICN_gate_passed'] is True and report['bound_inputs_unchanged'] is True, 'completed reported procedure and quality')
require(report['status'] == 'completed_specific_cavity_Netgen_only' and report['stage'] == 'completed_all_local_checks' and report['actual_SICN_threshold'] == .1, 'exact completed scope and strict threshold')
require(report['options'] == actual['options'] and report['native_operation_counts'] == receipt['declared_operation_counts'] == actual['declared_operation_counts'], 'options and attempted operations join declarations')
require(report['call_counts_are_attempts'] is True and receipt['operation_counts_are_declarations_not_observed'] is True, 'operation attribution exact')
require(receipt['scope'] == 'one_specific_saved_apex1435493_cavity_Netgen_witness', 'historical controller scope label preserved')
require(report['upstream_census_launch_deviation_sha256'] == actual['upstream_census_launch_deviation_sha256'] == closed['upstream_launch_deviation_sha256'] and report['declared_controller_command_conformant'] is False and actual['declared_controller_command_conformant'] is False and closed['upstream_declared_controller_command_conformant'] is False, 'd60 false conformance preserved')
for key in ('full_head_geometry_read', 'generation_authorized', 'head_execution_authorized', 'stitching_authorized', 'native_head_application_authorized', 'engineering_accepted', 'physics_qualified', 'manufacturing_authorized', 'global_self_intersection_checked', 'geometric_tetrahedron_overlap_checked', 'new_interior_node_point_in_cavity_containment_checked', 'interior_ancestry_inferred'):
    require(report[key] is False, 'bounded false report field: ' + key)
require(actual['automatic_retry'] is False and actual['domain_query_authorized'] is False and actual['PDE_solve_authorized'] is False, 'no retry/domain/PDE authority')
require(receipt['hard_wall_seconds'] == 30 and receipt['sampled_RSS_stop_bytes'] == 1024**3 and receipt['sampled_output_stop_bytes'] == 16*1024**2 and receipt['threads'] == 2, 'unchanged sampled controls')
require(receipt['hard_OS_CPU_quota_applied'] is False and receipt['hard_address_space_limit_applied'] is False, 'no hard CPU/address-space guarantee')
require(receipt['max_observed_RSS_bytes'] == max((s['RSS_bytes'] for s in receipt['RSS_samples']), default=0), 'RSS sample maximum')
require(receipt['final_output_bytes_before_receipt'] == 108064 - identity(OUT + 'execution-receipt.json')['bytes'], 'pre-receipt output total')
for field, name in [('reader_sha256','reader.py'), ('runner_sha256','run_readback.py'), ('native_log_sha256','native.log'), ('fixture_report_sha256','fixture-report.json')]:
    require(receipt[field] == before[OUT + name]['sha256'], 'receipt direct file: ' + name)
require(report['mesh_sha256'] == before[OUT + 'cavity.msh']['sha256'] and report['mesh_bytes'] == before[OUT + 'cavity.msh']['bytes'], 'tiny MSH opaque identity only')
require(report['full_tiny_arrays_sha256'] == before[OUT + 'arrays.json']['sha256'], 'full tiny array JSON identity')
require(report['gmsh_warnings_errors'] == [], 'worker recorded no warning/error rows')
log = body(OUT + 'native.log').decode()
require('Optimizing mesh (Netgen)' in log and '20 nodes' in log and '72 elements' in log and 'Error' not in log, 'complete native log saved associations')
baseline = load(W + 'fixed-shell-generation-apex1613790-001/arrays.json')['saved_reopen']
baseline_report = load(W + 'fixed-shell-generation-apex1613790-001/fixture-report.json')['saved_reopen']
require(arrays['before'] == baseline and report['before'] == baseline_report, 'complete single saved baseline unchanged')
require(arrays['before'] == arrays['after_geometry_flag'] and report['before'] == report['after_geometry_flag'], 'complete geometry-flag no-op')
require(arrays['after'] == arrays['saved_reopen'] and report['after'] == report['saved_reopen'], 'complete after/reopen equality')
shell = load(actual['local_shell_input'])
require(report['local_to_global_shell_node_tags'] == shell['local_to_global_node_tags'] and report['original_source_classifications'] == shell['original_source_classifications'], 'full original shell map/classes preserved')
require({k:int(v) for k,v in report['shell']['exact_volume_mm3'].items()} == {k:int(v) for k,v in shell['exact_enclosed_volume_mm3'].items()}, 'exact recorded reference volume association')
reference_volume = int(shell['exact_enclosed_volume_mm3']['numerator']) / int(shell['exact_enclosed_volume_mm3']['denominator'])
shell_points = [v['coordinates_mm'] for v in shell['vertex_rows']]
shell_faces = sorted(rotation(v['local_node_tags']) for v in shell['oriented_triangle_rows'])
stage_results = {}
require(set(arrays) == {'before','after_geometry_flag','after','saved_reopen'}, 'exact four saved stages')
for stage, a in arrays.items():
    r = report[stage]; nt = a['node_tags']; xyz = a['coordinates_mm']; et = a['tetra_tags']; conn = a['tetra_node_tags']; n = len(nt); m = len(et)
    require(nt == sorted(set(nt)) and et == sorted(set(et)) and all(type(t) is int and t > 0 for t in nt + et), stage + ' unique ordered positive tags')
    require(len(xyz) == n and all(len(row) == 3 for row in xyz) and all(type(x) in (int,float) and math.isfinite(x) for x in flatten(xyz)), stage + ' finite full coordinate rows')
    require(len(set(tuple(row) for row in xyz)) == n and len(conn) == m and all(len(row) == len(set(row)) == 4 for row in conn), stage + ' distinct coordinates and TET4 rows')
    require(set(flatten(conn)) == set(nt), stage + ' no missing or orphan nodes')
    canonical = sorted(sorted(row) for row in conn)
    require(len(set(tuple(row) for row in canonical)) == m, stage + ' no duplicate tagged tetrahedra')
    require(nt[:16] == list(range(1,17)) and packed(xyz[:16], 'd') == packed(shell_points,'d'), stage + ' all16 fixed binary64 coordinates')
    for v, row in zip(shell['vertex_rows'], xyz[:16]):
        require([float(x).hex() for x in row] == v['binary64_hex'] and packed(row,'d').hex() == v['binary64_little_endian_bytes_hex'], stage + ' original shell hex association')
    structural = {'sorted_node_tags_sha256': digest(nt,'Q'), 'sorted_coordinates_sha256': digest(xyz,'d'), 'tetra_tags_sha256': digest(et,'Q'), 'tagged_tetra_connectivity_sha256': digest(conn,'Q'), 'canonical_cells_sha256': digest(canonical,'Q')}
    require(all(r[k] == value for k, value in structural.items()), stage + ' five structural typed hashes')
    classes = [[tag, 2 if tag <= 16 else 3] for tag in nt]
    require(r['node_classifications'] == classes and r['node_entity_classifications'] == [[tag,dim,1] for tag,dim in classes], stage + ' complete local classification records')
    require(r['node_counts_by_classification_dimension'] == {'0':0,'1':0,'2':16,'3':n-16}, stage + ' dimension counts')
    require((r['nodes'],r['tetrahedra'],r['referenced_nodes'],r['referenced_interior_nodes'],r['unreferenced_nodes'],r['duplicate_tetrahedra']) == (n,m,n,n-16,0,0), stage + ' dynamic complete counts')
    metrics = {}
    require(set(a['native_qualities']) == {'SICN','Jacobian','native_volume_mm3'}, stage + ' exact native metric set')
    for name, values in a['native_qualities'].items():
        d = distribution(values)
        require(len(values) == m and d == r['quality'][name], stage + ' full saved metric summary/hash: ' + name)
        if name != 'SICN':
            require(all(x > 0 for x in values), stage + ' positive saved ' + name)
        metrics[name] = d
    signed = a['independent_signed_volume_mm3']; d = distribution(signed)
    require(len(signed) == m and all(x > 0 for x in signed), stage + ' complete positive stored signed volumes')
    require(all(r['independent_signed_volume_mm3'][k] == value for k, value in d.items()), stage + ' stored signed summary/hash')
    signed_sum = math.fsum(signed); native_sum = math.fsum(a['native_qualities']['native_volume_mm3'])
    require(signed_sum == r['independent_signed_volume_mm3']['sum'] and native_sum == r['native_volume_sum_mm3'], stage + ' saved scalar volume sums')
    require(abs(signed_sum/reference_volume-1) == r['independent_signed_volume_mm3']['relative_error'] <= 1e-6 and abs(native_sum/reference_volume-1) <= 1e-6, stage + ' unchanged recorded volume bookkeeping')
    faces = defaultdict(list)
    for row in conn:
        for omit in range(4):
            face = [row[i] for i in range(4) if i != omit]
            if omit % 2: face[1],face[2] = face[2],face[1]
            faces[tuple(sorted(face))].append(face)
    require(all(len(v) in (1,2) for v in faces.values()), stage + ' abstract incidence at most two')
    boundary = sorted(rotation(v[0]) for v in faces.values() if len(v) == 1)
    internal = [v for v in faces.values() if len(v) == 2]
    require(boundary == shell_faces and all(rotation(v[0]) == rotation(list(reversed(v[1]))) for v in internal), stage + ' abstract oriented shell and opposite internal facets')
    require(r['boundary_triangles'] == len(boundary) == 28 and r['internal_faces'] == len(internal) and r['same_oriented_internal_faces'] == r['nonmanifold_volume_faces'] == 0, stage + ' incidence summaries')
    require(r['no_curve_or_surface_periodic_mapping'] is True and r['periodic_entities_checked'] == [[2,1]], stage + ' worker periodic metadata')
    stage_results[stage] = {'nodes':n,'TET4':m,'interior_node_tags':[t for t in nt if t>16], 'boundary_faces':len(boundary), 'opposite_internal_faces':len(internal), 'structural_hashes':structural,'native_metric_summaries':metrics, 'stored_signed_volume_summary':r['independent_signed_volume_mm3'], 'native_volume_sum_mm3':native_sum}
require(min(arrays['after']['native_qualities']['SICN']) >= .1 and all(x > 0 for x in arrays['after']['native_qualities']['SICN']), 'all dynamic after cells meet strict stored SICN gate')
after = {name: identity(name) for name in sorted(pins)}
require(before == after, 'all selected input and output bodies unchanged during audit')
result = {'schema':'962-apex1613790-Netgen-independent-saved-check/v1','status':'PASS_SAVED_ASSOCIATIONS_ONLY','checks_completed':len(checks), 'input_and_output_identities':before,'root_actual_input_roles':len(actual['input_hashes']), 'output_inventory':closed['output_files'],'output_count':8,'output_bytes':108064,'stages':stage_results,'all_selected_bodies_before_after_exact':True,'root_lifecycle':{'controller_RC':0,'worker_RC':0,'root_stop':None,'native_PID_observed':False,'controller_wait_reaped_and_absent_root_attributed':True,'native_cleanup':'Exactee558 finally/receipt-attributed only'},'scope':'Saved JSON/byte/IEEE754 summaries and abstract tagged-facet combinatorics only. No determinant, SICN formula, geometry/pair/containment/domain predicate, MSH decode, producer/helper/guard, scientific/native or runtime-body replay. Native classifications/periodic state and native metric values remain worker observations.', 'upstream_declared_controller_command_conformant':False,'head_execution_authorized':False,'engineering_accepted':False,'physics_qualified':False,'manufacturing_authorized':False}
with (PEER/'independent-saved-check.json').open('x') as stream:
    json.dump(result,stream,indent=2,allow_nan=False);stream.write('\n')
print(json.dumps({'status':result['status'],'checks':len(checks),'stages':{k:{q:v[q] for q in ('nodes','TET4','interior_node_tags')} for k,v in stage_results.items()}},sort_keys=True))
