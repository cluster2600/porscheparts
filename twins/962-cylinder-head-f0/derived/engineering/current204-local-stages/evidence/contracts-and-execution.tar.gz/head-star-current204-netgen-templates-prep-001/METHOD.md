# Remaining115 held Netgen binding templates

Data-only preparation after the closed remaining115 generation invocation. All115
were natural procedural completions with strict SICN rejection and the existing
`one_Netgen` route. Apex1393275 is excluded and remains held without retry.

The115 JSON templates are NOT actuals and cannot authorize native work. Peer and
root acceptance are deliberately null; all execution/review/qualification flags
are false. No output/source materialization was made. The exact38af worker,1e6
controller,fc1 cavity and3a55 finite manifest remain untouched. No new launcher,
program copies, test, import, runtime or geometry/native operation was prepared
or executed. The root source review/guards already bound by the common38-pin map
remain historical observations, not a fresh runtime or result acceptance.

The index contains one shared binding object and its explicit JSON-encoding
digest; each template repeats that digest and has six same-case direct pins
(mesh/report/arrays/receipt/frozen generation actual/per-case root closure).
This avoids a whole-index/template hash cycle. Before a future actual, root must
merge the common input map with all six case pins, add exact stopped peer/root
acceptance and future review records, freshly hash inputs/native3/NumPy, and
freeze/review the full consumed actual. Materialize only exact reader/controller
and that actual as frozen-contract.json after approval by the separate process.
Do not materialize these held templates.

All115 JSON report/array/receipt/actual/closure joins and current source maps were
read/hashed with stdlib before and after; dynamic node/TET/interior/quality and
storage values are retained from each actual saved generation record. No old
57/11 state is transferred. Mesh digest/size is attributed to the exact root
closed inventories and matching worker reports; only mesh lstat/size/mtime was
independently checked, with no body read, hash or decode. This is association
preparation, not an independent geometry/metric or lifecycle proof.

Netgen policy/options/counts are copied from exact literal worker assignments:
one volume geometry-flag operation, one forced Netgen call, one cache rebuild,
one write; zero generation/solve. The objective threshold .3 is unchanged and
strict acceptance remains all SICN>=.1 with the existing other native gates.
30s, sampled1GiB RSS/16MiB output, requested2threads, root outer40s and existing
owned cleanup remain; these are not hard OS quotas. A result requires fresh full
before/after/reopen/shell audits. Domain admission only after a strict pass with
I>=1 and M>=K; otherwise hold. No rerank, backfill, retry, head/stitch/PDE or
physical/material/process/manufacturing authority follows from these files.
