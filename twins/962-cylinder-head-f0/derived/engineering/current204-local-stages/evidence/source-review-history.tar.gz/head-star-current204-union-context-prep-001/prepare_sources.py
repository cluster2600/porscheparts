"""Source-only donor adaptation; no prepared functions or native/runtime bodies."""
from pathlib import Path
import ast,difflib,hashlib,json
ROOT=Path(__file__).resolve().parents[3];PREP=Path(__file__).resolve().parent
BASE='work/962-engineering/';sha=lambda b:hashlib.sha256(b).hexdigest()
donor=BASE+'direct-sicn-apex1474426-head-context-prep-001/reader.py'
old=(ROOT/donor).read_text();new=old
paths={
 'MESH':BASE+'apex1474426-head-application-001/head-volume.msh',
 'WORKER':BASE+'apex1474426-head-application-001/readback-report.json',
 'RECEIPT':BASE+'apex1474426-head-application-001/execution-receipt.json',
 'FIRST':BASE+'head-star-current204-full-stars-001/readback-report.json',
 'CLASS_HELPER':BASE+'head-star-current204-full-stars-prep-001/reader.py',
 'FIRST_CONTRACT':BASE+'head-star-current204-full-stars-001/frozen-contract.json',
 'CLOSED':BASE+'apex1474426-head-application-root-execution-001/closed-result.json',
 'CENSUS_PEER':BASE+'head-star-current204-full-stars-result-peer-001/review.json',
 'BATCH':BASE+'head-star-current204-batch-shells-001/report.json',
 'MANIFEST':BASE+'head-star-current204-local-stages-prep-001/case-manifest.json'}
ms='4c6543f8e905c2771f9f313e5e131d06d081928deafb8dd5b43b18d9d2c73a3f'
fixed={}
extra=[BASE+'head-star-current204-full-stars-001/execution-receipt.json',BASE+'head-star-current204-full-stars-root-execution-001/closed-result.json',BASE+'head-star-current204-full-stars-root-execution-001/result-review.json',BASE+'head-star-current204-full-stars-root-execution-001/result-peer-acceptance.json',BASE+'head-star-current204-batch-shells-001/receipt.json',BASE+'head-star-current204-batch-shells-execution-prep-001/actual-contract.json',BASE+'head-star-current204-batch-shells-root-execution-001/closed-result.json',BASE+'head-star-current204-batch-shells-root-execution-001/result-review.json',BASE+'head-star-current204-batch-shells-root-execution-001/result-peer-acceptance.json',BASE+'head-star-current204-batch-shells-result-peer-001/review.json',BASE+'head-star-current204-local-stages-prep-001/held-contract.json',BASE+'head-star-current204-local-stages-source-peer-001/review.json',BASE+'head-star-current204-finite-batch-plan-001/NOTE.md','twins/962-cylinder-head-f0/source/mesh_head.py']
for path in list(paths.values())+extra:
 fixed[path]=ms if path==paths['MESH'] else sha((ROOT/path).read_bytes())
start=new.index("OUTPUT='");end=new.index('RUNTIME=',start)
block="OUTPUT='work/962-engineering/head-star-current204-union-context-001'\nMSH_SHA='"+ms+"'\n"
block+='\n'.join(k+'='+repr(v) for k,v in paths.items())+'\n'
block+="MESH_HELPER='twins/962-cylinder-head-f0/source/mesh_head.py'\nFIXED_INPUTS="+repr(fixed)+"\nFACES=((0,2,1),(0,1,3),(1,2,3),(2,0,3));CHUNK=100000;BOUNDARY=871731\n"
new=new[:start]+block+new[end:]
new=new.replace('HELD read-only current partial-head apex1474426 context census; no candidate, quality or geometry writes.','HELD read-only current204 selected116 union parent-context census; no candidate or geometry writes.')
new=new.replace('962-apex1474426-current-head-context/v1','962-current204-selected116-union-head-context/v1').replace('235742918','235744782').replace("prior['expected_positive_poor_total']!=208","prior['expected_positive_poor_total']!=204")
new=new.replace("peer.get('decision')!='CLEAR_COMPLETED_READ_ONLY_CURRENT208_CENSUS_MESH_REMAINS_REJECTED'","peer.get('decision')!='CLEAR_COMPLETED_READ_ONLY_CENSUS_WHOLE_HEAD_QUALITY_REJECTED'")
new=new.replace("peer['bindings']['report']['sha256']!=FIXED_INPUTS[FIRST] or peer['blockers']!=[] or peer['head_volume_accepted'] is not False","peer['records']['worker_report']['sha256']!=FIXED_INPUTS[FIRST] or peer['blockers']!=[] or peer['engineering_accepted'] is not False")
new=new.replace("helpers['require_after_match'](first,proof,208)","helpers['require_after_match'](first,proof,204)")
start=new.index('def selection_records(');end=new.index('\ndef main():',start)
one=new[start:end].replace('def selection_records(observation,shell):','def one_case_records(observation,shell,case):\n APEX=case[\'apex\'];NV=case[\'shell_nodes\'];NF=case[\'shell_faces\'];K=case[\'old_tetrahedra\'];NB=case[\'original_boundary_shell_nodes\']')
one=one.replace('Specific original60/33/32 map and native owner/corner identity; no candidate.','One selected complete star and exact native owner/corner/word association; no candidate.')
for a,b in [('len(cells)!=60','len(cells)!=K'),('len(old)!=60','len(old)!=K'),('len(points)!=33','len(points)!=NV+1'),('len(old_points)!=33','len(old_points)!=NV+1'),('len(mapping)!=32','len(mapping)!=NV'),('len(source_boundary)!=27','len(source_boundary)!=NB'),('len(other)!=5','len(other)!=NV-NB'),('len(vertices)!=32','len(vertices)!=NV'),('len(rows)!=60','len(rows)!=NF'),('t>32','t>NV')]:one=one.replace(a,b)
one=one.replace('Specific current original60/33 and32shell identity required','Exact selected complete-star/shell identity required').replace('Original27 boundary and5 other dim3 shell tags required','Original per-case boundary and other-interior shell tags required').replace('All32 original coordinate rows required','All original shell coordinate rows required').replace('Complete60 shell faces required','Every selected case shell face required').replace('Exact local1..32 shell triangles required','Exact per-case local shell triangles required')
selection='''
def encoded(value):
 return (json.dumps(value,indent=2,allow_nan=False)+'\\n').encode()

def merge_case_records(cases,records,census_cells,census_nodes):
 old={};old_points={};faces={};boundary=set();shell_tags=set();by_apex={};summaries=[];used=set()
 for case in cases:
  apex=case['apex'];record=records[apex]
  if (record.get('eligible') is not True or set(record['all_vertex_tags'])&used
      or hashlib.sha256(encoded(record)).hexdigest()!=case['source_record_sha256']):
   raise ValueError('Selected whole vertex sets must remain disjoint and exact')
  used.update(record['all_vertex_tags']);observation=record['observation'];shell=record['shell']
  for value,key in [(shell,'shell_serialized_sha256'),(observation,'observation_serialized_sha256'),(record['necessary_face_screen'],'screen_serialized_sha256')]:
   if hashlib.sha256(encoded(value)).hexdigest()!=case[key]:raise ValueError('Exact selected embedded body identity changed')
  complete=[r for r in census_cells if apex in r['node_tags']]
  if (complete!=observation['native_ordered_cell_rows'] or len(complete)!=case['old_tetrahedra']
      or [r['tetrahedron_tag'] for r in complete]!=case['old_tetrahedron_tags']
      or sorted({t for r in complete for t in r['node_tags']})!=case['old_vertex_tags']
      or any(census_nodes[r['node_tag']]!=r for r in observation['selected_node_rows'])):
   raise ValueError('Every current complete incident cell including good/shared context must match')
  a,b,mapping,expected,original_boundary=one_case_records(observation,shell,case)
  if set(old)&set(a) or set(old_points)&set(b) or set(faces)&set(expected):raise ValueError('Selected cell, vertex or face collision refused')
  old.update(a);old_points.update(b);faces.update(expected);boundary.update(original_boundary);shell_tags.update(mapping);by_apex[apex]=a
  summaries.append({'apex':apex,'case_key':case['case_key'],'case_record_sha256':case['source_record_sha256'],
   'old_tetrahedra':case['old_tetrahedra'],'shell_nodes':case['shell_nodes'],'shell_faces':case['shell_faces'],
   'original_boundary_shell_nodes':case['original_boundary_shell_nodes'],'old_cell_tags':sorted(a),
   'shell_node_tags':mapping,'shell_face_keys':[list(k) for k in sorted(expected)]})
 return old,old_points,sorted(shell_tags),faces,boundary,by_apex,summaries

def selection_records(manifest,batch,first):
 cases=manifest['cases_in_increasing_apex_order'];tags=[r['apex'] for r in cases];star=first['complete_seed_star_census']
 if (manifest.get('schema')!='962-current204-finite-local-stage-manifest/v1' or manifest['selected_count']!=116
     or len(tags)!=116 or tags!=sorted(set(tags)) or set(tags)!=set(batch['selected_apex_tags'])
     or manifest['source_batch_report_sha256']!=FIXED_INPUTS[BATCH] or batch['source_census_sha256']!=FIXED_INPUTS[FIRST]
     or manifest['source_parent_MSH_sha256']!=MSH_SHA or batch['source_MSH_sha256']!=MSH_SHA
     or batch['source_current_positive_poor_cells']!=204 or star['movable_count']!=154
     or not set(tags)<=set(star['movable_node_tags']) or star['complete_incident_tetrahedron_count']!=5267):
  raise ValueError('Exact current154-seed census and frozen selected116 manifest required')
 records={r['apex']:r for r in batch['all_candidate_star_records']};nodes={r['node_tag']:r for r in star['unique_incident_nodes']}
 answer=merge_case_records(cases,records,star['complete_incident_tetrahedra'],nodes)
 if (len(answer[0]),len(answer[1]),len(answer[2]),len(answer[3]),len(answer[5]))!=(4164,2430,2314,4164,116):
  raise ValueError('Exact selected union old-cells/vertices/shells/faces/apices required')
 return answer

def mask_exclusions(apices,old,tags,element_tags):
 a=sorted(apices);e=sorted(old)
 if not a or len(a)!=len(set(a)) or not set(a)<=set(map(int,tags)) or not e or not set(e)<=set(map(int,element_tags)):
  raise ValueError('Every exact selected apex and old-cell exclusion must exist in the full arrays')
 return a,e
'''
new=new[:start]+one+'\n'+selection+new[end:]
new=new.replace("  observation=json.loads((ROOT/OBS).read_text());shell=json.loads((ROOT/SHELL).read_text())\n  old,old_points,mapping,expected_faces,original_boundary=selection_records(observation,shell)","  manifest=json.loads((ROOT/MANIFEST).read_text());batch=json.loads((ROOT/BATCH).read_text())\n  old,old_points,mapping,expected_faces,original_boundary,by_apex,case_summaries=selection_records(manifest,batch,first)")
new=new.replace('(1097050,3620820)','(1097057,3620861)')
new=new.replace('apex_rows={}','apex_rows={apex:{} for apex in by_apex}')
new=new.replace("   for j in np.flatnonzero(np.any(conn==APEX,axis=1)):\n    apex_rows[int(et[startrow+j])]=conn[j].tolist()","   for j in np.flatnonzero(np.any(np.isin(conn,np.asarray(sorted(by_apex),dtype='<u8')),axis=1)):\n    row=conn[j].tolist();present=set(row)&set(by_apex)\n    if len(present)!=1:raise ValueError('Selected apices unexpectedly share a current tetrahedron')\n    apex_rows[next(iter(present))][int(et[startrow+j])]=row")
new=new.replace("  if apex_rows!=old:raise ValueError('Complete original apex incidence/order differs; outside apex use refused')","  if apex_rows!=by_apex:raise ValueError('Every selected apex complete incidence/order differs; omitted good/outside use refused')")
new=new.replace("  entities=sorted((int(d),int(t)) for d,t in gmsh.model.getEntities());entity_rows=[];lower=[];periodic=[];max_element=int(et.max());all_lower_tags=[]","  entities=sorted((int(d),int(t)) for d,t in gmsh.model.getEntities());entity_rows=[];lower=[];periodic=[];max_element=int(et.max());all_lower_tags=[]\n  parameter_inventory=[];node_seen=np.zeros(len(tags),dtype=np.uint8)")
needle="   entity_rows.append({'dimension':dim,'entity_tag':entity,'oriented_immediate_boundary':boundary,'name':gmsh.model.getEntityName(dim,entity)})"
extra='''
   owned,owned_xyz,owned_param=gmsh.model.mesh.getNodes(dim,entity,False,True)
   owned=np.asarray(owned,dtype='<u8');ix=np.argsort(owned);owned=owned[ix];where=np.searchsorted(tags,owned)
   owned_xyz=np.asarray(owned_xyz,dtype='<f8').reshape(-1,3)[ix];parameter_width=dim if len(owned_param) else 0
   if (len(np.unique(owned))!=len(owned) or np.any(where>=len(tags)) or not np.array_equal(tags[where],owned)
       or np.any(node_seen[where]) or owned_xyz.tobytes()!=np.asarray(xyz[where],dtype='<f8').tobytes()
       or len(owned_param) not in (0,len(owned)*dim)):
    raise ValueError('Complete entity ownership/coordinate/available-parametric association changed')
   node_seen[where]=1
   params=np.asarray(owned_param,dtype='<f8').reshape(len(owned),parameter_width)[ix] if parameter_width else np.empty((len(owned),0),dtype='<f8')
   if not np.isfinite(params).all():raise ValueError('Finite full original parameter rows required')
   parameter_inventory.append({'dimension':dim,'entity_tag':entity,'count':len(owned),'parameter_width':parameter_width,
    'node_tags_u64_sha256':arrsha(owned),'coordinate_words_f64_sha256':arrsha(owned_xyz),'available_parameter_words_f64_sha256':arrsha(params)})'''
new=new.replace(needle,needle+extra)
new=new.replace("  lower.sort(key=lambda row:(row['dimension'],row['entity_tag'],row['element_type']))","  if not np.all(node_seen==1):raise ValueError('Every original node entity/parameter row must be captured once')\n  lower.sort(key=lambda row:(row['dimension'],row['entity_tag'],row['element_type']))")
new=new.replace("   if int(tags[index])!=tag:raise ValueError('Outside owner references absent node')","   if index>=len(tags) or int(tags[index])!=tag:raise ValueError('Outside owner references absent node')")
new=new.replace("  node_mask=tags!=APEX;cell_mask=~np.isin(et,np.asarray(sorted(old),dtype='<u8'))","  excluded_nodes,excluded_cells=mask_exclusions(by_apex,old,tags,et)\n  node_mask=~np.isin(tags,np.asarray(excluded_nodes,dtype='<u8'));cell_mask=~np.isin(et,np.asarray(excluded_cells,dtype='<u8'))")
new=new.replace("'full_classification_proof_sha256':json_sha(classes)}","'full_classification_proof_sha256':json_sha(classes),'full_original_entity_parametric_metadata_sha256':json_sha(parameter_projection(parameter_inventory))}")
new=new.replace("status='complete_current_partial_head_apex1474426_context_census'","status='complete_current204_selected116_union_parent_context_census'")
new=new.replace("   complete_old_apex_incident_rows=[{'tetrahedron_tag':t,'node_tags':old[t]} for t in sorted(old)],\n   all60_selected_shell_face_records=joined,", "   selected_case_contexts=case_summaries,selected_apex_tags=sorted(by_apex),complete_old_selected_apex_incident_rows=[{'tetrahedron_tag':t,'node_tags':old[t]} for t in sorted(old)],\n   all_selected_shell_face_records=joined,")
new=new.replace('selected33_native_node_rows=selected_nodes','selected_original_native_node_rows=selected_nodes')
new=new.replace("   full_entity_metadata=entity_rows,full_physical_group_metadata=groups,full_periodic_metadata=periodic,","   full_entity_metadata=entity_rows,full_physical_group_metadata=groups,full_periodic_metadata=periodic,full_entity_node_parameter_inventory=parameter_inventory,")
new=new.replace("quality_and_global_incidence='Retained current partial.after/saved only; no native qualities or global incidence recomputed.'","quality_and_global_incidence='Current204 partial.after/saved quality and whole-head face-incidence retained only; complete selected116 apex/face-owner lookup is freshly scanned.'")
new=new.replace('Selected33 coordinate/class/entity/param join failed','Selected union coordinate/class/entity/param join failed')
extra_functions='''def parameter_projection(inventory):
 return [{k:row[k] for k in ['dimension','entity_tag','count','parameter_width','node_tags_u64_sha256','available_parameter_words_f64_sha256']} for row in inventory]

def validate_maxima(node_max,element_max,native_node_max,native_element_max):
 if any(type(v) is not int or v<=0 for v in [node_max,element_max,native_node_max,native_element_max]) or (node_max,element_max)!=(native_node_max,native_element_max):
  raise ValueError('Native maxima must equal independent complete all-dimensional arrays')
 return {'node':node_max,'element_all_dimensions':element_max}

'''.replace('\n+','\n')
new=new.replace('def main():',extra_functions+'def main():',1)
new=new.replace("  actual_max={'node':int(tags.max()),'element_all_dimensions':max_element}\n  if (int(gmsh.model.mesh.getMaxNodeTag()),int(gmsh.model.mesh.getMaxElementTag()))!=(actual_max['node'],max_element):\n   raise ValueError('Native maxima differ from complete independent all-dimensional arrays')","  actual_max=validate_maxima(int(tags.max()),max_element,int(gmsh.model.mesh.getMaxNodeTag()),int(gmsh.model.mesh.getMaxElementTag()))")
ast.parse(new);(PREP/'reader.py').write_text(new)
runner_source=BASE+'direct-sicn-apex1474426-head-context-prep-001/run_readback.py';runner=(ROOT/runner_source).read_text()
changed=runner.replace('one_stopped_Delaunay_saved_mesh_read_only','one_current204_selected116_union_parent_context_read_only')
(PREP/'run_readback.py').write_text(changed)
for name,a,b,source,target in [('source',old,new,donor,'reader.py'),('controller',runner,changed,runner_source,'run_readback.py')]:
 (PREP/(name+'.diff')).write_text(''.join(difflib.unified_diff(a.splitlines(True),b.splitlines(True),fromfile=source,tofile=str((PREP/target).relative_to(ROOT)))))
print(json.dumps({'reader_sha256':sha(new.encode()),'runner_sha256':sha(changed.encode()),'fixed_input_count':len(fixed),'parent_body_read':False,'prepared_functions_tests_or_imports_executed':False},indent=2))
