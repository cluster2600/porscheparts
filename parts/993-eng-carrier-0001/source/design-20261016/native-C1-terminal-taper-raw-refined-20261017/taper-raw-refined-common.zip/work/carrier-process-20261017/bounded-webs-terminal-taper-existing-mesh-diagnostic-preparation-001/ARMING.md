# Metadata-only arming, after a separate ROOT GO

Preserve all three pending JSON objects. In a new plan.json set launch_ready=true and root_GO_sha256 to the actual existing root_GO path's digest; append that single GO path/digest to files_sha256 and recompute input_count/input_bytes. Removing that pin, restoring the original counts, false readiness and null GO digest must recover the entire pending plan.

Create launch-plan.json with status=armed_existing_raw_mesh_diagnostic and launch_ready=true. Change child command indices 4 and 6 to the new absolute plan path and its digest. Replace the pending-plan input entry with the new plan entry and add the same actual GO pin. No other input, source, command or resource change is allowed. Invert all these fields and require whole-object equality with pending-launch-plan.json.

Create command.json with status=ready_for_one_authorized_execution, root_GO_pending=false; replace supervisor argv indices 4 and 6 by the absolute actual launch path and its digest. The four-field inverse must equal command-pending.json. Verify all fresh pins and closed metadata guards, the absent output/execution directories, and all three whole-object inverses before an authorized run. The supervisor parent is not niced. No native execution is authorized by this document.
