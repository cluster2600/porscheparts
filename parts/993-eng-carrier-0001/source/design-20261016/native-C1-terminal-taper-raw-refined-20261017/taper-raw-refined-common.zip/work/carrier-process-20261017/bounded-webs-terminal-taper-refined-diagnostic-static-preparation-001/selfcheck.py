"""Retained small solver/deck fixtures plus raw diagnostic identity/scope checks."""
import ast
import copy
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

H=Path(__file__).resolve().parent;R=H.parents[2]
C=R/'work/carrier-process-20261017/bounded-webs-C1-terminal-taper-static-preparation-001'
def load(name,path):
    s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
retained=load('_retained_taper_deck_fixtures',C/'selfcheck.py');m=load('_raw_refined_diagnostic_static',H/'run.py')

class NewTests(unittest.TestCase):
    def plan(self,case='rigid'):return json.loads((H/f'{case}-pending-plan.json').read_text())
    def test_entire_inverse_and_unchanged_deck_solver_functions(self):
        d=json.loads((H/'source-changes.json').read_text());text=(H/'run.py').read_text();back=text
        for row in reversed(d['replacements']):
            self.assertEqual(back.count(row['after']),1);back=back.replace(row['after'],row['before'],1)
        self.assertEqual(back,(R/d['original_source']).read_text())
        old={n.name:ast.dump(n,include_attributes=False)for n in ast.parse(back).body if isinstance(n,ast.FunctionDef)}
        new={n.name:ast.dump(n,include_attributes=False)for n in ast.parse(text).body if isinstance(n,ast.FunctionDef)}
        for name in ['make_execute','deck_contract','prepare_execute','verify_coarse_deck','prepare']:
            self.assertEqual(old[name],new[name])
        current={n.name:ast.dump(n,include_attributes=False)for n in ast.parse((C/'run.py').read_text()).body if isinstance(n,ast.FunctionDef)}
        for name in ['verify_mesh','verify_protected_root','verify_protected']:self.assertEqual(new[name],current[name])
        for name in d['unchanged_postprocess_sources']:
            self.assertEqual((H/'postprocess'/name).read_bytes(),(C/'postprocess'/name).read_bytes())
    def test_actual_parent_import_and_full_protected_guards(self):
        p=self.plan();m.verify_mesh(p);m.verify_protected_root(p);m.verify_protected(p)
        self.assertEqual(p['expected_new_import_observation']['relative_volume_difference'],-7.771561172376096e-16)
    def test_actual_raw_diagnostic_and_same_taper_coarse_guards(self):
        for case in ['rigid','spring']:m.verify_diagnostic_mesh(self.plan(case))
    def test_missing_ROOT_or_crossed_mesh_refuses(self):
        for key in ['diagnostic_root_review_sha256','coarse_cases_ROOT_sha256']:
            p=self.plan();p[key]=None
            with self.subTest(key=key),self.assertRaises(ValueError):m.verify_diagnostic_mesh(p)
        p=self.plan();p['mesh_files_sha256']['mesh.inp']='0'*64
        with self.assertRaisesRegex(ValueError,'raw mesh identity'):m.verify_diagnostic_mesh(p)
    def test_unchanged_raw_BREP_binding_and_eyes(self):
        binding=load('_raw_BREP_binding',H/'postprocess/cad_binding.py');p=self.plan();folder=R/p['mesh_source'];answer=binding.verify(folder,json.loads((folder/'mesh.json').read_text()))
        self.assertEqual(answer['sha256'],p['BREP_sha256'])
        p=self.plan('spring');contract=p['planned_support_contract'];self.assertEqual(contract['eye_node_counts'],[2274,2278]);self.assertEqual(contract['SPRING1_elements'],13656);self.assertEqual(contract['K_per_node_by_eye_N_mm'],[1000/2274,1000/2278])
    def test_unarmed_before_any_mesh_or_science(self):
        with tempfile.TemporaryDirectory()as tmp:
            path=Path(tmp)/'plan.json';path.write_text(json.dumps(dict(launch_ready=False)))
            with self.assertRaisesRegex(ValueError,'not armed'):m.verified(json.loads(path.read_text()),m.sha(path),path)
    def test_scope_keeps_h2_and_candidate_false(self):
        tree=ast.parse((H/'run.py').read_text());run=next(n for n in tree.body if isinstance(n,ast.FunctionDef)and n.name=='run');text=ast.unparse(run)
        self.assertIn('candidate_qualified=False',text);self.assertIn('h2_qualified=False',text);self.assertIn('strict_H2_volume_refusal_preserved=True',text)
        self.assertNotIn('h2_qualified=True',text)
        for row in tree.body:
            if isinstance(row,(ast.Import,ast.ImportFrom)):self.assertFalse(any(n.name.startswith(('numpy','gmsh','skfem'))for n in row.names))
    def test_two_actual_same_CAD_coarse_baselines_only(self):
        for case in ['rigid','spring']:
            p=self.plan(case);self.assertEqual(p['coarse_cases_ROOT_sha256'],'15c76fbdfc9563bc296b4a567c1218bee99d6fe7a6889171c2514ec75d2ff287');self.assertEqual(len(p['baselines']),1);self.assertEqual(p['baselines'][0]['mesh'],'same_taper_coarse_global7');self.assertFalse(p['candidate_qualified']);self.assertFalse(p['h2_qualified'])

if __name__=='__main__':
    suite=unittest.TestSuite([unittest.defaultTestLoader.loadTestsFromTestCase(retained.old.retained.Checks),unittest.defaultTestLoader.loadTestsFromTestCase(retained.old.NewChecks),unittest.defaultTestLoader.loadTestsFromTestCase(retained.previous.NewChecks),unittest.defaultTestLoader.loadTestsFromTestCase(NewTests)])
    raise SystemExit(not unittest.TextTestRunner(verbosity=2).run(suite).wasSuccessful())
