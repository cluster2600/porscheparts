"""Closed-proof and strict whole-measure contracts; no scientific imports."""
import ast
import importlib.util
import json
import math
import struct
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('unarmed_existing_mesh_qualification',HERE/'run.py')
r=importlib.util.module_from_spec(spec);spec.loader.exec_module(r)


def write(root,name,data):
    (root/name).write_text(json.dumps(data));return name


def volume_fixture(root):
    write(root,'left.inp','never parsed');write(root,'right.inp','never parsed')
    plan=dict(pair_terminal='terminal.json',pair_assessment='assessment.json',pair_supervision='supervision.json',pair_root_review='review.json',
              CAD_adaptive_master_volume_mm3=2.,meshes=[dict(id='left',inp='left.inp'),dict(id='right',inp='right.inp')],
              files_sha256={'left.inp':r.sha(root/'left.inp'),'right.inp':r.sha(root/'right.inp')})
    volume=dict(mm3=1.,float_hex=1..hex(),binary64_big_endian_hex='3ff0000000000000')
    lower=math.nextafter(1.,0.);right=dict(mm3=lower,float_hex=lower.hex(),binary64_big_endian_hex=struct.pack('>d',lower).hex())
    comparison=dict(binary64_equal=False,exact_difference_of_observed_binary64_mm3='-1/9007199254740992',baseline_serialized=volume,candidate_serialized=right,admission=False,historical_volume_guard_overridden=False)
    rows=[dict(id=x['id'],mesh_INP_sha256=plan['files_sha256'][x['inp']],volume=volume if x['id']=='left' else right,
               imported_node_and_element_identity_checked=True,quality=dict(finite=True,nonpositive_elements=0,minimum_Jacobian=.1)) for x in plan['meshes']]
    actual=dict(status='two_serialized_new_taper_volumes_measured_no_admission',sources_unchanged=True,plan_unchanged=True,h2_qualified=False,historical_volume_guard_overridden=False,
                comparison=comparison,rows=rows,same_adaptive_CAD_reference=dict(mm3=2.))
    supervision=dict(actual_returncode=0,direct_child_reaped=True,final_group_members=[],timeout=False,interrupted=False,sources_and_plan_unchanged=True)
    write(root,'assessment.json',actual);write(root,'supervision.json',supervision)
    terminal=dict(actual_tool_returncode=0,actual_child_returncode=0,direct_child_reaped=True,final_group_members=[],all_fresh_pins_equal=True,whole_before_after_maps_equal=True,
                  assessment_sha256=r.sha(root/'assessment.json'),supervision_sha256=r.sha(root/'supervision.json'),comparison=comparison)
    write(root,'terminal.json',terminal)
    review=dict(schema='root-new-taper-serialized-pair-terminal-1',actual_tool_RC=0,all7_whole_outputs_verified=True,h2_qualified=False,candidate_qualified=False,terminal_sha256=r.sha(root/'terminal.json'),assessment_sha256=r.sha(root/'assessment.json'),supervision_sha256=r.sha(root/'supervision.json'),volume_comparison=comparison,rows=rows)
    write(root,'review.json',review)
    return plan


def pass_fixture(root,wrong_previous=False):
    (root/'proofs').mkdir();protected={'1,2,3':['bolt0']};records=[];events=[];previous=None;proof_shas={};review_passes=[]
    for i in range(4):
        name=f'pass-{i+1:04d}.json'
        d=dict(previous_pass_proof_sha256=None if wrong_previous and i==1 else previous,protected_facets_unchanged=True,
               all_input_nodes_used_and_IDs_XYZ_unchanged=True,protected_facets=protected,input_nodes=10+i,output_nodes=11+i,input_elements=2+i,output_elements=3+i)
        write(root/'proofs',name,d);digest=r.sha(root/'proofs'/name);previous=digest;proof_shas[name]=digest
        records.append(dict(proof=name,proof_sha256=digest));events.extend([dict(event='pass_start'),dict(event='pass_finish',proof_sha256=digest)]);review_passes.append(dict(proof_sha256=digest))
    events.append(dict(event='targets_reached',marked=0));(root/'passes.jsonl').write_text(''.join(json.dumps(x)+'\n' for x in events))
    a=dict(adaptive_passes=records,h2_qualified=False,volume_error_non_regression=False,pass_proof_artifacts_sha256=proof_shas,protected_facets=protected,
           protected_facets_unchanged_at_every_pass=True,all_original_nodes_IDs_XYZ_unchanged_and_used=True,original_NPZ_XYZ_block_preserved=True,original_INP_NODE_lexemes_preserved=True)
    write(root,'h2-assessment.json',a);write(root,'h2-supervision.json',dict(actual_returncode=1));write(root,'h2-terminal.json',dict(actual_tool_returncode=1,assessment_sha256=r.sha(root/'h2-assessment.json'),supervision_sha256=r.sha(root/'h2-supervision.json')))
    review=dict(terminal_sha256=r.sha(root/'h2-terminal.json'),assessment_sha256=r.sha(root/'h2-assessment.json'),supervision_sha256=r.sha(root/'h2-supervision.json'),actual_tool_RC=1,h2_qualified=False,all_four_whole_proofs_and_journal_finish_rows_joined=True,actual_PGID_freshly_absent=True)
    write(root,'h2-review.json',review)
    return dict(h2_assessment='h2-assessment.json',h2_supervision='h2-supervision.json',h2_terminal='h2-terminal.json',h2_root_review='h2-review.json',passes_journal='passes.jsonl',passes_directory='proofs',files_sha256={'proofs/'+k:v for k,v in proof_shas.items()})


class Checks(unittest.TestCase):
    def test_unequal_closed_volume_observation_never_admits(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);plan=volume_fixture(root)
            with patch.object(r,'ROOT',root):result=r.volume_authority(plan)
            self.assertFalse(result['comparison']['binary64_equal']);self.assertTrue(result['diagnostic_only']);self.assertFalse(result['volume_admission']);self.assertFalse(result['comparison']['admission']);self.assertFalse(result['comparison']['historical_volume_guard_overridden'])

    def test_crossed_receipts_or_wrong_rows_refuse(self):
        for kind in ['hash','row']:
            with self.subTest(kind=kind),tempfile.TemporaryDirectory() as tmp:
                root=Path(tmp);plan=volume_fixture(root)
                if kind=='hash':
                    f=root/'terminal.json';d=json.loads(f.read_text());d['assessment_sha256']='0'*64;f.write_text(json.dumps(d))
                else:
                    f=root/'review.json';d=json.loads(f.read_text());d['rows'][1]['volume']['mm3']=1.5;f.write_text(json.dumps(d))
                with patch.object(r,'ROOT',root),self.assertRaises(ValueError):r.volume_authority(plan)

    def test_four_complete_closed_passes_and_stale_chain(self):
        for bad in [False,True]:
            with self.subTest(bad=bad),tempfile.TemporaryDirectory() as tmp:
                root=Path(tmp);plan=pass_fixture(root,bad)
                with patch.object(r,'ROOT',root):
                    if bad:
                        with self.assertRaisesRegex(ValueError,'ancestry'):r.pass_authority(plan)
                    else:
                        proof=r.pass_authority(plan);self.assertEqual(len(proof['proofs']),4);self.assertFalse(proof['original_run_h2_qualified'])

    def test_whole_h_target_not_inferred_from_mark0(self):
        rows=[dict(target_attained=True,measured_h_mm=.5,target_h_mm=.5)]*2;r.accept_measurements(rows)
        for wrong in [dict(target_attained=False,measured_h_mm=.5,target_h_mm=.5,marked=0),dict(target_attained=True,measured_h_mm=.5000000000000001,target_h_mm=.5)]:
            with self.subTest(wrong=wrong),self.assertRaises(ValueError):r.accept_measurements([rows[0],wrong])
        with self.assertRaises(ValueError):r.accept_measurements(rows[:1])

    def test_protected_midside_IDs_are_exact_not_nearest(self):
        pairs=((0,1),(1,2),(2,0),(0,3),(1,3),(2,3));face=[(1,2,3)];base=(1,2,3,4,5,6,7,8,9,10)
        self.assertEqual(r.protected_edge_mids({1:base},face,pairs),{(1,2):5,(2,3):6,(1,3):7})
        wrong=(1,2,3,4,50,6,7,8,9,10)
        with self.assertRaisesRegex(ValueError,'Inconsistent'):r.protected_edge_mids({1:base,2:wrong},face,pairs)

    def test_entire_original_measure_call_and_no_refinement_or_Gmsh(self):
        tree=ast.parse((HERE/'run.py').read_text());calls=[n for n in ast.walk(tree) if isinstance(n,ast.Call)]
        measure=[n for n in calls if ast.unparse(n.func)=='measure.region_edges'];self.assertEqual(len(measure),1)
        self.assertEqual([ast.unparse(x) for x in measure[0].args],['points','elements','region'])
        self.assertFalse(any(any(x in ast.unparse(n.func) for x in ['refine_with_ledger','adaptive_refine','gmsh.','solve(']) for n in calls))
        for n in tree.body:
            if isinstance(n,(ast.Import,ast.ImportFrom)):self.assertFalse(any(x.name.startswith(('numpy','gmsh','skfem')) for x in n.names))

    def test_unarmed_before_import_or_actual_mesh(self):
        with tempfile.TemporaryDirectory() as tmp:
            f=Path(tmp)/'plan.json';f.write_text(json.dumps(dict(launch_ready=False)))
            with self.assertRaisesRegex(ValueError,'unarmed'):r.run(f,r.sha(f))

    def test_whole_source_inverse_and_diagnostic_scope(self):
        record=json.loads((HERE/'source-changes.json').read_text());text=(HERE/'run.py').read_text();back=text
        for c in reversed(record['replacements']):back=back.replace(c['new'],c['old'])
        self.assertEqual(back,(r.ROOT/record['original_path']).read_text())
        old={n.name:ast.dump(n,include_attributes=False)for n in ast.parse(back).body if isinstance(n,ast.FunctionDef)}
        new={n.name:ast.dump(n,include_attributes=False)for n in ast.parse(text).body if isinstance(n,ast.FunctionDef)}
        self.assertEqual({k for k in old if old[k]!=new[k]},{'volume_authority','pass_authority','run'})
        self.assertNotIn('h2_qualified_under_distinct_serialized_reference=True',text)
        self.assertIn('h2_qualified=False,candidate_qualified=False,law_original_RC1_preserved=True',text)


if __name__=='__main__':unittest.main()
