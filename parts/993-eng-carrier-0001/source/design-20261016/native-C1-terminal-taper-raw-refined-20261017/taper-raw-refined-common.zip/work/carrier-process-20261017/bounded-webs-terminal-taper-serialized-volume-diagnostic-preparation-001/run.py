"""Two read-only serialized new-taper volume evaluations; preserve the actual h2 refusal."""
import argparse
from fractions import Fraction
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import resource
import signal
import struct
import sys
import time

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]


def require(ok, message):
    if not ok: raise ValueError(message)


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda: f.read(1024 * 1024), b''): h.update(b)
    return h.hexdigest()


def write(path, value):
    with Path(path).open('x') as f:
        json.dump(value, f, indent=2, allow_nan=False); f.write('\n'); f.flush(); os.fsync(f.fileno())


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec); spec.loader.exec_module(module); return module


def number(value):
    require(type(value) is float and math.isfinite(value) and value > 0, 'Finite positive binary64 volume required')
    return dict(mm3=value, float_hex=value.hex(), binary64_big_endian_hex=struct.pack('>d', value).hex())


def pair_comparison(baseline, candidate):
    left, right = number(baseline), number(candidate)
    return dict(baseline_serialized=left, candidate_serialized=right,
                binary64_equal=left['binary64_big_endian_hex'] == right['binary64_big_endian_hex'],
                exact_difference_of_observed_binary64_mm3=str(Fraction(candidate)-Fraction(baseline)),
                admission=False, historical_volume_guard_overridden=False)


def verify_closed_refusal(plan):
    terminal = json.loads((ROOT / plan['h2_terminal']).read_text())
    assessment = json.loads((ROOT / plan['h2_assessment']).read_text())
    supervision = json.loads((ROOT / plan['h2_supervision']).read_text())
    review = json.loads((ROOT / plan['h2_ROOT_review']).read_text())
    parent = json.loads((ROOT / plan['parent_terminal']).read_text())
    parent_review = json.loads((ROOT / plan['parent_ROOT_review']).read_text())
    require(terminal['actual_tool_returncode'] == terminal['actual_child_returncode'] == 1
            and terminal['direct_child_reaped'] and terminal['owned_group_freshly_absent']
            and terminal['all_current_pins_and_whole_maps_equal'] and not terminal['h2_qualified']
            and not terminal['FEA_started'], 'Actual refused new-taper refinement not closed')
    require(terminal['assessment_sha256'] == sha(ROOT / plan['h2_assessment'])
            and terminal['supervision_sha256'] == sha(ROOT / plan['h2_supervision']), 'Closed new-taper refusal SHA join differs')
    require(review['schema'] == 'root-new-taper-H2-strict-refusal-terminal-1'
            and review['actual_tool_RC'] == 1 and review['terminal_sha256'] == sha(ROOT / plan['h2_terminal'])
            and review['all_sources_and_maps_freshly_equal'] and review['actual_PGID_freshly_absent']
            and review['all_four_whole_proofs_and_journal_finish_rows_joined']
            and review['h2_qualified'] is False and review['FEA_started'] is False, 'New-taper ROOT refusal join differs')
    require(supervision['actual_returncode'] == 1 and supervision['direct_child_reaped']
            and not supervision['final_group_members'] and not supervision['timeout']
            and supervision['sources_and_plan_unchanged'], 'Refused new-taper group not closed')
    require(assessment['error']['message'] == 'Original volume non-regression gate failed'
            and assessment['volume_error_non_regression'] is False and assessment['h2_qualified'] is False
            and assessment['pins_unchanged'] and assessment['plan_unchanged'], 'Original volume refusal changed')
    require(terminal['all_whole_outputs'][plan['meshes'][1]['inp']]['sha256'] == plan['files_sha256'][plan['meshes'][1]['inp']], 'Actual refused mesh payload differs')
    require(parent_review['schema'] == 'root-new-taper-T10-terminal-1' and parent_review['actual_tool_RC'] == 0
            and parent_review['terminal_sha256'] == sha(ROOT / plan['parent_terminal'])
            and parent_review['all18_whole_outputs_verified'] and parent_review['fresh_PGID_absent']
            and parent_review['BREP_sha256'] == plan['BREP_sha256']
            and parent_review['BREP_import']['adaptive_master_volume_mm3'] == plan['CAD_adaptive_master_volume_mm3'], 'Closed parent new-taper mesh join differs')
    parent_key = str(Path(plan['meshes'][0]['inp']).relative_to(Path(plan['parent_terminal']).parent))
    require(parent['whole_outputs'][parent_key]['sha256'] == plan['files_sha256'][plan['meshes'][0]['inp']]
            and (parent_review['node_count'], parent_review['C3D10_count']) == (plan['meshes'][0]['nodes'], plan['meshes'][0]['elements'])
            and (review['raw_nodes'], review['raw_C3D10_elements']) == (plan['meshes'][1]['nodes'], plan['meshes'][1]['elements']), 'Actual serialized pair payload/counts differ')


def read_one(mesh, energy, ordering, gmsh, np):
    """The exact Gmsh block from the refused C1 source, applied independently."""
    rt, rx, re, ri = energy.read_mesh(mesh)
    report = {}
    gmsh.initialize()
    try:
        gmsh.option.setNumber('General.Terminal', 0); gmsh.option.setNumber('General.NumThreads', 1)
        permutation = ordering.type11_permutation(gmsh.model.mesh.getElementProperties(11))
        inverse = [permutation.index(i) for i in range(10)]
        report['CCX_positions_for_native_type11'] = permutation
        entity = gmsh.model.addDiscreteEntity(3)
        gmsh.model.mesh.addNodes(3, entity, rt.tolist(), rx.ravel().tolist())
        gmsh.model.mesh.addElementsByType(entity, 11, re.tolist(), rt[ri[:, permutation]].ravel().tolist())
        kinds, eid, conn = gmsh.model.mesh.getElements(3)
        require(list(kinds) == [11] and len(eid[0]) == len(re), 'Gmsh import topology mismatch')
        order = np.argsort(eid[0]); require(np.array_equal(eid[0][order], re)
            and np.array_equal(np.asarray(conn[0]).reshape(-1, 10)[:, inverse][order], rt[ri]), 'Gmsh imported connectivity changed')
        gt, gx, _ = gmsh.model.mesh.getNodes(); order = np.argsort(gt)
        require(np.array_equal(gt[order], rt) and np.array_equal(np.asarray(gx).reshape(-1, 3)[order], rx), 'Gmsh imported coordinates changed')
        jac = gmsh.model.mesh.getElementQualities(eid[0], 'minDetJac')
        volumes = gmsh.model.mesh.getElementQualities(eid[0], 'volume')
        require(np.isfinite(jac).all() and min(jac) > 0 and np.isfinite(volumes).all() and min(volumes) > 0, 'Original Gmsh Jacobian/volume guard')
        volume = float(volumes.sum())
        quality = dict(minimum_Jacobian=float(min(jac)), nonpositive_elements=int(np.count_nonzero(jac <= 0)), finite=True, elements=len(jac))
    finally: gmsh.finalize()
    return dict(nodes=len(rt), elements=len(re), quality=quality, volume=number(volume),
                CCX_positions_for_native_type11=report['CCX_positions_for_native_type11'],
                imported_node_and_element_identity_checked=True,
                sum_order='Original INP injection and Gmsh getElements return order, exactly as C1 h2; volumes.sum().')


def run(plan_path, expected):
    started = time.monotonic(); plan_path = Path(plan_path)
    require(sha(plan_path) == expected, 'Plan drift')
    plan = json.loads(plan_path.read_text())
    require(plan['launch_ready'] and plan['root_GO_sha256'] is not None, 'Volume diagnostic remains unarmed')
    require(sha(ROOT / plan['root_GO']) == plan['root_GO_sha256'], 'Root GO differs')
    require(plan['outer_seconds'] == 180 and plan['inner_seconds'] == 150 and plan['CPU_seconds'] == [140,160]
            and plan['threads'] == 1 and plan['workers'] == 0, 'Read-only resources differ')
    require([row['id'] for row in plan['meshes']] == ['parent_serialized_new_taper', 'candidate_refused_h2'], 'Only two fixed serialized meshes allowed')
    require(os.getpriority(os.PRIO_PROCESS, 0) == 10 and all(os.environ.get(k) == '1' for k in
            ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS')), 'nice10/one thread required')
    signal.signal(signal.SIGALRM, lambda *_: (_ for _ in ()).throw(TimeoutError('150s read-only serialized pair cap')))
    signal.setitimer(signal.ITIMER_REAL,150); resource.setrlimit(resource.RLIMIT_CPU,(140,160))
    pins = plan['files_sha256']; before = {n:sha(ROOT/n) for n in pins}; require(before == pins, 'Input/source/runtime differs')
    verify_closed_refusal(plan)
    output = ROOT / plan['output_directory']; require(not output.exists() and not output.is_symlink(), 'Fresh diagnostic output required'); output.mkdir()
    report = dict(status='incomplete_readonly_pair', rows=[], plan_sha256=expected,
                  no_CAD_import=True, mesh_generated=False, refinement_repeated=False, FEA_started=False,
                  h2_qualified=False, historical_volume_guard_overridden=False)
    error = None
    try:
        sys.path.insert(0,str(ROOT/plan['gmsh_site_packages']))
        import numpy as np
        import gmsh
        require(gmsh.__version__ == '4.15.2' and Path(gmsh.__file__).resolve() == (ROOT/plan['gmsh_module']).resolve(), 'Pinned Gmsh runtime differs')
        energy = load('unchanged_serialized_energy_reader',ROOT/plan['energy_reader'])
        ordering = load('unchanged_native_type11_order',ROOT/plan['type11_helper'])
        for row in plan['meshes']:
            result = read_one(ROOT/row['inp'],energy,ordering,gmsh,np)
            require((result['nodes'],result['elements']) == (row['nodes'],row['elements']), 'Actual serialized mesh counts differ')
            metadata = json.loads((ROOT/row['metadata']).read_text())
            result.update(id=row['id'], mesh_INP_sha256=sha(ROOT/row['inp']),
                          historical_metadata_volume=number(metadata['mesh_volume_mm3']),
                          historical_metadata_relative_volume_error=metadata['volume_relative_error'],
                          serialized_relative_to_same_adaptive_CAD=result['volume']['mm3']/plan['CAD_adaptive_master_volume_mm3']-1)
            write(output/(row['id']+'.json'),result); report['rows'].append(result)
        report['comparison'] = pair_comparison(report['rows'][0]['volume']['mm3'],report['rows'][1]['volume']['mm3'])
        report['same_adaptive_CAD_reference'] = number(plan['CAD_adaptive_master_volume_mm3'])
        report['closed_baseline_energy_volumes'] = [dict(path=name,volume=number(json.loads((ROOT/name).read_text())['volume_mm3'])) for name in plan['baseline_energy_reports']]
        report['status'] = 'two_serialized_new_taper_volumes_measured_no_admission'
    except BaseException as exc:
        error = exc; report['error'] = dict(type=type(exc).__name__,message=str(exc))
    finally:
        signal.setitimer(signal.ITIMER_REAL,0)
    after = {n:sha(ROOT/n) for n in pins}
    report.update(sources_before=before,sources_after=after,sources_unchanged=before==after,
                  plan_unchanged=sha(plan_path)==expected,wall_seconds=time.monotonic()-started,
                  peak_RSS_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,actual_workers=0)
    write(output/'assessment.json',report)
    require(before==after and report['plan_unchanged'],'Frozen pair diagnostic input changed')
    if error is not None: raise error
    print(json.dumps(dict(status=report['status'],binary64_equal=report['comparison']['binary64_equal'],assessment_sha256=sha(output/'assessment.json'))),flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('plan');parser.add_argument('--plan-sha256',required=True)
    args=parser.parse_args();run(args.plan,args.plan_sha256)
