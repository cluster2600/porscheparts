"""Retained stdlib adaptive guards and exact new closed two-region bindings."""
import ast
import copy
import importlib.util
import json
from pathlib import Path
import unittest

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
OLD = ROOT / 'work/carrier-process-20261017/bounded-webs-C1-discrete-refinement-preparation-001'


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


r = load('_unarmed_new_taper_h2', HERE / 'run.py')
retained = load('_old_discrete_guards', ROOT / 'work/carrier-process-20261017/bounded-webs-discrete-real-preparation-002/selfcheck.py')
prior = load('_old_C1_discrete_guards', OLD / 'selfcheck.py')
retained.r = prior.r = r
retained.HERE = HERE


class NewBindings(unittest.TestCase):
    def data(self):
        return (json.loads((HERE / 'pending-plan.json').read_text()),
                json.loads((HERE / 'peak-rois.json').read_text())['regions'])

    def test_full_source_inverse_and_unchanged_bodies(self):
        text = (HERE / 'run.py').read_text()
        for change in reversed(json.loads((HERE / 'source-changes.json').read_text())['replacements']):
            self.assertEqual(text.count(change['after']), 1)
            text = text.replace(change['after'], change['before'])
        self.assertEqual(text, (OLD / 'run.py').read_text())
        functions = lambda p: {n.name: ast.dump(n, include_attributes=False) for n in ast.parse(p.read_text()).body if isinstance(n, ast.FunctionDef)}
        old, new = functions(OLD / 'run.py'), functions(HERE / 'run.py')
        for name in set(old) - {'verify_C1_cases', 'main'}:
            self.assertEqual(old[name], new[name], name)

    def test_two_actual_distinct_ROIs(self):
        plan, regions = self.data()
        r.verify_C1_cases(plan, regions)
        self.assertNotEqual(regions[0]['bounds_mm'], regions[1]['bounds_mm'])
        self.assertEqual([v['target_h_mm'] for v in regions], [0.46689539918333095, 0.7584314239141896])
        self.assertLess(regions[0]['reference_IP_xyz_mm'][0], 0)
        self.assertGreater(regions[1]['reference_IP_xyz_mm'][0], 0)

    def test_old_h2_target_or_box_refuses(self):
        for field, value in [('target_h_mm', 0.4668954269534402), ('bounds_mm', [[0, 0, 0], [1, 1, 1]])]:
            plan, regions = self.data()
            regions[0][field] = value
            with self.assertRaises(ValueError):
                r.verify_C1_cases(plan, regions)

    def test_swapped_case_refuses(self):
        plan, regions = self.data()
        plan['cases']['rigid'] = copy.deepcopy(plan['cases']['spring'])
        with self.assertRaises(ValueError):
            r.verify_C1_cases(plan, regions)

    def test_foreign_CAD_refuses(self):
        plan, regions = self.data()
        plan['BREP_sha256'] = '0' * 64
        with self.assertRaises(ValueError):
            r.verify_C1_cases(plan, regions)

    def test_unchanged_resource_and_scientific_limits(self):
        plan, _ = self.data()
        self.assertEqual([plan['outer_seconds'], plan['inner_alarm_seconds'], plan['CPU_seconds']], [1200, 1150, [1100, 1101]])
        self.assertEqual([plan['maximum_nodes'], plan['maximum_elements']], [500000, 500000])
        source = (HERE / 'run.py').read_text()
        self.assertIn("abs(meta['volume_relative_error']) <= abs(reference['volume_relative_error'])", source)
        self.assertIn("require(all(r['target_attained'] for r in measured)", source)
        self.assertIn('closed.verify_protected_root(plan)', source)


if __name__ == '__main__':
    excluded = {'test_current_metadata_does_not_inherit_Gmsh_sizing', 'test_parent_layout_exact_and_exclusive'}
    suite = unittest.TestSuite([retained.Checks(n) for n in unittest.defaultTestLoader.getTestCaseNames(retained.Checks) if n not in excluded])
    suite.addTest(prior.NewChecks('test_current_BREP_metadata_no_false_STEP_or_Gmsh'))
    suite.addTest(prior.NewChecks('test_explicit_BREP_parent_layout_exclusive'))
    suite.addTests(unittest.defaultTestLoader.loadTestsFromTestCase(NewBindings))
    raise SystemExit(not unittest.TextTestRunner(verbosity=2).run(suite).wasSuccessful())
