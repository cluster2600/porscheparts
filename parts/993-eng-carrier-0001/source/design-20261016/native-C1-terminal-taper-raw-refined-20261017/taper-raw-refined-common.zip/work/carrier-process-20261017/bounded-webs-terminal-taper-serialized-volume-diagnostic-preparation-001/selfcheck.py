"""Pure serialization/binding/source contracts; no NumPy/Gmsh/mesh import."""
import ast
import importlib.util
import json
import math
from pathlib import Path
import struct
import tempfile
import textwrap
import unittest
from unittest.mock import patch

HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('unarmed_serialized_pair',HERE/'run.py')
r=importlib.util.module_from_spec(spec);spec.loader.exec_module(r)


def fixture(root):
    def write(name,data):
        (root/name).write_text(json.dumps(data));return name
    candidate=write('candidate.inp','synthetic identity, not a mesh')
    parent_inp=write('parent.inp','synthetic parent, not a mesh')
    plan=dict(h2_terminal='terminal.json',h2_assessment='assessment.json',h2_supervision='supervision.json',
              h2_ROOT_review='review.json',parent_terminal='parent-terminal.json',parent_ROOT_review='parent-review.json',
              BREP_sha256='b'*64,CAD_adaptive_master_volume_mm3=1.,
              meshes=[dict(id='parent_serialized_new_taper',inp=parent_inp,nodes=4,elements=1),dict(id='candidate_refused_h2',inp=candidate,nodes=5,elements=2)],
              files_sha256={candidate:r.sha(root/candidate),parent_inp:r.sha(root/parent_inp)})
    write('assessment.json',dict(error=dict(message='Original volume non-regression gate failed'),
          volume_error_non_regression=False,h2_qualified=False,pins_unchanged=True,plan_unchanged=True))
    write('supervision.json',dict(actual_returncode=1,direct_child_reaped=True,final_group_members=[],timeout=False,sources_and_plan_unchanged=True))
    write('terminal.json',dict(actual_tool_returncode=1,actual_child_returncode=1,direct_child_reaped=True,owned_group_freshly_absent=True,
          all_current_pins_and_whole_maps_equal=True,h2_qualified=False,FEA_started=False,
          assessment_sha256=r.sha(root/'assessment.json'),supervision_sha256=r.sha(root/'supervision.json'),
          all_whole_outputs={candidate:dict(sha256=r.sha(root/candidate))}))
    write('review.json',dict(schema='root-new-taper-H2-strict-refusal-terminal-1',actual_tool_RC=1,terminal_sha256=r.sha(root/'terminal.json'),
          all_sources_and_maps_freshly_equal=True,actual_PGID_freshly_absent=True,all_four_whole_proofs_and_journal_finish_rows_joined=True,
          h2_qualified=False,FEA_started=False,raw_nodes=5,raw_C3D10_elements=2))
    write('parent-terminal.json',dict(whole_outputs={parent_inp:dict(sha256=r.sha(root/parent_inp))}))
    write('parent-review.json',dict(schema='root-new-taper-T10-terminal-1',actual_tool_RC=0,terminal_sha256=r.sha(root/'parent-terminal.json'),
          all18_whole_outputs_verified=True,fresh_PGID_absent=True,BREP_sha256='b'*64,BREP_import=dict(adaptive_master_volume_mm3=1.),node_count=4,C3D10_count=1))
    return plan

class Checks(unittest.TestCase):
    def test_Gmsh_block_exact_and_no_generation(self):
        record=json.loads((HERE/'gmsh-block-provenance.json').read_text())
        text=(HERE/'run.py').read_text();tree=ast.parse(text)
        fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='read_one')
        segment=ast.get_source_segment(text,fn)
        start=segment.index('    gmsh.initialize()\n');end=segment.index('    finally: gmsh.finalize()\n')+len('    finally: gmsh.finalize()\n')
        self.assertEqual(textwrap.dedent(segment[start:end]),record['extracted_block'])
        calls={ast.unparse(n.func) for n in ast.walk(tree) if isinstance(n,ast.Call) and ast.unparse(n.func).startswith('gmsh.')}
        self.assertEqual(calls,{'gmsh.initialize','gmsh.finalize','gmsh.option.setNumber','gmsh.model.mesh.getElementProperties',
            'gmsh.model.addDiscreteEntity','gmsh.model.mesh.addNodes','gmsh.model.mesh.addElementsByType',
            'gmsh.model.mesh.getElements','gmsh.model.mesh.getNodes','gmsh.model.mesh.getElementQualities'})

    def test_binary64_and_JSON_roundtrip(self):
        for value in [285536.3061386665,1.,math.nextafter(1.,math.inf),float.fromhex('0x0.0000000000001p-1022')]:
            d=json.loads(json.dumps(r.number(value)))
            self.assertEqual(struct.pack('>d',d['mm3']).hex(),d['binary64_big_endian_hex'])
            self.assertEqual(float.fromhex(d['float_hex']),value)

    def test_zero_tolerance_comparison_never_admits(self):
        same=r.pair_comparison(1.,1.);near=r.pair_comparison(1.,math.nextafter(1.,math.inf))
        self.assertTrue(same['binary64_equal']);self.assertEqual(same['exact_difference_of_observed_binary64_mm3'],'0')
        self.assertFalse(near['binary64_equal']);self.assertNotEqual(near['exact_difference_of_observed_binary64_mm3'],'0')
        self.assertFalse(same['admission']);self.assertFalse(same['historical_volume_guard_overridden'])
        for v in [0.,-0.,-1.,True,float('nan'),float('inf')]:
            with self.subTest(value=v),self.assertRaises(ValueError):r.number(v)

    def test_closed_actual_refusal_passes_without_adopting(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);plan=fixture(root)
            with patch.object(r,'ROOT',root):r.verify_closed_refusal(plan)

    def test_wrong_return_or_crossed_assessment_refuses(self):
        for key,value in [('actual_child_returncode',0),('assessment_sha256','0'*64)]:
            with self.subTest(key=key),tempfile.TemporaryDirectory() as tmp:
                root=Path(tmp);plan=fixture(root);f=root/'terminal.json';d=json.loads(f.read_text());d[key]=value;f.write_text(json.dumps(d))
                with patch.object(r,'ROOT',root),self.assertRaises(ValueError):r.verify_closed_refusal(plan)

    def test_wrong_candidate_payload_refuses(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);plan=fixture(root);plan['files_sha256']['candidate.inp']='0'*64
            with patch.object(r,'ROOT',root),self.assertRaisesRegex(ValueError,'payload'):r.verify_closed_refusal(plan)

    def test_unarmed_before_scientific_import_or_data(self):
        with tempfile.TemporaryDirectory() as tmp:
            f=Path(tmp)/'plan.json';f.write_text(json.dumps(dict(launch_ready=False)))
            with self.assertRaisesRegex(ValueError,'unarmed'):r.run(f,r.sha(f))
        for node in ast.parse((HERE/'run.py').read_text()).body:
            if isinstance(node,(ast.Import,ast.ImportFrom)):
                self.assertFalse(any(n.name.startswith(('numpy','gmsh','skfem')) for n in node.names))

    def test_wrong_ROOT_or_parent_payload_refuses(self):
        for name,key,value in [('review.json','terminal_sha256','0'*64),('parent-review.json','BREP_sha256','0'*64)]:
            with self.subTest(name=name),tempfile.TemporaryDirectory() as tmp:
                root=Path(tmp);plan=fixture(root);f=root/name;d=json.loads(f.read_text());d[key]=value;f.write_text(json.dumps(d))
                with patch.object(r,'ROOT',root),self.assertRaises(ValueError):r.verify_closed_refusal(plan)

    def test_whole_inverse_and_unchanged_numeric_functions(self):
        record=json.loads((HERE/'source-changes.json').read_text());new=(HERE/'run.py').read_text();back=new
        for c in reversed(record['replacements']):
            self.assertEqual(back.count(c['new']),1);back=back.replace(c['new'],c['old'])
        self.assertEqual(r.sha(r.ROOT/record['original_source']),record['original_sha256'])
        self.assertEqual(back,(r.ROOT/record['original_source']).read_text())
        before={n.name:ast.dump(n,include_attributes=False) for n in ast.parse(back).body if isinstance(n,ast.FunctionDef)}
        after={n.name:ast.dump(n,include_attributes=False) for n in ast.parse(new).body if isinstance(n,ast.FunctionDef)}
        self.assertEqual({k for k in before if before[k]!=after[k]},{'verify_closed_refusal','run'})
        for k in ['read_one','number','pair_comparison']:self.assertEqual(before[k],after[k])


if __name__=='__main__':unittest.main()
