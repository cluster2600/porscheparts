"""Pin the same adaptive operator to actual new taper evidence; no mesh import."""
from pathlib import Path
import hashlib,json,os,copy
H=Path(__file__).resolve().parent;R=H.parents[2];O=R/'work/carrier-process-20261017/bounded-webs-C1-discrete-refinement-preparation-001';F=R/'work/carrier-process-20261017/bounded-webs-C1-terminal-taper-static-preparation-001';S=R/'work/carrier-process-20261017/source010-exposure-preflight-003/supervise.py'
def sha(p):
 d=hashlib.sha256()
 with Path(p).open('rb')as f:
  for b in iter(lambda:f.read(1024*1024),b''):d.update(b)
 return d.hexdigest()
def rel(p):return str(p.relative_to(R))
def write(p,d):
 with p.open('x')as f:json.dump(d,f,indent=2,allow_nan=False);f.write('\n');f.flush();os.fsync(f.fileno())
review=F/'root-solver-terminal-review-001.json';assert sha(review)=='15c76fbdfc9563bc296b4a567c1218bee99d6fe7a6889171c2514ec75d2ff287'
rois=json.loads((H/'peak-rois-pending.json').read_text());rois.update(status='SOURCE_ONLY_actual_coarse_ROOT_bound_no_refinement',source_cases_root_review=rel(review),source_cases_root_review_sha256=sha(review));write(H/'peak-rois.json',rois)
p=json.loads((O/'pending-plan.json').read_text());oldfiles=p['files_sha256'];actual=json.loads((F/'rigid-001/case-plan.json').read_text());files={n:h for n,h in oldfiles.items()if '/runtimes/'in n or '/carrier-local-adaptive-20261017/software/'in n};files.update(actual['files_sha256'])
for key in ['mesh_source','mesh_terminal','mesh_assessment','mesh_supervision','mesh_root_review','mesh_root_review_sha256','BREP_sha256','CAD_inputs','expected_bore_node_counts','actual_import_options_required','expected_new_import_observation','import_observation_method','protected_terminal','protected_assessment','protected_supervision','protected_report','inspection_report','protected_root_review','protected_root_review_sha256','protected_surface_STL_sha256']:
 p[key]=copy.deepcopy(actual[key])
p.update(schema='actual-raw-taper-adaptive-discrete-refinement-pending-1',launch_ready=False,root_GO=rel(H/'root-review-GO-001.json'),root_GO_sha256=None,reference_mesh=actual['mesh_source'],output_directory=rel(H/'output-001'),specification=rel(H/'peak-rois.json'),closed_verifier_source=rel(F/'run.py'),binding_source=actual['binding_source'],cases_root_review=rel(review),combined_cases_terminal=rel(F/'solver-terminal-collection.json'),revision='same_discrete_operator_two_distinct_actual_new_taper_half_h_regions',candidate_qualified=False,law_original_RC1_preserved=True,actual_C1_h2_qualified=False,new_taper_h2_qualified=False,historical_other_CAD_H2_not_adopted=True,cases={})
for case in ['rigid','spring']:
 q=F/(case+'-001');p['cases'][case]={name:rel(q/(name+'.json'))for name in ['assessment','energy-audit','global-peaks']};p['cases'][case]={'assessment':rel(q/'assessment.json'),'energy':rel(q/'energy-audit.json'),'peaks':rel(q/'global-peaks.json')}
 for name in p['cases'][case].values():files[name]=sha(R/name)
for key in ['bridge','package_helper','energy_source','measure_source','type11_helper','catalogue_record','closed_verifier_source','binding_source','cases_root_review','combined_cases_terminal','specification']:
 files[p[key]]=sha(R/p[key])
for path in [H/'run.py',H/'derive.py',H/'source-changes.json',H/'run-from-C1.diff',H/'README.md',H/'prepare.py',O/'run.py',O/'selfcheck.py',R/'work/carrier-process-20261017/bounded-webs-discrete-real-preparation-002/selfcheck.py',S]:files[rel(path)]=sha(path)
p['files_sha256']=files;p['input_count']=len(files);p['input_bytes']=sum((R/n).stat().st_size for n in files);write(H/'pending-plan.json',p)
launch=dict(schema='owned_same_adaptive_new_taper_mesh_pending_1',launch_ready=False,root_GO=p['root_GO'],root_GO_sha256=None,command=[str(R/'work/part-workflow/runtimes/geometry-standalone/bin/python'),'-I','-B',str(H/'run.py'),str(H/'pending-plan.json'),'--plan-sha256',sha(H/'pending-plan.json')],cwd=str(R),output_directory=p['output_directory'],execution_directory=rel(H/'execution-001'),source_sha256={rel(S):sha(S),rel(H/'run.py'):sha(H/'run.py')},inputs_sha256=dict(files,**{rel(H/'pending-plan.json'):sha(H/'pending-plan.json')}),section_workers=1,maximum_pending_layers=2,actual_workers=0,total_wall_budget_seconds=1200,cleanup_grace_seconds=[10,10])
write(H/'pending-launch.json',launch);write(H/'pending-command.json',dict(launch_ready=False,argv=[str(R/'work/part-workflow/runtimes/geometry-standalone/bin/python'),'-I','-B',str(S),str(H/'pending-launch.json'),'--plan-sha256',sha(H/'pending-launch.json')]))
print(json.dumps({n:sha(H/n)for n in ['run.py','peak-rois.json','pending-plan.json','pending-launch.json','pending-command.json']}));print('pins',len(files))
