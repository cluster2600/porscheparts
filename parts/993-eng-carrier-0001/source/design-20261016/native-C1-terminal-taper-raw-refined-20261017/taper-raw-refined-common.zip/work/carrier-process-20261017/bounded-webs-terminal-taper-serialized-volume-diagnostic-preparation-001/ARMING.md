# Whole-object arming proposal

No command here is authorized for execution yet. Keep all pending objects unchanged.

After a separate actual ROOT GO, create `plan.json` from `pending-plan.json`: set `launch_ready=true`, set `root_GO_sha256` to the actual GO file digest, append that exact existing `root_GO` path/digest to `files_sha256`, and recompute `input_count`/`input_bytes`. All other keys and source bytes remain unchanged. The inverse removes only that GO pin, restores the two counts, false readiness and the null GO hash, and must equal the complete pending plan.

Create `launch-plan.json` from `pending-launch-plan.json`: set `status=armed_new_taper_serialized_pair` and `launch_ready=true`; change child command index 4 from the pending plan to the new absolute plan path and index 6 to its digest. In `inputs_sha256`, replace only the pending-plan entry with the actual plan entry and add the exact GO pin. The preflight entry and every existing source/runtime pin remain unchanged. Invert these exact changes and require whole-object equality with the pending launch.

Create `command.json` from `command-pending.json`: set `status=ready_for_one_authorized_execution`, `root_GO_pending=false`; replace supervisor argv index 4 by the new absolute launch path and index 6 by its digest. Inverting those four fields must reproduce the complete pending command. The supervisor parent is not niced. All source/argv/resources/operands otherwise remain unchanged. Before any execution, rehash all pins, validate the closed pair through `verify_closed_refusal` using the armed plan, and require fresh output and execution paths. Record all three whole-object inverse checks and the exact actual ROOT GO. No automatic retry.
