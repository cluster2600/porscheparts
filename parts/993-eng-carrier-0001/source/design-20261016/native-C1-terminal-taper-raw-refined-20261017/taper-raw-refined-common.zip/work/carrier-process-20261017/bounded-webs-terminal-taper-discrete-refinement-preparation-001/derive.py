"""Minimal new closed-case bindings; adaptive/geometry/quality bodies unchanged."""
from pathlib import Path
import ast,difflib,hashlib,json
H=Path(__file__).resolve().parent;R=H.parents[2];O=R/'work/carrier-process-20261017/bounded-webs-C1-discrete-refinement-preparation-001/run.py';old=O.read_text();new=old;rows=[]
def replace(a,b):
 global new
 assert new.count(a)==1,(a[:80],new.count(a));new=new.replace(a,b);rows.append(dict(before=a,after=b))
replace('"""Same adaptive discrete campaign on the closed C1 BREP mesh and two real peak ROIs."""','"""Same adaptive discrete campaign on the new raw-taper mesh and two distinct real peak ROIs."""')
node=next(n for n in ast.parse(new).body if isinstance(n,ast.FunctionDef)and n.name=='verify_C1_cases')
replace(ast.get_source_segment(new,node),'''
def verify_C1_cases(plan, regions):
    """Bind two distinct measured new-taper peak boxes; no field recalculation."""
    require(set(plan['cases']) == {'rigid', 'spring'} and len(regions) == 2, 'Two actual new-taper cases required')
    review = json.loads((ROOT / plan['cases_root_review']).read_text())
    terminal_path = ROOT / plan['combined_cases_terminal']
    whole = json.loads(terminal_path.read_text())
    require(review['schema'] == 'root-two-new-taper-linear-static-terminal-1'
            and review['status'] == 'closed_actual_RC0_two_new_taper_static_and_energy_cases'
            and review['actual_tool_RC'] == 0 and review['terminal_sha256'] == sha(terminal_path)
            and review['actual_new_BREP_sha256'] == plan['BREP_sha256']
            and review['candidate_qualified'] is False and review['law_original_RC1_preserved'] is True,
            'Closed new-taper ROOT review differs')
    require(whole['status'] == 'two_actual_linear_static_cases_closed_no_qualification', 'Actual combined terminal differs')
    for key, region in zip(('rigid', 'spring'), regions):
        paths = plan['cases'][key]
        assessment, energy, peaks = [json.loads((ROOT / paths[role]).read_text()) for role in ('assessment', 'energy', 'peaks')]
        terminal = whole['cases'][key]; root = review['cases'][key]
        require(terminal['actual_tool_returncode'] == terminal['actual_container_returncode'] == terminal['attach_cli_returncode'] == 0
                and terminal['owned_container_removed'] and terminal['all_current_pins_equal'], 'Actual new case not closed')
        require(terminal['assessment_sha256'] == root['assessment_sha256'] == sha(ROOT / paths['assessment'])
                and assessment['energy_audit_sha256'] == sha(ROOT / paths['energy'])
                and assessment['global_peaks_sha256'] == sha(ROOT / paths['peaks'])
                and terminal['whole_outputs_sha256'][paths['energy']] == sha(ROOT / paths['energy'])
                and terminal['whole_outputs_sha256'][paths['peaks']] == sha(ROOT / paths['peaks'])
                and root['all_global_maximum_ties'] == peaks['all_global_maximum_ties'], 'Actual new case/ROI SHA join differs')
        require(assessment['status'] == 'actual_linear_static_and_independent_energy_completed'
                and assessment['sources_unchanged'] and assessment['plan_unchanged'] and assessment['within_case_budget']
                and assessment['native_result']['mesh_sha256'] == plan['files_sha256'][plan['reference_mesh'] + '/mesh.inp'], 'Actual new case mesh/assessment differs')
        require(energy['energy_closure_pass'] and energy['tolerance'] == 1e-4
                and energy['relative_energy_closure_error'] <= 1e-4 and peaks['no_peak_excluded']
                and peaks['maximum_ties'] == 1 and len(peaks['all_global_maximum_ties']) == 1, 'Actual full new energy/peak gates differ')
        peak = peaks['all_global_maximum_ties'][0]; measure = peak['corner_measure']
        require(region['id'] == assessment['case_name'] == peaks['case']
                and region['element_id'] == peak['element_id'] and region['reference_IP_one_based'] == peak['IP_one_based']
                and region['reference_IP_xyz_mm'] == peak['reference_undeformed_IP_xyz_mm']
                and region['bounds_mm'] == measure['bounds_mm']
                and region['measured_reference_h_mm'] == measure['measured_h_mm']
                and region['target_h_mm'] == measure['proposed_half_h_mm'] == measure['measured_h_mm'] / 2, 'Actual peak ROI/half-h differs')
    require(regions[0]['bounds_mm'] != regions[1]['bounds_mm'], 'The two measured new-taper regions must remain distinct')
'''.strip())
replace("plan['reference_mesh'] == 'work/carrier-process-20261017/bounded-webs-BREP-mesh-preparation-002/output-001/cad-BREP-master/mesh-7'","plan['reference_mesh'] == 'work/carrier-process-20261017/bounded-webs-C1-terminal-taper-BREP-mesh-preparation-001/output-001/cad-BREP-master/mesh-7'")
replace('closed.verify_mesh(plan); closed.verify_protected(plan)','closed.verify_mesh(plan); closed.verify_protected_root(plan); closed.verify_protected(plan)')
replace("h2_qualified=False, FEA_started=False)","h2_qualified=False, FEA_started=False, candidate_qualified=False, law_original_RC1_preserved=True)")
inverse=new
for row in reversed(rows):
 assert inverse.count(row['after'])==1;inverse=inverse.replace(row['after'],row['before'])
assert inverse==old
(H/'run.py').write_text(new)
(H/'source-changes.json').write_text(json.dumps(dict(source=str(O.relative_to(R)),source_sha256=hashlib.sha256(O.read_bytes()).hexdigest(),replacements=rows,whole_inverse_equal=True,resource_or_scientific_threshold_changed=False,old_shared_ROI_assertion_was_historical_observation=True),indent=2)+'\n')
(H/'run-from-C1.diff').write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile=str(O.relative_to(R)),tofile=str((H/'run.py').relative_to(R)))))
