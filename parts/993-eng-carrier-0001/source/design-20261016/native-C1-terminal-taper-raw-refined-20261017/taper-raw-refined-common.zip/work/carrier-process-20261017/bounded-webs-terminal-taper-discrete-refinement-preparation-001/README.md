# New taper: two actual peak regions, common local half-h proposal

This is source-only preparation. No refinement, Gmsh operation, field calculation
or new FEA has run. The actual new coarse-case ROOT closure15c76fbdfc9563bc296b4a567c1218bee99d6fe7a6889171c2514ec75d2ff287 is bound; a separate ROOT GO is still required before arming. No old C1/H2 target, node roster or geometry is transferred.

The rigid peak is element84327/IP1 at negative X. Its actual longest of six
corner edges is 0.9337907983666619 mm; the unchanged relative rule gives target
0.46689539918333095 mm. The spring peak is element54403/IP3 at positive X,
with actual h=1.5168628478283792 mm and target0.7584314239141896 mm. Each region
is its complete actual peak-element corner bounding box, without padding,
new radius, margin grid or selection of a different peak. All original global
maxima were retained. These are two distinct regions on one common new mesh.

Reuse the retained `bounded-webs-C1-discrete-refinement-preparation-001/run.py`
adaptive campaign, the same scikit-fem12.0.2 package helper and lineage-preserving
T10 bridge, the unchanged edge-measurement helper and native type11 permutation.
Keep every refinement/lift/protected-facet/serialization/quality/volume function
body. Only the actual new master/source/ROOT bindings and two-case ROI verifier
need adaptation. The old final assertion that both old peaks share one ROI was
an observation of that old CAD; the new verifier must instead bind both complete
distinct measured regions, not collapse or replace one of them.

Preserve all old node IDs and solver-coordinate lexemes, the original NPZ XYZ
block, six complete BC/load rosters, and every protected exterior facet at each
pass. Preserve the original straight-midside and 1e-10 serialization guards,
positive Jacobian/volume checks and unchanged volume-error non-regression gate.
Gmsh is a discrete quality evaluator only; it does not remesh or import CAD.

The target is a post-mesh measurement, not a Gmsh size setting. The unchanged
`mark_t4`/`region_edges` contract measures all six full corner edges of tetrahedra
selected by centroid in the region and full edges whose two ends lie inside.
Every region must actually meet its half-h maximum-edge target. Otherwise keep
the refusal and do not proceed to FEA. Closure may propagate outside the boxes;
record that actual topology and all pass lineage rather than claiming a purely
box-limited edit or exact rational geometry conservation.

Retain the existing 1200-second owned group, 1150-second inner alarm,
CPU1100/1101, one thread/no workers and the existing 500,000-node/element caps.
No automatic retry or cap increase is proposed. The new raw BREP keeps its
post-Build law refusal and remains unqualified. A geometrically checked mesh
would still not establish stress convergence or strength. Separate ROOT review
and GO are required before any real refinement or later solver run.

## Exact arming boundary

Preserve the pending plan, launch and command. A separate real GO may change
only readiness, its actual path/hash and its added pin; replace the pending
plan path/hash in the launch argv/input map, then the pending launch path/hash
in the command. Require the entire inverse of those changes to equal all three
pending objects, and freshly hash all pins/confirm both output paths absent.
Keep sources, targets, caps, solver coordinates, resource budgets and cleanup
unchanged. No real refinement is authorized by this preparation.
