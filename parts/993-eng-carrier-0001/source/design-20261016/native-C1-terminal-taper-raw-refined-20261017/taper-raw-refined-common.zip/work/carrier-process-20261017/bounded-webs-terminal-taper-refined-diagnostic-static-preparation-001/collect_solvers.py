"""Seal actual solver tool returns, owned-container closure and complete outputs."""
import copy
import hashlib
import json
import os
import re
import subprocess
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]


def require(ok, message):
    if not ok:
        raise ValueError(message)


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


def main():
    go_path = HERE / 'root-solver-GO-001.json'
    go_sha = sha(go_path)
    require(go_sha == '4d9258f67956beeb5c4e06168d0156f625168f56dc1aefe0cecda190bd041fc0', 'Actual solver GO differs')
    go = read(go_path)
    actual = {'rigid': (30681, 'cb72ec', '06e78a'), 'spring': (69039, '334496', '024587')}
    report = dict(status='two_actual_linear_static_cases_closed_no_qualification', cases={},
                  root_solver_GO_sha256=go_sha, collector_sha256=sha(__file__), scientific_imports=False,
                  candidate_qualified=False, h2_qualified=False, diagnostic_raw_mesh_scope=True,
                  strict_H2_volume_refusal_preserved=True, law_original_RC1_preserved=True,
                  convergence_or_strength_threshold_added=False, physical_validation=False)
    for case, (handle, initial, terminal) in actual.items():
        output = HERE / (case + '-001')
        command = read(HERE / (case + '-solver-command.json'))
        pending_path = HERE / (case + '-solver-pending-command-002.json')
        pending = read(pending_path)
        inverse = copy.deepcopy(command)
        for key in go['allowed_command_arming_fields']:
            inverse[key] = pending[key]
        require(inverse == pending and sha(pending_path) == go['cases'][case]['command_sha256']
                and command['argv'] == pending['argv'], 'Whole command inverse or original argv differs')
        plan_path = output / 'case-plan.json'
        plan = read(plan_path)
        require(sha(plan_path) == go['cases'][case]['case_plan_sha256'], 'Prepared case plan changed')
        current = {name: sha(ROOT / name) for name in plan['files_sha256']}
        require(current == plan['files_sha256'], 'Current frozen input/source/runtime differs')
        assessment = read(output / 'assessment.json')
        native = read(output / 'execution/native-receipt.json')
        native_plan = read(output / 'execution/native-plan.json')
        energy = read(output / 'energy-audit.json')
        peaks = read(output / 'global-peaks.json')
        require(assessment['status'] == 'actual_linear_static_and_independent_energy_completed'
                and assessment['plan_unchanged'] and assessment['within_case_budget']
                and assessment['sources_before'] == assessment['sources_after'] == current,
                'Actual numeric closeout or whole source maps differ')
        require(native['status'] == 'solver_executed_no_numeric_admission'
                and native['actual_container_exit_code'] == native['attach_cli_returncode'] == 0
                and native['container_removed'] and native['input_hashes_unchanged']
                and native['within_global_budget'] and native['global_admission'] is False
                and native['native_plan_sha256'] == sha(output / 'execution/native-plan.json')
                and native['helper_source_sha256'] == plan['helper_sha256'], 'Actual owned-container cleanup differs')
        require({n: sha(Path(n)) for n in native_plan['files_sha256']} == native_plan['files_sha256'], 'Actual solver input pins differ')
        expected_native_plan = dict(case_directory=str((output/'cad/mesh-7').resolve()), case_name=plan['case_name'],
            container_name=plan['container_name'], ownership_token=plan['ownership_token'],
            image=plan['image'], binary_sha256=plan['binary_sha256'], wall_budget_seconds=1800,
            cleanup_reserve_seconds=60, solver_timeout_seconds=1680,
            container_command=['--signal=TERM','--kill-after=10s','1680s','/usr/bin/ccx','-i',plan['case_name']],
            initial_case_files=['mesh.inp','mesh.npz','mesh.json',plan['case_name']+'.inp'],
            files_sha256={str(ROOT/n):h for n,h in plan['files_sha256'].items()})
        expected_native_plan['files_sha256'][str(output/'cad/mesh-7'/(plan['case_name']+'.inp'))] = plan['prepared_deck_sha256']
        for filename in ['mesh.inp','mesh.npz','mesh.json']:
            expected_native_plan['files_sha256'][str(output/'cad/mesh-7'/filename)] = plan['mesh_files_sha256'][filename]
        require(native_plan == expected_native_plan, 'Whole actual owned native plan differs')
        require(command['deck_ROOT_review_sha256'] == go['deck_ROOT_review_sha256'] == sha(ROOT/command['deck_ROOT_review'])
                and command['root_solver_GO_sha256'] == go_sha and sha(ROOT/command['root_solver_GO']) == go_sha
                and command['launch_ready'] is True, 'Actual command ROOT joins differ')
        comparisons=[]
        for baseline in plan['baselines']:
            retained=read(ROOT/baseline['receipt']); retained_peaks=read(ROOT/baseline['peaks']); measured=assessment['native_result']
            comparisons.append(dict(mesh=baseline['mesh'],retained=retained,retained_global_peaks=retained_peaks,
                displacement_max_ratio=measured['displacement_max_mm']/retained['displacement_max_mm'],
                global_VM_max_ratio=measured['integration_point_VM_max_MPa']/retained['integration_point_VM_max_MPa'],
                load_dot_displacement_ratio=measured['external_work_Nmm']/retained['external_work_Nmm'],
                interpretation='Measured same-taper coarse/refined diagnostic ratios with unchanged discrete loads/BC; strict volume/law refusals remain, no convergence or strength threshold added'))
        require(assessment['comparisons_to_same_taper_coarse_mesh'] == comparisons, 'Whole same-coarse comparisons differ')
        require(assessment['h2_qualified'] is False and assessment['strict_H2_volume_refusal_preserved'] is True
                and assessment['diagnostic_raw_mesh_scope'] is True, 'Raw diagnostic refusal scope differs')
        cid=native['container_id'];require(re.fullmatch('[0-9a-f]{64}',cid) is not None,'Actual full container ID required')
        argv=['/usr/local/bin/docker','container','ls','-a','--no-trunc','--filter','id='+cid,'--format','{{.ID}}']
        absent=subprocess.run(argv,capture_output=True,text=True,timeout=20)
        require(absent.returncode == 0 and not absent.stdout.strip() and not absent.stderr.strip(), 'Fresh exact owned container absence unconfirmed')
        identity = native['actual_container_before_start']
        require(identity['Name'] == '/' + plan['container_name'] and identity['Owner'] == plan['ownership_token']
                and identity['Id'] == native['container_id'] and identity['Image'] == plan['image']
                and identity['NanoCpus'] == 10**9 and identity['Memory'] == identity['MemorySwap'] == 6 * 1024**3
                and identity['NetworkMode'] == 'none' and identity['PidsLimit'] == 128
                and identity['ReadonlyRootfs'] is True and identity['Entrypoint'] == ['/usr/bin/timeout']
                and identity['Cmd'] == expected_native_plan['container_command'] and identity['Tmpfs'] == {'/tmp':'rw,size=512m'}
                and identity['WorkingDir'] == '/work', 'Actual container identity/resources differ')
        require(sha(output / 'execution/prepared-deck.inp') == go['cases'][case]['prepared_deck_sha256']
                and sha(output / 'execution/load-and-supports.json') == go['cases'][case]['prepared_load_support_sha256']
                and sha(output / 'energy-audit.json') == assessment['energy_audit_sha256']
                and sha(output / 'global-peaks.json') == assessment['global_peaks_sha256'], 'Whole diagnostic output binding differs')
        require(energy['energy_closure_pass'] and energy['tolerance'] == 1e-4
                and peaks['no_peak_excluded'] and len(peaks['all_global_maximum_ties']) == peaks['maximum_ties']
                and peaks['maximum_VM_MPa'] == assessment['native_result']['integration_point_VM_max_MPa']
                and assessment['candidate_qualified'] is False and assessment['law_original_RC1_preserved'], 'Energy/all-peak scope differs')
        files = [p for base in (output, HERE / (case + '-solver-host-001')) for p in base.rglob('*') if p.is_file()]
        require(not any(p.is_symlink() for p in files), 'Symbolic actual outputs refused')
        report['cases'][case] = dict(actual_tool_handle=handle, actual_initial_chunk=initial,
            actual_terminal_chunk=terminal, actual_tool_returncode=0, actual_container_returncode=0,
            attach_cli_returncode=0, owned_container_removed=True, native_container_id=native['container_id'],
            fresh_exact_container_absence=dict(command=argv,returncode=absent.returncode,stdout=absent.stdout,stderr=absent.stderr),
            whole_native_plan_reconstructed_equal=True, native_plan_pin_count=len(native_plan['files_sha256']),
            case_wall_seconds=assessment['wall_seconds'], native_owned_wall_seconds=native['wall_seconds'],
            whole_same_coarse_comparisons=comparisons,
            entire_command_inverse_equal=True, current_case_pin_count=len(current), all_current_pins_equal=True,
            case_plan_sha256=sha(plan_path), assessment_sha256=sha(output / 'assessment.json'),
            native_receipt_sha256=sha(output / 'execution/native-receipt.json'),
            whole_outputs_sha256={str(p.relative_to(ROOT)): sha(p) for p in sorted(files)},
            whole_output_bytes=sum(p.stat().st_size for p in files), actual_native_result=assessment['native_result'],
            independent_energy_audit=energy, all_global_peak_ties=peaks,
            interpretation='Actual diagnostic raw refined taper mesh and same-coarse assumed physics; original volume/law refusals remain, no H2 admission, convergence, strength or manufacturing qualification')
    target = HERE / 'solver-terminal-collection.json'
    with target.open('x') as stream:
        json.dump(report, stream, indent=2, allow_nan=False)
        stream.write('\n'); stream.flush(); os.fsync(stream.fileno())
    print(json.dumps(dict(status=report['status'], terminal_sha256=sha(target), cases=list(report['cases']))))


if __name__ == '__main__':
    main()
