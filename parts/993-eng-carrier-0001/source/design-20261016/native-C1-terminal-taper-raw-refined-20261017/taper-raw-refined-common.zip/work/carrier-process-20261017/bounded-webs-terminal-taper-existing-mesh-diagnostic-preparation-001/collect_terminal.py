"""Close our actual raw-mesh diagnostic; never repeat measurements or qualify it."""
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import subprocess

B=Path(__file__).resolve().parent
R=B.parents[2]

def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    return h.hexdigest()

def read(name):return json.loads((B/name).read_text())

p=read('plan.json');p0=read('pending-plan.json');L=read('launch-plan.json');L0=read('pending-launch-plan.json');C=read('command.json');C0=read('command-pending.json')
s=read('execution-001/execution-receipt.json');a=read('output-001/assessment.json');started=read('execution-001/started.json')
assert s['actual_returncode']==0 and s['direct_child_reaped'] and not s['final_group_members'] and not s['timeout']
assert not s['signals_to_owned_group_only'] and s['cleanup_error'] is None and s['sources_and_plan_unchanged']
assert s['sources_before']==s['sources_after']
assert a['sources_before']==a['sources_after']==p['files_sha256'] and a['sources_unchanged'] and a['plan_unchanged']
assert a['h2_qualified'] is False and a['candidate_qualified'] is False and a['law_original_RC1_preserved'] is True
assert a['closed_unequal_volume_observation']['comparison']['binary64_equal'] is False
assert all(x['target_attained']for x in a['whole_original_measurements'])
assert a['plan_sha256']==sha(B/'plan.json') and a['status']=='existing_raw_new_taper_mesh_measured_no_admission'
assert s['plan_sha256']==sha(B/'launch-plan.json') and s['command']==L['command']
pins=dict(L['inputs_sha256']);pins.update(L['source_sha256']);assert all(sha(R/k)==v for k,v in pins.items())
GO=p['root_GO'];back=deepcopy(p);back['launch_ready']=False;back['root_GO_sha256']=None;del back['files_sha256'][GO];back['input_count']=p0['input_count'];back['input_bytes']=p0['input_bytes'];assert back==p0
back=deepcopy(L);back['status']=L0['status'];back['launch_ready']=False;back['command'][4]=L0['command'][4];back['command'][6]=L0['command'][6];del back['inputs_sha256'][GO];del back['inputs_sha256'][str(B.relative_to(R)/'plan.json')];back['inputs_sha256'][str(B.relative_to(R)/'pending-plan.json')]=sha(B/'pending-plan.json');assert back==L0
back=deepcopy(C);back['status']=C0['status'];back['root_GO_pending']=True;back['argv'][4]=C0['argv'][4];back['argv'][6]=C0['argv'][6];assert back==C0
q=subprocess.run(['/bin/ps','-axo','pid=,ppid=,pgid=,state='],check=True,capture_output=True,text=True)
members=[line.split() for line in q.stdout.splitlines() if len(line.split())==4 and int(line.split()[2])==started['pgid']];assert not members
outputs={str(f.relative_to(B)):dict(bytes=f.stat().st_size,sha256=sha(f)) for d in ['execution-001','output-001'] for f in sorted((B/d).rglob('*')) if f.is_file()}
for n in ['stdout.log','stderr.log']:assert s['logs_sha256'][n]==sha(B/'execution-001'/n)
report=dict(schema='owned-new-taper-raw-mesh-diagnostic-terminal-1',status='actual_RC0_raw_mesh_preservation_and_whole_half_h_measured_no_qualification',actual_tool_handle=69624,actual_initial_chunk='8d59f6',actual_terminal_chunk='cf536d',actual_tool_returncode=0,actual_child_returncode=s['actual_returncode'],PGID=started['pgid'],direct_child_reaped=True,final_group_members=[],fresh_PGID_absent=True,signals=[],timeout=False,cleanup_error=None,supervisor_seconds=s['elapsed_seconds'],child_seconds=a['wall_seconds'],maxRSS_bytes=a['peak_RSS_bytes'],all_fresh_pins_equal=True,unique_pins=len(pins),whole_three_pending_inverses_equal=True,whole_before_after_maps_equal=True,source_sha256=sha(B/'run.py'),plan_sha256=sha(B/'plan.json'),launch_sha256=sha(B/'launch-plan.json'),supervision_sha256=sha(B/'execution-001/execution-receipt.json'),assessment_sha256=sha(B/'output-001/assessment.json'),root_GO_sha256=p['root_GO_sha256'],whole_outputs=outputs,whole_original_measurements=a['whole_original_measurements'],whole_actual_preservation=a['actual_preservation'],closed_pass_preservation=a['closed_pass_preservation'],comparison=a['closed_unequal_volume_observation']['comparison'],historical_volume_guard_overridden=False,h2_qualified=False,candidate_qualified=False,law_original_RC1_preserved=True,FEA_started=False,recalculation_during_collection=False,collector_source_sha256=sha(__file__))
with (B/'terminal-collection.json').open('x') as f:json.dump(report,f,indent=2,allow_nan=False);f.write('\n')
print(json.dumps(dict(terminal_sha256=sha(B/'terminal-collection.json'),assessment_sha256=report['assessment_sha256'],supervision_sha256=report['supervision_sha256'],whole_outputs=len(outputs),fresh_pins=len(pins),binary64_equal=a['closed_unequal_volume_observation']['comparison']['binary64_equal'],measured_h=[x['measured_h_mm']for x in a['whole_original_measurements']],targets=[x['target_h_mm']for x in a['whole_original_measurements']],group_absent=True)))
