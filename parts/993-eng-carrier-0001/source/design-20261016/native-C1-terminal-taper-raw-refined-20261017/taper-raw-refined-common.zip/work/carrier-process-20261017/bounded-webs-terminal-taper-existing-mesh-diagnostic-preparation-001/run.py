"""Diagnose an EXISTING raw new-taper mesh; preserve both strict volume refusals."""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import resource
import signal
import sys
import time

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]


def require(ok, message):
    if not ok: raise ValueError(message)


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda: f.read(1024*1024), b''): h.update(b)
    return h.hexdigest()


def write(path, value):
    with Path(path).open('x') as f:
        json.dump(value,f,indent=2,allow_nan=False);f.write('\n');f.flush();os.fsync(f.fileno())


def load(name, path):
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m


def volume_authority(plan):
    paths=[plan[k] for k in ('pair_terminal','pair_assessment','pair_supervision','pair_root_review')]
    terminal,actual,supervision,review=[json.loads((ROOT/p).read_text()) for p in paths]
    require(terminal['actual_tool_returncode']==terminal['actual_child_returncode']==0
            and terminal['direct_child_reaped'] and not terminal['final_group_members']
            and terminal['all_fresh_pins_equal'] and terminal['whole_before_after_maps_equal'], 'Serialized pair not closed')
    require(terminal['assessment_sha256']==sha(ROOT/plan['pair_assessment'])
            and terminal['supervision_sha256']==sha(ROOT/plan['pair_supervision'])
            and review['terminal_sha256']==sha(ROOT/plan['pair_terminal'])
            and review['assessment_sha256']==sha(ROOT/plan['pair_assessment'])
            and review['supervision_sha256']==sha(ROOT/plan['pair_supervision']), 'Serialized pair SHA join differs')
    require(supervision['actual_returncode']==0 and supervision['direct_child_reaped']
            and not supervision['final_group_members'] and not supervision['timeout']
            and not supervision['interrupted'] and supervision['sources_and_plan_unchanged'], 'Serialized pair execution not closed')
    require(actual['status']=='two_serialized_new_taper_volumes_measured_no_admission'
            and actual['sources_unchanged'] and actual['plan_unchanged']
            and not actual['h2_qualified'] and not actual['historical_volume_guard_overridden'], 'Pair diagnostic scope changed')
    comparison=actual['comparison']
    require(comparison==terminal['comparison']==review['volume_comparison']
            and comparison['binary64_equal'] is False
            and review['schema']=='root-new-taper-serialized-pair-terminal-1'
            and review['actual_tool_RC']==0 and review['all7_whole_outputs_verified']
            and not review['h2_qualified'] and not review['candidate_qualified']
            and not comparison['admission'] and not comparison['historical_volume_guard_overridden'], 'Closed unequal serialized-volume observation differs')
    require(len(actual['rows'])==2 and actual['rows']==review['rows'], 'Both actual serialized rows must match the root closure')
    require(actual['same_adaptive_CAD_reference']['mm3']==plan['CAD_adaptive_master_volume_mm3'], 'Unchanged adaptive CAD reference differs')
    for i,(row,mesh) in enumerate(zip(actual['rows'],plan['meshes'])):
        require(row['volume']==comparison[('baseline_serialized','candidate_serialized')[i]], 'Serialized row volume not joined to observation')
        require(row['id']==mesh['id'] and row['mesh_INP_sha256']==plan['files_sha256'][mesh['inp']]
                and row['imported_node_and_element_identity_checked'] and row['quality']['finite']
                and row['quality']['nonpositive_elements']==0 and row['quality']['minimum_Jacobian']>0,
                'Actual serialized input/quality differs')
    return dict(comparison=comparison,qualities=actual['rows'],adaptive_CAD_reference=actual['same_adaptive_CAD_reference'],
                diagnostic_only=True, volume_admission=False,
                authority='Closed same-operator Gmsh serialized pair; actual ONE-ULP inequality retained as observation only. Neither volume guard is overridden.')


def pass_authority(plan):
    a=json.loads((ROOT/plan['h2_assessment']).read_text());review=json.loads((ROOT/plan['h2_root_review']).read_text())
    terminal=json.loads((ROOT/plan['h2_terminal']).read_text())
    require(review['terminal_sha256']==sha(ROOT/plan['h2_terminal'])
            and terminal['assessment_sha256']==sha(ROOT/plan['h2_assessment'])
            and terminal['supervision_sha256']==sha(ROOT/plan['h2_supervision'])
            and review['actual_tool_RC']==1 and review['h2_qualified'] is False
            and review['all_four_whole_proofs_and_journal_finish_rows_joined']
            and review['actual_PGID_freshly_absent'], 'Historical actual refusal review differs')
    journal=ROOT/plan['passes_journal'];require(journal.read_bytes().endswith(b'\n'),'Incomplete pass journal')
    events=[json.loads(line) for line in journal.read_text().splitlines()]
    require([e['event'] for e in events]==['pass_start','pass_finish']*4+['targets_reached'],'Four complete passes required')
    records=a['adaptive_passes'];require(len(records)==4 and a['h2_qualified'] is False and a['volume_error_non_regression'] is False,'Old refusal was changed')
    previous=None;proofs=[]
    for i,record in enumerate(records):
        path=ROOT/plan['passes_directory']/record['proof'];proof=json.loads(path.read_text());digest=sha(path)
        require(digest==record['proof_sha256']==a['pass_proof_artifacts_sha256'][path.name]
                and digest==events[2*i+1]['proof_sha256']==plan['files_sha256'][str(path.relative_to(ROOT))]
                and proof['previous_pass_proof_sha256']==previous
                and proof['protected_facets_unchanged'] and proof['all_input_nodes_used_and_IDs_XYZ_unchanged']
                and proof['protected_facets']==a['protected_facets'], 'Closed pass ancestry/preservation differs')
        previous=digest;proofs.append(dict(path=str(path.relative_to(ROOT)),sha256=digest,pass_number=i+1,
            input_nodes=proof['input_nodes'],output_nodes=proof['output_nodes'],input_elements=proof['input_elements'],output_elements=proof['output_elements']))
    require(a['protected_facets_unchanged_at_every_pass'] and a['all_original_nodes_IDs_XYZ_unchanged_and_used']
            and a['original_NPZ_XYZ_block_preserved'] and a['original_INP_NODE_lexemes_preserved'], 'Closed original preservation guards failed')
    return dict(proofs=proofs,journal_sha256=sha(journal),protected_facets=a['protected_facets'],
                original_volume_guard_passed=False,original_run_h2_qualified=False,marking_not_used_for_final_h=True)


def protected_edge_mids(elements, protected_faces, pairs):
    needed={tuple(sorted((face[i],face[j]))) for face in protected_faces for i,j in ((0,1),(1,2),(2,0))}
    mids={}
    for row in elements.values():
        for k,(i,j) in enumerate(pairs,4):
            key=tuple(sorted((row[int(i)],row[int(j)])))
            if key in needed:
                require(key not in mids or mids[key]==row[k],'Inconsistent protected edge midside')
                mids[key]=row[k]
    require(set(mids)==needed,'Missing protected edge midside')
    return mids


def accept_measurements(rows):
    require(len(rows)==2 and all(r['target_attained'] and r['measured_h_mm']<=r['target_h_mm'] for r in rows),
            'Whole original measurement did not attain both actual half-h targets')


def run(path, expected):
    started=time.monotonic();path=Path(path);require(sha(path)==expected,'Plan drift');plan=json.loads(path.read_text())
    require(plan['launch_ready'] and plan['root_GO_sha256'] is not None,'Existing raw-mesh diagnostic remains unarmed')
    require(sha(ROOT/plan['root_GO'])==plan['root_GO_sha256'],'Root GO differs')
    require((plan['outer_seconds'],plan['inner_seconds'],plan['CPU_seconds'],plan['threads'],plan['workers'])==(180,150,[140,160],1,0),'Diagnostic resource drift')
    require(os.getpriority(os.PRIO_PROCESS,0)==10 and all(os.environ.get(k)=='1' for k in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS')),'nice10/one thread required')
    signal.signal(signal.SIGALRM,lambda *_:(_ for _ in ()).throw(TimeoutError('150s existing-mesh readonly diagnostic cap')))
    signal.setitimer(signal.ITIMER_REAL,150);resource.setrlimit(resource.RLIMIT_CPU,(140,160))
    pins=plan['files_sha256'];before={p:sha(ROOT/p) for p in pins};require(before==pins,'Actual input/source/runtime differs')
    output=ROOT/plan['output_directory'];require(not output.exists() and not output.is_symlink(),'Fresh readonly proof output required');output.mkdir()
    report=dict(status='incomplete_existing_raw_mesh_diagnostic',policy='Whole original h/preservation measurement; unequal serialized-volume observation is not an admission',
                h2_qualified=False,candidate_qualified=False,law_original_RC1_preserved=True,original_run_h2_qualified=False,
                original_volume_guard_overridden=False,refinement_repeated=False,mesh_generated=False,FEA_started=False,
                physical_validation=False,manufacturing_authorized=False)
    error=None
    try:
        pair=load('original_serialized_pair_proofs',ROOT/plan['pair_source']);pair.verify_closed_refusal(plan)
        report['closed_unequal_volume_observation']=volume_authority(plan);report['closed_pass_preservation']=pass_authority(plan)
        h2=load('original_C1_refinement_helpers',ROOT/plan['h2_source'])
        spec=json.loads((ROOT/plan['specification']).read_text());h2.verify_C1_cases(plan,spec['regions'])
        binding=load('original_native_BREP_binding',ROOT/plan['binding_source'])
        for row in plan['meshes']:
            folder=(ROOT/row['inp']).parent;metadata=json.loads((ROOT/row['metadata']).read_text());binding.verify(folder,metadata)
        sys.path.insert(0,str(ROOT/plan['numpy_site']))
        import numpy as np
        energy=load('original_energy_mesh_reader',ROOT/plan['energy_reader']);require(energy.COORDINATE_ROUNDOFF_MM==1e-10,'Original coordinate guard differs')
        bridge=load('original_boundary_and_groups',ROOT/plan['bridge']);measure=load('entire_original_half_h_measure',ROOT/plan['measure_source'])
        loaded=[]
        for row in plan['meshes']:
            tags,xyz,eids,conn=energy.read_mesh(ROOT/row['inp'])
            with np.load(ROOT/row['npz'],allow_pickle=False) as archive:arrays={k:archive[k].copy() for k in archive.files}
            require(set(arrays)=={'tags','xyz','faces',*bridge.GROUPS},'Actual NPZ fields differ')
            require(np.array_equal(tags,arrays['tags']) and np.allclose(xyz,arrays['xyz'],rtol=0,atol=1e-10),'Actual INP/NPZ original1e-10 guard failed')
            require(np.array_equal(np.unique(conn),np.arange(len(tags))),'Actual orphan node')
            require(np.max(np.abs(xyz[conn][:,4:]-(xyz[conn][:,energy.EDGE_PAIRS[:,0]]+xyz[conn][:,energy.EDGE_PAIRS[:,1]])/2))<=1e-10,'Actual straight midside guard failed')
            elements={int(e):tuple(map(int,tags[c])) for e,c in zip(eids,conn)};boundary=bridge.boundary(elements)
            require(set(boundary)=={tuple(sorted(map(int,f))) for f in arrays['faces']},'Actual NPZ boundary differs')
            loaded.append(dict(tags=tags,xyz=xyz,arrays=arrays,elements=elements,boundary=boundary,inp=ROOT/row['inp']))
        old,new=loaded;count=len(old['tags'])
        require(new['arrays']['tags'].dtype==old['arrays']['tags'].dtype and new['arrays']['tags'][:count].tobytes()==old['arrays']['tags'].tobytes()
                and new['arrays']['xyz'].dtype==old['arrays']['xyz'].dtype and new['arrays']['xyz'][:count].tobytes()==old['arrays']['xyz'].tobytes(),'Actual old NPZ prefix changed')
        oldrows=h2.node_lines(old['inp']);newrows=h2.node_lines(new['inp']);require(all(newrows.get(tag)==line for tag,line in oldrows.items()),'Actual old INP NODE lexemes changed')
        groups={g:old['arrays'][g].tolist() for g in bridge.GROUPS}
        require(all(new['arrays'][g].dtype==old['arrays'][g].dtype and new['arrays'][g].tobytes()==old['arrays'][g].tobytes() for g in bridge.GROUPS),'Actual six rosters changed')
        require({g:len(v) for g,v in groups.items()}==plan['expected_bore_node_counts'],'Actual six roster counts differ')
        identities={face:face for face in new['boundary'] if face in old['boundary']}
        protected=h2.protected_facets(old['boundary'],identities,groups)
        require(protected==h2.protected_facets(new['boundary'],{face:face for face in new['boundary']},groups)
                ==report['closed_pass_preservation']['protected_facets'],'Actual protected facets differ from closed passes')
        faces=[tuple(map(int,k.split(','))) for k in protected]
        require(protected_edge_mids(old['elements'],faces,energy.EDGE_PAIRS)==protected_edge_mids(new['elements'],faces,energy.EDGE_PAIRS),'Actual protected midside IDs changed')
        report['actual_preservation']=dict(six_roster_counts={g:len(v) for g,v in groups.items()},protected_facets=protected,
             protected_midside_IDs_unchanged=True,all_old_INP_NODE_lexemes_unchanged=True,all_old_NPZ_tags_XYZ_prefix_bytes_unchanged=True,
             all_actual_nodes_used=True,actual_NPZ_INP_coordinate_guard_mm=1e-10,actual_NPZ_boundaries_equal_INP=True)
        write(output/'actual-mesh-preservation.json',report['actual_preservation'])
        points={int(t):list(x) for t,x in zip(new['tags'],new['xyz'])};elements=list(new['elements'].items())
        measurements=[measure.region_edges(points,elements,region) for region in spec['regions']]
        report['whole_original_measurements']=measurements
        for i,result in enumerate(measurements):write(output/('measurement-'+str(i)+'.json'),result)
        accept_measurements(measurements)
        report.update(status='existing_raw_new_taper_mesh_measured_no_admission',
              both_half_h_targets_measured_attained=True,diagnosed_candidate_INP_sha256=sha(ROOT/plan['meshes'][1]['inp']),
              diagnosed_candidate_NPZ_sha256=sha(ROOT/plan['meshes'][1]['npz']),diagnosed_candidate_metadata_sha256=sha(ROOT/plan['meshes'][1]['metadata']))
    except BaseException as exc:error=exc;report['error']=dict(type=type(exc).__name__,message=str(exc))
    finally:signal.setitimer(signal.ITIMER_REAL,0)
    after={p:sha(ROOT/p) for p in pins};report.update(sources_before=before,sources_after=after,sources_unchanged=before==after,
        plan_sha256=expected,plan_unchanged=sha(path)==expected,wall_seconds=time.monotonic()-started,peak_RSS_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss)
    write(output/'assessment.json',report);require(before==after and report['plan_unchanged'],'Readonly diagnostic mutated a pinned input')
    if error is not None:raise error
    print(json.dumps(dict(status=report['status'],assessment_sha256=sha(output/'assessment.json'))),flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('plan');parser.add_argument('--plan-sha256',required=True)
    args=parser.parse_args();run(args.plan,args.plan_sha256)
