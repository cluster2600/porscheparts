"""Fifteen retained guards plus compact BREP/closed-ROI contracts, stdlib only."""
import ast
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
OLD = ROOT / 'work/carrier-process-20261017/bounded-webs-discrete-real-preparation-002'

def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec); spec.loader.exec_module(result); return result

r = load('unarmed_C1_adaptive', HERE / 'run.py')
retained = load('retained_discrete_guards', OLD / 'selfcheck.py')
retained.r = r; retained.HERE = HERE


def fixture(root):
    def write(name, data):
        (root / name).write_text(json.dumps(data)); return name
    write('mesh.inp', 'synthetic mesh identity, never parsed')
    plan = dict(BREP_sha256='b' * 64, reference_mesh='.', cases_root_review='review.json',
                files_sha256={'./mesh.inp': r.sha(root / 'mesh.inp')}, cases={})
    review = dict(status='root_closed_two_actual_C1_BREP_linear_cases_energy_PASS_all_peaks_preserved',
                  BREP_sha256=plan['BREP_sha256'], new_mesh_inp_sha256=r.sha(root / 'mesh.inp'), cases={})
    regions = []
    for key, name in [('rigid', 'combined-rigid-static'), ('spring', 'combined-spring-1000-static')]:
        peak = dict(element_id=42, IP_one_based=1, reference_undeformed_IP_xyz_mm=[.25, .25, .25],
                    corner_measure=dict(bounds_mm=[[0, 0, 0], [1, 1, 1]], measured_h_mm=1., proposed_half_h_mm=.5))
        paths = dict(assessment=write(key+'-assessment.json',dict(status='actual_linear_static_and_independent_energy_completed',
                         sources_unchanged=True, plan_unchanged=True, within_case_budget=True, case_name=name,
                         native_result=dict(mesh_sha256=r.sha(root/'mesh.inp')))),
                     energy=write(key+'-energy.json',dict(energy_closure_pass=True, tolerance=1e-4, relative_energy_closure_error=1e-8)),
                     peaks=write(key+'-peaks.json',dict(case=name, no_peak_excluded=True, maximum_ties=1, all_global_maximum_ties=[peak])))
        paths['terminal'] = write(key+'-terminal.json',dict(actual_tool_returncode=0, actual_container_exit_code=0,
                     container_removed=True, fresh_source_pins_equal=True,
                     assessment_sha256=r.sha(root/paths['assessment']), energy_audit_sha256=r.sha(root/paths['energy']),
                     global_peaks_sha256=r.sha(root/paths['peaks'])))
        plan['cases'][key] = paths; review['cases'][key] = dict(terminal_sha256=r.sha(root/paths['terminal']))
        regions.append(dict(id=name, element_id=42, reference_IP_one_based=1, reference_IP_xyz_mm=[.25, .25, .25],
                            bounds_mm=[[0, 0, 0], [1, 1, 1]], measured_reference_h_mm=1., target_h_mm=.5))
    write('review.json', review)
    return plan, regions


class NewChecks(unittest.TestCase):
    def test_literal_inverse_and_common_math_ast(self):
        record = json.loads((HERE/'source-changes.json').read_text()); text = (HERE/'run.py').read_text()
        for row in reversed(record['replacements']):
            self.assertEqual(text.count(row['after']), 1); text = text.replace(row['after'], row['before'])
        self.assertEqual(text, (OLD/'run.py').read_text())
        funcs = lambda p: {n.name: ast.dump(n, include_attributes=False) for n in ast.parse(p.read_text()).body if isinstance(n, ast.FunctionDef)}
        old, new = funcs(OLD/'run.py'), funcs(HERE/'run.py')
        for name in ['require','sha','load','protected_facets','node_lines','ordered_tags','retain_npz_xyz','adaptive_refine']:
            self.assertEqual(old[name], new[name], name)

    def test_current_BREP_metadata_no_false_STEP_or_Gmsh(self):
        keys = ['CAD_source_format','CAD_source_file','BREP_sha256','CAD_master_receipt_sha256','CAD_volume_receipt_sha256',
                'CAD_volume_operator','CAD_adaptive_master_volume_mm3','OCC_import_reference_receipt_sha256',
                'OCC_import_check_reference_mm3','OCC_import_check_operator']
        reference = {k:'historical-unchanged-'+k for k in keys}; reference.update(global_mesh_size_factor=.875, nodes=123)
        original = dict(reference); source = dict(format='BREP', sha256='b'*64)
        meta = r.mesh_metadata(reference, {'minimum_Jacobian':.25}, 200, 80, 9., 10., {'end0':12}, '4.15.2', 'current-C1', 'a'*64, source)
        self.assertEqual(reference, original); self.assertEqual(meta['historical_reference_mesh_metadata'], reference)
        self.assertEqual(meta['CAD_source'], source); self.assertNotIn('STEP_sha256', meta)
        self.assertNotIn('global_mesh_size_factor',meta); self.assertEqual(meta['nodes'],200)
        self.assertFalse(meta['quality_evaluator']['remeshing'])
        self.assertTrue(all(meta[k]==reference[k] for k in keys))
        with self.assertRaisesRegex(ValueError,'Explicit BREP'):
            r.mesh_metadata(dict(reference,STEP_sha256='wrong'), {'minimum_Jacobian':.25},200,80,9.,10.,{},'4.15.2','x','a',source)

    def test_explicit_BREP_parent_layout_exclusive(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp); src=root/'source'; src.mkdir(); dst=root/'out';dst.mkdir()
            sources={};expected={}
            for name in ['carrier.brep','study.json','brep-master.json']:
                (src/name).write_bytes(name.encode());sources[name]=src/name;expected[name]=r.sha(src/name)
            self.assertEqual(r.copy_parent_inputs(sources,dst,expected),expected)
            self.assertEqual(set(p.name for p in dst.iterdir()),set(sources))
            with self.assertRaises(FileExistsError):r.copy_parent_inputs(sources,dst,expected)
            with self.assertRaisesRegex(ValueError,'Incomplete'):r.copy_parent_inputs({'carrier.step':src/'carrier.brep'},dst,{})

    def test_two_closed_real_ROI_contracts_pass(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);plan,regions=fixture(root)
            with patch.object(r,'ROOT',root):r.verify_C1_cases(plan,regions)

    def test_wrong_half_h_or_box_refused(self):
        for key,value in [('target_h_mm',.6),('bounds_mm',[[0,0,0],[2,2,2]])]:
            with self.subTest(key=key),tempfile.TemporaryDirectory() as tmp:
                root=Path(tmp);plan,regions=fixture(root);regions[0][key]=value
                with patch.object(r,'ROOT',root),self.assertRaisesRegex(ValueError,'ROI/half-h'):r.verify_C1_cases(plan,regions)

    def test_crossed_actual_result_SHA_refused(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);plan,regions=fixture(root);p=root/plan['cases']['rigid']['terminal'];d=json.loads(p.read_text());d['energy_audit_sha256']='0'*64;p.write_text(json.dumps(d))
            with patch.object(r,'ROOT',root),self.assertRaisesRegex(ValueError,'SHA join'):r.verify_C1_cases(plan,regions)

    def test_failed_native_or_wrong_master_refused(self):
        for role in ['native','master']:
            with self.subTest(role=role),tempfile.TemporaryDirectory() as tmp:
                root=Path(tmp);plan,regions=fixture(root)
                if role=='native':
                    p=root/plan['cases']['rigid']['terminal'];d=json.loads(p.read_text());d['actual_container_exit_code']=1;p.write_text(json.dumps(d))
                else:
                    p=root/'review.json';d=json.loads(p.read_text());d['BREP_sha256']='0'*64;p.write_text(json.dumps(d))
                with patch.object(r,'ROOT',root),self.assertRaises(ValueError):r.verify_C1_cases(plan,regions)


if __name__=='__main__':
    replaced={'test_current_metadata_does_not_inherit_Gmsh_sizing','test_parent_layout_exact_and_exclusive'}
    baseline=[retained.Checks(n) for n in unittest.defaultTestLoader.getTestCaseNames(retained.Checks) if n not in replaced]
    suite=unittest.TestSuite([*baseline,unittest.defaultTestLoader.loadTestsFromTestCase(NewChecks)])
    raise SystemExit(not unittest.TextTestRunner(verbosity=1).run(suite).wasSuccessful())
