"""Small source, pending-plan and native-result stubs; no CAD or scientific import."""
import ast
import copy
import importlib.util
import inspect
import json
from pathlib import Path
import sys
import tempfile
import textwrap
import unittest
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[2]
def load(name,path):
 s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
m=load('_C1_native_preparation',HERE/'diagnose.py');local=load('_C1_D2_fixture',HERE/'local_properties.py')
class Props:
 def IsNormalDefined(self):return True
 def IsCurvatureDefined(self):return True
 def Normal(self):return type('Direction',(),{'Coord':lambda self:(0.,0.,1.)})()
 def MinCurvature(self):return 0.
 def MaxCurvature(self):return 1.
 def MeanCurvature(self):return .5
 def GaussianCurvature(self):return 0.
def hit(w,face,origin=False,state='TopAbs_IN',transition='IntCurveSurface_Out'):
 return dict(W_mm=w,face_index_zero_based=face,coincident_with_start_native_tolerance=origin,state=state,transition=transition)
class Tests(unittest.TestCase):
 def test_no_scientific_import(self):self.assertFalse(set(sys.modules)&{'numpy','build123d','OCP'})
 def test_retained_four_function_bodies_exact(self):
  path=ROOT/'work/carrier-process-20261017/bounded-webs-peak-brep-diagnostic-002/diagnose.py';ns=m.retained_namespace(path,{})
  run=next(n for n in ast.parse(path.read_text()).body if isinstance(n,ast.FunctionDef)and n.name=='run')
  for name in ('query','bounds','surface_info','edge_info'):
   old=next(n for n in run.body if isinstance(n,ast.FunctionDef)and n.name==name)
   actual=ast.parse(textwrap.dedent(inspect.getsource(ns[name]))).body[0]
   self.assertEqual(ast.dump(old,include_attributes=False),ast.dump(actual,include_attributes=False))
 def test_pending_rejects_before_any_native_inputs(self):
  with tempfile.TemporaryDirectory()as t:
   p=Path(t)/'p.json';p.write_text(json.dumps(dict(launch_ready=False)))
   with self.assertRaisesRegex(ValueError,'NON-ARMED'):m.verify(p,m.sha(p),True)
 def test_plan_sha_refused_first(self):
  with tempfile.TemporaryDirectory()as t:
   p=Path(t)/'p';p.write_text('{}')
   with self.assertRaisesRegex(ValueError,'Plan identity'):m.verify(p,'0'*64,True)
 def test_changed_bounds_refused(self):
  for key,value in [('outer',181),('inner',151),('CPU',[140,160]),('workers',1),('threads',2)]:
   with self.subTest(key=key),tempfile.TemporaryDirectory()as t:
    bounds=dict(outer=180,inner=150,CPU=[140,141],threads=1,workers=0);bounds[key]=value
    p=Path(t)/'p';p.write_text(json.dumps(dict(schema='actual-C1-common-IP-native-plan-1',launch_ready=False,bounds=bounds)))
    with self.assertRaisesRegex(ValueError,'bounds'):m.verify(p,m.sha(p))
 def test_support_and_outward_normals_distinct(self):
  r=local.curvature(Props(),'TopAbs_REVERSED');self.assertEqual(r['normal_support'],[0.,0.,1.]);self.assertEqual(r['normal_outward'],[-0.,-0.,-1.]);self.assertEqual(r['maximum_curvature_per_mm'],1.)
 def test_undefined_D2_stays_unmeasured(self):
  p=Props();p.IsCurvatureDefined=lambda:False;r=local.curvature(p,'TopAbs_FORWARD');self.assertEqual(r['status'],'undefined_native_D2_properties');self.assertIsNone(r['local_chord'])
 def test_nonfinite_native_curvature_refused(self):
  p=Props();p.MaxCurvature=lambda:float('nan')
  with self.assertRaises(ValueError):local.curvature(p,'TopAbs_FORWARD')
 def test_edge_or_vertex_support_never_calls_D2(self):
  tree=ast.parse((HERE/'diagnose.py').read_text());fn=next(n for n in ast.walk(tree)if isinstance(n,ast.FunctionDef)and n.name=='properties');ns={}
  exec(compile(ast.Module(body=[fn],type_ignores=[]),'properties-source-fixture','exec'),ns)
  for kind in ('BRepExtrema_IsOnEdge','BRepExtrema_IsVertex'):
   result=type('Result',(),{'SupportTypeShape2':lambda self,index:kind,'NbSolution':lambda self:1})()
   self.assertEqual(ns['properties'](0,result)['status'],'closest_support_not_face_interior')
 def test_one_unambiguous_local_chord(self):
  h=[hit(0.,3,True,transition='IntCurveSurface_In'),hit(2.5,4)];r=local.qualify_chord(h,3)
  self.assertEqual(r['thickness_mm'],2.5);self.assertIn('not_global',r['scope'])
 def test_tangent_or_boundary_target_no_thickness(self):
  for changes in [dict(transition='IntCurveSurface_Tangent'),dict(state='TopAbs_ON')]:
   h=[hit(0.,3,True,transition='IntCurveSurface_In'),hit(2.5,4)];h[1].update(changes);self.assertIsNone(local.qualify_chord(h,3)['thickness_mm'])
 def test_no_origin_or_foreign_origin_no_thickness(self):
  for h in [[hit(2.5,4)],[hit(0.,2,True,transition='IntCurveSurface_In'),hit(2.5,4)]]:self.assertIsNone(local.qualify_chord(h,3)['thickness_mm'])
 def test_duplicate_origin_or_first_exit_no_thickness(self):
  h=[hit(0.,3,True,transition='IntCurveSurface_In'),hit(2.5,4)]
  for extra in [h[0],h[1]]:self.assertIsNone(local.qualify_chord(h+[extra],3)['thickness_mm'])
 def test_first_crossing_must_be_out(self):
  h=[hit(0.,3,True,transition='IntCurveSurface_In'),hit(1.,4,transition='IntCurveSurface_In'),hit(2.5,5)]
  self.assertIsNone(local.qualify_chord(h,3)['thickness_mm'])
 def test_ray_and_section_use_actual_geometry_not_old_caps(self):
  s=(HERE/'diagnose.py').read_text();self.assertIn('0.,diagonal)',s);self.assertIn('gp_Pnt(point[0],0.,0.)',s);self.assertIn('Approximation(False)',s)
  self.assertNotIn('1e-5',s);self.assertNotIn('81.675',s);self.assertNotIn('85535',s)
 def test_D2_is_explicit_and_no_fillet_remesh_solver(self):
  tree=ast.parse((HERE/'diagnose.py').read_text());calls=[n for n in ast.walk(tree)if isinstance(n,ast.Call)]
  prop=next(n for n in calls if isinstance(n.func,ast.Name)and n.func.id=='BRepLProp_SLProps');self.assertEqual(prop.args[3].value,2)
  self.assertFalse(any(isinstance(n.func,ast.Attribute)and n.func.attr in ('Add','generate','solve','mesh')for n in calls))
 def test_multiple_closest_supports_never_use_the_first(self):
  tree=ast.parse((HERE/'diagnose.py').read_text());fn=next(n for n in ast.walk(tree)if isinstance(n,ast.FunctionDef)and n.name=='properties');ns={}
  exec(compile(ast.Module(body=[fn],type_ignores=[]),'properties-source-fixture','exec'),ns)
  result=type('Result',(),{'NbSolution':lambda self:2})()
  row=ns['properties'](0,result);self.assertEqual(row['status'],'unresolved_native_multiple_closest_supports');self.assertEqual(row['closest_solution_count'],2);self.assertIsNone(row['local_chord'])
 def test_multiple_shells_never_trace_the_first(self):
  from types import SimpleNamespace
  tree=ast.parse((HERE/'diagnose.py').read_text());fn=next(n for n in ast.walk(tree)if isinstance(n,ast.FunctionDef)and n.name=='properties')
  def forbidden():raise AssertionError('Must not instantiate a native ray')
  ns=dict(local=local,faces=[SimpleNamespace(wrapped=SimpleNamespace(Orientation=lambda:'TopAbs_FORWARD'))],BRepAdaptor_Surface=lambda *args:None,BRepLProp_SLProps=lambda *args:Props(),tolerance=.001,
   box=[[-1.,-1.,-1.],[1.,1.,1.]],body=SimpleNamespace(shells=lambda:[object(),object()]),IntCurvesFace_ShapeIntersector=forbidden)
  exec(compile(ast.Module(body=[fn],type_ignores=[]),'properties-source-fixture','exec'),ns)
  result=SimpleNamespace(NbSolution=lambda:1,SupportTypeShape2=lambda index:'BRepExtrema_IsInFace',ParOnFaceS2=lambda index:(0.,0.),PointOnShape2=lambda index:SimpleNamespace(Coord=lambda:(0.,0.,0.)))
  row=ns['properties'](0,result);self.assertEqual(row['local_chord']['shell_count'],2);self.assertIsNone(row['local_chord']['thickness_mm'])
 def test_unknown_orientation_has_no_outward_normal(self):
  for orientation in ('TopAbs_INTERNAL','TopAbs_EXTERNAL','unknown'):
   row=local.curvature(Props(),orientation);self.assertEqual(row['status'],'undefined_native_topological_orientation');self.assertIsNone(row['normal_outward']);self.assertIsNone(row['local_chord'])
if __name__=='__main__':unittest.main()
