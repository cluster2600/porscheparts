"""Sixteen frozen baseline checks and small source/closed-qualification fixtures; no NumPy or Docker."""
import ast
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
OLD = ROOT / 'work/carrier-process-20261017/bounded-webs-BREP-static-preparation-002'

def load(name, path):
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m

r=load('new_qualified_C1_static',HERE/'run.py')
baseline=load('sixteen_frozen_static_checks',OLD/'selfcheck_v3.py')

def fixture(root):
    names={k:'qualification-'+k+'.json' for k in ('terminal','assessment','supervision','root_review','preservation','measurement_0','measurement_1')}
    names={'qualification_'+k:v for k,v in names.items()}
    def put(role,value): (root/names['qualification_'+role]).write_text(json.dumps(value))
    flags=dict(original_run_h2_qualified=False,original_volume_guard_overridden=False,refinement_repeated=False,FEA_started=False)
    tool=dict(session_id=13579,initial_chunk='7b7180',terminal_chunk='634ad2',RC=0)
    counts=dict(bolt0=528,bolt1=528,bolt2=528,bolt3=528,end0=2274,end1=2278)
    preservation=dict(six_roster_counts=counts,protected_facets={str(i):['end0'] for i in range(3210)},
        protected_midside_IDs_unchanged=True,all_old_INP_NODE_lexemes_unchanged=True,
        all_old_NPZ_tags_XYZ_prefix_bytes_unchanged=True,all_actual_nodes_used=True)
    rows=[dict(region_id=r.CASES[k][0],target_attained=True,measured_h_mm=.4,target_h_mm=.4668954269534402) for k in ('rigid','spring')]
    for i,m in enumerate(rows):put('measurement_'+str(i),m)
    put('preservation',preservation)
    hashes={'mesh.inp':'a'*64,'mesh.npz':'b'*64,'mesh.json':'c'*64}
    qualified=dict(inp_sha256=hashes['mesh.inp'],npz_sha256=hashes['mesh.npz'],metadata_sha256=hashes['mesh.json'])
    actual=dict(flags,status='existing_C1_h2_qualified_under_distinct_serialized_volume_contract_no_FEA',
        h2_qualified_under_distinct_serialized_reference=True,sources_unchanged=True,plan_unchanged=True,
        qualified_candidate_INP_sha256=hashes['mesh.inp'],qualified_candidate_NPZ_sha256=hashes['mesh.npz'],
        qualified_candidate_metadata_sha256=hashes['mesh.json'],whole_original_measurements=rows,actual_preservation=preservation,
        distinct_volume_authority={'comparison':dict(binary64_equal=True,exact_difference_of_observed_binary64_mm3='0',historical_volume_guard_overridden=False)})
    put('assessment',actual)
    supervision=dict(actual_returncode=0,direct_child_reaped=True,final_group_members=[],timeout=False,interrupted=False,sources_and_plan_unchanged=True)
    put('supervision',supervision)
    outputs={}
    for role,filename in [('preservation','actual-mesh-preservation.json'),('measurement_0','measurement-0.json'),('measurement_1','measurement-1.json')]:
        outputs['output-001/'+filename]={'sha256':r.sha(root/names['qualification_'+role])}
    terminal=dict(actual_tool=tool,actual_outer_returncode=0,actual_child_returncode=0,direct_child_reaped=True,final_group_members=[],
        fresh_pins_equal=True,sources_and_plan_unchanged=True,assessment_sha256=r.sha(root/names['qualification_assessment']),
        supervision_sha256=r.sha(root/names['qualification_supervision']),qualified_candidate=qualified,whole_measurements=rows,
        outputs=outputs,protected_facets_count=3210)
    put('terminal',terminal)
    review=dict(flags,actual_tool=tool,terminal_sha256=r.sha(root/names['qualification_terminal']),
        assessment_sha256=r.sha(root/names['qualification_assessment']),supervision_sha256=r.sha(root/names['qualification_supervision']),
        h2_qualified_under_distinct_serialized_reference=True,whole_measurements=rows,six_roster_counts=counts,
        protected_facets_count=3210,entire_preservation_report_sha256=r.sha(root/names['qualification_preservation']),
        complete_three_pass_and_same_operator_volume_proofs_rejoined=True)
    put('root_review',review)
    plan=dict(names,mesh_files_sha256=hashes,expected_bore_node_counts=counts,
              files_sha256={n:r.sha(root/n) for n in names.values()})
    return plan,actual,terminal,review

class Checks(unittest.TestCase):
    def test_source_delta_exact_and_unchanged_math_callbacks(self):
        record=json.loads((HERE/'source-derivation.json').read_text())
        old=(OLD/'run.py').read_text();new=(HERE/'run.py').read_text()
        self.assertEqual(hashlib.sha256(old.encode()).hexdigest(),record['reference_caller_sha256'])
        rebuilt=old
        for row in record['replacements']:
            self.assertEqual(rebuilt.count(row['old']),1);rebuilt=rebuilt.replace(row['old'],row['new'])
        self.assertEqual(rebuilt,new)
        funcs=lambda text:{n.name:ast.dump(n) for n in ast.parse(text).body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
        a,b=funcs(old),funcs(new)
        self.assertEqual([n for n in a if a[n]!=b[n]],['verified','prepare','run'])
        for name in record['unchanged_AST_functions_and_classes']:self.assertEqual(a[name],b[name])
        self.assertEqual(r.sha(ROOT/record['solve_source']),record['solve_source_sha256'])

    def test_closed_qualification_fixture_passes(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d);plan,*_=fixture(p)
            with patch.object(r,'ROOT',p):r.verify_qualification(plan)

    def test_crossed_assessment_pin_is_not_terminal_authority(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d);plan,a,t,review=fixture(p);t['assessment_sha256']='0'*64
            (p/plan['qualification_terminal']).write_text(json.dumps(t))
            review['terminal_sha256']=r.sha(p/plan['qualification_terminal'])
            (p/plan['qualification_root_review']).write_text(json.dumps(review))
            plan['files_sha256']={n:r.sha(p/n) for n in plan['files_sha256']}
            with patch.object(r,'ROOT',p),self.assertRaisesRegex(ValueError,'SHA joins'):r.verify_qualification(plan)

    def test_candidate_and_legacy_refusal_cannot_be_relabelled(self):
        for field in ('candidate','legacy'):
            with self.subTest(field=field),tempfile.TemporaryDirectory() as d:
                p=Path(d);plan,a,*_=fixture(p)
                if field=='candidate':plan['mesh_files_sha256']['mesh.inp']='0'*64
                else:a['original_run_h2_qualified']=True;(p/plan['qualification_assessment']).write_text(json.dumps(a))
                with patch.object(r,'ROOT',p),self.assertRaises(ValueError):r.verify_qualification(plan)

    def test_entire_measurement_output_cannot_be_crossed(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d);plan,*_=fixture(p);m=json.loads((p/plan['qualification_measurement_0']).read_text());m['target_attained']=False
            (p/plan['qualification_measurement_0']).write_text(json.dumps(m))
            with patch.object(r,'ROOT',p),self.assertRaisesRegex(ValueError,'measurements'):r.verify_qualification(plan)

    def test_actual_coarse_cards_and_complete_contract_equal(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d);(p/'coarse.inp').write_text('frozen coarse deck');evidence={'full':{'unused':3}}
            (p/'contract.json').write_text(json.dumps(evidence));plan=dict(coarse_deck='coarse.inp',coarse_load_support='contract.json')
            blocks=[('*NSET,NSET=FIXED',['1,2']),('*BOUNDARY',['FIXED,1,3']),('*CLOAD',['3,3,-4000'])]
            with patch.object(r,'ROOT',p):
                result=r.verify_coarse_deck(plan,blocks,evidence,lambda _:copy.deepcopy(blocks))
                self.assertTrue(result['complete_load_support_contract_equal'])
                changed=copy.deepcopy(blocks);changed[-1][1][0]='3,3,-3999'
                with self.assertRaisesRegex(ValueError,'cards changed'):r.verify_coarse_deck(plan,changed,evidence,lambda _:copy.deepcopy(blocks))
                with self.assertRaisesRegex(ValueError,'contract differs'):r.verify_coarse_deck(plan,blocks,{'full':{'unused':4}},lambda _:copy.deepcopy(blocks))

    def test_spring_element_IDs_may_change_but_nodes_may_not(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d);(p/'coarse.inp').write_text('frozen coarse deck');(p/'contract.json').write_text('{}')
            plan=dict(coarse_deck='coarse.inp',coarse_load_support='contract.json')
            old=[('*ELEMENT,TYPE=SPRING1,ELSET=S01',['100,10','101,11'])]
            new=[('*ELEMENT,TYPE=SPRING1,ELSET=S01',['200,10','201,11'])]
            with patch.object(r,'ROOT',p):
                r.verify_coarse_deck(plan,new,{},lambda _:old)
                new[0][1][1]='201,12'
                with self.assertRaisesRegex(ValueError,'spring node'):r.verify_coarse_deck(plan,new,{},lambda _:old)

    def test_new_plans_remain_unarmed_before_any_scientific_import(self):
        for case in ('rigid','spring'):
            path=HERE/(case+'-pending-plan.json');plan=json.loads(path.read_text())
            self.assertFalse(plan['launch_ready']);self.assertFalse(plan['FEA_executed'])
            with self.assertRaisesRegex(ValueError,'not armed'):r.verified(plan,r.sha(path),path)

if __name__=='__main__':
    suite=unittest.TestSuite([unittest.defaultTestLoader.loadTestsFromTestCase(baseline.baseline.retained.Checks),
        unittest.defaultTestLoader.loadTestsFromTestCase(baseline.baseline.NewChecks),
        unittest.defaultTestLoader.loadTestsFromTestCase(baseline.NewChecks),unittest.defaultTestLoader.loadTestsFromTestCase(Checks)])
    raise SystemExit(not unittest.TextTestRunner(verbosity=1).run(suite).wasSuccessful())
