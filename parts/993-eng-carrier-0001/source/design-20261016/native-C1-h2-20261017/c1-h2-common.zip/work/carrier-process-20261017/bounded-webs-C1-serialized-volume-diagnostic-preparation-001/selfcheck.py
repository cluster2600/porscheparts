"""Pure serialization/binding/source contracts; no NumPy/Gmsh/mesh import."""
import ast
import importlib.util
import json
import math
from pathlib import Path
import struct
import tempfile
import textwrap
import unittest
from unittest.mock import patch

HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('unarmed_serialized_pair',HERE/'run.py')
r=importlib.util.module_from_spec(spec);spec.loader.exec_module(r)


def fixture(root):
    def write(name,data):
        (root/name).write_text(json.dumps(data));return name
    candidate=write('candidate.inp','synthetic identity, not a mesh')
    plan=dict(h2_terminal='terminal.json',h2_assessment='assessment.json',h2_supervision='supervision.json',
              meshes=[dict(id='baseline_serialized_C1',inp='unused'),dict(id='candidate_refused_h2',inp=candidate)],
              files_sha256={candidate:r.sha(root/candidate)})
    write('assessment.json',dict(error=dict(message='Original volume non-regression gate failed'),
          volume_error_non_regression=False,h2_qualified=False,pins_unchanged=True,plan_unchanged=True))
    write('supervision.json',dict(actual_returncode=1,direct_child_reaped=True,final_group_members=[],timeout=False,sources_and_plan_unchanged=True))
    write('terminal.json',dict(actual_outer_returncode=1,actual_child_returncode=1,direct_child_reaped=True,final_group_members=[],
          fresh_plan_pins_equal=True,h2_qualified=False,FEA_started=False,
          assessment_sha256=r.sha(root/'assessment.json'),supervision_sha256=r.sha(root/'supervision.json'),
          output_files={'mesh/mesh.inp':dict(sha256=r.sha(root/candidate))}))
    return plan


class Checks(unittest.TestCase):
    def test_Gmsh_block_exact_and_no_generation(self):
        record=json.loads((HERE/'gmsh-block-provenance.json').read_text())
        text=(HERE/'run.py').read_text();tree=ast.parse(text)
        fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='read_one')
        segment=ast.get_source_segment(text,fn)
        start=segment.index('    gmsh.initialize()\n');end=segment.index('    finally: gmsh.finalize()\n')+len('    finally: gmsh.finalize()\n')
        self.assertEqual(textwrap.dedent(segment[start:end]),record['extracted_block'])
        calls={ast.unparse(n.func) for n in ast.walk(tree) if isinstance(n,ast.Call) and ast.unparse(n.func).startswith('gmsh.')}
        self.assertEqual(calls,{'gmsh.initialize','gmsh.finalize','gmsh.option.setNumber','gmsh.model.mesh.getElementProperties',
            'gmsh.model.addDiscreteEntity','gmsh.model.mesh.addNodes','gmsh.model.mesh.addElementsByType',
            'gmsh.model.mesh.getElements','gmsh.model.mesh.getNodes','gmsh.model.mesh.getElementQualities'})

    def test_binary64_and_JSON_roundtrip(self):
        for value in [285536.3061386665,1.,math.nextafter(1.,math.inf),float.fromhex('0x0.0000000000001p-1022')]:
            d=json.loads(json.dumps(r.number(value)))
            self.assertEqual(struct.pack('>d',d['mm3']).hex(),d['binary64_big_endian_hex'])
            self.assertEqual(float.fromhex(d['float_hex']),value)

    def test_zero_tolerance_comparison_never_admits(self):
        same=r.pair_comparison(1.,1.);near=r.pair_comparison(1.,math.nextafter(1.,math.inf))
        self.assertTrue(same['binary64_equal']);self.assertEqual(same['exact_difference_of_observed_binary64_mm3'],'0')
        self.assertFalse(near['binary64_equal']);self.assertNotEqual(near['exact_difference_of_observed_binary64_mm3'],'0')
        self.assertFalse(same['admission']);self.assertFalse(same['historical_volume_guard_overridden'])
        for v in [0.,-0.,-1.,True,float('nan'),float('inf')]:
            with self.subTest(value=v),self.assertRaises(ValueError):r.number(v)

    def test_closed_actual_refusal_passes_without_adopting(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);plan=fixture(root)
            with patch.object(r,'ROOT',root):r.verify_closed_refusal(plan)

    def test_wrong_return_or_crossed_assessment_refuses(self):
        for key,value in [('actual_child_returncode',0),('assessment_sha256','0'*64)]:
            with self.subTest(key=key),tempfile.TemporaryDirectory() as tmp:
                root=Path(tmp);plan=fixture(root);f=root/'terminal.json';d=json.loads(f.read_text());d[key]=value;f.write_text(json.dumps(d))
                with patch.object(r,'ROOT',root),self.assertRaises(ValueError):r.verify_closed_refusal(plan)

    def test_wrong_candidate_payload_refuses(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);plan=fixture(root);plan['files_sha256']['candidate.inp']='0'*64
            with patch.object(r,'ROOT',root),self.assertRaisesRegex(ValueError,'payload'):r.verify_closed_refusal(plan)

    def test_unarmed_before_scientific_import_or_data(self):
        with tempfile.TemporaryDirectory() as tmp:
            f=Path(tmp)/'plan.json';f.write_text(json.dumps(dict(launch_ready=False)))
            with self.assertRaisesRegex(ValueError,'unarmed'):r.run(f,r.sha(f))
        for node in ast.parse((HERE/'run.py').read_text()).body:
            if isinstance(node,(ast.Import,ast.ImportFrom)):
                self.assertFalse(any(n.name.startswith(('numpy','gmsh','skfem')) for n in node.names))


if __name__=='__main__':unittest.main()
