# Diagnostic de volume sérialisé C1, non armé

Un seul processus évaluera successivement le vrai baseline mesh.inp20b6 et le candidat h/2 déjà refusé, sans relancer le raffinement. read_one reprend exactement le bloc Gmsh de la source C1 refusée0e899 (indentation seule, preuve gmsh-block-provenance.json) : modèle discret, mêmes tableaux lus par energy.read_mesh, type11/permutationnative/inverse, mêmes contrôles coords/connectivité, Jac et volume.sum dans l'ordre getElements. Chaque appel initialize/finalize est indépendant. Aucun importCAO, mesh.generate, optimisation, nouveau maillage ni FEA.

Les deux volumes seront rendus en JSON, float.hex et octets binary64 big-endian. Leur comparaison est l'égalité des64bits, sans epsilon. Le delta Fraction décrit exactement les deux doubles observés, pas le volume géométrique exact. Les anciens mesh.json, leurs erreurs relatives et les deux volumes des audits énergie clos seront rapportés séparément ; l'opérateur de ces audits affines n'est pas présenté comme l'opérateur Gmsh. La référenceCAO adaptative reste285603.99883560487. Aucun fichier ni garde historique n'est réécrit.

Le RC1 réel H2 C1 et ses trois preuves/journal restent intacts. Le caller joint le vrai terminal à son assessment/supervision et au SHA du candidat sérialisé. Un résultat égal pourra seulement motiver une proposition ultérieure de comparaison like-for-like à zéro tolérance. Le diagnostic garde toujours h2_qualified=false et historical_volume_guard_overridden=false. Il ne mesure pas h ; le marquage final vide n'est jamais promu en qualification.

Bornes proposées :180s superviseur/150s alarme/CPU140–160,1thread/0worker/nice10. Le readback précédent de85315T10 prenait1,66s ; deux lectures d'environ90kT10 motivent cette borne sans préjuger leur durée. Gmsh4.15.2/NumPy/python sont ceux du runtime existant, sources et bibliothèques pinnées. Aucun runtime modifié.

Sept tests stdlib réels passent : blocGmsh exact+interdiction des autres appels, représentationdouble/JSON ycomprissubnormal, différence1ULP refusée, absence d'admission même surégalité, jointures/refus natif/payload et arrêt nonarmé avant import. Prévol uniquementSHA/JSON, aucun INP/NPZ parsé.

pending-plan.json et pending-launch-plan.json restent NON armés (GO_SHA null). Commande fournie pour revue seulement ; aucune exécution avant vraiGO puis nouveaux plans armés distincts. Les résultats futurs ne sont pas inventés.
