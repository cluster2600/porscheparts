# Diagnostic natif du pic C1 — code préparé, non armé

Seul point de référence : élément84037/IP1, XYZ
[82.1363150782041,−14.38884836795918,12.860258089066248] mm, commun aux deux
cas C1 clos et lié au maître BREP a42e6942. Le point est recalculé avec le vrai
INP C1 et le `gauss_point` affine existant, qui vérifie aussi les six midsides.
Les quatre vrais coins du même élément servent uniquement de sondes annexes.
Pas de grille, d'ancienne sonde H2 ou d'alias entre rigide et K1000.

`retained_namespace` charge par AST les quatre fonctions internes `query`,
`bounds`, `surface_info`, `edge_info` du diagnostic002 corrigé d477d433. Leur
corps reste identique ; le nouveau namespace contient les faces/arêtes du
maître C1, les mêmes classes natives et le helper de normales9e5a1fee. Le
diagnostic d'origine entier n'est pas exécuté. Toutes les distances face/arête
sont rapportées ; les huit premières positions et leurs ex æquo conservent
les détails comme dans le diagnostic historique.

`local_properties.py` est le seul ajout de calcul local : propriétés D2 aux UV
natifs d'un support strictement intérieur à une face, courbures principales
signées suivant la paramétrisation du support et normale topologique orientée.
Les UV ne viennent pas d'une reprojection approximative. Les supports sur
arête/sommet et les propriétés non définies restent indéterminés. Les méthodes
D2 et les intersections sont documentées dans les sources primaires OCCT :
[BRepLProp_SLProps](https://github.com/Open-Cascade-SAS/OCCT/blob/V7_8_1/src/BRepLProp/BRepLProp_SLProps.hxx),
[IntCurvesFace_ShapeIntersector](https://github.com/Open-Cascade-SAS/OCCT/blob/V7_8_1/src/IntCurvesFace/IntCurvesFace_ShapeIntersector.hxx).
Ce repère documentaire ne remplace pas l'identité du runtime réellement pinné.

La normale intérieure sert à une requête sur le shell entier, de zéro à la
diagonale de sa boîte native. Toutes les intersections sont conservées avec
face, état, transition et paramètre. Seule une origine unique sur l'intérieur
de la face, transition entrante, suivie d'une première sortie unique sur
l'intérieur d'une face permet de nommer une corde normale locale. Toute
ambiguïté donne `thickness_mm=null`. Aucune limite historique1e−5/6mm n'est
copiée. Les tolérances viennent uniquement de la topologie/native Confusion.
Il ne s'agit pas d'une épaisseur minimale globale.

La coupe reprend `BRepAlgoAPI_Section`/`Approximation(False)` de l'export de la
figure22, à **X=82.1363150782041mm**, et reporte toutes ses arêtes, types,
longueurs et rayons natifs. Aucun échantillonnage pour le dessin n'est ajouté.
Le reçu conserve `role_assignment=null` : les mesures doivent être revues
avant de nommer une face pied de nervure/calotte/blendR1.

Les19 petits tests stdlib sont réellement PASS, y compris les quatre corps
AST identiques, garde non armée avant imports, D2 indéfini, orientation,
rayon ambigu, sommet/arête, plusieurs intersections et ex æquo. Les stubs ne
prouvent pas l'exécution des API natives. Aucun CAD, maillage, solveur ou import
scientifique n'a été exécuté pendant cette préparation.

Plan non armé :180s extérieures,150s alarme,CPU140/141s,1thread,0worker,
nice10 enfant et4d18 inchangé avec10+10s de nettoyage. Le prévol ne fait que des
hashes et lectures JSON. Une révision armée et un GO racine restent requis.

Révision002 : la source001 et ses preuves restent intactes. Plusieurs solutions
de distance donnent un statut indéterminé avant toute première solution ;
plusieurs shells empêchent tout rayon sur un sous-ensemble du solide ; seules
les orientations FORWARD/REVERSED définissent la normale extérieure. Trois
fixtures ciblées vérifient ces refus conservateurs. Aucune autre méthode,
borne, tolérance ou géométrie ne change.
