# Raffinement discret local du vrai C1 BREP, non armé

Le caller reprend la campagne adaptative discrète002 entière. Les huit fonctions communes require/sha/load/protected_facets/node_lines/ordered_tags/retain_npz_xyz/adaptive_refine sont AST identiques. Le bridgefaeb, package2e354, mesure8e38 et permutationGmsh3707 restent les mêmes fichiers gelés. Aucun code scikit-fem/Gmsh/énergie n'est modifié.

Le delta est explicite dans run.py.diff et treize substitutions réversibles source-changes.json : entrée globale C1 réelle, trois fichiers parent carrier.brep/study.json/brep-master.json, métadonnées BREP actuelles et liens vers les preuves closes mesh/protected/deuxFEA. verify_mesh et verify_protected sont appelés depuis le caller FEA002 gelé, sans recopier leurs gardes. Les ROI sont recoupées avec les deux rapports entiers de pics et leurs terminaux, eux-mêmes reliés à la revue racine4999244c. Ce contrôle de provenance n'exécute aucune mathématique de champ.

Les deux cas ont réellement le même pic84037/IP1 et AABB. Les deux entrées de peak-rois.json gardent donc cette même boîte et h0.9337908539068804→cible0.4668954269534402mm ; il n'y a ni marge de boîte ni grille. Marquage/fermeture/arrêt mark_t4 vide, facettes BC protégées à chaque passe, tous anciens nœuds utilisés, IDs/XYZ et anciens NODE INP conservés, préfixe NPZ séparé, rosters528×4/2274/2278 byteexacts et parentés immédiates par passe sont inchangés.

La qualité utilise seulement le modèle discret Gmsh4.15.2, permutation type11 puis inverse exacte, minDetJac>0 et volume>0. Le volume est rapporté au maître adaptatif C1 ; le garde de non-régression relative est exactement celui d'origine, contre mesh.json C1. Il n'y a pas de revendication de conservation géométrique Q exacte. Les métadonnées distinguent les autorités du maître inchangé, le backend scikit-fem actuel et le sizing Gmsh historique.

Bornes identiques :1200s externe/1150s alarme/CPU1100–1101,1thread/0worker,nice10,500knœuds et500kéléments, aucun retry. Les contrôles noyau et toutes les FEA restent à faire après GO ; ce dossier ne relit pas les champs natifs ni les maillages pendant ses tests/prévol (SHA seul sur les entrées). Aucun remesh CAD ni nouvelle CAO n'est demandé.

Vingt-deux tests stdlib réels passent : quinze gardes historiques appliquées au nouveau module et sept contrats BREP/ROI/provenance. Les deux anciens tests spécifiques STEP sont remplacés par les deux contrats BREP correspondants. Les bornes/définitions mathématiques ne changent pas.

Le pending-plan et le pending-launch-plan sont volontairement NON armés : root_GO_sha256=null et launch_ready=false. Le command-pending est un argv exact dont le caller refuserait l'exécution à ce stade. Après revue et vrai GO seulement, créer une nouvelle plan.json armée liée au vrai fichier GO, puis un nouveau launch-plan.json/command.json avec leurs vrais SHA ; préserver tous les pending. Ne lancer aucun kernel avant cela. Aucun futur SHA ni résultat n'est anticipé.
