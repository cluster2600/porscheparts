"""Bind the reviewed C1 diagnostic GO; scientific sources and pending plans remain immutable."""
import copy
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import time

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[2]
def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb')as f:
        for b in iter(lambda:f.read(1024**2),b''):h.update(b)
    return h.hexdigest()
def write(name,data):
    with (HERE/name).open('x')as f:
        json.dump(data,f,indent=2,allow_nan=False);f.write('\n');f.flush();os.fsync(f.fileno())
def rel(p):return str(p.relative_to(ROOT))
started=time.monotonic()
expected={'pending-plan.json':'a33432db850706bd5de64ccbc83e1e681081ba08cbcc854abf0ee8feb8dd569d','pending-launch-plan.json':'5afa5810d87e53a8b15156f7a9c955b4dcdcaef033d5f092847d221f86038e92','root-review-GO-001.json':'89e6c162f183b68638ec001aa44d384632dd7ba39f192e2ee1b41fdf587d1e35','diagnose.py':'a5e06380d8d3f2e04346573b560c6862f726dbd27dbde825fc563e3ac96ec771','local_properties.py':'5995a0d331c9ab1c546309eb0b2926cc3539a465b9ec88b10845db6f8c8b1005'}
assert {n:sha(HERE/n)for n in expected}==expected
original=json.loads((HERE/'pending-plan.json').read_text())
old_launch=json.loads((HERE/'pending-launch-plan.json').read_text())
go=json.loads((HERE/'root-review-GO-001.json').read_text())
assert go['status']=='GO_one_owned_native_readonly_diagnostic'
assert go['source_sha256']==expected['diagnose.py'] and go['helper_sha256']==expected['local_properties.py']
assert original['launch_ready']is False and old_launch['launch_ready']is False
for key in ('output_directory','execution_directory'):
    p=ROOT/original[key]
    assert not p.exists() and not any(q.is_symlink()for q in [p,*p.parents])
go_key=rel(HERE/'root-review-GO-001.json')
plan=copy.deepcopy(original);plan['launch_ready']=True;plan['files_sha256'][go_key]=expected['root-review-GO-001.json']
inverse=copy.deepcopy(plan);inverse['launch_ready']=False;del inverse['files_sha256'][go_key]
assert inverse==original
write('armed-plan.json',plan);plan_sha=sha(HERE/'armed-plan.json')
launch=copy.deepcopy(old_launch);launch['launch_ready']=True
assert launch['command'][-2:]==[str(HERE/'pending-plan.json'),expected['pending-plan.json']]
launch['command'][-2:]=[str(HERE/'armed-plan.json'),plan_sha]
launch['inputs_sha256'][go_key]=expected['root-review-GO-001.json']
armed_key=rel(HERE/'armed-plan.json');launch['inputs_sha256'][armed_key]=plan_sha
inverse=copy.deepcopy(launch);inverse['launch_ready']=False;inverse['command'][-2:]=old_launch['command'][-2:]
del inverse['inputs_sha256'][go_key];del inverse['inputs_sha256'][armed_key]
assert inverse==old_launch
pins={**launch['inputs_sha256'],**launch['source_sha256']}
actual={n:sha(ROOT/n)for n in pins};assert actual==pins
spec=importlib.util.spec_from_file_location('_C1_arming_verify',HERE/'diagnose.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
checked,_,_=module.verify(HERE/'armed-plan.json',plan_sha,native=True);assert checked==plan
write('launch-plan.json',launch);launch_sha=sha(HERE/'launch-plan.json')
argv=[str(ROOT/'work/part-workflow/runtimes/geometry-standalone/bin/python'),'-I','-B',str(ROOT/'work/carrier-process-20261017/source010-exposure-preflight-003/supervise.py'),str(HERE/'launch-plan.json'),'--plan-sha256',launch_sha]
write('armed-command.json',dict(schema='one_actual_readonly_C1_diagnostic_command',argv=argv,root_GO_sha256=expected['root-review-GO-001.json']))
write('arming-assessment.json',dict(status='GO_bound_all_fresh_pins_strict_whole_inverse_PASS_no_native_executed',root_GO_sha256=expected['root-review-GO-001.json'],pending=expected,arming_source_sha256=sha(__file__),armed_plan_sha256=plan_sha,launch_plan_sha256=launch_sha,command_sha256=sha(HERE/'armed-command.json'),strict_inverse_entire_plan_and_launch=True,unique_launch_pins=len(pins),total_pin_bytes=sum((ROOT/n).stat().st_size for n in pins),all_pins_actual_equal=True,output_and_execution_absent=True,scientific_sources_unchanged=True,elapsed_seconds=time.monotonic()-started))
print(json.dumps(dict(status='armed_without_native_run',plan_sha256=plan_sha,launch_sha256=launch_sha,unique_pins=len(pins),arming_sha256=sha(HERE/'arming-assessment.json'))))
