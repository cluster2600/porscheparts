# Préparation des deux cas C1 h/2 — non armée

Le candidat est celui déjà construit et qualifié en lecture seule, sans refaire le raffinement. La qualification13579/634ad2 est close RC0 et sa revue racine4c0fa1eb est liée. Elle mesure entièrement h=0,46689542695319447 mm pour les deux cibles0,4668954269534402 mm ; l'égalité des deux volumes sérialisés est une autorité distincte à tolérance zéro. L'ancien refus RC1, son h2=false et ses métadonnées restent intacts.

Le caller dérive exactement de54014. Seules verified/prepare/run changent ; verify_qualification et verify_coarse_deck sont ajoutées. Les callbacks prepare_execute/make_execute, deck_contract, verify_mesh parent, verify_protected complet, solve87be, binders BREP et helperDocker cbba sont inchangés. source.diff et source-derivation.json rendent les remplacements inversibles et les AST vérifiables.

Les plans pending copient le candidat INP43906/NPZcdf4/metadata6736 dans deux nouveaux cas, plus les trois parents BREP explicites inchangés. Le basename cad/mesh-7 demeure une convention technique ; la provenance publiée est C1local-h/2 et ses SHA. Aucun STEP fictif, ancien h2=false non réétiqueté.

Physique inchangée : E107000MPa,nu0,31,Fz−4000N,My850000Nmm ; quatre rosters bolt528,ends2274/2278. Rigide13656DOF ; K1000TOTAL par œil ET axe donne13656SPRING1 et1000/n_eye par nœud. Pendant la future préparation, les vraies cartes CLOAD/FIXED/BOUNDARY/SPRING sont égales au coarse ; les SPRING1 conservent leurs nœuds, leurs nouveaux IDs d'élément peuvent changer avec le nombre de tets BODY. Le contrat load-and-supports entier doit être identique au coarse. Aucune ancienne matrice réutilisée.

Les16tests antérieurs s'exécutent depuis leurs sources gelées ; l'inversion du delta et les AST prouvent la conservation des fonctions dans ce nouveau caller. Huit tests nouveaux portent sur qualification fermée/liaisons/candidat/refus historique, mesures entières, cartes réelles, springrosters et plans non armés. Ils n'importent aucune bibliothèque scientifique ni Docker.

Préparation proposée : deux appels séparés via superviseur4d18,180s par appel,0worker/1thread/nice10. Les pending-prepare-launch et pending-prepare-command restent non armés et le source refuse launch_ready=false AVANT tout import scientifique. Root doit revoir/autoriser l'armement avant NumPy ou génération de deck. Le callback DeckPrepared conserve le deck et s'arrête avant Docker.

CCX futur seulement après revue des deux decks et GO distinct : deux entrées successives1800s chacune,solver1680s,réservecleanup60s,1CPU/6GiB/6GiBmemory-swap total (0supplémentaire),réseaunone,imagec977/binaire271f. Le helper owned et le forwardcancel restent inchangés. Aucune enveloppe commune3600s ni retry. Les vrais conteneurs doivent être supprimés et les RC collectées.

Postprocess inchangé : énergie1e-4,JSON/NPZ/DAT et réactions/résidus/work originaux,tous les picsIP/ex æquo,C2inclus. Comparaison exclusivement aux deux vrais cas C1coarse clos root4999244c. Rapports descriptifs de U/VM/F·U et migration des pics, sans nouveau critère de convergence ou résistance. Un pic migré hors ROI reste visible et n'est pas convergé par la seule qualification locale. Pas de validation physique/fabrication.
