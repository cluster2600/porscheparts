# C1 : deux calculs coarse → h/2 réellement fermés

Les deux calculs CCX sont clos RC0 sous l'image/binaire gelés, avec les conteneurs owned retirés. Les copies d'entrée, 6 rosters, charges et appuis complets sont identiques aux deux vrais cas C1 coarse. Les 58 sorties de cas ont été relues intégralement pour SHA ; les 620 pins sources/entrées uniques restent conformes. Le maillage candidat a 168248 nœuds et90766C3D10 ; la qualification distincte close donne h=0,46689542695319447mm dans les deux AABB. Le vieux refus de volume demeure inchangé.

| Cas | Umax coarse→h/2 (mm) | VMmax coarse→h/2 (MPa) | Écart relatif de clôture d'énergie |
|---|---|---|---|
| Rigide | 2.7941041 → 2.79456582 | 907.278068 → 996.757555 | 8.55524274e-09 |
| K1000 par œil/axe | 18.1714911 → 18.1744212 | 2663.07518 → 2996.49611 | 2.50912042e-08 |

La tolérance d'énergie1e-4 est inchangée. Les maxima h/2, tous conservés sans exclusion, sont90371/IP2 pour les deux cas : XYZ[82.16233219777006,−14.460778139518327,12.883191321497591]mm, arête maximale du tétra au pic0,39084401096899957mm. Le pic coarse était84037/IP1. Les rapports VM sont1.09862410489 et1.12520147213 ; les déplacements et travaux restent beaucoup plus proches. Aucun nouveau seuil de convergence ou résistance n'est appliqué. Ces deux résultats ne suffisent pas à déclarer la contrainte convergée.

Le diagnostic géométrique coarse séparé évoque une corde normale locale mince ; il ne constitue ni une épaisseur minimale globale ni une preuve de singularité. Cette étude reste linéaire, sous charges/appuis hypothétiques et sans valeur admissible matériau. Aucune qualification physique ou fabrication, aucune nouvelle CAO et aucun calcul supplémentaire ne sont produits ici. `summary.json` contient les réactions, travaux, énergies, rapports et tous les pics entiers ; chaque cas conserve sa propre clôture native et son inventaire SHA.
