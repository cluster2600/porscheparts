"""Retained callback checks and fixed BREP/K1000 proof fixtures; stdlib only."""
import ast
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
spec = importlib.util.spec_from_file_location('retained_static_checks', HERE / 'selfcheck.py')
retained = importlib.util.module_from_spec(spec); spec.loader.exec_module(retained)
r = retained.r

def deck_fixture(support=None):
    ends = [[10, 11], [20, 21, 22]]
    blocks = [('*NSET,NSET=FIXED', ['10,11,20,21,22'])]
    if support is None:
        blocks.append(('*BOUNDARY', ['FIXED,1,3']))
    else:
        eid = 50
        for eye, nodes in enumerate(ends):
            for dof in range(1, 4):
                label = f'S{eye}{dof}'; rows = []
                for node in nodes: rows.append(f'{eid},{node}'); eid += 1
                blocks += [(f'*ELEMENT,TYPE=SPRING1,ELSET={label}', rows),
                           (f'*SPRING,ELSET={label}', [str(dof), str(support / len(nodes))])]
    blocks.append(('*CLOAD', ['1,3,-4000']))
    return blocks, ends, {1: [212.5, 0., 0.]}

def protected_fixture(root):
    body = 'a' * 64; surface = 'b' * 64
    source = dict(format='brep', sha256=body)
    protected = dict(study_assembly_screen_pass=True, nominal_mass_kg=1.262, mass_ceiling_pass=False,
                     candidate_CAD_source=source, unused_nested_authority={'retained': [1, 2, 3]})
    inspection = dict(study_assembly_screen_pass=True, nominal_mass_kg=1.262, mass_ceiling_pass=False,
                      CAD_source=source, inputs_sha256={'candidate-native.brep': body, 'carrier.stl': surface})
    def put(name, value): (root / name).write_text(json.dumps(value))
    put('protected.json', protected); put('inspection.json', inspection)
    assessment = dict(status='complete_BREP_protected_checks_passed_current_1p3kg', checker_returned=True,
        current_mass_ceiling_1p3kg_pass=True, inputs_runtime_plan_unchanged=True,
        CAD_source=source, STL_sha256=surface, actual_protected_interfaces=copy.deepcopy(protected),
        protected_report=copy.deepcopy(protected), actual_inspection=copy.deepcopy(inspection),
        legacy_mass_flag_retained_without_override=False,
        outputs={'protected-input/protected-interfaces.json': {'sha256': r.sha(root / 'protected.json')},
                 'protected-input/inspection.json': {'sha256': r.sha(root / 'inspection.json')}})
    put('assessment.json', assessment)
    put('terminal.json', dict(actual_outer_returncode=0, actual_child_returncode=0))
    put('supervision.json', dict(status='executed', actual_returncode=0, direct_child_reaped=True,
        final_group_members=[], timeout=False, interrupted=False, sources_and_plan_unchanged=True))
    names = dict(protected_terminal='terminal.json', protected_assessment='assessment.json',
                 protected_supervision='supervision.json', protected_report='protected.json', inspection_report='inspection.json')
    plan = dict(names, BREP_sha256=body, protected_surface_STL_sha256=surface,
                files_sha256={name: r.sha(root / name) for name in names.values()})
    return plan, assessment, protected

class NewChecks(unittest.TestCase):
    def test_rigid_actual_roster_and_serialized_resultants(self):
        blocks, ends, xyz = deck_fixture()
        result = r.deck_contract(blocks, ends, None, xyz, [0, 0, -4000], [0, 850000, 0])
        self.assertEqual(result['rigid_constrained_DOFs'], 15); self.assertEqual(result['SPRING1_elements'], 0)
        self.assertEqual(result['serialized_force_N'], [0, 0, -4000])
        self.assertEqual(result['serialized_moment_Nmm'], [0, 850000, 0])
    def test_K1000_is_total_per_eye_axis_not_per_node(self):
        blocks, ends, xyz = deck_fixture(1000)
        result = r.deck_contract(blocks, ends, 1000, xyz, [0, 0, -4000], [0, 850000, 0])
        self.assertEqual(result['SPRING1_elements'], 15)
        self.assertEqual([v['per_node_stiffness_N_mm'] for v in result['springs']], [500.] * 3 + [1000 / 3] * 3)
        altered = copy.deepcopy(blocks)
        next(lines for key, lines in altered if key == '*SPRING,ELSET=S01')[1] = '1000'
        with self.assertRaisesRegex(ValueError, 'total PER EYE'): r.deck_contract(altered, ends, 1000, xyz, [0, 0, -4000], [0, 850000, 0])
    def test_stale_end_roster_refuses(self):
        blocks, ends, xyz = deck_fixture()
        with self.assertRaisesRegex(ValueError, 'actual new mesh'): r.deck_contract(blocks, [[10, 12], ends[1]], None, xyz, [0, 0, -4000], [0, 850000, 0])
    def test_full_protected_contract_and_legacy_flag(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp); plan, assessment, protected = protected_fixture(root)
            with patch.object(r, 'ROOT', root): r.verify_protected(plan)
            protected['unused_nested_authority']['retained'].append(4)
            (root / 'protected.json').write_text(json.dumps(protected))
            assessment['outputs']['protected-input/protected-interfaces.json']['sha256'] = r.sha(root / 'protected.json')
            (root / 'assessment.json').write_text(json.dumps(assessment))
            with patch.object(r, 'ROOT', root), self.assertRaisesRegex(ValueError, 'Full BREP reports'): r.verify_protected(plan)
    def test_pending_plans_fail_before_any_native_operation(self):
        for name in ['rigid-pending-plan.json', 'spring-pending-plan.json']:
            path = HERE / name; plan = json.loads(path.read_text())
            self.assertFalse(plan['launch_ready']); self.assertIsNone(plan['protected_terminal'])
            with self.assertRaisesRegex(ValueError, 'not armed'): r.verified(plan, r.sha(path), path)
            with self.assertRaisesRegex(ValueError, 'remains pending'): r.verify_protected(plan)
    def test_retained_native_callback_and_solve_are_unmodified(self):
        reference = json.loads((HERE / 'source-reference.json').read_text())
        source = (ROOT / reference['simulation_source']).read_bytes()
        self.assertEqual(hashlib.sha256(source).hexdigest(), reference['simulation_source_sha256'])
        solve = next(n for n in ast.parse(source).body if isinstance(n, ast.FunctionDef) and n.name == 'solve')
        constants = {n.value for n in ast.walk(solve) if isinstance(n, ast.Constant) and isinstance(n.value, str)}
        self.assertFalse(constants & {'carrier.step', 'STEP_sha256'})
        original = ast.parse((ROOT / reference['reference_caller']).read_text()); current = ast.parse((HERE / 'run.py').read_text())
        for name in ['prepare_execute', 'make_execute', 'copy_exact']:
            old = next(n for n in original.body if isinstance(n, ast.FunctionDef) and n.name == name)
            new = next(n for n in current.body if isinstance(n, ast.FunctionDef) and n.name == name)
            self.assertEqual(ast.dump(old), ast.dump(new))

if __name__ == '__main__':
    suite = unittest.TestSuite([unittest.defaultTestLoader.loadTestsFromTestCase(retained.Checks),
                               unittest.defaultTestLoader.loadTestsFromTestCase(NewChecks)])
    raise SystemExit(not unittest.TextTestRunner(verbosity=1).run(suite).wasSuccessful())
