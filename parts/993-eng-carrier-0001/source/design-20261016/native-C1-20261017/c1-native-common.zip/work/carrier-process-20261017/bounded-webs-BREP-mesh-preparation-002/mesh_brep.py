"""Private entire mesh87be body, explicit BREP source and unchanged meshing settings."""
import hashlib
import json
import numpy as np

def observed_import_options(gmsh, out, phase):
    required = {'Geometry.OCCFixDegenerated': 0., 'Geometry.OCCFixSmallEdges': 0.,
                'Geometry.OCCFixSmallFaces': 0., 'Geometry.OCCSewFaces': 0.,
                'Geometry.OCCMakeSolids': 0., 'Geometry.OCCScaling': 1.}
    observed = {name: float(gmsh.option.getNumber(name)) for name in required}
    (out/('BREP-import-options-'+phase+'.json')).write_text(json.dumps(observed, indent=2)+'\n')
    assert observed == required, 'Actual Gmsh import healing/scaling options differ'
    return observed

def mesh(folder, size):
    import gmsh
    out = folder / f'mesh-{size:g}'
    out.mkdir(exist_ok=False)
    g = json.loads((folder / 'study.json').read_text())['geometry']
    gmsh.initialize()
    try:
        gmsh.option.setNumber('General.Terminal', 0)
        gmsh.option.setNumber('General.NumThreads', 1)
        options_before = observed_import_options(gmsh, out, 'before')
        gmsh.model.occ.importShapes(str(folder / 'carrier.brep'), format='brep')
        gmsh.model.occ.synchronize()
        options_after = observed_import_options(gmsh, out, 'after')
        assert options_after == options_before
        volumes = gmsh.model.getEntities(3)
        assert len(volumes) == 1
        master = json.loads((folder/'brep-master.json').read_text())
        assert master['CAD_source_format'] == 'BREP'
        assert hashlib.sha256((folder/'carrier.brep').read_bytes()).hexdigest() == master['BREP_sha256']
        occ_volume = float(gmsh.model.occ.getMass(3, volumes[0][1]))
        assert np.isfinite(occ_volume) and occ_volume > 0
        occ_relative_error = occ_volume/master['nonadaptive_import_volume_mm3']-1
        import_receipt = {'CAD_source_format': 'BREP', 'BREP_sha256': master['BREP_sha256'],
                          'OCC_imported_volume_mm3': occ_volume,
                          'nonadaptive_reference_volume_mm3': master['nonadaptive_import_volume_mm3'],
                          'nonadaptive_reference_operator': master['nonadaptive_import_volume_operator'],
                          'nonadaptive_reference_receipt_sha256': master['nonadaptive_volume_receipt_sha256'],
                          'adaptive_master_volume_mm3': master['native_volume_mm3'],
                          'adaptive_master_operator': master['native_volume_operator'],
                          'actual_import_options_before': options_before, 'actual_import_options_after': options_after,
                          'imported_CAD_absolute_identity_proved': False,
                          'relative_volume_difference': occ_relative_error,
                          'historical_relative_guard': 1e-8, 'passed': abs(occ_relative_error) < 1e-8}
        (out/'BREP-import.json').write_text(json.dumps(import_receipt, indent=2)+'\n')
        assert import_receipt['passed'], 'Historical1e-8 import volume guard refused'
        gmsh.model.addPhysicalGroup(3, [volumes[0][1]], name='BODY')
        gmsh.option.setNumber('Mesh.MeshSizeMin', 2)
        gmsh.option.setNumber('Mesh.MeshSizeMax', 8)
        gmsh.option.setNumber('Mesh.MeshSizeFromCurvature', 18)
        gmsh.option.setNumber('Mesh.MeshSizeFactor', size/8)
        gmsh.option.setNumber('Mesh.ElementOrder', 2)
        # Straight midsides avoid inverted curved elements at small OCC blends;
        # geometry error is reported and checked through mesh refinement.
        gmsh.option.setNumber('Mesh.SecondOrderLinear', 1)
        gmsh.option.setNumber('Mesh.SaveAll', 0)
        gmsh.model.mesh.generate(3)
        types, elements, _ = gmsh.model.mesh.getElements(3)
        assert list(types) == [11], types
        jac = gmsh.model.mesh.getElementQualities(elements[0], 'minDetJac')
        quality = {'minimum_Jacobian': float(min(jac)),
                   'nonpositive_elements': int(np.count_nonzero(jac <= 0)),
                   'finite': bool(np.isfinite(jac).all()), 'elements': len(jac)}
        (out/'quality.json').write_text(json.dumps(quality, indent=2)+'\n')
        assert np.isfinite(jac).all() and min(jac) > 0
        tags, xyz, _ = gmsh.model.mesh.getNodes()
        order = np.argsort(tags); tags = tags[order]; xyz = xyz.reshape(-1, 3)[order]
        faces = []
        for kind, _, conn in zip(*gmsh.model.mesh.getElements(2)):
            assert kind == 9
            faces.extend(conn.reshape(-1, 6)[:, :3])
        groups = {**{f'bolt{i}': [] for i in range(4)}, **{f'end{i}': [] for i in range(2)}}
        for _, face in gmsh.model.getEntities(2):
            if gmsh.model.getType(2, face) != 'Cylinder':
                continue
            lo, hi = gmsh.model.getParametrizationBounds(2, face)
            p = gmsh.model.getValue(2, face, (lo+hi)/2)
            names = []
            for i, (x, y) in enumerate(g['central_bolt_centres_xy_mm']):
                if abs(np.hypot(p[0]-x, p[1]-y)-g['central_bore_radius_mm']) < 1e-5:
                    names.append(f'bolt{i}')
            for i, x in enumerate(g['end_centres_x_mm']):
                if abs(np.hypot(p[0]-x, p[2])-g['end_bore_radius_mm']) < 1e-5:
                    names.append(f'end{i}')
            assert len(names) <= 1
            for name in names:
                groups[name].extend(gmsh.model.mesh.getNodes(2, face, includeBoundary=True)[0])
        groups = {k: np.unique(v).astype(int) for k, v in groups.items()}
        assert min(map(len, groups.values())) >= 12
        assert len(set(np.concatenate(list(groups.values())))) == sum(map(len, groups.values()))
        gmsh.write(str(out / 'mesh.inp'))
        np.savez_compressed(out / 'mesh.npz', tags=tags, xyz=xyz,
                            faces=np.asarray(faces), **groups)
        mesh_volume = float(gmsh.model.mesh.getElementQualities(elements[0], 'volume').sum())
        cad_volume = master['native_volume_mm3']
        meta = {'nodes': len(tags), 'C3D10_elements': len(elements[0]),
                'minimum_sampled_Jacobian': float(min(jac)),
                'bore_node_counts': {k: len(v) for k, v in groups.items()},
                'gmsh_version': gmsh.__version__, 'element_order': 2, 'straight_midsides': True,
                'global_mesh_size_factor': size/8,
                'mesh_volume_mm3': mesh_volume, 'volume_relative_error': mesh_volume/cad_volume-1,
                'CAD_source_format': 'BREP', 'CAD_source_file': 'carrier.brep',
                'BREP_sha256': master['BREP_sha256'],
                'CAD_master_receipt_sha256': master['native_containment_receipt_sha256'],
                'CAD_volume_receipt_sha256': master['native_volume_receipt_sha256'],
                'CAD_adaptive_master_volume_mm3': master['native_volume_mm3'],
                'CAD_volume_operator': master['native_volume_operator'],
                'OCC_import_check_reference_mm3': master['nonadaptive_import_volume_mm3'],
                'OCC_import_check_operator': master['nonadaptive_import_volume_operator'],
                'OCC_import_reference_receipt_sha256': master['nonadaptive_volume_receipt_sha256'],
                'OCC_imported_volume_mm3': occ_volume,
                'OCC_import_relative_volume_difference': occ_relative_error}
        (out/'mesh.json').write_text(json.dumps(meta, indent=2)+'\n')
        print(json.dumps(meta), flush=True)
    finally:
        gmsh.finalize()
    return out

