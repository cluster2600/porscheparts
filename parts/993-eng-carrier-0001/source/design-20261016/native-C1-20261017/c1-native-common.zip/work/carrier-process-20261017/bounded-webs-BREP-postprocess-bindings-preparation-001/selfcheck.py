"""Source/provenance tests only; no NumPy, OCP, Gmsh or solver import."""
import ast
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import tempfile
import unittest
HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
MESH = ROOT / 'work/carrier-process-20261017/bounded-webs-BREP-mesh-preparation-002/output-001/cad-BREP-master/mesh-7'
spec = importlib.util.spec_from_file_location('pure_BREP_binding', HERE / 'cad_binding.py')
binding = importlib.util.module_from_spec(spec); spec.loader.exec_module(binding)

class Checks(unittest.TestCase):
    def test_exact_inverse_restores_both_complete_sources(self):
        changes = json.loads((HERE / 'source-changes.json').read_text())
        for name, record in changes.items():
            text = (HERE / name).read_text()
            self.assertEqual(hashlib.sha256(text.encode()).hexdigest(), record['executed_copy_sha256'])
            for item in reversed(record['replacements']):
                self.assertEqual(text.count(item['after']), 1)
                text = text.replace(item['after'], item['before'])
            self.assertEqual(hashlib.sha256(text.encode()).hexdigest(), record['reference_sha256'])
            self.assertEqual(text, (ROOT / record['reference_path']).read_text())
    def test_real_closed_mesh_provenance_without_scientific_import(self):
        metadata = json.loads((MESH / 'mesh.json').read_text())
        provenance = binding.verify(MESH, metadata)
        self.assertEqual(provenance['format'], 'BREP')
        self.assertFalse(provenance['STEP_exchange_qualified'])
        self.assertFalse(provenance['imported_CAD_absolute_identity_proved'])
        self.assertNotEqual(provenance['adaptive_volume_mm3'], provenance['nonadaptive_import_reference_mm3'])
    def test_wrong_metadata_operator_or_STEP_alias_refuses(self):
        original = json.loads((MESH / 'mesh.json').read_text())
        cases = [('CAD_source_format', 'STEP'), ('CAD_source_file', 'carrier.step'),
                 ('BREP_sha256', '0' * 64), ('CAD_master_receipt_sha256', '0' * 64),
                 ('OCC_import_reference_receipt_sha256', '0' * 64),
                 ('CAD_adaptive_master_volume_mm3', 1.), ('OCC_import_check_reference_mm3', 1.),
                 ('CAD_volume_operator', {}), ('OCC_import_check_operator', {}), ('STEP_sha256', '0' * 64)]
        for key, value in cases:
            altered = copy.deepcopy(original); altered[key] = value
            with self.subTest(key=key), self.assertRaises(ValueError): binding.verify(MESH, altered)
    def test_wrong_body_or_symlink_description_refuses(self):
        metadata = json.loads((MESH / 'mesh.json').read_text())
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp); folder = root / 'mesh-7'; folder.mkdir()
            (root / 'brep-master.json').write_bytes((MESH.parent / 'brep-master.json').read_bytes())
            (root / 'carrier.brep').write_bytes(b'not the native master')
            with self.assertRaises(ValueError): binding.verify(folder, metadata)
            (root / 'brep-master.json').unlink()
            (root / 'brep-master.json').symlink_to(MESH.parent / 'brep-master.json')
            with self.assertRaises(ValueError): binding.verify(folder, metadata)
    def test_no_scientific_import_until_factory_call_and_no_launcher(self):
        tree = ast.parse((HERE / 'factory.py').read_text())
        imports = [n for n in tree.body if isinstance(n, (ast.Import, ast.ImportFrom))]
        names = [n.module if isinstance(n, ast.ImportFrom) else a.name for n in imports for a in (n.names if isinstance(n, ast.Import) else [None])]
        self.assertFalse(set(names) & {'numpy', 'gmsh', 'OCP'})
        self.assertIn('energy=energy', (HERE / 'factory.py').read_text())
        self.assertFalse(any(isinstance(n, ast.Attribute) and n.attr in {'Popen', 'run', 'solve', 'generate'} for n in ast.walk(tree)))
    def test_pending_solve_and_complete_protected_check_stay_unknown(self):
        p = json.loads((HERE / 'pending-plan.json').read_text())
        self.assertFalse(p['launch_ready']); self.assertFalse(p['FEA_executed'])
        self.assertIsNone(p['complete_direct_BREP_protected_receipt_sha256'])
        self.assertIsNone(p['CCX_rigid_result_sha256']); self.assertIsNone(p['CCX_K1000_result_sha256'])
        spec = importlib.util.spec_from_file_location('pending_factory_only', HERE / 'factory.py')
        factory = importlib.util.module_from_spec(spec); spec.loader.exec_module(factory)
        with self.assertRaises(ValueError): factory.load()
        self.assertFalse(set(sys.modules) & {'numpy', 'gmsh', 'OCP'})

if __name__ == '__main__': unittest.main()
