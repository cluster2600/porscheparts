"""One complete protected comparator on the explicit existing BREP and new surface."""
import hashlib
import importlib.util
import json
from pathlib import Path
import resource
import shutil
import signal
import sys
import time
import traceback

HERE=Path(__file__).resolve().parent
MASTER='a42e6942722957076410d4a89b24f9bd0f11677dfa8319103d6733a0db8a1cf9'
SURFACE='577f0e319722ff785099d5b3d29862fac883937d0ea1441f6e5759398c7d418d'
def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb')as f:
        for block in iter(lambda:f.read(8*1024*1024),b''):h.update(block)
    return h.hexdigest()
def write(path,value):
    with Path(path).open('x')as f:json.dump(value,f,indent=2,allow_nan=False);f.write('\n');f.flush();__import__('os').fsync(f.fileno())
def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
def verify(plan,fresh=True):
    if (plan['schema']!='native-BREP-new-STL-complete-protected-comparator-2' or plan['CAD_source']['format']!='brep' or
        plan['CAD_source']['sha256']!=MASTER or plan['STL_sha256']!=SURFACE or plan['inner_wall_seconds']!=560 or
        plan['outer_wall_seconds']!=600 or plan['CPU_seconds']!=[520,540] or plan['current_mass_ceiling_kg']!=1.3):raise ValueError('Reviewed binding/resources/current ceiling changed')
    before={p:sha(p)for p in plan['files_sha256']}
    if before!=plan['files_sha256']:raise ValueError('Frozen inputs/runtime/sources differ')
    if any(str(Path(alias).resolve())!=target for alias,target in plan['runtime_aliases'].items()):raise ValueError('Existing Python runtime alias changed')
    joint=json.loads(Path(plan['joint_surface_terminal']).read_text())
    if (joint['status']!='joint_surface_checks_passed' or joint['actual_outer_returncode']!=0 or joint['actual_container_exit_code']!=0 or
        joint['container_removed'] is not True or joint['all_current_equal'] is not True or joint['STL_sha256']!=SURFACE or
        joint['master_BREP_sha256']!=MASTER):raise ValueError('Actual new surface joint audit is not closed/bound')
    if json.loads(Path(plan['interface_contract']).read_text())['mass_ceiling_kg']!=1.2:raise ValueError('Historical mass ceiling changed')
    factory=load('_BREP_surface_comparator_factory_preflight',HERE/'factory.py')
    factory.validate_binding(plan,json.loads(Path(plan['containment_terminal']).read_text()))
    if any(plan['files_sha256'].get(plan[k])!=d for k,d in [('master_BREP',MASTER),('surface_STL',SURFACE),('study',plan['study_sha256'])]):raise ValueError('Actual input paths are not bound in frozen files')
    output=Path(plan['output_directory'])
    if fresh and(output.exists()or output.is_symlink()):raise FileExistsError('Preserve prior protected comparison')
    if output.parent.resolve()!=output.parent:raise ValueError('Output parent symlink refused')
    return before
def measured_flags(report):
    measured=report.get('actual_inspection',{})
    report['legacy_mass_flag_retained_without_override']=measured.get('mass_ceiling_pass')
    report['legacy_mass_ceiling_kg']=1.2
    report['current_mass_ceiling_kg']=1.3
    report['current_mass_ceiling_1p3kg_pass']=('nominal_mass_kg'in measured and measured['nominal_mass_kg']<=1.3)
    return report.get('checker_returned') is True and measured.get('study_assembly_screen_pass') is True and report['current_mass_ceiling_1p3kg_pass']
def main():
    planpath=HERE/'plan.json';plan_sha=sha(planpath);plan=json.loads(planpath.read_text())
    if sys.argv[1:]==['--preflight']:
        verify(plan);print(json.dumps(dict(status='preflight_only_no_scientific_import',plan_sha256=plan_sha,pins=len(plan['files_sha256']))));return 0
    assert not sys.argv[1:]
    started=time.monotonic();CPU=time.process_time()
    signal.signal(signal.SIGALRM,lambda *_:(_ for _ in ()).throw(TimeoutError('Complete BREP protected comparison wall cap560')))
    signal.alarm(560);resource.setrlimit(resource.RLIMIT_CPU,(520,540))
    before=verify(plan);output=Path(plan['output_directory']);output.mkdir()
    report=dict(schema='native-BREP-new-STL-complete-protected-assessment-2',status='incomplete',plan_sha256=plan_sha,
        sources_runtime_before=before,source_sha256=sha(__file__),CAD_source=plan['CAD_source'],STL_sha256=SURFACE,
        workers=0,native_pool_setting=1,geometry_modified=False,FEA_executed=False,global_admission=False,
        continuous_distance_bound=False,historical_protected003_relabelled=False)
    previous_path=list(sys.path)
    try:
        sys.path.insert(0,plan['dependency_site']);sys.path.insert(1,plan['native_site'])
        import networkx,numpy,build123d,trimesh,manifold3d
        from OCP import OCP
        modules={n:str(Path(m.__file__).resolve())for n,m in [('networkx',networkx),('numpy',numpy),('build123d',build123d),('trimesh',trimesh),('manifold3d',manifold3d),('OCP',OCP)]}
        if modules!=plan['native_module_paths']or networkx.__version__!='3.4.2':raise ValueError('Actual scientific module origin differs')
        report['actual_native_module_paths']=modules
        copied=output/'protected-input';copied.mkdir()
        for name,key in [('candidate-native.brep','master_BREP'),('carrier.stl','surface_STL'),('study.json','study')]:
            source=Path(plan[key]);target=copied/name
            with source.open('rb')as src,target.open('xb')as dst:shutil.copyfileobj(src,dst,1024*1024)
            if sha(target)!=plan['files_sha256'][str(source)]:raise ValueError('Exclusive input copy differs')
        factory=load('_BREP_new_surface_comparator_factory',HERE/'factory.py');checker=factory.load(planpath)
        report['producer_provenance']=checker.provenance;report['checker_called']=True
        try:report['protected_report']=checker.check(copied);report['checker_returned']=True
        except BaseException as error:
            report.update(checker_returned=False,checker_error=dict(type=type(error).__name__,message=str(error),traceback=traceback.format_exc()))
        for name,key in [('inspection.json','actual_inspection'),('protected-interfaces.json','actual_protected_interfaces')]:
            if(copied/name).is_file():report[key]=json.loads((copied/name).read_text())
        report['status']='complete_BREP_protected_checks_passed_current_1p3kg'if measured_flags(report)else'refused_complete_BREP_protected_checks'
    except BaseException as error:report['failure']=dict(type=type(error).__name__,message=str(error),traceback=traceback.format_exc())
    finally:
        sys.path[:]=previous_path;signal.alarm(0)
        try:after=verify(plan,fresh=False);intact=before==after and sha(planpath)==plan_sha
        except BaseException as error:after={};intact=False;report['integrity_failure']=str(error)
        report.update(sources_runtime_after=after,inputs_runtime_plan_unchanged=intact,wall_seconds=time.monotonic()-started,
            CPU_seconds=time.process_time()-CPU,maxRSS_bytes_macos=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss)
        if not intact:report['status']='refused_input_runtime_plan_drift'
        report['outputs']={str(p.relative_to(output)):dict(sha256=sha(p),bytes=p.stat().st_size)for p in output.rglob('*')if p.is_file()}
        write(output/'assessment.json',report)
    print(json.dumps({k:report.get(k)for k in ['status','checker_returned','legacy_mass_flag_retained_without_override','current_mass_ceiling_1p3kg_pass','wall_seconds']}),flush=True)
    return 0 if report['status']=='complete_BREP_protected_checks_passed_current_1p3kg'and report['inputs_runtime_plan_unchanged']else 1
if __name__=='__main__':raise SystemExit(main())
