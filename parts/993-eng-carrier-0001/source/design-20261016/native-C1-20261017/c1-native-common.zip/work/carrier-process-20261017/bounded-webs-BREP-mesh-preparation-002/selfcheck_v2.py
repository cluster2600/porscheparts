"""Seven retained tests plus four operator/options/derivation contracts; stdlib only."""
import ast
import hashlib
import importlib.util
import json
from pathlib import Path
import tempfile
from types import SimpleNamespace
import unittest
HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
spec = importlib.util.spec_from_file_location('retained_mesh_checks', HERE / 'selfcheck.py')
retained = importlib.util.module_from_spec(spec); spec.loader.exec_module(retained)

class NewChecks(unittest.TestCase):
    def test_literal_inverse_preserves_entire_sources(self):
        changes = json.loads((HERE / 'source-changes.json').read_text())
        for name, key in [('mesh_brep.py', 'mesh_replacements'), ('run.py', 'run_replacements')]:
            text = (HERE / name).read_text()
            for change in reversed(changes[key]):
                self.assertEqual(text.count(change['after']), 1)
                text = text.replace(change['after'], change['before'])
            old = changes['old_sources'][name]
            self.assertEqual(hashlib.sha256(text.encode()).hexdigest(), old['sha256'])
            self.assertEqual(text, (ROOT / old['path']).read_text())
        for name in changes['unchanged']:
            self.assertEqual(hashlib.sha256((HERE / name).read_bytes()).hexdigest(), changes['old_sources'][name]['sha256'])
    def test_actual_options_recorded_and_asserted(self):
        tree = ast.parse((HERE / 'mesh_brep.py').read_text())
        fn = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'observed_import_options')
        namespace = {'json': json}
        exec(compile(ast.Module(body=[fn], type_ignores=[]), '<observed-options-only>', 'exec'), namespace)
        expected = {'Geometry.OCCFixDegenerated': 0., 'Geometry.OCCFixSmallEdges': 0.,
                    'Geometry.OCCFixSmallFaces': 0., 'Geometry.OCCSewFaces': 0.,
                    'Geometry.OCCMakeSolids': 0., 'Geometry.OCCScaling': 1.}
        with tempfile.TemporaryDirectory() as tmp:
            p = Path(tmp); gmsh = SimpleNamespace(option=SimpleNamespace(getNumber=expected.__getitem__))
            self.assertEqual(namespace['observed_import_options'](gmsh, p, 'before'), expected)
            self.assertEqual(json.loads((p / 'BREP-import-options-before.json').read_text()), expected)
            for index, name in enumerate(expected):
                wrong = dict(expected); wrong[name] = 0. if name.endswith('Scaling') else 1.
                gmsh = SimpleNamespace(option=SimpleNamespace(getNumber=wrong.__getitem__))
                with self.assertRaises(AssertionError): namespace['observed_import_options'](gmsh, p, str(index))
                self.assertEqual(json.loads((p / ('BREP-import-options-' + str(index) + '.json')).read_text()), wrong)
    def test_two_actual_authorities_and_separate_roles(self):
        m = json.loads((HERE / 'brep-master.json').read_text())
        p = ROOT / m['nonadaptive_volume_receipt']; terminal = ROOT / m['nonadaptive_volume_terminal']
        self.assertEqual(hashlib.sha256(p.read_bytes()).hexdigest(), m['nonadaptive_volume_receipt_sha256'])
        self.assertEqual(hashlib.sha256(terminal.read_bytes()).hexdigest(), m['nonadaptive_volume_terminal_sha256'])
        receipt = json.loads(p.read_text()); closed = json.loads(terminal.read_text())
        self.assertEqual(closed['actual_outer_returncode'], 0); self.assertEqual(closed['actual_child_returncode'], 0)
        self.assertEqual(m['nonadaptive_import_volume_mm3'], receipt['methods'][0]['signed_mass_mm3'])
        self.assertEqual(m['native_volume_mm3'], receipt['methods'][2]['signed_mass_mm3'])
        self.assertNotEqual(m['nonadaptive_import_volume_mm3'], m['native_volume_mm3'])
        self.assertEqual(m['nonadaptive_import_volume_operator']['arguments'], [False, False, False])
        self.assertEqual(m['native_volume_operator']['arguments'], [1e-10, True, False])
        self.assertFalse(m['imported_CAD_absolute_identity_proved'])
    def test_import_and_mesh_volume_use_correct_operators(self):
        text = (HERE / 'mesh_brep.py').read_text()
        self.assertIn("occ_volume/master['nonadaptive_import_volume_mm3']-1", text)
        self.assertIn("cad_volume = master['native_volume_mm3']", text)
        self.assertIn("mesh_volume/cad_volume-1", text)
        self.assertIn("'historical_relative_guard': 1e-8", text)
        self.assertLess(text.index("options_before ="), text.index('gmsh.model.occ.importShapes'))
        self.assertLess(text.index('gmsh.model.occ.importShapes'), text.index("options_after ="))
        self.assertLess(text.index("options_after ="), text.index('gmsh.model.mesh.generate'))

if __name__ == '__main__':
    suite = unittest.TestSuite([unittest.defaultTestLoader.loadTestsFromTestCase(retained.Check),
                               unittest.defaultTestLoader.loadTestsFromTestCase(NewChecks)])
    raise SystemExit(not unittest.TextTestRunner(verbosity=1).run(suite).wasSuccessful())
