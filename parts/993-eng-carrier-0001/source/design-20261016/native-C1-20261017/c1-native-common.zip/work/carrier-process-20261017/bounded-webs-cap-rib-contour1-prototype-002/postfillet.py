"""One isolated R1 native fillet on the seven-edge negative-Y contour only."""
import argparse
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import resource
import signal
import sys
import time
import traceback

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def require(ok, message):
    if not ok:
        raise ValueError(message)


def verify_radius(radius, plan):
    require(type(radius) is float and math.isfinite(radius) and radius == plan['radius_mm'] == 1.,
            'Only the single explicitly authorised R1.0 candidate is accepted')


def check_contour_ids(ids):
    require(ids == [431,293,292,291,290,289,161], 'Only the seven-edge actual contour1 is authorised')


def unwrap_one_solid(shape, children):
    leaves=[]
    def visit(item):
        kind=str(item.ShapeType()).rsplit('.',1)[-1]
        row=dict(native_type=str(item.ShapeType()))
        if kind=='TopAbs_SOLID':
            leaves.append(item)
        elif kind in ('TopAbs_COMPOUND','TopAbs_COMPSOLID'):
            row['children']=[visit(child) for child in children(item)]
        else:
            raise ValueError('Native fillet container has a non-Solid leaf: '+kind)
        return row
    structure=visit(shape)
    require(len(leaves)==1,'Native fillet must contain exactly one Solid leaf; observed='+str(len(leaves))+'; structure='+json.dumps(structure))
    return leaves[0],structure


def native_empty(shape):
    return shape is None or shape.wrapped.IsNull() or all(not getattr(shape, key)()
        for key in ('solids', 'faces', 'edges', 'vertices'))


def verify_pins(pins):
    observed = {name: sha(ROOT / name) for name in pins}
    require(observed == pins, 'An input/source changed')
    return observed


def run(radius, plan_sha):
    started = time.monotonic()
    require(sha(HERE/'plan.json') == plan_sha, 'Plan SHA differs')
    plan = json.loads((HERE/'plan.json').read_text())
    verify_radius(radius, plan)
    before = verify_pins(plan['files_sha256'])
    output = ROOT / plan['output_directory']
    require(not output.exists() and not output.is_symlink(), 'Fresh output required')
    output.mkdir()
    signal.signal(signal.SIGALRM, lambda *_: (_ for _ in ()).throw(TimeoutError('CAD prototype wall budget')))
    signal.alarm(270)
    resource.setrlimit(resource.RLIMIT_CPU, (250, 251))
    report = dict(schema='isolated-cap-rib-contour1-native-fillet-1', status='refused', radius_mm=radius,
                  operation='BRepFilletAPI_MakeFillet R1 on contour1 only; positive-Y contour2 retained as reference',
                  baseline_STEP_sha256=plan['files_sha256'][plan['STEP']], selected_edges=[],
                  CAD_qualified=False, FEA_executed=False, supports_revalidated=False,
                  manufacturing_authorized=False, sources_before=before)
    try:
        sys.path.insert(0, str(ROOT / plan['native_site']))
        from build123d import Solid, import_step, export_step, export_stl, export_brep
        from OCP.BRep import BRep_Tool
        from OCP.BRepAdaptor import BRepAdaptor_Surface
        from OCP.BRepBuilderAPI import BRepBuilderAPI_MakeVertex
        from OCP.BRepExtrema import BRepExtrema_DistShapeShape
        from OCP.BRepFilletAPI import BRepFilletAPI_MakeFillet
        from OCP.OSD import OSD_ThreadPool
        from OCP.Precision import Precision
        from OCP.TopoDS import TopoDS, TopoDS_Iterator
        from OCP.gp import gp_Pnt
        OSD_ThreadPool.DefaultPool_s().Init(1)
        corrections = load('_fillet_precise_volume', ROOT / plan['volume_source'])
        normal_helper = load('_fillet_existing_normals', ROOT / plan['normal_source'])
        body = import_step(ROOT / plan['STEP'])
        require(body.is_valid and len(body.solids()) == 1, 'Baseline must be one valid solid')
        faces, edges = list(body.faces()), list(body.edges())
        face_edges = [list(face.edges()) for face in faces]
        diagnosis = json.loads((ROOT / plan['diagnostic']).read_text())
        source_record = diagnosis['probes'][0]['nearest_edges'][0]
        require(diagnosis['status'] == 'complete_readonly_diagnostic' and diagnosis['sources_unchanged'], 'Invalid diagnostic')
        source_index = source_record['edge_index_zero_based']
        source = edges[source_index]
        require(source_record['adjacent_faces_zero_based'] == [124, 165] and source_record['native_continuity'].endswith('GeomAbs_C0'), 'Unexpected source junction')
        require(source.length == source_record['length_mm'], 'Source edge reimport differs')
        fractions = (0., .25, .5, .75, 1.)
        source_points = [list(source.position_at(f)) for f in fractions]
        source_tolerance = BRep_Tool.Tolerance_s(source.wrapped)
        adjacent = [[i for i, items in enumerate(face_edges) if any(edge.wrapped.IsSame(item.wrapped) for item in items)] for edge in edges]

        def query(point, edge):
            q = BRepExtrema_DistShapeShape(BRepBuilderAPI_MakeVertex(gp_Pnt(*point)).Shape(), edge.wrapped)
            q.SetMultiThread(False); q.Perform()
            require(q.IsDone() and q.NbSolution() > 0, 'Native edge query incomplete')
            return q

        selected = []
        for sx, sy in ((1,1), (-1,1)):
            expected = [[sx*p[0], sy*p[1], p[2]] for p in source_points]
            matches = []
            for i, edge in enumerate(edges):
                if len(adjacent[i]) != 2:
                    continue
                if any(not str(BRepAdaptor_Surface(faces[j].wrapped, True).GetType()).endswith('GeomAbs_SurfaceOfExtrusion') for j in adjacent[i]):
                    continue
                tol = source_tolerance + BRep_Tool.Tolerance_s(edge.wrapped)
                box = edge.bounding_box()
                if any(p[d] < list(box.min)[d]-tol or p[d] > list(box.max)[d]+tol for p in expected for d in range(3)):
                    continue
                queries = [query(p, edge) for p in expected]
                errors = [q.Value() for q in queries]
                if max(errors) <= tol:
                    matches.append((i, edge, queries[2], errors, tol))
            require(len(matches) == 1, f'Expected one geometric XY mirror for {(sx,sy)}, found {len(matches)}')
            i, edge, q, errors, tol = matches[0]
            require(str(q.SupportTypeShape2(1)).endswith('IsOnEdge'), 'Mirrored midpoint must lie on the edge interior')
            parameter = q.ParOnEdgeS2(1)[0]
            ns = [normal_helper.boundary_normal(edge, faces[j], parameter)[0] for j in adjacent[i]]
            angular = Precision.Angular_s()
            cap = [n for n in ns if abs(n[1]) <= angular and n[2] > 0 and sx*n[0] < 0]
            wall = [n for n in ns if abs(n[2]) <= angular and sy*n[1] < 0 and sx*n[0] < 0]
            require(len(cap) == len(wall) == 1, 'Mirrored cap/rib outward normal roles differ')
            require(str(BRep_Tool.Continuity_s(edge.wrapped, *(faces[j].wrapped for j in adjacent[i]))).endswith('GeomAbs_C0'), 'Expected native C0 junction')
            selected.append(edge)
            report['selected_edges'].append(dict(mirror_X=sx, mirror_Y=sy, edge_index_zero_based=i,
                adjacent_faces_zero_based=adjacent[i], length_mm=edge.length, normal_roles=dict(cap=cap[0].tolist(), rib=wall[0].tolist()),
                sample_fraction=fractions, expected_mirrored_points_mm=expected, sample_distances_mm=errors,
                native_sum_tolerance_mm=tol, recognition='Unique native five-point source/mirror containment, adjacency and normal roles; actual contour identity checked separately'))
        require(len({item['edge_index_zero_based'] for item in report['selected_edges']}) == 2, 'Two negative-Y junction seeds required')
        old_volume, old_error = corrections.precise_volume(body)
        report.update(old_volume_mm3=old_volume, old_volume_estimated_relative_error=old_error,
                      native_confusion_mm=Precision.Confusion_s(), native_angular_precision=Precision.Angular_s())
        builder = BRepFilletAPI_MakeFillet(body.solids()[0].wrapped)
        diagnostic = json.loads((ROOT/plan['contour_diagnostic']).read_text())
        expected=[row['edge_index_zero_based'] for row in diagnostic['initial_contours'][0]['edges']]
        check_contour_ids(expected)
        for i in expected:
            builder.Add(radius,edges[i].wrapped)
        require(builder.NbContours()==1,'Only one actual native contour may be filleted')
        actual=[next(i for i,e in enumerate(edges) if e.wrapped.IsSame(builder.Edge(1,j)))
                for j in range(1,builder.NbEdges(1)+1)]
        check_contour_ids(actual)
        require(builder.IsConstant(1) and builder.Radius(1)==1.,'Contour1 must remain constant R1')
        report['native_contour1']=dict(edges=actual,native_radius_mm=builder.Radius(1),native_length_mm=builder.Length(1))
        report['unselected_reference_contour2']=[row['edge_index_zero_based'] for row in diagnostic['initial_contours'][1]['edges']]
        report['design_scope']='Only the negative-Y seven-edge contour, including both X peak junctions. Four-junction symmetry is not claimed; no stress peak may be excluded later.'
        report['stage']='native_contour1_build'
        builder.Build()
        report['native_build_status']=dict(IsDone=builder.IsDone(),HasResult=builder.HasResult(),
            NbFaultyContours=builder.NbFaultyContours(),NbFaultyVertices=builder.NbFaultyVertices(),
            FaultyVertices_mm=[list(BRep_Tool.Pnt_s(builder.FaultyVertex(k)).Coord()) for k in range(1,builder.NbFaultyVertices()+1)],
            StripeStatus=[str(builder.StripeStatus(ci)) for ci in range(1,builder.NbContours()+1)])
        require(builder.IsDone(), 'Native contour1 R1 fillet did not complete')
        raw=builder.Shape()
        report['native_returned_shape_type']=str(raw.ShapeType())
        def children(shape):
            iterator=TopoDS_Iterator(shape)
            while iterator.More():
                yield iterator.Value()
                iterator.Next()
        leaf,structure=unwrap_one_solid(raw,children)
        report['native_returned_container_structure']=structure
        candidate = Solid(TopoDS.Solid_s(leaf))
        require(candidate.is_valid and len(candidate.solids()) == 1, 'Fillet must produce one valid solid')
        new_volume, new_error = corrections.precise_volume(candidate)
        report['stage']='native_additivity_check'
        removed, added = body-candidate, candidate-body
        report.update(new_volume_mm3=new_volume, new_volume_estimated_relative_error=new_error,
            old_minus_new_native_empty=native_empty(removed), new_minus_old_native_empty=native_empty(added),
            new_minus_old_volume_mm3=0. if native_empty(added) else corrections.precise_volume(added)[0],
            old_minus_new_volume_mm3=0. if native_empty(removed) else corrections.precise_volume(removed)[0])
        require(report['old_minus_new_native_empty'], 'Native fillet removes material; additive contract refused')
        require(not report['new_minus_old_native_empty'] and report['new_minus_old_volume_mm3'] > 0 and new_volume > old_volume,
                'Native added material must be strictly positive')
        export_brep(candidate, output/'candidate-native.brep')
        export_step(candidate, output/'carrier.step')
        export_stl(candidate, output/'carrier.stl', tolerance=.06, angular_tolerance=.10)
        reread = import_step(output/'carrier.step')
        require(reread.is_valid and len(reread.solids()) == 1, 'STEP readback must be one valid solid')
        read_volume, read_error = corrections.precise_volume(reread)
        require(abs(read_volume/new_volume-1) < 1e-8, 'Existing STEP roundtrip volume guard failed')
        require(native_empty(body-reread), 'STEP readback removed material')
        box = reread.bounding_box()
        bounds = [list(box.min), list(box.max)]
        require(all(bounds[0][d] >= plan['minimum_xyz_mm'][d]-plan['existing_bound_guard_mm'] and bounds[1][d] <= plan['maximum_xyz_mm'][d]+plan['existing_bound_guard_mm'] for d in range(3)), 'Existing global bounds failed')
        settings = json.loads((ROOT / plan['study']).read_text())
        density = settings['material']['density_tonne_mm3']*1000
        mass = read_volume*density
        require(mass <= 1.3, 'Existing authorised mass ceiling failed')
        (output/'study.json').write_bytes((ROOT/plan['study']).read_bytes())
        protected = load('_fillet_existing_protected_check', ROOT / plan['protected_source'])
        report['stage']='existing_complete_protected_interface_screen'
        try:
            protection = protected.check(output)
        except AssertionError as error:
            if (output/'inspection.json').is_file():
                report['protected_interface_partial_report']=json.loads((output/'inspection.json').read_text())
            raise ValueError('Existing protected-interface checker refused after successful native contour1 fillet') from error
        require(protection['study_assembly_screen_pass'], 'Original complete protected-interface screen failed')
        report.update(status='native_additive_candidate_passed_geometry_gates', stage='complete', CAD_qualified=True,
            STEP_readback_volume_mm3=read_volume, STEP_readback_estimated_relative_error=read_error,
            STEP_readback_relative_volume_difference=read_volume/new_volume-1, mass_kg=mass, bounds_mm=bounds,
            protected_interface_report=protection, requested_constant_native_radius_mm=radius,
            produced_native_surface_types=sorted({str(BRepAdaptor_Surface(face.wrapped,True).GetType()) for face in candidate.faces()}),
            effect='Native Boolean old-minus-new empty and new-minus-old positive: material-adding fillet',
            no_source_builder_modified=True, old_supports_applicable_to_new_CAD=False)
    except BaseException as error:
        report['failure'] = dict(type=type(error).__name__, message=str(error), traceback=traceback.format_exc())
    finally:
        signal.alarm(0)
        after = {name: sha(ROOT/name) for name in before}
        report.update(sources_after=after, sources_unchanged=before == after,
                      elapsed_seconds=time.monotonic()-started)
        if before != after:
            report['status'] = 'refused_input_drift'
            report['CAD_qualified'] = False
        report['outputs_sha256'] = {p.name: sha(p) for p in output.iterdir() if p.is_file()}
        with (output/'assessment.json').open('x') as stream:
            json.dump(report, stream, indent=2, allow_nan=False); stream.write('\n')
    print(json.dumps(dict(status=report['status'], CAD_qualified=report['CAD_qualified'],
                          elapsed_seconds=report['elapsed_seconds'], assessment_sha256=sha(output/'assessment.json'))), flush=True)
    return 0 if report['CAD_qualified'] and report['sources_unchanged'] else 1


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('stage', choices=['run'])
    parser.add_argument('--radius-mm', type=float, required=True)
    parser.add_argument('--plan-sha256', required=True)
    args = parser.parse_args()
    raise SystemExit(run(args.radius_mm, args.plan_sha256))
