"""Two separately bounded linear CCX cases on the actual native-BREP global7 mesh."""
import argparse
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import shutil
import signal
import sys
import time

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
IMAGE = 'sha256:c9772ae9223a4f800a3ceda77d2494e67e34c8526eb0f204b3c8e052266641b4'
BINARY = '271f8411371b978d7a8d31a7a13d0765e6e1f872e8a8b1d6aac6d0856c71ec6c'
CASES = {'rigid': ('combined-rigid-static', None), 'spring': ('combined-spring-1000-static', 1000)}


def require(ok, message):
    if not ok: raise ValueError(message)


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''): h.update(block)
    return h.hexdigest()


def write(path, value):
    with Path(path).open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False); stream.write('\n')


def load(name, path, injected=None):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec); module.__dict__.update(injected or {}); spec.loader.exec_module(module)
    return module


def copy_exact(source, target, expected):
    with Path(source).open('rb') as src, Path(target).open('xb') as dst:
        shutil.copyfileobj(src, dst, 1024 * 1024)
    require(sha(target) == expected, 'Copied case input differs')


class DeckPrepared(Exception):
    pass


def prepare_execute(case, execution, name, digest_record):
    """Preserve the deck made by unchanged solve(), then stop before Docker."""
    def execute(folder, actual_name, *args, **kwargs):
        require(Path(folder) == case and actual_name == name, 'Unexpected preparation callback')
        source = case / (name + '.inp'); target = execution / 'prepared-deck.inp'
        require(not target.exists() and not target.is_symlink(), 'Prepared deck already exists')
        digest_record['deck_sha256'] = sha(source)
        source.rename(target)
        require(sha(target) == digest_record['deck_sha256'], 'Prepared deck rename differs')
        raise DeckPrepared('Generated native deck retained; no solver called')
    return execute


def make_execute(helper, backend, plan, case, execution, started):
    """The sole production solve callback: frozen owned Docker supervision."""
    used = False
    def execute(folder, name, *args, **kwargs):
        nonlocal used
        require(not used and Path(folder) == case and name == plan['case_name'], 'Unexpected/repeated execute callback')
        used = True; callback_start = time.monotonic()
        require(sha(case / (name + '.inp')) == plan['prepared_deck_sha256'], 'Native deck differs from prepared original solve deck')
        require(sha(execution / 'prepared-deck.inp') == plan['prepared_deck_sha256'], 'Frozen prepared deck changed')
        owned = dict(case_directory=str(case.resolve()), case_name=name,
                     container_name=plan['container_name'], ownership_token=plan['ownership_token'],
                     image=IMAGE, binary_sha256=BINARY, wall_budget_seconds=1800, cleanup_reserve_seconds=60,
                     solver_timeout_seconds=1680,
                     container_command=['--signal=TERM', '--kill-after=10s', '1680s', '/usr/bin/ccx', '-i', name],
                     initial_case_files=['mesh.inp', 'mesh.npz', 'mesh.json', name + '.inp'],
                     files_sha256={str(ROOT / p): h for p, h in plan['files_sha256'].items()})
        owned['files_sha256'][str(case / (name + '.inp'))] = plan['prepared_deck_sha256']
        for filename in ['mesh.inp', 'mesh.npz', 'mesh.json']:
            owned['files_sha256'][str(case / filename)] = plan['mesh_files_sha256'][filename]
        write(execution / 'native-plan.json', owned)
        helper.HERE = execution  # Private module instance; frozen capsule directory is never written.
        result = helper.supervise(owned, backend, started=started)
        result.update(native_plan_sha256=sha(execution / 'native-plan.json'), helper_source_sha256=plan['helper_sha256'])
        write(execution / 'native-receipt.json', result)
        require(result['status'] == 'solver_executed_no_numeric_admission'
                and result['actual_container_exit_code'] == 0 and result['container_removed']
                and result['input_hashes_unchanged'] and result['within_global_budget'], 'Owned CCX execution/cleanup failed')
        require(not backend.cancelled, 'Cancellation requested after owned cleanup')
        write(case / 'runtime.json', dict(status='executed', image=IMAGE, ccx_binary_sha256=BINARY,
              container_name=plan['container_name'], actual_container_id=result['container_id'],
              native_returncode=result['actual_container_exit_code'], owned_container_removed=True,
              CPUs=1, memory_bytes=6*1024**3, memory_swap_bytes=6*1024**3, network='none',
              native_plan_sha256=sha(execution / 'native-plan.json'), native_receipt_sha256=sha(execution / 'native-receipt.json')))
        left = started + 1800 - time.monotonic()
        require(left > 0, 'No postprocess time remains in per-case budget')
        # No local alarm can interrupt the frozen helper's reserved container cleanup.
        signal.signal(signal.SIGALRM, lambda *_: (_ for _ in ()).throw(TimeoutError('Per-case postprocess deadline')))
        signal.setitimer(signal.ITIMER_REAL, left)
        return time.monotonic() - callback_start
    return execute


def deck_contract(blocks, end_rosters, support, positions, target_force, target_moment):
    """Read-only evidence from the actual unchanged solve deck; no load feedback."""
    require(len(end_rosters) == 2 and all(end_rosters) and
            len(set(end_rosters[0]) | set(end_rosters[1])) == sum(map(len, end_rosters)), 'Two disjoint actual end rosters required')
    fixed = [int(v) for key, lines in blocks if key == '*NSET,NSET=FIXED' for line in lines for v in line.split(',')]
    require(fixed == end_rosters[0] + end_rosters[1], 'FIXED deck set differs from actual new mesh')
    boundaries = [lines for key, lines in blocks if key == '*BOUNDARY']
    require(boundaries == ([['FIXED,1,3']] if support is None else []), 'Original rigid/spring displacement support differs')
    elements, stiffnesses = {}, {}
    for key, lines in blocks:
        if key.startswith('*ELEMENT,TYPE=SPRING1,ELSET='):
            label = key.split('ELSET=')[1]
            require(label not in elements, 'Duplicate spring element set')
            elements[label] = [[int(v) for v in line.split(',')] for line in lines]
        elif key.startswith('*SPRING,ELSET='):
            label = key.split('ELSET=')[1]
            require(label not in stiffnesses and len(lines) == 2, 'Duplicate or malformed stiffness card')
            stiffnesses[label] = (int(lines[0]), float(lines[1]))
    springs = []
    if support is None:
        require(not elements and not stiffnesses, 'Rigid case unexpectedly contains springs')
    else:
        require(support == 1000, 'Only original K1000 model authorized')
        labels = {f'S{eye}{dof}' for eye in range(2) for dof in range(1, 4)}
        require(set(elements) == set(stiffnesses) == labels, 'Expected all six directional eye sets')
        eids = []
        for eye, nodes in enumerate(end_rosters):
            for dof in range(1, 4):
                label = f'S{eye}{dof}'; rows = elements[label]
                require(all(len(row) == 2 for row in rows) and [row[1] for row in rows] == nodes,
                        'Spring element nodes differ from actual eye roster')
                require(stiffnesses[label] == (dof, support / len(nodes)), 'K1000 must be total PER EYE AND AXIS, divided by node count')
                eids.extend(row[0] for row in rows)
                springs.append(dict(eye=eye, DOF=dof, node_count=len(nodes),
                    per_node_stiffness_N_mm=stiffnesses[label][1],
                    summed_card_stiffness_N_mm=len(nodes) * stiffnesses[label][1], declared_total_per_eye_axis_N_mm=support))
        require(len(eids) == len(set(eids)), 'Duplicate spring element IDs')
    forces = [[], [], []]; moments = [[], [], []]; load_count = 0
    for key, lines in blocks:
        if key != '*CLOAD': continue
        for line in lines:
            node, dof, value = line.split(','); node, dof, value = int(node), int(dof), float(value)
            require(node in positions and dof in (1, 2, 3) and math.isfinite(value), 'Invalid serialized CLOAD')
            f = [0., 0., 0.]; f[dof - 1] = value; x, y, z = positions[node]
            cross = [y * f[2] - z * f[1], z * f[0] - x * f[2], x * f[1] - y * f[0]]
            for d in range(3): forces[d].append(f[d]); moments[d].append(cross[d])
            load_count += 1
    require(load_count > 0, 'No original combined load cards')
    force = [math.fsum(v) for v in forces]; moment = [math.fsum(v) for v in moments]
    return dict(scope='Actual serialized cards and mesh INP coordinates; diagnostic resultants do not modify solve loads or add a criterion',
        actual_eye_node_counts=list(map(len, end_rosters)), actual_end_nodes=sum(map(len, end_rosters)),
        rigid_constrained_DOFs=3 * len(fixed) if support is None else 0,
        SPRING1_elements=sum(len(v) for v in elements.values()), springs=springs,
        spring_model='K1000 TOTAL per eye and axis, each node receives1000/n_eye' if support is not None else 'Original FIXED,1,3 on actual new end rosters',
        serialized_CLOAD_entries=load_count, serialized_force_N=force, serialized_moment_Nmm=moment,
        target_force_N=target_force, target_moment_Nmm=target_moment,
        force_delta_serialized_minus_target_N=[a-b for a,b in zip(force, target_force)],
        moment_delta_serialized_minus_target_Nmm=[a-b for a,b in zip(moment, target_moment)],
        unchanged_original_distribute_unrounded_resultant_assertions_reached=True)


def verify_mesh(plan):
    terminal = json.loads((ROOT / plan['mesh_terminal']).read_text())
    assessment = json.loads((ROOT / plan['mesh_assessment']).read_text())
    supervision = json.loads((ROOT / plan['mesh_supervision']).read_text())
    require(terminal['actual_outer_returncode'] == terminal['actual_child_returncode'] == 0
            and terminal['fresh_postcollection_pins_equal'] and terminal['sources_and_plan_unchanged']
            and terminal['assessment_sha256'] == sha(ROOT / plan['mesh_assessment'])
            and terminal['supervision_sha256'] == sha(ROOT / plan['mesh_supervision']), 'Closed native BREP mesh terminal differs')
    require(supervision['actual_returncode'] == 0 and supervision['direct_child_reaped']
            and not supervision['final_group_members'] and supervision['sources_and_plan_unchanged'], 'Mesh execution not closed')
    require(assessment['status'] == 'native_BREP_mesh_completed' and assessment['sources_unchanged']
            and assessment['quality']['finite'] and assessment['quality']['nonpositive_elements'] == 0
            and assessment['quality']['minimum_Jacobian'] > 0, 'Native BREP mesh gates refused')
    imported = assessment['BREP_import']
    require(imported['passed'] and imported['historical_relative_guard'] == 1e-8
            and imported['relative_volume_difference'] == 0
            and imported['actual_import_options_before'] == imported['actual_import_options_after']
            == plan['actual_import_options_required'], 'Actual comparable-operator import/options differ')
    require(assessment['mesh_metadata']['CAD_source_format'] == 'BREP'
            and assessment['mesh_metadata']['BREP_sha256'] == plan['BREP_sha256']
            and assessment['mesh_metadata']['bore_node_counts'] == plan['expected_bore_node_counts'], 'Actual BREP/groups differ')


def verify_protected(plan):
    names = ('protected_terminal', 'protected_assessment', 'protected_supervision', 'protected_report', 'inspection_report')
    require(all(plan.get(name) is not None for name in names), 'Complete direct BREP comparator remains pending')
    require(all(plan[name] in plan['files_sha256'] for name in names), 'Complete comparator proof not SHA-bound')
    terminal, assessment, supervision, protected, inspection = [json.loads((ROOT / plan[name]).read_text()) for name in names]
    require(terminal['actual_outer_returncode'] == terminal['actual_child_returncode'] == 0, 'Actual comparator outer/child return failed')
    require(terminal['assessment_sha256'] == sha(ROOT / plan['protected_assessment'])
            and terminal['supervision_sha256'] == sha(ROOT / plan['protected_supervision']), 'Full BREP reports terminal SHA links differ')
    require(supervision['status'] == 'executed' and supervision['actual_returncode'] == 0
            and supervision['direct_child_reaped'] and not supervision['final_group_members']
            and not supervision['timeout'] and not supervision['interrupted']
            and supervision['sources_and_plan_unchanged'], 'Actual complete BREP comparison not closed')
    require(assessment['status'] == 'complete_BREP_protected_checks_passed_current_1p3kg'
            and assessment['checker_returned'] is True and assessment['current_mass_ceiling_1p3kg_pass'] is True
            and assessment['inputs_runtime_plan_unchanged'] is True, 'Complete BREP comparator refused')
    require(assessment['CAD_source']['format'] == 'brep' and assessment['CAD_source']['sha256'] == plan['BREP_sha256']
            and assessment['STL_sha256'] == plan['protected_surface_STL_sha256'], 'Complete comparator CAD/STL binding differs')
    require(assessment['outputs']['protected-input/protected-interfaces.json']['sha256'] == sha(ROOT / plan['protected_report'])
            and assessment['outputs']['protected-input/inspection.json']['sha256'] == sha(ROOT / plan['inspection_report']), 'Complete comparator outputs differ')
    require(assessment['actual_protected_interfaces'] == protected == assessment['protected_report']
            and assessment['actual_inspection'] == inspection, 'Full BREP reports differ, not a projection')
    require(protected['study_assembly_screen_pass'] is True and inspection['study_assembly_screen_pass'] is True
            and inspection['nominal_mass_kg'] <= 1.3 and protected['nominal_mass_kg'] == inspection['nominal_mass_kg'], 'Complete interface/current-mass criteria failed')
    require(assessment['legacy_mass_flag_retained_without_override'] == inspection['mass_ceiling_pass'] == protected['mass_ceiling_pass'], 'Historical1.2kg flag was relabelled')
    require(protected['candidate_CAD_source']['format'] == inspection['CAD_source']['format'] == 'brep'
            and protected['candidate_CAD_source']['sha256'] == inspection['inputs_sha256']['candidate-native.brep'] == plan['BREP_sha256']
            and inspection['inputs_sha256']['carrier.stl'] == plan['protected_surface_STL_sha256'], 'Actual full BREP report input differs')


def verified(plan, expected_hash, plan_path):
    require(sha(plan_path) == expected_hash and plan['launch_ready'] is True, 'Plan not armed or changed')
    require(plan['case_key'] in CASES and (plan['case_name'], plan['support_N_mm']) == CASES[plan['case_key']], 'Wrong fixed case')
    require(plan['wall_budget_seconds'] == 1800 and plan['cleanup_reserve_seconds'] == 60
            and plan['image'] == IMAGE and plan['binary_sha256'] == BINARY, 'Fixed solver/resource identity differs')
    require(plan['mesh_source'] == 'work/carrier-process-20261017/bounded-webs-BREP-mesh-preparation-002/output-001/cad-BREP-master/mesh-7', 'Wrong actual native BREP mesh')
    require(os.getpriority(os.PRIO_PROCESS, 0) == 10 and all(os.environ.get(k) == '1' for k in
            ('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS')), 'nice10 and one local BLAS thread required')
    actual = {p: sha(ROOT / p) for p in plan['files_sha256']}; require(actual == plan['files_sha256'], 'An input/source/runtime differs')
    verify_mesh(plan)
    verify_protected(plan)
    study = json.loads((ROOT / plan['CAD_inputs']['study.json']).read_text())
    require(study['material']['E_MPa'] == 107000 and study['material']['nu'] == .31
            and study['load_cases']['combined']['force_N'] == [0, 0, -4000]
            and study['load_cases']['combined']['moment_Nmm'] == [0, 850000, 0], 'Original fixed physics differs')
    return actual


def prepare(plan, plan_path, expected_hash):
    before = verified(plan, expected_hash, plan_path)
    output = ROOT / plan['case_output']; require(not output.exists() and not output.is_symlink(), 'Fresh case copy required')
    require(all(not p.is_symlink() for p in output.parents), 'Symlink case ancestor')
    output.mkdir(); cad = output / 'cad'; cad.mkdir(); case = cad / 'mesh-7'; case.mkdir(); execution = output / 'execution'; execution.mkdir()
    for name, p in plan['CAD_inputs'].items(): copy_exact(ROOT / p, cad / name, before[p])
    for name, digest in plan['mesh_files_sha256'].items(): copy_exact(ROOT / plan['mesh_source'] / name, case / name, digest)
    sys.path.insert(0, str(ROOT / plan['numpy_site']))
    sim = load('private_static_prepare_' + plan['case_key'], ROOT / plan['simulation_source'])
    sim.CONTAINER = plan['container_name']; record = {}
    sim.execute = prepare_execute(case, execution, plan['case_name'], record)
    try: sim.solve(case, 'combined', support=plan['support_N_mm'], procedure='static')
    except DeckPrepared: pass
    else: raise ValueError('Deck preparation failed to stop before execution')
    require(record.get('deck_sha256') and not (case / (plan['case_name'] + '.inp')).exists(), 'Prepared deck not retained exclusively')
    binding = load('prepare_BREP_provenance_' + plan['case_key'], ROOT / plan['binding_source'])
    energy = load('prepare_BREP_energy_reader_' + plan['case_key'], ROOT / plan['energy_source'], {'_verify_BREP_binding': binding.verify})
    blocks = energy.blocks(execution / 'prepared-deck.inp')
    tags, xyz, _, _ = energy.read_mesh(case / 'mesh.inp')
    with sim.np.load(case / 'mesh.npz', allow_pickle=False) as mesh:
        require(sim.np.array_equal(tags, mesh['tags']) and sim.np.allclose(xyz, mesh['xyz'], rtol=0, atol=energy.COORDINATE_ROUNDOFF_MM), 'Original INP/NPZ coordinate guard refused')
        end_rosters = [mesh['end0'].astype(int).tolist(), mesh['end1'].astype(int).tolist()]
        require({name: len(mesh[name]) for name in plan['expected_bore_node_counts']} == plan['expected_bore_node_counts'], 'Copied actual bore groups differ')
    load_ids = sorted({int(row.split(',')[0]) for key, lines in blocks if key == '*CLOAD' for row in lines})
    indices = sim.np.searchsorted(tags, load_ids)
    require(sim.np.all(indices < len(tags)) and sim.np.array_equal(tags[indices], load_ids), 'Unknown serialized load node')
    positions = {node: xyz[index].tolist() for node, index in zip(load_ids, indices)}
    study = json.loads((cad / 'study.json').read_text())
    evidence = deck_contract(blocks, end_rosters, plan['support_N_mm'], positions,
                             study['load_cases']['combined']['force_N'], study['load_cases']['combined']['moment_Nmm'])
    write(execution / 'load-and-supports.json', evidence)
    armed = dict(plan, prepared_deck_sha256=record['deck_sha256'], preparation_plan_sha256=expected_hash,
                 prepared_load_support_sha256=sha(execution / 'load-and-supports.json'))
    write(output / 'case-plan.json', armed)
    require(before == {p: sha(ROOT / p) for p in before}, 'Preparation changed frozen inputs')
    write(output / 'preparation.json', dict(status='actual_original_solve_deck_prepared_no_FEA', case_name=plan['case_name'],
          case_plan_sha256=sha(output / 'case-plan.json'), prepared_deck_sha256=record['deck_sha256'],
          load_support_evidence_sha256=sha(execution / 'load-and-supports.json'), sources_unchanged=True, FEA_started=False))
    print(json.dumps(dict(status='prepared_no_FEA', case=plan['case_key'], plan_sha256=sha(output / 'case-plan.json'), deck_sha256=record['deck_sha256'])), flush=True)


def run(plan, plan_path, expected_hash):
    started = time.monotonic(); before = verified(plan, expected_hash, plan_path)
    output = ROOT / plan['case_output']; case = output / 'cad/mesh-7'; execution = output / 'execution'
    require(not (output / 'assessment.json').exists() and not (execution / 'ccx.prestart').exists(), 'Preserve previous native case')
    require(set(p.name for p in case.iterdir()) == {'mesh.inp', 'mesh.npz', 'mesh.json'}, 'Case copy is no longer fresh')
    require(sha(execution / 'prepared-deck.inp') == plan['prepared_deck_sha256'], 'Prepared original deck changed')
    require(sha(execution / 'load-and-supports.json') == plan['prepared_load_support_sha256'], 'Prepared actual load/support evidence changed')
    sys.path.insert(0, str(ROOT / plan['numpy_site']))
    sim = load('private_static_solve_' + plan['case_key'], ROOT / plan['simulation_source'])
    binding = load('private_BREP_provenance_' + plan['case_key'], ROOT / plan['binding_source'])
    energy = load('private_static_energy_' + plan['case_key'], ROOT / plan['energy_source'], {'_verify_BREP_binding': binding.verify})
    peak = load('private_static_peak_' + plan['case_key'], ROOT / plan['peak_source'], {'_verify_BREP_binding': binding.verify})
    helper = load('private_owned_CCX_' + plan['case_key'], ROOT / plan['helper_source']); backend = helper.DockerCLI()
    require(energy.ENERGY_RELATIVE_TOLERANCE == 1e-4, 'Energy criterion changed')
    old_handlers = {sig: signal.signal(sig, backend.cancel) for sig in (signal.SIGTERM, signal.SIGINT)}
    sim.CONTAINER = plan['container_name']; sim.execute = make_execute(helper, backend, plan, case, execution, started)
    report = dict(status='incomplete_no_numeric_admission', case_name=plan['case_name'], image=IMAGE,
                  physical_validation=False, strength_allowable_added=False, convergence_threshold_added=False,
                  prepared_actual_load_supports=json.loads((execution / 'load-and-supports.json').read_text()))
    error = None
    try:
        native = sim.solve(case, 'combined', support=plan['support_N_mm'], procedure='static')
        require(not backend.cancelled, 'Cancellation requested')
        independent = energy.audit(case, plan['case_name']); write(output / 'energy-audit.json', independent)
        require(independent['energy_closure_pass'], 'Original independent energy criterion failed')
        peaks = peak.locate_case(case, plan['case_name'], energy, sim, sim.np); write(output / 'global-peaks.json', peaks)
        comparisons = []
        for baseline in plan['baselines']:
            retained = json.loads((ROOT / baseline['receipt']).read_text())
            retained_peaks = json.loads((ROOT / baseline['peaks']).read_text())
            require(retained['name'] == plan['case_name'] and retained_peaks['case'] == plan['case_name'], 'Wrong retained comparison case')
            comparisons.append(dict(mesh=baseline['mesh'], retained=retained, retained_global_peaks=retained_peaks,
                displacement_max_ratio=native['displacement_max_mm'] / retained['displacement_max_mm'],
                global_VM_max_ratio=native['integration_point_VM_max_MPa'] / retained['integration_point_VM_max_MPa'],
                load_dot_displacement_ratio=native['external_work_Nmm'] / retained['external_work_Nmm'],
                interpretation='Measured ratios across different CAD and regenerated meshes; not a convergence or strength criterion'))
        require(time.monotonic() - started < 1800, 'Per-case budget exceeded before numeric closeout')
        report.update(status='actual_linear_static_and_independent_energy_completed', native_result=native,
                      energy_audit_sha256=sha(output / 'energy-audit.json'), global_peaks_sha256=sha(output / 'global-peaks.json'),
                      comparisons_to_historical_other_CAD_global7=comparisons, all_global_maxima_included=True)
    except BaseException as exc:
        error = exc; report['error'] = dict(type=type(exc).__name__, message=str(exc))
    finally:
        signal.setitimer(signal.ITIMER_REAL, 0)
        for sig, handler in old_handlers.items(): signal.signal(sig, handler)
    require(sha(execution / 'load-and-supports.json') == plan['prepared_load_support_sha256'], 'Prepared actual load/support evidence changed during solve')
    after = {p: sha(ROOT / p) for p in before}
    report.update(plan_sha256=expected_hash, plan_unchanged=sha(plan_path) == expected_hash,
                  sources_before=before, sources_after=after, sources_unchanged=before == after,
                  wall_seconds=time.monotonic()-started, per_case_budget_seconds=1800,
                  scope='One new linear case on native BREP global7. Original assumed loads/material and per-eye support model retained with NEW nodal rosters. Other-CAD historical comparisons do not establish convergence or physical/manufacturing qualification.')
    report['within_case_budget'] = report['wall_seconds'] <= 1800
    if not report['within_case_budget']:
        report['status'] = 'case_budget_exceeded_no_numeric_admission'
        if error is None: error = TimeoutError('Per-case bookkeeping exceeded 1800s')
    write(output / 'assessment.json', report)
    require(before == after and report['plan_unchanged'], 'A frozen case input changed')
    if error is not None: raise error
    print(json.dumps(dict(status=report['status'], case=plan['case_key'], assessment_sha256=sha(output / 'assessment.json'))), flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(); parser.add_argument('mode', choices=['prepare', 'run']); parser.add_argument('plan'); parser.add_argument('--plan-sha256', required=True)
    args = parser.parse_args(); path = Path(args.plan); plan = json.loads(path.read_text())
    (prepare if args.mode == 'prepare' else run)(plan, path, args.plan_sha256)
