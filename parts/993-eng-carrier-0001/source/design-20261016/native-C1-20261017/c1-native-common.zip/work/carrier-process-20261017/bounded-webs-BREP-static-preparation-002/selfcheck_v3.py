"""Unchanged thirteen baseline checks plus the two-link revision, no scientific import."""
import hashlib
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
OLD = ROOT / 'work/carrier-process-20261017/bounded-webs-BREP-static-preparation-001'

def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
    return module

baseline = load('frozen_static_13checks', OLD / 'selfcheck_v2.py')
r = load('static_terminal_two_links', HERE / 'run.py')

def linked_fixture(root):
    plan, assessment, protected = baseline.protected_fixture(root)
    terminal = json.loads((root / 'terminal.json').read_text())
    terminal.update(assessment_sha256=r.sha(root / 'assessment.json'), supervision_sha256=r.sha(root / 'supervision.json'))
    (root / 'terminal.json').write_text(json.dumps(terminal))
    plan['files_sha256']['terminal.json'] = r.sha(root / 'terminal.json')
    return plan, terminal

class NewChecks(unittest.TestCase):
    def test_only_two_equalities_added_and_retained_tests_unchanged(self):
        record = json.loads((HERE / 'source-derivation.json').read_text())
        text = (HERE / 'run.py').read_text()
        self.assertEqual(text.count(record['inserted_text']), 1)
        self.assertEqual(text.replace(record['inserted_text'], ''), (OLD / 'run.py').read_text())
        for name, digest in record['retained_tests_byte_identical'].items():
            self.assertEqual(hashlib.sha256((HERE / name).read_bytes()).hexdigest(), digest)
            self.assertEqual((HERE / name).read_bytes(), (OLD / name).read_bytes())
    def test_correctly_joined_full_trio_passes(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp); plan, _ = linked_fixture(root)
            self.assertEqual({n: r.sha(root / n) for n in plan['files_sha256']}, plan['files_sha256'])
            with patch.object(r, 'ROOT', root): r.verify_protected(plan)
    def test_individually_pinned_but_crossed_receipts_refuse(self):
        for role in ['assessment_sha256', 'supervision_sha256']:
            with self.subTest(role=role), tempfile.TemporaryDirectory() as tmp:
                root = Path(tmp); plan, terminal = linked_fixture(root)
                terminal[role] = '0' * 64
                (root / 'terminal.json').write_text(json.dumps(terminal))
                plan['files_sha256']['terminal.json'] = r.sha(root / 'terminal.json')
                self.assertEqual({n: r.sha(root / n) for n in plan['files_sha256']}, plan['files_sha256'])
                with patch.object(r, 'ROOT', root), self.assertRaisesRegex(ValueError, 'terminal SHA links'):
                    r.verify_protected(plan)

if __name__ == '__main__':
    # These thirteen are replayed from the untouched001 source. Exact inverse above
    # proves every other line of002, including all maths/callbacks, is identical.
    suite = unittest.TestSuite([unittest.defaultTestLoader.loadTestsFromTestCase(baseline.retained.Checks),
                               unittest.defaultTestLoader.loadTestsFromTestCase(baseline.NewChecks),
                               unittest.defaultTestLoader.loadTestsFromTestCase(NewChecks)])
    raise SystemExit(not unittest.TextTestRunner(verbosity=1).run(suite).wasSuccessful())
