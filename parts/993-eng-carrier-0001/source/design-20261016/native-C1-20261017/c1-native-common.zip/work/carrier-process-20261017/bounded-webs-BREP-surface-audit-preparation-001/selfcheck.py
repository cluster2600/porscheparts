"""Strict binding and unchanged audit-source assertions; no scientific imports."""
import ast
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('_BREP_screen_checks',HERE/'run_brep_audit.py');driver=importlib.util.module_from_spec(spec);spec.loader.exec_module(driver)
class Checks(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup);self.root=Path(self.tmp.name)
        self.terminal=dict(status='surface_generated_not_yet_audited',actual_outer_returncode=0,actual_child_returncode=0,direct_child_reaped=True,final_group_members=[],all_current_equal=True,master_BREP_sha256=driver.MASTER,
            outputs={'output-001/surface/carrier-remeshed.stl':dict(sha256=driver.SURFACE)})
        self.path=self.root/'terminal.json';self.path.write_text(json.dumps(self.terminal))
        self.plan=dict(schema='native-BREP-new-surface-sampled-screen-1',master_sha256=driver.MASTER,surface_sha256=driver.SURFACE,distance_limit_mm=.06,CPU_seconds=[520,540],inner_wall_seconds=560,outer_wall_seconds=600,files_sha256={},generation_terminal=str(self.path),output_directory=str(self.root/'output'))
    def test_closed_actual_generation(self):driver.verify(self.plan)
    def test_failed_or_unreaped_generation_refused(self):
        for key,value in [('actual_outer_returncode',1),('actual_child_returncode',1),('direct_child_reaped',False),('final_group_members',[{}]),('all_current_equal',False)]:
            d=dict(self.terminal);d[key]=value;self.path.write_text(json.dumps(d))
            with self.assertRaises(ValueError):driver.verify(self.plan)
    def test_wrong_surface_and_threshold_refused(self):
        for key,value in [('surface_sha256','wrong'),('master_sha256','wrong'),('distance_limit_mm',.061),('inner_wall_seconds',561)]:
            with self.assertRaises(ValueError):driver.verify(dict(self.plan,**{key:value}))
    def test_existing_and_dangling_output_refused(self):
        p=Path(self.plan['output_directory']);p.mkdir()
        with self.assertRaises(FileExistsError):driver.verify(self.plan)
        p.rmdir();p.symlink_to(self.root/'missing')
        with self.assertRaises(FileExistsError):driver.verify(self.plan)
    def test_source_tamper_refused(self):
        f=self.root/'source';f.write_text('one');p=dict(self.plan,files_sha256={str(f):driver.sha(f)});driver.verify(p);f.write_text('two')
        with self.assertRaises(ValueError):driver.verify(p)
    def test_delegates_one_native_audit_and_no_old_model(self):
        tree=ast.parse((HERE/'run_brep_audit.py').read_text());calls=[n for n in ast.walk(tree)if isinstance(n,ast.Call)and ast.unparse(n.func)=='module.run']
        self.assertEqual(len(calls),1);self.assertEqual(len(calls[0].args),4)
        self.assertNotIn('old_STL',ast.unparse(tree))
if __name__=='__main__':unittest.main()
