"""One sampled native-BREP shell screen of the actual new surface; no full admission."""
import hashlib
import importlib.util
import json
from pathlib import Path
import resource
import signal
import sys
import time
import traceback

HERE=Path(__file__).resolve().parent
MASTER='a42e6942722957076410d4a89b24f9bd0f11677dfa8319103d6733a0db8a1cf9'
SURFACE='577f0e319722ff785099d5b3d29862fac883937d0ea1441f6e5759398c7d418d'
def sha(p):
    h=hashlib.sha256()
    with Path(p).open('rb')as f:
        for block in iter(lambda:f.read(8*1024*1024),b''):h.update(block)
    return h.hexdigest()
def verify(plan,fresh=True):
    if (plan['schema']!='native-BREP-new-surface-sampled-screen-1'or plan['master_sha256']!=MASTER or
        plan['surface_sha256']!=SURFACE or plan['distance_limit_mm']!=.06 or plan['CPU_seconds']!=[520,540]or
        plan['inner_wall_seconds']!=560 or plan['outer_wall_seconds']!=600):raise ValueError('Reviewed surface/criteria/resources differ')
    for path,digest in plan['files_sha256'].items():
        if sha(path)!=digest:raise ValueError('Source/input/runtime changed: '+path)
    terminal=json.loads(Path(plan['generation_terminal']).read_text())
    if (terminal['status']!='surface_generated_not_yet_audited'or terminal['actual_outer_returncode']!=0 or
        terminal['actual_child_returncode']!=0 or terminal['direct_child_reaped']is not True or terminal['final_group_members']!=[] or
        terminal['all_current_equal']is not True or terminal['master_BREP_sha256']!=MASTER or
        terminal['outputs']['output-001/surface/carrier-remeshed.stl']['sha256']!=SURFACE):raise ValueError('Actual surface generation is not closed and bound')
    output=Path(plan['output_directory'])
    if fresh and(output.exists()or output.is_symlink()):raise FileExistsError('Preserve previous sampled screen')
def main():
    planpath=HERE/'plan.json';plan_sha=sha(planpath);plan=json.loads(planpath.read_text())
    if sys.argv[1:]==['--preflight']:
        verify(plan);print(json.dumps(dict(status='preflight_only_no_OCP',pins=len(plan['files_sha256']),plan_sha256=plan_sha)));return 0
    assert not sys.argv[1:]
    started=time.monotonic();CPU=time.process_time()
    signal.signal(signal.SIGALRM,lambda *_:(_ for _ in ()).throw(TimeoutError('Sampled BREP screen wall cap560')))
    signal.alarm(560);resource.setrlimit(resource.RLIMIT_CPU,(520,540));verify(plan)
    output=Path(plan['output_directory']);output.mkdir();before={p:sha(p)for p in plan['files_sha256']}
    report=dict(schema='native-BREP-new-surface-sampled-assessment-1',status='incomplete',plan_sha256=plan_sha,
        master_BREP_sha256=MASTER,surface_STL_sha256=SURFACE,source_sha256=sha(__file__),sources_runtime_before=before,
        workers=0,native_pool_setting=1,old_model_compared=False,topology_audit_executed=False,global_admission=False,FEA_executed=False)
    previous_path=list(sys.path)
    try:
        sys.path.insert(0,plan['helper_directory'])
        spec=importlib.util.spec_from_file_location('_native_BREP_surface_screen_private',plan['BREP_audit_source'])
        module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
        import build123d
        import numpy
        from OCP import OCP
        actual_modules={n:str(Path(m.__file__).resolve())for n,m in [('build123d',build123d),('numpy',numpy),('OCP',OCP)]}
        if actual_modules!=plan['native_module_paths']:raise ValueError('Native audit borrowed unexpected modules')
        report['actual_native_module_paths']=actual_modules
        from OCP.OSD import OSD_ThreadPool
        OSD_ThreadPool.DefaultPool_s().Init(1)
        result=module.run(plan['master_BREP'],plan['surface_STL'],output/'native',MASTER)
        assert result['CAD_source']==dict(format='brep',sha256=MASTER,path=plan['master_BREP'])
        assert result['results']['candidate_STL']['sha256']==SURFACE
        samples=output/'native/exact-CAD-surface-samples.npz'
        assert sha(samples)==result['exact_CAD_surface_samples_sha256']
        report.update(status='sampled_mesh_to_BREP_passed_pending_inverse_and_topology'if result['candidate_sampled_chord_screen_pass']else'refused_sampled_mesh_to_BREP_chord',
            sampled_forward_chord_pass=result['candidate_sampled_chord_screen_pass'],
            outputs={p.name:dict(sha256=sha(p),bytes=p.stat().st_size)for p in(output/'native').iterdir()})
    except BaseException as error:report['failure']=dict(type=type(error).__name__,message=str(error),traceback=traceback.format_exc())
    finally:
        sys.path[:]=previous_path;signal.alarm(0)
        try:after={p:sha(p)for p in before};intact=before==after and sha(planpath)==plan_sha;verify(plan,fresh=False)
        except BaseException as error:after={};intact=False;report['integrity_failure']=str(error)
        report.update(sources_runtime_after=after,inputs_runtime_plan_unchanged=intact,wall_seconds=time.monotonic()-started,
            CPU_seconds=time.process_time()-CPU,maxRSS_bytes_macos=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss)
        if not intact:report['status']='refused_input_runtime_plan_drift'
        with(output/'assessment.json').open('x')as f:json.dump(report,f,indent=2,allow_nan=False);f.write('\n')
    print(json.dumps({k:report.get(k)for k in ['status','sampled_forward_chord_pass','wall_seconds','CPU_seconds','maxRSS_bytes_macos']}),flush=True)
    return 0 if report['status']=='sampled_mesh_to_BREP_passed_pending_inverse_and_topology'and report['inputs_runtime_plan_unchanged']else 1
if __name__=='__main__':raise SystemExit(main())
