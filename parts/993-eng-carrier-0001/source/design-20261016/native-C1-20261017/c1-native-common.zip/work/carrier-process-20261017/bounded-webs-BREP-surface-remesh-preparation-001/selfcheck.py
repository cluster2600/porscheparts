"""Source-only equivalence/threshold tests; no scientific or CAD imports."""
import ast
import hashlib
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest

HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('_surface_driver_tests',HERE/'run_meshing.py');driver=importlib.util.module_from_spec(spec);spec.loader.exec_module(driver)
class Checks(unittest.TestCase):
    def test_reversible_sources(self):
        changes=json.loads((HERE/'source-changes.json').read_text())
        for name,row in changes.items():
            text=(HERE/'source'/name).read_text();ast.parse(text)
            for change in reversed(row['replacements']):text=text.replace(change['after'],change['before'])
            self.assertEqual(text,Path(row['original_path']).read_text())
            self.assertEqual(hashlib.sha256(text.encode()).hexdigest(),row['original_sha256'])
    def test_same_surface_settings_and_no_T10(self):
        tree=ast.parse((HERE/'source/gmsh_brep_remesh.py').read_text())
        options={n.args[0].value:n.args[1].value for n in ast.walk(tree)if isinstance(n,ast.Call)and ast.unparse(n.func)=='gmsh.option.setNumber'and isinstance(n.args[1],ast.Constant)}
        self.assertEqual(options,{'General.NumThreads':2,'Mesh.MeshSizeMax':3,'Mesh.MeshSizeFromCurvature':96,'Mesh.Algorithm':6,'Mesh.ElementOrder':1,'Mesh.Smoothing':0,'Mesh.Binary':1})
        calls=[n for n in ast.walk(tree)if isinstance(n,ast.Call)and ast.unparse(n.func)=='gmsh.model.mesh.generate']
        self.assertEqual(len(calls),1);self.assertEqual(calls[0].args[0].value,2)
        self.assertIn("format='brep'",(HERE/'source/gmsh_brep_remesh.py').read_text())
    def test_same_sampling_seed_and_no_old_STL(self):
        s=(HERE/'source/brep_surface_audit.py').read_text()
        for text in ['np.linspace(surface.FirstUParameter(), surface.LastUParameter(), 7)','np.linspace(surface.FirstVParameter(), surface.LastVParameter(), 7)','np.random.RandomState(9931016)','2048','512',"<= .06"]:self.assertIn(text,s)
        self.assertIn("for label, path in [('candidate_STL', candidate)]:",s);self.assertNotIn('original_STL',s)
    def test_all_final_audit_gates_preserved(self):
        s=(HERE/'source/cad_mesh_brep_audit.py').read_text()
        for text in ["'needle_triangles'","found or len(pairs)","inverse['maximum_mm'] > .06","volume_error > .002","bounds_error > .06","> .01","row['triangles'] == 0"]:self.assertIn(text,s)
    def test_original_pure_helpers_byte_equal(self):
        base=HERE.parents[2]/'parts/993-eng-carrier-0001/source/remesh-20261016'
        for n in ['audit.py','remesh.py']:self.assertEqual((HERE/'source'/n).read_bytes(),(base/n).read_bytes())
    def test_binary_count_and_truncation(self):
        with tempfile.TemporaryDirectory()as name:
            import struct
            p=Path(name)/'one.stl';p.write_bytes(bytes(80)+struct.pack('<I',1)+bytes(50));self.assertEqual(driver.binary_count(p),1)
            p.write_bytes(p.read_bytes()[:-1])
            with self.assertRaises(ValueError):driver.binary_count(p)
    def test_input_binding_is_BREP_only(self):
        spec=importlib.util.spec_from_file_location('_surface_identity_tests',HERE/'source/gmsh_brep_remesh.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
        with tempfile.TemporaryDirectory()as name:
            p=Path(name)/'id.json';p.write_text(json.dumps(dict(CAD_source=dict(format='brep',sha256='a'*64))))
            self.assertEqual(m.identity_brep_sha256(p),'a'*64)
            p.write_text(json.dumps(dict(geometry_sha256={'carrier.step':'a'*64})))
            with self.assertRaises(ValueError):m.identity_brep_sha256(p)
if __name__=='__main__':unittest.main()
