"""One global mesh of the closed native BREP master; no FEA or STEP alias."""
import faulthandler
import hashlib
import importlib.util
import json
from pathlib import Path
import resource
import shutil
import signal
import sys
import time
import traceback

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[2]

def sha(path):
    digest=hashlib.sha256()
    with Path(path).open('rb')as stream:
        for block in iter(lambda:stream.read(1024*1024),b''):digest.update(block)
    return digest.hexdigest()

def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module

def write(path,value):
    with Path(path).open('x')as stream:json.dump(value,stream,indent=2,allow_nan=False);stream.write('\n')

def run():
    faulthandler.enable(all_threads=True);started=time.monotonic()
    plan=json.loads((HERE/'plan.json').read_text())
    before={name:sha(ROOT/name)for name in plan['files_sha256']};assert before==plan['files_sha256']
    output=ROOT/plan['output_directory'];assert not output.exists()and not output.is_symlink();output.mkdir()
    signal.signal(signal.SIGALRM,lambda *_:(_ for _ in ()).throw(TimeoutError('BREP mesh wall budget')))
    signal.alarm(3500);resource.setrlimit(resource.RLIMIT_CPU,(3400,3420))
    report=dict(schema='native-BREP-global-mesh-diagnostic-1',status='incomplete',sources_before=before,
                source_format='BREP',STEP_exchange_qualified=False,FEA_executed=False,
                candidate_qualified=False,automatic_retry=False,actual_workers=0,threads=1)
    try:
        sys.path.insert(0,str(ROOT/plan['gmsh_site']))
        import numpy as np
        import gmsh
        assert gmsh.__version__=='4.15.2'
        assert 'OCP'not in sys.modules,'This mesher must not load a second OCC kernel via OCP'
        runtime=dict(python=sys.version,numpy=np.__version__,gmsh=gmsh.__version__,
                     gmsh_module=str(Path(gmsh.__file__).resolve()),numpy_module=str(Path(np.__file__).resolve()))
        assert Path(gmsh.__file__).resolve()==(ROOT/plan['gmsh_module']).resolve()
        assert Path(np.__file__).resolve()==(ROOT/plan['numpy_module']).resolve()
        write(output/'runtime-before.json',runtime)
        master=json.loads((HERE/'brep-master.json').read_text())
        containment=json.loads((ROOT/master['native_containment_receipt']).read_text())
        assert containment['strict_native_empty']and containment['actual_child_returncode']==0
        assert master['native_containment_receipt_sha256']==before[master['native_containment_receipt']]
        assert master['native_volume_receipt_sha256']==before[master['native_volume_receipt']]
        volume_authority=json.loads((ROOT/master['native_volume_receipt']).read_text())
        assert master['native_volume_mm3']==volume_authority['native_BREP']['material_solid_volume_mm3']
        assert master['nonadaptive_volume_receipt_sha256']==before[master['nonadaptive_volume_receipt']]
        assert master['nonadaptive_volume_terminal_sha256']==before[master['nonadaptive_volume_terminal']]
        volume_diagnostic=json.loads((ROOT/master['nonadaptive_volume_receipt']).read_text())
        volume_terminal=json.loads((ROOT/master['nonadaptive_volume_terminal']).read_text())
        assert volume_terminal['actual_outer_returncode']==volume_terminal['actual_child_returncode']==0
        assert volume_terminal['direct_child_reaped']and not volume_terminal['final_group_members']
        assert not volume_terminal['timeout']and not volume_terminal['interrupted']
        assert volume_terminal['sources_and_plan_unchanged']and volume_terminal['fresh_postcollection_pins_equal']
        assert volume_terminal['assessment_sha256']==master['nonadaptive_volume_receipt_sha256']
        assert volume_diagnostic['one_reloaded_valid_native_Solid']and volume_diagnostic['same_Solid_native_identity']
        assert volume_diagnostic['sources_unchanged']and volume_diagnostic['Gmsh_imported']is False
        nonadaptive=volume_diagnostic['methods'][0];adaptive=volume_diagnostic['methods'][2]
        assert nonadaptive['method']=='Gmsh_boolean_F_F_F'and nonadaptive['arguments']==[False,False,False]
        assert master['nonadaptive_import_volume_operator']['arguments']==nonadaptive['arguments']
        assert master['nonadaptive_import_volume_mm3']==nonadaptive['signed_mass_mm3']
        assert master['native_volume_operator']['arguments']==adaptive['arguments']==[1e-10,True,False]
        assert master['native_volume_mm3']==adaptive['signed_mass_mm3']
        assert master['CAD_source_format']=='BREP'and master['BREP_sha256']==sha(ROOT/plan['BREP'])
        case=output/'cad-BREP-master';case.mkdir()
        for name,source in [('carrier.brep',ROOT/plan['BREP']),('study.json',ROOT/plan['study']),('brep-master.json',HERE/'brep-master.json')]:
            with source.open('rb')as src,(case/name).open('xb')as dst:shutil.copyfileobj(src,dst,1024*1024)
            assert sha(case/name)==sha(source)
        mesh_module=load('_single_private_BREP_mesher',HERE/'mesh_brep.py')
        roster_module=load('_actual_BREP_group_rosters',HERE/'rosters.py')
        mesh_folder=mesh_module.mesh(case,7)
        metadata=json.loads((mesh_folder/'mesh.json').read_text())
        assert metadata['CAD_source_format']=='BREP'and 'STEP_sha256'not in metadata
        assert metadata['nodes']<=plan['maximum_nodes']and metadata['C3D10_elements']<=plan['maximum_elements']
        rosters={}
        with np.load(mesh_folder/'mesh.npz',allow_pickle=False)as new,np.load(ROOT/plan['EF7_npz'],allow_pickle=False)as old:
            for name in ['bolt0','bolt1','bolt2','bolt3','end0','end1']:
                newids=new[name].astype(int);oldids=old[name].astype(int)
                ni=np.searchsorted(new['tags'],newids);oi=np.searchsorted(old['tags'],oldids)
                assert np.array_equal(new['tags'][ni],newids)and np.array_equal(old['tags'][oi],oldids)
                rosters[name]=roster_module.compare_roster(newids.tolist(),new['xyz'][ni].tolist(),oldids.tolist(),old['xyz'][oi].tolist())
        write(output/'six-group-rosters-vs-EF7.json',rosters)
        report.update(status='native_BREP_mesh_completed',mesh_metadata=metadata,
                      BREP_import=json.loads((mesh_folder/'BREP-import.json').read_text()),
                      quality=json.loads((mesh_folder/'quality.json').read_text()),
                      six_actual_groups=list(rosters),groups_identity_claim=False,
                      roster_summary={name:{key:row[key]for key in ['new_count','EF7_count','node_tag_roster_identical','exact_XYZ_bitset_identical','shared_tag_count','exact_XYZ_shared_count']}for name,row in rosters.items()})
        assert 'OCP'not in sys.modules
        runtime_after=dict(python=sys.version,numpy=np.__version__,gmsh=gmsh.__version__,
                           gmsh_module=str(Path(gmsh.__file__).resolve()),numpy_module=str(Path(np.__file__).resolve()))
        assert runtime_after==runtime
        write(output/'runtime-after.json',runtime_after)
    except BaseException as error:
        report['failure']=dict(type=type(error).__name__,message=str(error),traceback=traceback.format_exc())
    finally:
        signal.alarm(0);after={name:sha(ROOT/name)for name in before}
        report.update(sources_after=after,sources_unchanged=before==after,elapsed_seconds=time.monotonic()-started,
                      maximum_RSS_bytes_macos=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss)
        if before!=after:report['status']='refused_input_drift'
        report['outputs_sha256']={str(p.relative_to(output)):sha(p)for p in output.rglob('*')if p.is_file()}
        write(output/'assessment.json',report)
    print(json.dumps(dict(status=report['status'],elapsed_seconds=report['elapsed_seconds'],assessment_sha256=sha(output/'assessment.json'))),flush=True)
    return 0 if report['status']=='native_BREP_mesh_completed'and report['sources_unchanged']else 1

if __name__=='__main__':raise SystemExit(run())
