"""Exact roster comparison only: tag changes do not establish material motion."""
import math
import struct

def compare_roster(new_ids,new_xyz,old_ids,old_xyz):
    def check(ids,xyz):
        if len(ids)!=len(xyz)or len(ids)!=len(set(ids)):raise ValueError('Roster IDs/coordinates length or uniqueness')
        if any(type(i)is not int or i<=0 for i in ids):raise ValueError('Positive integer node tags required')
        if any(len(row)!=3 or any(not math.isfinite(float(x))for x in row)for row in xyz):raise ValueError('Finite XYZ rows required')
        return {struct.pack('>3d',*map(float,row))for row in xyz}
    newbits=check(new_ids,new_xyz);oldbits=check(old_ids,old_xyz)
    ns,os=set(new_ids),set(old_ids)
    return dict(new_count=len(new_ids),EF7_count=len(old_ids),node_tag_roster_identical=ns==os,
                exact_XYZ_bitset_identical=newbits==oldbits,new_tags_only=sorted(ns-os),EF7_tags_only=sorted(os-ns),
                shared_tag_count=len(ns&os),exact_XYZ_shared_count=len(newbits&oldbits),
                new_XYZ_only_count=len(newbits-oldbits),EF7_XYZ_only_count=len(oldbits-newbits),
                new_node_tags=new_ids,new_XYZ_hex=[[float(x).hex()for x in row]for row in new_xyz],
                scope='Node tag and exact IEEE coordinate roster differences only; no physical motion or boundary equivalence claim.')
