"""Stdlib-only roster and provenance/scope tests; no NumPy/Gmsh/OCP."""
import ast
import importlib.util
import json
from pathlib import Path
import unittest
HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('rosters',HERE/'rosters.py');rosters=importlib.util.module_from_spec(spec);spec.loader.exec_module(rosters)
class Check(unittest.TestCase):
    def test_renumbered_roster_same_coordinates(self):
        r=rosters.compare_roster([2],[[1.,2.,3.]],[1],[[1.,2.,3.]])
        self.assertFalse(r['node_tag_roster_identical']);self.assertTrue(r['exact_XYZ_bitset_identical'])
    def test_same_tags_changed_coordinates(self):
        r=rosters.compare_roster([1],[[1.,2.,4.]],[1],[[1.,2.,3.]])
        self.assertTrue(r['node_tag_roster_identical']);self.assertFalse(r['exact_XYZ_bitset_identical'])
    def test_signed_zero_is_only_bit_difference(self):
        r=rosters.compare_roster([1],[[-0.,0.,0.]],[1],[[0.,0.,0.]])
        self.assertFalse(r['exact_XYZ_bitset_identical'])
    def test_bad_rosters_refuse(self):
        for ids,xyz in [([1,1],[[0.,0.,0.],[0.,0.,0.]]),([1],[]),([0],[[0.,0.,0.]]),([1],[[float('nan'),0.,0.]]),([1],[[0.,0.]])]:
            with self.assertRaises(ValueError):rosters.compare_roster(ids,xyz,[1],[[0.,0.,0.]])
    def test_master_format_and_real_volume_authority(self):
        m=json.loads((HERE/'brep-master.json').read_text())
        self.assertEqual(m['CAD_source_format'],'BREP');self.assertNotIn('STEP_sha256',m)
        source=json.loads((HERE.parents[2]/m['native_volume_receipt']).read_text())
        self.assertEqual(m['native_volume_mm3'],source['native_BREP']['material_solid_volume_mm3'])
    def test_one_mesh_generate_no_solve(self):
        t=ast.parse((HERE/'mesh_brep.py').read_text());calls=[n for n in ast.walk(t)if isinstance(n,ast.Call)]
        self.assertEqual(sum(isinstance(n.func,ast.Attribute)and n.func.attr=='generate'for n in calls),1)
        self.assertEqual(sum(isinstance(n.func,ast.Attribute)and n.func.attr=='getMass'for n in calls),1)
        self.assertNotIn('STEP_sha256',(HERE/'mesh_brep.py').read_text())
        t=ast.parse((HERE/'run.py').read_text())
        self.assertFalse(any(isinstance(n,ast.Attribute)and n.attr=='solve'for n in ast.walk(t)))
        self.assertFalse(any(isinstance(n,ast.ImportFrom)and n.module and n.module.startswith('OCP')for n in ast.walk(t)))
    def test_settings_and_BC_original_constants(self):
        text=(HERE/'mesh_brep.py').read_text()
        for line in ["gmsh.option.setNumber('Mesh.MeshSizeMin', 2)","gmsh.option.setNumber('Mesh.MeshSizeMax', 8)","gmsh.option.setNumber('Mesh.MeshSizeFromCurvature', 18)","gmsh.option.setNumber('Mesh.MeshSizeFactor', size/8)","gmsh.option.setNumber('Mesh.ElementOrder', 2)","gmsh.option.setNumber('Mesh.SecondOrderLinear', 1)","assert min(map(len, groups.values())) >= 12"]:
            self.assertIn(line,text)
        self.assertIn("'historical_relative_guard': 1e-8",text)
if __name__=='__main__':unittest.main()
