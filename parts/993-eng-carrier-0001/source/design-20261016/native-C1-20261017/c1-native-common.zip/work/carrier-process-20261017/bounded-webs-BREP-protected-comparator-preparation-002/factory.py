"""Private native-BREP input adapter; preserve both complete original comparators."""
import hashlib
import importlib.util
import json
from pathlib import Path
from types import SimpleNamespace

HERE=Path(__file__).resolve().parent
MASTER='a42e6942722957076410d4a89b24f9bd0f11677dfa8319103d6733a0db8a1cf9'
STL='577f0e319722ff785099d5b3d29862fac883937d0ea1441f6e5759398c7d418d'
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def verify(plan):
    for path,digest in plan['files_sha256'].items():
        p=Path(path)
        if not p.is_file()or p.is_symlink()or sha(p)!=digest:raise ValueError('Frozen comparator input changed: '+str(p))
def validate_binding(plan,terminal):
    source=plan['CAD_source']
    if source['format']!='brep'or source['sha256']!=MASTER or source['filename']!='candidate-native.brep' or plan['STL_sha256']!=STL:
        raise ValueError('Wrong native BREP/STL identity')
    if (terminal['status']!='native_BREP_strict_native_empty_pass'or terminal['strict_native_empty']is not True or
        terminal['actual_outer_returncode']!=0 or terminal['actual_child_returncode']!=0 or
        terminal['sources_and_plan_unchanged']is not True or terminal['fresh_postcollection_pins_equal']is not True or
        terminal['master_source']!={'format':'BREP','path':source['original_master_path'],'sha256':MASTER}):
        raise ValueError('Native BREP containment receipt is not the closed actual result')
def fresh_case(folder,plan):
    folder=Path(folder)
    for name in ['inspection.json','inspection-source.py','protected-interfaces.json','carrier-normalized.stl','bracket-intersection.stl']:
        p=folder/name
        if p.exists()or p.is_symlink():raise FileExistsError('Preserve prior comparator output: '+name)
    case_inputs(folder,plan)
def case_inputs(folder,plan):
    folder=Path(folder)
    for name,digest in [('candidate-native.brep',MASTER),('carrier.stl',STL),('study.json',plan['study_sha256'])]:
        p=folder/name
        if not p.is_file()or p.is_symlink()or sha(p)!=digest:raise ValueError('Fresh case input differs: '+name)
def _load(name,path,injected=None):
    spec=importlib.util.spec_from_file_location(name,path);module=importlib.util.module_from_spec(spec)
    module.__dict__.update(injected or {});spec.loader.exec_module(module);return module
def load(plan_path):
    """Loading imports the scientific runtime; call only inside a reviewed bounded caller."""
    plan_path=Path(plan_path);plan_sha=sha(plan_path);plan=json.loads(plan_path.read_text());verify(plan)
    terminal=json.loads(Path(plan['containment_terminal']).read_text());validate_binding(plan,terminal)
    corrected=_load('_BREP_comparator_corrected_private',plan['corrected_cad_source'])
    producer=dict(adapter_source_sha256=sha(__file__),adapter_plan_sha256=plan_sha,
        comparator_sources_sha256={n:sha(HERE/'source'/n)for n in ['inspect_candidate_brep.py','inspect_protected_brep.py']},
        historical_sources_sha256=plan['historical_sources_sha256'],scope='Native BREP input; complete original comparison maths, zones and thresholds.')
    injected=dict(_corrected=corrected,_CAD_SOURCE=plan['CAD_source'],_PRODUCER=producer)
    candidate=_load('_BREP_candidate_comparator_private',HERE/'source/inspect_candidate_brep.py',injected)
    protected=_load('_BREP_protected_comparator_private',HERE/'source/inspect_protected_brep.py',dict(injected,
        _candidate=candidate,_original_source_directory=Path(plan['original_protected_source']).parent))
    def check(folder):
        verify(plan);fresh_case(folder,plan)
        if sha(plan_path)!=plan_sha:raise ValueError('Comparator plan changed')
        try:return protected.check(folder)
        finally:
            verify(plan);case_inputs(folder,plan)
            if sha(plan_path)!=plan_sha:raise ValueError('Comparator plan changed')
    return SimpleNamespace(check=check,provenance=producer)
