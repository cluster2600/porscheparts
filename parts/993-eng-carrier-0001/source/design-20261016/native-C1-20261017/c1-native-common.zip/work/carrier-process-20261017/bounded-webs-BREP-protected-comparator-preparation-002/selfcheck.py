"""Literal/AST preservation and input refusals; no scientific imports or native calls."""
import ast
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest

HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('_BREP_comparator_checks',HERE/'factory.py')
factory=importlib.util.module_from_spec(spec);spec.loader.exec_module(factory)
class Checks(unittest.TestCase):
    def setUp(self):
        self.plan=dict(CAD_source=dict(format='brep',sha256=factory.MASTER,filename='candidate-native.brep',original_master_path='master'),STL_sha256=factory.STL)
        self.terminal=dict(status='native_BREP_strict_native_empty_pass',strict_native_empty=True,actual_outer_returncode=0,actual_child_returncode=0,
            sources_and_plan_unchanged=True,fresh_postcollection_pins_equal=True,master_source=dict(format='BREP',path='master',sha256=factory.MASTER))
    def test_closed_binding(self):factory.validate_binding(self.plan,self.terminal)
    def test_wrong_BREP_or_STL(self):
        for key in ['format','sha256','filename']:
            p=copy.deepcopy(self.plan);p['CAD_source'][key]='wrong'
            with self.assertRaises(ValueError):factory.validate_binding(p,self.terminal)
        p=copy.deepcopy(self.plan);p['STL_sha256']='wrong'
        with self.assertRaises(ValueError):factory.validate_binding(p,self.terminal)
    def test_nonempty_nonterminal_or_wrong_master_refused(self):
        for key in ['strict_native_empty','sources_and_plan_unchanged','fresh_postcollection_pins_equal']:
            t=copy.deepcopy(self.terminal);t[key]=False
            with self.assertRaises(ValueError):factory.validate_binding(self.plan,t)
        for key in ['actual_outer_returncode','actual_child_returncode']:
            t=copy.deepcopy(self.terminal);t[key]=1
            with self.assertRaises(ValueError):factory.validate_binding(self.plan,t)
        t=copy.deepcopy(self.terminal);t['master_source']['path']='other'
        with self.assertRaises(ValueError):factory.validate_binding(self.plan,t)
    def test_exact_literal_delta_only(self):
        changes=json.loads((HERE/'source-changes.json').read_text())
        for name,row in changes.items():
            original=Path(row['original_path']).read_text();adapted=(HERE/'source'/name).read_text();restored=adapted
            self.assertEqual(hashlib.sha256(original.encode()).hexdigest(),row['original_sha256'])
            for delta in reversed(row['replacements']):
                self.assertEqual(restored.count(delta['after']),1);restored=restored.replace(delta['after'],delta['before'])
            self.assertEqual(restored,original);ast.parse(adapted)
    def test_math_helpers_byte_AST_unchanged(self):
        changes=json.loads((HERE/'source-changes.json').read_text());row=changes['inspect_candidate_brep.py']
        def functions(text):return {n.name:ast.dump(n,include_attributes=False)for n in ast.parse(text).body if isinstance(n,ast.FunctionDef)}
        a=functions(Path(row['original_path']).read_text());b=functions((HERE/'source/inspect_candidate_brep.py').read_text())
        for name in ['intersection_volume','normalized_mesh']:self.assertEqual(a[name],b[name])
    def test_existing_and_dangling_outputs_refused(self):
        with tempfile.TemporaryDirectory()as name:
            folder=Path(name);p=folder/'protected-interfaces.json';p.write_text('old')
            with self.assertRaises(FileExistsError):factory.fresh_case(folder,self.plan)
            p.unlink();p.symlink_to(folder/'missing')
            with self.assertRaises(FileExistsError):factory.fresh_case(folder,self.plan)
    def test_missing_case_inputs_and_tampered_pins_refused(self):
        with tempfile.TemporaryDirectory()as name:
            folder=Path(name)
            with self.assertRaises(ValueError):factory.case_inputs(folder,dict(self.plan,study_sha256='x'))
            p=folder/'source';p.write_text('a');plan=dict(files_sha256={str(p):factory.sha(p)})
            factory.verify(plan);p.write_text('b')
            with self.assertRaises(ValueError):factory.verify(plan)
    def test_all_original_thresholds_and_zones_retained(self):
        source=(HERE/'source/inspect_candidate_brep.py').read_text()
        for literal in ['collision_volume<=1e-5','max(preserved.values())<=1e-5',"x['intersection_mm3']<=1e-6",'Cylinder(7,46','Cylinder(15.999,.2','Cylinder(1,12)','np.arange(64)','np.linspace(-15.9,3.9,17)']:
            self.assertIn(literal,source)
        self.assertIn('Box(130, 72, 8)',(HERE/'source/inspect_protected_brep.py').read_text())
    def test_factory_only_changes_reviewed_surface_identity(self):
        old=HERE.parent/'bounded-webs-BREP-protected-comparator-preparation-001'
        before=(old/'factory.py').read_text();after=(HERE/'factory.py').read_text()
        self.assertEqual(after.replace(factory.STL,'9f816e28300396bb074f7cd5587fc277bb27410074f0efced32dbce9ab867e1e'),before)
        for name in ['inspect_candidate_brep.py','inspect_protected_brep.py']:
            self.assertEqual((HERE/'source'/name).read_bytes(),(old/'source'/name).read_bytes())
    def test_current_ceiling_does_not_override_legacy_flag(self):
        m=factory._load('_BREP_bounded_caller_tests',HERE/'run.py')
        report=dict(checker_returned=True,actual_inspection=dict(nominal_mass_kg=1.2624,mass_ceiling_pass=False,study_assembly_screen_pass=True))
        self.assertTrue(m.measured_flags(report));self.assertIs(report['legacy_mass_flag_retained_without_override'],False)
        report['actual_inspection']['nominal_mass_kg']=1.3000001;self.assertFalse(m.measured_flags(report))
        report['actual_inspection']['nominal_mass_kg']=1.2;report['checker_returned']=False;self.assertFalse(m.measured_flags(report))
    def test_all_resources_are_fixed_before_scientific_import(self):
        m=factory._load('_BREP_bounded_caller_resources_tests',HERE/'run.py')
        plan=dict(schema='wrong',CAD_source={},STL_sha256='wrong')
        with self.assertRaises(ValueError):m.verify(plan)
        tree=ast.parse((HERE/'run.py').read_text());calls=[ast.unparse(n.func)for n in ast.walk(tree)if isinstance(n,ast.Call)]
        self.assertEqual(calls.count('checker.check'),1);self.assertNotIn('export_step',calls);self.assertNotIn('gmsh.model.mesh.generate',calls)
if __name__=='__main__':unittest.main()
