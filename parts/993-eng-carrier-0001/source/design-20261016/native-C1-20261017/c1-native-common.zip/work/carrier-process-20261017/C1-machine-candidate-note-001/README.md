# Candidat machine pour la révision native C1

Le format NXG XII 600 est un candidat LPBF documenté chez Nikon : volume600×600×600mm, et la page titane liste Ti6Al4V ELI Grade23 ainsi que cette famille de machines. Ce relevé ne désigne aucun prestataire et ne contient aucun jeu de paramètres laser.

La pose à45° autour de Z est déjà celle du build_pyslm.py gelé. Sans changer la géométrie ou sa pose, tourner les huit coins de sa boîte CAO complète donne une enveloppe conservatrice du corps de[470.226, 470.226, 52.0]mm. Le contrôle des supports complets de la nouvelle révision reste à produire ; aucun ancien rapport LPBF ne lui est attribué.

Sources officielles : [dimensions Nikon](https://ngpd.nikon.com/material-processing/product/slm-solutions/) et [titane Nikon](https://nikon-slm-solutions.com/materials/titanium/), consultées le17octobre2026. Le JSON conserve les autorités et la méthode du seul calcul de boîte.
