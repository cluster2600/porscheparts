"""Declare a private provenance-only adaptation of the retained BREP T10 caller."""
import ast,difflib,hashlib,json,os
from pathlib import Path
H=Path(__file__).resolve().parent;R=H.parents[2];OLD=R/'work/carrier-process-20261017/bounded-webs-BREP-mesh-preparation-002'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
for n in ['mesh_brep.py','rosters.py']:(H/n).write_bytes((OLD/n).read_bytes())
helpers='''def verify_master(master,before,plan):
    assert master['CAD_source_format']=='BREP'and master['BREP_sha256']==before[plan['BREP']]
    for pathkey,hashkey in [('native_containment_receipt','native_containment_receipt_sha256'),('native_containment_root','native_containment_root_sha256'),('native_volume_receipt','native_volume_receipt_sha256'),('nonadaptive_volume_receipt','nonadaptive_volume_receipt_sha256'),('nonadaptive_volume_terminal','nonadaptive_volume_terminal_sha256'),('profile_root_review','profile_root_review_sha256')]:
        assert before[master[pathkey]]==master[hashkey]==sha(ROOT/master[pathkey])
    containment=json.loads((ROOT/master['native_containment_receipt']).read_text());cr=json.loads((ROOT/master['native_containment_root']).read_text());residue=json.loads((ROOT/master['native_containment_residue']).read_text())
    assert containment['actual_tool_and_child_returncode']==0 and containment['direct_child_reaped']and containment['owned_group_empty']and not containment['timeout']and containment['cleanup_error']is None
    assert cr['actual_tool_RC']==0 and cr['terminal_sha256']==master['native_containment_receipt_sha256']and cr['raw_candidate_BREP_sha256']==master['BREP_sha256']
    assert cr['residue_sha256']==before[master['native_containment_residue']]==sha(ROOT/master['native_containment_residue'])and residue['native_valid']and residue['native_topologically_empty']and not any(residue['counts'].values())and residue['bounds_mm']is None
    measured=json.loads((ROOT/master['native_volume_receipt']).read_text());terminal=json.loads((ROOT/master['nonadaptive_volume_terminal']).read_text());root=json.loads((ROOT/master['profile_root_review']).read_text())
    assert root['actual_tool_RC']==0 and root['terminal_sha256']==master['nonadaptive_volume_terminal_sha256']and root['volume_methods_sha256']==master['native_volume_receipt_sha256']and root['all3_original_evaluate_overloads_same_Solid']and root['actual_binary64_hexes_verified']
    assert root['data_sha256']==before[master['profile_data']]==sha(ROOT/master['profile_data'])
    profile=json.loads((ROOT/master['profile_data']).read_text());assert profile['candidate_BREP_sha256']==master['BREP_sha256']and profile['native_volume_methods']==measured
    assert terminal['actual_tool_returncode']==terminal['actual_child_returncode']==0 and terminal['direct_child_reaped']and terminal['final_group_members']==[]and terminal['cleanup_error']is None and not terminal['timeout']
    assert terminal['native_volume_methods']==measured and measured['same_native_Solid_identity_before_after']and measured['same_Solid_passed_to_all_three_unchanged_calls']and measured['adaptive_exact_binary64_equal_to_closed_reference']
    assert measured['Gmsh_imported']is False and measured['Gmsh_getMass_mm3']is None and measured['new_T10_mesh_executed']is False
    assert master['nonadaptive_volume_receipt']==master['native_volume_receipt']and master['nonadaptive_volume_receipt_sha256']==master['native_volume_receipt_sha256']
    nonadaptive,closed,adaptive=measured['methods']
    assert nonadaptive['method']=='Gmsh_boolean_F_F_F'and nonadaptive['arguments']==master['nonadaptive_import_volume_operator']['arguments']==[False,False,False]
    assert closed['arguments']==[True,False,False]and adaptive['arguments']==master['native_volume_operator']['arguments']==[1e-10,True,False]
    assert master['nonadaptive_import_volume_mm3']==nonadaptive['signed_mass_mm3']==root['actual_boolean_F_F_F_volume_mm3']
    assert master['native_volume_mm3']==adaptive['signed_mass_mm3']==root['actual_adaptive_volume_mm3']
    assert all(row['mass_binary64_hex']==row['signed_mass_mm3'].hex()for row in measured['methods'])
    assert master['candidate_qualified']is False and master['law_original_RC1_preserved']is True
    return measured

def verify(ready=False):
    plan=json.loads((HERE/'plan.json'if ready else HERE/'pending-plan.json').read_text())
    if ready:assert plan['launch_ready']is True and plan['root_GO_sha256']is not None and sha(ROOT/plan['root_GO'])==plan['root_GO_sha256'],'NOT ARMED: ROOT GO required'
    assert plan['outer_wall_seconds']==3600 and plan['inner_wall_seconds']==3500 and plan['CPU_seconds']==3400 and plan['CPU_hard_seconds']==3420 and plan['threads']==1 and plan['actual_workers']==0
    before={name:sha(ROOT/name)for name in plan['files_sha256']};assert before==plan['files_sha256']
    out=ROOT/plan['output_directory'];assert not out.exists()and not any(p.is_symlink()for p in [out,*out.parents])
    if not ready:assert not(ROOT/plan['execution_directory']).exists()
    verify_master(json.loads((HERE/'brep-master.json').read_text()),before,plan)
    return plan,before

'''
text=(OLD/'run.py').read_text();start=text.index("        master=json.loads((HERE/'brep-master.json').read_text())");stop=text.index("        case=output/'cad-BREP-master'",start);block=text[start:stop]
changes=[('"""One global mesh of the closed native BREP master; no FEA or STEP alias."""','"""Preserved terminal taper: one BREP T10 diagnostic; law RC1 and downstream pending."""'),('def run():',helpers+'def run():'),("    plan=json.loads((HERE/'plan.json').read_text())\n    before={name:sha(ROOT/name)for name in plan['files_sha256']};assert before==plan['files_sha256']","    plan,before=verify(True)"),(block,"        master=json.loads((HERE/'brep-master.json').read_text());verify_master(master,before,plan)\n"),("                candidate_qualified=False,automatic_retry=False,actual_workers=0,threads=1)","                candidate_qualified=False,automatic_retry=False,actual_workers=0,threads=1,original_law_RC1_preserved=True,protected_interfaces_pending=True,method='new_preserved_taper_same_operator_import_volume_T10_1')")]
for before,after in changes:assert text.count(before)==1;text=text.replace(before,after,1)
(H/'run.py').write_text(text);inverse=text
for before,after in reversed(changes):assert inverse.count(after)==1;inverse=inverse.replace(after,before,1)
assert inverse==(OLD/'run.py').read_text()
(H/'run-from-BREP-mesh002.diff').write_text(''.join(difflib.unified_diff((OLD/'run.py').read_text().splitlines(True),text.splitlines(True),fromfile='BREP-mesh002/run.py',tofile='preserved-taper/run.py')))
(H/'source-changes.json').write_text(json.dumps(dict(original_directory=str(OLD.relative_to(R)),original_run_sha256=sha(OLD/'run.py'),new_run_sha256=sha(H/'run.py'),replacements=[dict(before=a,after=b)for a,b in changes],full_inverse_equal=True,unchanged={n:sha(H/n)for n in ['mesh_brep.py','rosters.py']}),indent=2)+'\n')
print(json.dumps(dict(source_sha256=sha(H/'run.py'),mesh_byte_exact=sha(H/'mesh_brep.py'),rosters_byte_exact=sha(H/'rosters.py'),full_inverse_equal=True)))
