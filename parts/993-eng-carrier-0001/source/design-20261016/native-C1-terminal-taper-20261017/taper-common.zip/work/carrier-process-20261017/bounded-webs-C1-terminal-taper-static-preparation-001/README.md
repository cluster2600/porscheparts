# Preserved taper: two pending linear static diagnostic cases

This is source-only preparation. No new deck, Docker operation, solver, energy
calculation or peak localization has run here. Both cases use the actual newly
closed size-7 T10 mesh of the preserved raw taper, with its actual node/element
identities and fresh end rosters. The candidate remains unqualified and retains
the original post-Build law refusal.

The rigid case fixes the new end-eye rosters. The spring case uses K1000 TOTAL
per eye and per axis, divided by that eye's actual node count: 2274 and 2278.
No old tag roster, stress, displacement or FEA result is transferred. Original
material E=107000 MPa, nu=0.31, Fz=-4000 N and My=+850000 Nmm remain unchanged.
The original solve, serialized load checks, independent energy closure (1e-4),
Gauss-point localization and all global maxima/ties are retained. Serialization
last-bit refusals remain refusals if reached; no loads are fed back or adjusted.

The new imported-volume observation is explicitly versioned. Old C1's exact
observed ratio 0 is retained in its original files; this candidate's actual
closed observation is -7.771561172376096e-16, from Gmsh volume
285603.1567960073 mm³ against same-operator native F/F/F reference
285603.15679600753 mm³. The unchanged strict 1e-8 import criterion is checked
again, along with the actual import options. The separate adaptive native
reference is 285602.88227244973 mm³. This observation binding does not assert
an absence of import healing or a new qualification.

The actual new protected-interface comparator and its ROOT closure are now
SHA-bound, including its complete inspection and protected-interface reports.
The earlier preclosure pending plans are preserved under history. The original
full checker and its criteria remain; no old STEP/C1 pass substitutes for the
new proof. Plans remain unarmed and refuse before any scientific calculation.
T10 and protected ROOT evidence join their actual terminals and supervision.

Each future case retains the original owned Docker helper: one CPU, 6 GiB RAM,
no extra swap, no network, 1800 s per-case budget with a 60 s cleanup reserve
and solver cap 1680 s. Output and container names are distinct and fresh.
Deck preparation and solver execution require separate reviewed commands and
ROOT GO. There is no automatic retry and no strength allowable, convergence
criterion or manufacturing release is introduced by this preparation.
