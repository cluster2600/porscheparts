"""NON-ARMED original C1 taper prototype; final geometry and strength remain pending."""
import importlib.util,json,math,os,resource,signal,sys,time,traceback
from pathlib import Path
from types import SimpleNamespace
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[2]
def load(name,path):
    s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
GATE=load('_retained_endfillet_geometry_gates',HERE.with_name('bounded-webs-C1-endfillet-preparation-002')/'close_end.py')
LAW=load('_retained_closed_terminal_law',HERE.with_name('bounded-webs-C1-terminal-law-observation-preparation-001')/'observe_law.py')
require,sha,write=GATE.require,GATE.sha,GATE.write
IDS=LAW.IDS
def validate_laws(rows,observed,physical,zero):
    LAW.other_six(rows);r=rows[0];old=observed['simulated_laws'][0]
    keys=['native_law_bounds','native_degree','native_poles','native_knots','native_multiplicities','native_rational','native_periodic']
    require('unavailable_reason'not in r and r.get('is_constant')is False and all(r.get(k)==old[k]for k in keys),'Post-Build target law differs from the closed physical-interval law')
    require(rows[1:]==observed['simulated_laws'][1:],'Other six complete native law records changed')
    result=LAW.proof(r['native_poles'],r['native_knots'],r['native_multiplicities'],r['native_degree'],physical,zero)
    require(result==observed['attached_exact_law_proof'],'Exact physical-interval coefficient proof differs');return result
def verify(path,expected,native=False):
    require(sha(path)==expected,'Plan hash differs');p=json.loads(Path(path).read_text())
    if native:require(p['launch_ready']is True,'NON-ARMED: ROOT review and GO required')
    require(p['schema']=='original-C1-scalar-terminal-taper-prototype-1'and p['contour']==IDS and p['zero_vertex']==302 and p['terminal_edge']==431,'Original one-terminal scope required')
    require(p['bounds']==dict(outer=180,inner=150,CPU=[140,141],threads=1,workers=0),'Reviewed prototype bounds differ')
    require(p['files_sha256'][p['baseline_STEP']]==GATE.BASELINE,'Unchanged original baseline required')
    before={k:sha(ROOT/k)for k in p['files_sha256']};require(before==p['files_sha256'],'Pinned source/input/runtime changed')
    out=ROOT/p['output_directory'];require(not out.exists()and not any(x.is_symlink()for x in [out,*out.parents]),'Fresh nonsymlink output required')
    if not native:require(not(ROOT/p['execution_directory']).exists(),'Fresh supervision required at preflight')
    return p,before,out
def run(path,expected):
    started=time.monotonic();p,before,out=verify(path,expected,True);out.mkdir();code=1
    report=dict(schema='original-C1-scalar-terminal-taper-prototype-1',status='refused_or_incomplete',method='rebuild_original_C1_with_one_native_scalar_zero_endpoint_1',candidate_qualified=False,downstream_checks={k:'PENDING'for k in GATE.PENDING},FEA_executed=False,sources_before=before,outputs_sha256={},no_Simulate=True,no_SetLaw=True,zero_radius_scope='Return of original blend addition to the existing sharp baseline vertex; no smooth-solid or strength claim')
    signal.signal(signal.SIGALRM,lambda *_:(_ for _ in ()).throw(TimeoutError('150s original-C1 taper prototype bound')));signal.alarm(150);resource.setrlimit(resource.RLIMIT_CPU,(140,141))
    events=(out/'events.jsonl').open('x')
    def event(name,**values):events.write(json.dumps(dict(event=name,seconds=time.monotonic()-started,**values),allow_nan=False)+'\n');events.flush();os.fsync(events.fileno())
    try:
        require(os.getpriority(os.PRIO_PROCESS,0)==10,'nice10 child required');sys.path.insert(0,str(ROOT/p['native_site']))
        from build123d import Solid,import_step,export_brep
        from OCP.BRep import BRep_Tool
        from OCP.BRepAdaptor import BRepAdaptor_Curve,BRepAdaptor_Surface
        from OCP.BRepAlgoAPI import BRepAlgoAPI_Cut
        from OCP.BRepBndLib import BRepBndLib
        from OCP.BRepCheck import BRepCheck_Analyzer
        from OCP.BRepFilletAPI import BRepFilletAPI_MakeFillet
        from OCP.BRepGProp import BRepGProp
        from OCP.Bnd import Bnd_Box
        from OCP.GProp import GProp_GProps
        from OCP.OSD import OSD_ThreadPool
        from OCP.TopAbs import TopAbs_SOLID,TopAbs_FACE,TopAbs_EDGE,TopAbs_VERTEX
        from OCP.TopExp import TopExp
        from OCP.TopTools import TopTools_IndexedMapOfShape,TopTools_ListOfShape
        from OCP.TopoDS import TopoDS,TopoDS_Iterator
        OSD_ThreadPool.DefaultPool_s().Init(1)
        old=load('_retained_postfillet4652_unwrap',ROOT/p['postfillet_source']);volume=load('_retained_precise_volume',ROOT/p['volume_source'])
        observed=json.loads((ROOT/p['law_assessment']).read_text());require(observed['status']=='explicit_terminal_law_observed_no_final_Build'and observed['sources_unchanged'],'Closed native law authority required')
        body=import_step(ROOT/p['baseline_STEP']);faces,edges,vertices=list(body.faces()),list(body.edges()),list(body.vertices());require(body.is_valid and len(body.solids())==1 and len(faces)==240 and len(edges)==733,'Actual original baseline topology required')
        prior=json.loads((ROOT/p['contour_diagnostic']).read_text())['initial_contours'][0];require([r['edge_index_zero_based']for r in prior['edges']]==IDS,'Closed original contour differs')
        face_edges=[list(f.edges())for f in faces]
        for row in prior['edges']:
            i=row['edge_index_zero_based'];e=edges[i];curve=BRepAdaptor_Curve(e.wrapped);adj=[j for j,es in enumerate(face_edges)if any(e.wrapped.IsSame(x.wrapped)for x in es)]
            require(e.length==row['length_mm']and str(curve.GetType())==row['curve_type']and[curve.FirstParameter(),curve.LastParameter()]==row['domain']and adj==row['adjacent_faces_zero_based'],'Original contour edge geometry differs')
            actual=sorted(tuple(BRep_Tool.Pnt_s(v.wrapped).Coord())for v in e.vertices());wanted=sorted(tuple(r['point_mm'])for r in row['vertices']);require(actual==wanted,'Original contour endpoint coordinates differ')
        require(edges[431].length==21.430826650472525,'Whole measured original edge431 required')
        builder=BRepFilletAPI_MakeFillet(body.solids()[0].wrapped)
        for i in IDS:builder.Add(1.,edges[i].wrapped)
        def contour_ids():return [next(i for i,e in enumerate(edges)if e.wrapped.IsSame(builder.Edge(1,j)))for j in range(1,builder.NbEdges(1)+1)]
        def endpoint_ids():return [[i for i,v in enumerate(vertices)if v.wrapped.IsSame(x)]for x in [builder.FirstVertex(1),builder.LastVertex(1)]]
        require(builder.NbContours()==1 and contour_ids()==IDS and endpoint_ids()==[[302],[125]],'Only the original complete contour and endpoints are allowed')
        zero=vertices[302].wrapped;require(list(BRep_Tool.Pnt_s(zero).Coord())==[82.202665223312,-14.18196820123,12.756757217282],'Original zero endpoint differs')
        physical=sorted(builder.Abscissa(1,v.wrapped)for v in edges[431].vertices());zero_at=builder.Abscissa(1,zero);require(physical==observed['simulated_laws'][0]['native_law_bounds']and zero_at==0.,'Actual physical edge interval differs from the closed observation')
        report.update(original_contour=IDS,physical_edge431_abscissae_mm=physical,zero_vertex=302,zero_at_native_abscissa_mm=zero_at,baseline_STEP_sha256=sha(ROOT/p['baseline_STEP']),law_assessment_sha256=sha(ROOT/p['law_assessment']))
        builder.SetRadius(0.,1,zero);event('before_unique_scalar_terminal_Build',contour=IDS,zero_vertex=302);builder.Build();event('after_unique_scalar_terminal_Build',IsDone=builder.IsDone())
        report['native_build_status']=dict(IsDone=builder.IsDone(),HasResult=builder.HasResult(),NbFaultyContours=builder.NbFaultyContours(),NbFaultyVertices=builder.NbFaultyVertices(),FaultyVertices_mm=[list(BRep_Tool.Pnt_s(builder.FaultyVertex(k)).Coord())for k in range(1,builder.NbFaultyVertices()+1)],StripeStatus=[str(builder.StripeStatus(i))for i in range(1,builder.NbContours()+1)])
        require(builder.IsDone(),'Original scalar-terminal C1 Build did not complete')
        def children(shape):
            it=TopoDS_Iterator(shape)
            while it.More():yield it.Value();it.Next()
        leaf,structure=old.unwrap_one_solid(builder.Shape(),children);candidate=Solid(TopoDS.Solid_s(leaf));report['native_container_structure']=structure
        require(candidate.is_valid and len(candidate.solids())==1,'Exactly one valid candidate Solid required')
        export_brep(candidate,out/'candidate-native.brep')
        report.update(raw_native_candidate_preserved_before_admission=True,outputs_sha256={'candidate-native.brep':sha(out/'candidate-native.brep')})
        report['stage']='post_Build_law_validation';rows=LAW.read_laws(builder,edges);report['post_Build_laws']=rows;report['exact_post_Build_law_proof']=validate_laws(rows,observed,physical,zero_at)
        require(builder.NbContours()==1 and contour_ids()==IDS and endpoint_ids()==[[302],[125]],'Original contour or opposite endpoint changed')
        report.update(other_six_laws_constant_R1=True,opposite_source_contour_endpoint125_unchanged=True)
        summary=GATE.retain_cut_helpers(ROOT/p['strict_cut_source'],dict(TopTools_IndexedMapOfShape=TopTools_IndexedMapOfShape,TopExp=TopExp,Bnd_Box=Bnd_Box,BRepBndLib=BRepBndLib,TopAbs_SOLID=TopAbs_SOLID,TopAbs_FACE=TopAbs_FACE,TopAbs_EDGE=TopAbs_EDGE,TopAbs_VERTEX=TopAbs_VERTEX,BRepCheck_Analyzer=BRepCheck_Analyzer,volume=volume,SimpleNamespace=SimpleNamespace,TopoDS=TopoDS,BRep_Tool=BRep_Tool,GProp_GProps=GProp_GProps,BRepGProp=BRepGProp,BRepAdaptor_Surface=BRepAdaptor_Surface))
        baseline=import_step(ROOT/p['baseline_STEP']);require(baseline.is_valid and len(baseline.solids())==1 and len(baseline.faces())==240 and len(baseline.edges())==733,'Fresh independent original baseline required for strict Cuts');report['baseline_reimported_independently_after_Build']=True
        cuts={}
        for name,left,right in [('baseline-minus-candidate',baseline,candidate),('candidate-minus-baseline',candidate,baseline)]:
            report['stage']=name;cut=BRepAlgoAPI_Cut();args=TopTools_ListOfShape();tools=TopTools_ListOfShape();args.Append(left.wrapped);tools.Append(right.wrapped);cut.SetArguments(args);cut.SetTools(tools);cut.SetNonDestructive(True);cut.SetRunParallel(False);cut.SetFuzzyValue(0.)
            event('before_strict_Cut',direction=name,NonDestructive=True,RunParallel=False,FuzzyValue=0.);cut.Build();event('after_strict_Cut',direction=name,IsDone=cut.IsDone());require(cut.IsDone(),'Strict native Cut incomplete: '+name)
            cuts[name]=summary(cut.Shape());write(out/(name+'.json'),cuts[name]);report['outputs_sha256'][name+'.json']=sha(out/(name+'.json'));report['strict_Cuts']=cuts
            if name=='baseline-minus-candidate':require(cuts[name]['native_topologically_empty'],'Original baseline material removed: strict Cut nonempty')
        added=cuts['candidate-minus-baseline'];require(not added['native_topologically_empty']and added.get('native_valid')is True and added['material_solid_volume_mm3']>0 and all(r['native_valid']and r['volume_mm3']>0 for r in added.get('solids',[])),'Strict positive valid added material required')
        native_volume,error=volume.precise_volume(candidate);baseline_volume,baseline_error=volume.precise_volume(baseline);require(native_volume>baseline_volume,'Native candidate volume must exceed the baseline')
        study=json.loads((ROOT/p['study']).read_text());mass=native_volume*study['material']['density_tonne_mm3']*1000;box=candidate.bounding_box();bounds=[list(box.min),list(box.max)]
        report.update(GATE.local_gate_flags(cuts['baseline-minus-candidate'],candidate.is_valid,len(candidate.solids()),mass,bounds,p),native_volume_mm3=native_volume,native_volume_estimated_relative_error=error,baseline_volume_mm3=baseline_volume,baseline_volume_estimated_relative_error=baseline_error,delta_from_baseline_volume_mm3=native_volume-baseline_volume,mass_kg=mass,bounds_mm=bounds)
        write(out/'study.json',study);report['outputs_sha256']['study.json']=sha(out/'study.json');report.update(status='original_C1_terminal_taper_local_checks_complete_PENDING_downstream',stage='local_complete',no_Clean_or_shape_healing_called=True,no_STEP_export_or_readback=True);code=0
    except BaseException as error:report['failure']=dict(type=type(error).__name__,message=str(error),traceback=traceback.format_exc())
    finally:
        signal.alarm(0);after={k:sha(ROOT/k)for k in before};report.update(sources_after=after,sources_unchanged=before==after,elapsed_seconds=time.monotonic()-started)
        if before!=after:report['status']='refused_input_drift';code=1
        write(out/'assessment.json',report);event('assessment_written',sha256=sha(out/'assessment.json'));events.close()
    print(json.dumps(dict(status=report['status'],candidate_qualified=False,assessment_sha256=sha(out/'assessment.json'))),flush=True);return code
if __name__=='__main__':
    mode,path,expected=sys.argv[1:]
    if mode=='preflight':p,_,_=verify(path,expected);print(json.dumps(dict(status='stdlib_only_preflight_no_native',armed=p['launch_ready'])))
    elif mode=='run':raise SystemExit(run(path,expected))
    else:raise ValueError('Use preflight or run PLAN SHA')
