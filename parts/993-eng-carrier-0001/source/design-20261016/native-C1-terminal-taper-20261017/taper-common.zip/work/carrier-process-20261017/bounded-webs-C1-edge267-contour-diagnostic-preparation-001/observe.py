"""NON-ARMED native Add-only contour observation: one seed267/R1, never Build."""
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import resource
import signal
import sys
import time
import traceback

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[2]
def require(ok,message):
    if not ok:raise ValueError(message)
def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb')as f:
        for b in iter(lambda:f.read(1024**2),b''):h.update(b)
    return h.hexdigest()
def load(name,path):
    s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
def write(path,value):
    with Path(path).open('x')as f:json.dump(value,f,indent=2,allow_nan=False);f.write('\n');f.flush();os.fsync(f.fileno())
def verify(path,expected,native=False):
    require(sha(path)==expected,'Plan hash differs');p=json.loads(Path(path).read_text())
    if native:require(p['launch_ready']is True,'NON-ARMED: no native observation before ROOT GO')
    require(p['schema']=='C1-edge267-R1-native-Add-only-plan-1'and p['seed_edge']==267 and type(p['radius_mm'])is float and p['radius_mm']==1.,'Only seed267/existing R1 is allowed')
    require(p['bounds']==dict(outer=180,inner=150,CPU=[140,141],threads=1,workers=0),'Observation bounds differ')
    before={k:sha(ROOT/k)for k in p['files_sha256']};require(before==p['files_sha256'],'Pinned input/source/runtime changed')
    out=ROOT/p['output_directory'];require(not out.exists()and not any(q.is_symlink()for q in [out,*out.parents]),'Fresh nonsymlink output required')
    if not native:require(not(ROOT/p['execution_directory']).exists(),'Fresh supervision required at preflight')
    return p,before,out
def contours(builder,record):
    rows=[]
    for ci in range(1,builder.NbContours()+1):
        row=dict(native_contour_one_based=ci,edge_count=builder.NbEdges(ci),IsConstant=bool(builder.IsConstant(ci)),Radius_mm=None,Radius_error=None)
        try:
            radius=float(builder.Radius(ci));require(math.isfinite(radius),'Nonfinite native Radius');row['Radius_mm']=radius
        except Exception as error:row['Radius_error']=dict(type=type(error).__name__,message=str(error))
        row['edges']=[record(builder.Edge(ci,j))for j in range(1,builder.NbEdges(ci)+1)]
        row['edge_indices_in_native_order']=[r['edge_index_zero_based']for r in row['edges']];rows.append(row)
    return rows

def run(plan_path,expected):
    started=time.monotonic();p,before,out=verify(plan_path,expected,True);out.mkdir();code=1
    report=dict(schema='C1-edge267-R1-native-Add-only-observation-1',status='incomplete_observation',candidate_qualified=False,native_Build_called=False,native_Cut_called=False,shape_exported=False,FEA_executed=False,seed_edges=[267],requested_radius_mm=1.,sources_before=before)
    signal.signal(signal.SIGALRM,lambda *_:(_ for _ in ()).throw(TimeoutError('150s native contour observation bound')))
    signal.alarm(150);resource.setrlimit(resource.RLIMIT_CPU,(140,141))
    try:
        require(os.getpriority(os.PRIO_PROCESS,0)==10,'nice10 child required')
        sys.path.insert(0,str(ROOT/p['native_site']))
        from build123d import import_brep
        from OCP.BRep import BRep_Tool
        from OCP.BRepAdaptor import BRepAdaptor_Curve,BRepAdaptor_Surface
        from OCP.BRepFilletAPI import BRepFilletAPI_MakeFillet
        from OCP.OSD import OSD_ThreadPool
        OSD_ThreadPool.DefaultPool_s().Init(1)
        retained=load('_retained_endfillet_scope_only',ROOT/p['prototype_source']);d=json.loads((ROOT/p['diagnostic']).read_text());r=retained.edge_record(d)
        require(sha(ROOT/p['C1_BREP'])==retained.MASTER,'Actual C1 master differs')
        body=import_brep(ROOT/p['C1_BREP']);require(body.is_valid and len(body.solids())==1,'One valid actual C1 Solid required')
        faces,edges=list(body.faces()),list(body.edges());face_edges=[list(f.edges())for f in faces]
        require(len(faces)==d['BREP_faces']and len(edges)==d['BREP_edges'],'Native topology counts differ')
        selected=edges[267];adj=[i for i,items in enumerate(face_edges)if any(selected.wrapped.IsSame(e.wrapped)for e in items)];box=selected.bounding_box()
        require(adj==r['adjacent_faces_zero_based']and selected.length==r['length_mm']and [list(box.min),list(box.max)]==r['bounds_mm'],'Measured seed edge differs')
        require(str(BRep_Tool.Continuity_s(selected.wrapped,faces[60].wrapped,faces[62].wrapped))==r['native_continuity'],'Seed continuity differs')
        for i in adj:
            q=next(f for f in d['probes'][0]['nearest_faces']if f['face_index_zero_based']==i);f=faces[i];box=f.bounding_box()
            require(str(BRepAdaptor_Surface(f.wrapped,True).GetType())==q['surface_type']and str(f.wrapped.Orientation())==q['orientation']and f.area==q['area_mm2']and [list(box.min),list(box.max)]==q['bounds_mm'],'Measured seed face differs')
        builder=BRepFilletAPI_MakeFillet(body.solids()[0].wrapped);builder.Add(1.,selected.wrapped)
        report['stage']='after_only_Add_no_Build'
        def record(edge):
            ids=[i for i,e in enumerate(edges)if e.wrapped.IsSame(edge)];require(len(ids)==1,'Native contour edge must map to exactly one C1 edge')
            i=ids[0];e=edges[i];box=e.bounding_box();adj=[j for j,items in enumerate(face_edges)if any(edge.IsSame(v.wrapped)for v in items)]
            return dict(edge_index_zero_based=i,curve_type=str(BRepAdaptor_Curve(edge).GetType()),length_mm=e.length,bounds_mm=[list(box.min),list(box.max)],native_tolerance_mm=BRep_Tool.Tolerance_s(edge),
                adjacent_faces_zero_based=adj,adjacent_surface_types=[str(BRepAdaptor_Surface(faces[j].wrapped,True).GetType())for j in adj],adjacent_orientations=[str(faces[j].wrapped.Orientation())for j in adj],
                native_continuity=None if len(adj)!=2 else str(BRep_Tool.Continuity_s(edge,faces[adj[0]].wrapped,faces[adj[1]].wrapped)))
        report.update(status='native_Add_R1_contours_observed_without_Build',native_contour_count=builder.NbContours(),contours=contours(builder,record),native_body_faces=len(faces),native_body_edges=len(edges),source_BREP_sha256=sha(ROOT/p['C1_BREP']),selection_prototype_guard_unchanged=True)
        code=0
    except BaseException as error:report['failure']=dict(type=type(error).__name__,message=str(error),traceback=traceback.format_exc())
    finally:
        signal.alarm(0);after={k:sha(ROOT/k)for k in before};report.update(sources_after=after,sources_unchanged=before==after,elapsed_seconds=time.monotonic()-started)
        if before!=after:report['status']='refused_input_drift';code=1
        write(out/'assessment.json',report)
    print(json.dumps(dict(status=report['status'],assessment_sha256=sha(out/'assessment.json'),native_Build_called=False)),flush=True);return code

if __name__=='__main__':
    mode,path,expected=sys.argv[1:]
    if mode=='preflight':p,_,_=verify(path,expected);print(json.dumps(dict(status='source_only_preflight_no_native',armed=p['launch_ready'])))
    elif mode=='run':raise SystemExit(run(path,expected))
    else:raise ValueError('Use preflight or run PLAN SHA')
