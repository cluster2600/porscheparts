"""Collect the actual owned local addition diagnostic; no geometry import or replay."""
import importlib.util,json,time
from pathlib import Path
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[2]
s=importlib.util.spec_from_file_location('_addition_terminal_stdlib',HERE/'measure.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m);sha,write=m.sha,m.write
read=lambda p:json.loads(p.read_text());start=time.monotonic();p=read(HERE/'armed-plan.json');launch=read(HERE/'launch-plan.json');sup=read(HERE/'execution-001/execution-receipt.json');a=read(HERE/'output-001/assessment.json');added=read(HERE/'output-001/candidate-minus-baseline.json')
assert sha(HERE/'launch-plan.json')=='e399d37556680b7d63f24aad7cdf092f0b4643ce34202810213ace0945d93aa6'
assert sup['plan_sha256']==sha(HERE/'launch-plan.json')and sup['command']==launch['command']and sup['actual_returncode']==0 and sup['status']=='executed'
assert sup['direct_child_reaped']and sup['no_non_zombie_group_members']and sup['final_group_members']==[]and sup['cleanup_error']is None and sup['failure']is None and not sup['timeout']and not sup['interrupted']and sup['signals_to_owned_group_only']==[]
pins={**launch['inputs_sha256'],**launch['source_sha256']};assert sup['sources_before']==sup['sources_after']==pins and sup['sources_and_plan_unchanged']and {n:sha(ROOT/n)for n in pins}==pins
assert a['sources_before']==a['sources_after']==p['files_sha256']and a['sources_unchanged']
assert a['status']=='preserved_taper_addition_mass_bounds_local_complete_PENDING_downstream'and a['added_material']==added and a['local_geometry_checks_passed']is True
assert added['native_valid']is True and added['material_solid_volume_mm3']>0 and not added['native_topologically_empty']and all(x['native_valid']and x['volume_mm3']>0 for x in added['solids'])
ks=('retention_assessment','retention_residue','retention_terminal','retention_supervision','retention_plan','retention_launch');retained=m.retention_records(p,*[read(ROOT/p[k])for k in ks]);flags=m.GATE.local_gate_flags(retained,True,1,a['mass_kg'],a['bounds_mm'],p)
assert all(a[k]==v for k,v in flags.items())and a['native_volume_mm3']>a['baseline_volume_mm3']and a['delta_from_baseline_volume_mm3']==a['native_volume_mm3']-a['baseline_volume_mm3']
study=read(HERE/'output-001/study.json');assert study==read(ROOT/p['study'])and a['mass_kg']==a['native_volume_mm3']*study['material']['density_tonne_mm3']*1000
assert a['candidate_qualified']is False and a['law_status']=='original_post_Build_law_RC1_preserved'and all(v=='PENDING'for v in a['downstream_checks'].values())and a['baseline_retention_Cut_repeated']is False and a['new_fillet_Build']is False and a['no_geometry_export']is True
for n,h in sup['logs_sha256'].items():assert sha(HERE/'execution-001'/n)==h
j=[json.loads(x)for x in(HERE/'output-001/events.jsonl').read_text().splitlines()];assert sum(x['event']=='before_one_candidate_minus_baseline_Cut'for x in j)==sum(x['event']=='after_one_candidate_minus_baseline_Cut'for x in j)==1 and j[-1]['sha256']==sha(HERE/'output-001/assessment.json')
files={}
for directory in ('execution-001','output-001'):
 for f in sorted((HERE/directory).iterdir()):assert f.is_file()and not f.is_symlink();files[str(f.relative_to(HERE))]=dict(bytes=f.stat().st_size,sha256=sha(f))
assert len(files)==8
r=dict(schema='owned-preserved-taper-addition-terminal-1',status='actual_owned_RC0_local_addition_mass_bounds_all_outputs_and_pins_verified',collector_source_sha256=sha(__file__),tool_handle=65053,tool_launch_chunk='025176',tool_terminal_chunk='4071f4',own_handle_collected=True,actual_tool_and_child_returncode=0,direct_child_reaped=True,owned_group_empty=True,signals=[],timeout=False,cleanup_error=None,supervision_sha256=sha(HERE/'execution-001/execution-receipt.json'),assessment_sha256=sha(HERE/'output-001/assessment.json'),started_sha256=sha(HERE/'execution-001/started.json'),whole_output_files=files,unique_current_pins=len(pins),all_current_pins_equal=True,retention_semantic_join_recomputed=True,supervised_wall_seconds=sup['elapsed_seconds'],child_wall_seconds=a['elapsed_seconds'],added_material_summary=added,native_candidate_volume_mm3=a['native_volume_mm3'],native_baseline_volume_mm3=a['baseline_volume_mm3'],native_volume_difference_mm3=a['delta_from_baseline_volume_mm3'],distinct_Cut_integral_mm3=added['material_solid_volume_mm3'],mass_kg=a['mass_kg'],bounds_mm=a['bounds_mm'],candidate_qualified=False,original_law_RC1_preserved=True,downstream_checks=a['downstream_checks'],no_repeated_retention_new_fillet_or_export=True,elapsed_collection_seconds=time.monotonic()-start)
write(HERE/'terminal-collection-001.json',r);print(json.dumps(dict(terminal_sha256=sha(HERE/'terminal-collection-001.json'),assessment_sha256=r['assessment_sha256'],supervision_sha256=r['supervision_sha256'],files=len(files),current_pins=len(pins))))
