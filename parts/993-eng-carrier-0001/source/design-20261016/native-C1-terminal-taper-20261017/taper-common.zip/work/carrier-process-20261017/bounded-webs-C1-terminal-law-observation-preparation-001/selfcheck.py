"""Small stdlib checks; no OCP import, native geometry or simulation."""
import ast,copy,hashlib,importlib.util,json,math,os,tempfile,time,unittest
from pathlib import Path
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[2]
spec=importlib.util.spec_from_file_location('_terminal_law_stdlib',HERE/'observe_law.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
class Checks(unittest.TestCase):
    def args(self):return [[0.,0.,1.,1.],[0.,21.430826650472525],[4,4],3,[0.,21.430826650472525],0.]
    def test_forward(self):self.assertEqual(m.proof(*self.args())['normalized_polynomial'],'3*t^2-2*t^3')
    def test_reverse(self):
        x=self.args();x[0]=[1.,1.,0.,0.];x[-1]=x[1][1];self.assertEqual(m.proof(*x)['normalized_polynomial'],'1-3*t^2+2*t^3')
    def test_foreign_poles(self):
        x=self.args();x[0][1]=.1
        with self.assertRaises(ValueError):m.proof(*x)
    def test_five_pole_extension_refused(self):
        x=self.args();x[0]=[0.,0.,-11.8,1.,1.]
        with self.assertRaises(ValueError):m.proof(*x)
    def test_foreign_bounds(self):
        x=self.args();x[1]=[0.,22.]
        with self.assertRaises(ValueError):m.proof(*x)
    def test_nonendpoint_zero(self):
        x=self.args();x[-1]=1.
        with self.assertRaises(ValueError):m.proof(*x)
    def test_invalid_knots(self):
        for v in [[0.,0.],[1.,0.],[0.,math.inf]]:
            x=self.args();x[1]=x[4]=v
            with self.assertRaises(ValueError):m.proof(*x)
    def test_mults_degree(self):
        for index,value in [(2,[3,4]),(3,True),(3,2)]:
            x=self.args();x[index]=value
            with self.assertRaises(ValueError):m.proof(*x)
    def test_other_six_drift(self):
        rows=[dict(edge_index_zero_based=i,is_constant=True,constant_radius_mm=1.)for i in m.IDS];m.other_six(rows);rows[1]['constant_radius_mm']=.9
        with self.assertRaises(ValueError):m.other_six(rows)
    def test_other_six_missing(self):
        with self.assertRaises(ValueError):m.other_six([])
    def test_nonarmed_before_science(self):
        with tempfile.TemporaryDirectory()as d:
            p=Path(d)/'plan.json';p.write_text(json.dumps(dict(launch_ready=False)))
            with self.assertRaisesRegex(ValueError,'NON-ARMED'):m.verify(p,m.sha(p),True)
    def test_single_Simulate_no_final_operations(self):
        tree=ast.parse((HERE/'observe_law.py').read_text());names=[n.func.attr for n in ast.walk(tree)if isinstance(n,ast.Call)and isinstance(n.func,ast.Attribute)]
        self.assertEqual(names.count('Simulate'),1);self.assertEqual(names.count('SetLaw'),1)
        self.assertFalse(set(names)&{'Build','Shape','Cut','Fuse','export_brep','export_step','export_stl'})
        calls=[n for n in ast.walk(tree)if isinstance(n,ast.Call)and isinstance(n.func,ast.Attribute)and n.func.attr=='SetRadius'];self.assertEqual(len(calls),1);self.assertIsInstance(calls[0].args[0],ast.Constant);self.assertEqual(calls[0].args[0].value,0.)
    def test_primary_API_prerequisites(self):
        p=ROOT/'work/carrier-process-20261017/bounded-webs-cap-rib-variable-fillet-prototype-001/source/ChFiDS_FilSpine-V7_9_3.cxx';s=p.read_text();start=s.index('Handle(Law_Function)& ChFiDS_FilSpine::ChangeLaw');body=s[start:s.index('//====',start)]
        self.assertIn('if (!SplitDone())',body);self.assertIn('if (IsConstant(IE))',body)
        signature='void ChFiDS_FilSpine::SetRadius(const Handle(Law_Function)& C, const Standard_Integer /*IinC*/)';self.assertIn(signature,s)
if __name__=='__main__':
    start=time.monotonic();result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(Checks));receipt=dict(status='stdlib_tests_PASS'if result.wasSuccessful()else'stdlib_tests_FAIL',tests=result.testsRun,failures=len(result.failures),errors=len(result.errors),native_import_or_execution=False,elapsed_seconds=time.monotonic()-start,source_sha256=m.sha(HERE/'observe_law.py'),tests_sha256=m.sha(__file__))
    with(HERE/'selfcheck-assessment.json').open('x')as f:json.dump(receipt,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
    raise SystemExit(0 if result.wasSuccessful()else 1)
