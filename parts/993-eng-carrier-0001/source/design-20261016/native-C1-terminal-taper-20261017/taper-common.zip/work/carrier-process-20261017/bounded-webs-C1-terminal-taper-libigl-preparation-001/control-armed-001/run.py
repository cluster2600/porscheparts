"""Supervise one owned container for the unchanged joint surface audit."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import signal
import sys
import time

HERE=Path(__file__).resolve().parent
OWNER='org.porscheparts.carrier.BREP-joint-surface'
FIELDS={'Id':'.Id','Name':'.Name','Image':'.Image','Owner':'(index .Config.Labels "'+OWNER+'")',
    'User':'.Config.User','NanoCpus':'.HostConfig.NanoCpus','Memory':'.HostConfig.Memory',
    'MemorySwap':'.HostConfig.MemorySwap','PidsLimit':'.HostConfig.PidsLimit','NetworkMode':'.HostConfig.NetworkMode',
    'ReadonlyRootfs':'.HostConfig.ReadonlyRootfs','Tmpfs':'.HostConfig.Tmpfs','Mounts':'.Mounts',
    'Entrypoint':'.Config.Entrypoint','Cmd':'.Config.Cmd','WorkingDir':'.Config.WorkingDir',
    'Running':'.State.Running','ExitCode':'.State.ExitCode','OOMKilled':'.State.OOMKilled','StateError':'.State.Error'}
FORMAT='{'+','.join('"'+k+'":{{json '+v+'}}'for k,v in FIELDS.items())+'}'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(p,value):
    with Path(p).open('x')as f:json.dump(value,f,indent=2,allow_nan=False);f.write('\n');f.flush();os.fsync(f.fileno())
def require_GO(plan):
    if plan['launch_ready']is not True or plan['root_GO_sha256']is None or sha(plan['root_GO'])!=plan['root_GO_sha256']:
        raise ValueError('NOT ARMED: explicit ROOT inverse/topology GO required')
def validate_forward_root(plan,review):
    assert review['status']=='closed_actual_RC0_forward_sampled_screen_only'and review['actual_tool_RC']==0
    assert review['terminal_sha256']==plan['native_terminal_sha256']and review['all9_whole_outputs_and_logs_matched']is True
    assert review['fresh_owned_group_members']==[]and review['native_CAD_samples']==8638
    assert review['whole_native_counts']['solids']==review['whole_native_counts']['shells']==1 and review['whole_degenerated_edges']==0
    assert review['law_RC1_retained']is True and review['candidate_qualified']is False and review['global_admission']is False
def verify(plan):
    assert plan['wall_seconds']==300 and plan['cleanup_reserve_seconds']==40
    assert plan['image']=='sha256:3ccaf5701c7c9add59eda6e8db918106fc8d51f4c2ef5b148d8079262861c7e1'
    assert plan['container_command']==['--signal=TERM','--kill-after=5s','230s','/usr/local/bin/python','-I','-B','/source/worker.py']
    assert sha(__file__)==plan['caller_sha256']
    for path,digest in plan['files_sha256'].items():
        p=Path(path);assert p.is_file()and not p.is_symlink()and p.resolve()==p and sha(p)==digest,path
    for key in ['output_directory','execution_directory']:
        p=Path(plan[key]);assert not p.exists()and not p.is_symlink(),key
        assert p.parent.resolve()==p.parent
    source=Path(plan['source_directory'])
    assert set(p.name for p in source.iterdir())=={'audit.py','cad_mesh_brep_audit.py','worker.py','expected-runtime.json','native-inputs.json'}
    native=json.loads((source/'native-inputs.json').read_text())
    assert native['STL_sha256']==plan['STL_sha256']and native['faces']==637836
    assert native['source_sha256']=={n:sha(source/n)for n in ['audit.py','cad_mesh_brep_audit.py','worker.py','expected-runtime.json']}
    assert sha(plan['STL'])==plan['STL_sha256']
    assert all(sha(plan[k])==plan[k+'_sha256']==native[k+'_sha256'] for k in ['BREP_receipt','CAD_samples'])
    terminal=json.loads(Path(plan['native_terminal']).read_text())
    assert terminal['status']=='sampled_mesh_to_BREP_passed_pending_inverse_and_topology'
    assert terminal['actual_outer_returncode']==terminal['actual_child_returncode']==0
    assert terminal['direct_child_reaped'] is True and terminal['final_group_members']==[] and terminal['cleanup_error'] is None
    assert terminal['all_current_equal'] is True and terminal['timeout'] is False and terminal['interrupted'] is False
    assert terminal['BREP_receipt_sha256']==plan['BREP_receipt_sha256']
    assert terminal['surface_STL_sha256']==plan['STL_sha256'] and terminal['master_BREP_sha256']==plan['master_BREP_sha256']
    assert terminal['CAD_surface_points_sha256']==plan['CAD_samples_sha256'] and terminal['CAD_surface_points']==8638
    assert sha(plan['master_BREP'])==plan['master_BREP_sha256']
    receipt=json.loads(Path(plan['BREP_receipt']).read_text())
    assert receipt['CAD_source']['format']=='brep' and receipt['CAD_source']['sha256']==plan['master_BREP_sha256']
    assert receipt['results']['candidate_STL']['sha256']==plan['STL_sha256'] and receipt['candidate_sampled_chord_screen_pass'] is True
    assert receipt['exact_CAD_surface_samples_sha256']==plan['CAD_samples_sha256'] and receipt['exact_CAD_surface_samples']==8638
    assert receipt['results']['candidate_STL']['maximum_distance_to_BREP_shell_mm']<=.06
    assert sha(plan['native_terminal'])==plan['native_terminal_sha256']
    assert sha(plan['forward_root_review'])==plan['forward_root_review_sha256']
    validate_forward_root(plan,json.loads(Path(plan['forward_root_review']).read_text()))
def identity(data,plan,cid=None):
    if not re.fullmatch('[0-9a-f]{64}',data.get('Id',''))or data.get('Name')!='/'+plan['container_name']or data.get('Owner')!=plan['ownership_token']or data.get('Image')!=plan['image']or(cid and data['Id']!=cid):
        raise ValueError('Owned container identity refused')
    return data['Id']
def isolation(data,plan):
    expected=dict(User=plan['user'],NanoCpus=10**9,Memory=4*1024**3,MemorySwap=4*1024**3,PidsLimit=64,
        NetworkMode='none',ReadonlyRootfs=True,Tmpfs={'/tmp':'rw,size=128m'},Entrypoint=['/usr/bin/timeout'],
        Cmd=plan['container_command'],WorkingDir='/output')
    if any(data.get(k)!=v for k,v in expected.items()):raise ValueError('Actual container isolation differs')
    binds=sorted((m['Source'],m['Destination'],m['RW'])for m in data.get('Mounts',[])if m.get('Type')=='bind')
    wanted=sorted([(plan['source_directory'],'/source',False),(plan['STL'],'/input/carrier.stl',False),(plan['BREP_receipt'],'/input/brep-audit.json',False),(plan['CAD_samples'],'/input/exact-CAD-surface-samples.npz',False),(plan['output_directory'],'/output',True)])
    if binds!=wanted or any(m.get('Type')not in ['bind','tmpfs']or(m.get('Type')=='tmpfs'and m.get('Destination')!='/tmp')for m in data.get('Mounts',[])):raise ValueError('Actual mounts differ')
def supervise(plan,backend,clock=time.monotonic,started=None):
    started=clock()if started is None else started;deadline=started+300;work_deadline=deadline-40;cid=None;attempted=False
    result=dict(status='incomplete_joint_surface_audit',container_removed=False,actual_container_exit_code=None,
        attach_cli_returncode=None,operations=[],continuous_CAD_fidelity_bound=False,full_audit=False,manufacturing_admission=False,
        candidate_qualified=False,original_law_RC1_preserved=True,protected_interfaces='PENDING',STEP_exchange='PENDING',FEA='PENDING')
    def command(args,cap=15,cleanup=False,log=None,allow_native_failure=False):
        left=(deadline-5 if cleanup else work_deadline)-clock()
        if left<=3:raise TimeoutError('No remaining time for Docker operation and CLI reap')
        reply=backend.invoke(args,min(cap,left-3),log,ignore_cancel=cleanup)
        result['operations'].append(dict(argv=args,returncode=reply['returncode'],timed_out=reply.get('timed_out',False),cancelled=reply.get('cancelled',False),cleanup=cleanup))
        if reply.get('timed_out'):raise TimeoutError('Docker CLI timeout: '+args[0])
        if reply.get('cancelled'):raise InterruptedError('Cancellation requested')
        if reply['returncode']!=0 and not allow_native_failure:raise RuntimeError('Docker CLI failure: '+args[0])
        return reply
    def inspect(target,cleanup=False):
        data=json.loads(command(['container','inspect',target,'--format',FORMAT],cleanup=cleanup)['stdout'])
        identity(data,plan,cid)
        if re.fullmatch('[0-9a-f]{64}',target)and data['Id']!=target:raise ValueError('Inspected ID changed')
        return data
    try:
        verify(plan)
        Path(plan['execution_directory']).mkdir();Path(plan['output_directory']).mkdir()
        image=json.loads(command(['image','inspect',plan['image'],'--format','{"Id":{{json .Id}},"Architecture":{{json .Architecture}},"Os":{{json .Os}}}'])['stdout'])
        if image!={'Id':plan['image'],'Architecture':'arm64','Os':'linux'}:raise ValueError('Immutable image platform differs')
        if command(['container','ls','-a','--no-trunc','--filter','name=^/'+plan['container_name']+'$','--format','{{.ID}}'])['stdout'].strip():raise ValueError('Container name exists')
        args=['create','--pull=never','--name',plan['container_name'],'--label',OWNER+'='+plan['ownership_token'],
            '--network','none','--cpus','1','--memory','4g','--memory-swap','4g','--pids-limit','64','--read-only',
            '--tmpfs','/tmp:rw,size=128m','--user',plan['user'],'--workdir','/output',
            '--env','OMP_NUM_THREADS=1','--env','OPENBLAS_NUM_THREADS=1','--env','MKL_NUM_THREADS=1']
        for source,destination,readonly in [(plan['source_directory'],'/source',True),(plan['STL'],'/input/carrier.stl',True),(plan['BREP_receipt'],'/input/brep-audit.json',True),(plan['CAD_samples'],'/input/exact-CAD-surface-samples.npz',True),(plan['output_directory'],'/output',False)]:
            args+=['--mount','type=bind,src='+source+',dst='+destination+(',readonly'if readonly else'')]
        args+=['--entrypoint','/usr/bin/timeout',plan['image'],*plan['container_command']]
        attempted=True;created=command(args,cap=20)['stdout'].strip()
        if not re.fullmatch('[0-9a-f]{64}',created):raise ValueError('Unknown creation response')
        data=inspect(created);cid=data['Id'];result['container_id']=cid;isolation(data,plan)
        result['actual_before_start']=data
        attached=command(['start','--attach',cid],cap=240,log=Path(plan['execution_directory'])/'native.stdout',allow_native_failure=True)
        result['attach_cli_returncode']=attached['returncode'];ended=inspect(cid);result['actual_after_start']=ended
        result['actual_container_exit_code']=ended.get('ExitCode')
        output=Path(plan['output_directory']);assert set(p.name for p in output.iterdir())=={'assessment.json','runtime-before.json','runtime-after.json','joint'}
        assert all(p.is_file() and not p.is_symlink() for p in output.iterdir() if p.name!='joint')
        joint=output/'joint';assert joint.is_dir() and not joint.is_symlink() and set(p.name for p in joint.iterdir())=={'cad-mesh-audit.json'}
        assert (joint/'cad-mesh-audit.json').is_file() and not (joint/'cad-mesh-audit.json').is_symlink()
        result['outputs']={str(p.relative_to(output)):dict(sha256=sha(p),bytes=p.stat().st_size)for p in output.rglob('*')if p.is_file()}
        report=json.loads((output/'assessment.json').read_text());before=json.loads((output/'runtime-before.json').read_text());after=json.loads((output/'runtime-after.json').read_text())
        complete=json.loads((joint/'cad-mesh-audit.json').read_text())
        result['native_assessment_status']=report['status'];result['joint_audit_status']=complete['status'];result['joint_audit_failures']=complete['failures']
        expected=json.loads((Path(plan['source_directory'])/'expected-runtime.json').read_text())
        assert report['STL_sha256']==plan['STL_sha256'] and report['BREP_receipt_sha256']==plan['BREP_receipt_sha256'] and report['CAD_samples_sha256']==plan['CAD_samples_sha256']
        assert report['input_sources_unchanged'] is True and report['runtime_unchanged'] is True and before==after==expected
        assert complete['candidate_STL_sha256']==plan['STL_sha256'] and complete['BRep_receipt_sha256']==plan['BREP_receipt_sha256'] and complete['exact_CAD_surface_samples_sha256']==plan['CAD_samples_sha256']
        if attached['returncode']!=0 or ended.get('Running')or ended.get('OOMKilled')or ended.get('StateError')or ended.get('ExitCode')!=0:raise ValueError('Native container failed')
        assert report['status']=='joint_surface_checks_passed' and complete['status']=='passed' and complete['failures']==[]
        result['status']='joint_surface_checks_passed'
    except BaseException as error:result.update(status='refused_joint_surface_audit',error_type=type(error).__name__,error=str(error))
    finally:
        if attempted:
            try:
                data=inspect(cid or plan['container_name'],cleanup=True);cid=data['Id'];result['container_id']=cid
                command(['rm','--force',cid],cap=20,cleanup=True)
                if command(['container','ls','-a','--no-trunc','--filter','id='+cid,'--format','{{.ID}}'],cleanup=True)['stdout'].strip():raise ValueError('Container still present')
                result['container_removed']=True
            except BaseException as error:result.update(status='cleanup_unconfirmed',cleanup_error=str(error))
        try:
            assert all(sha(p)==d for p,d in plan['files_sha256'].items());result['input_sources_unchanged']=True
        except BaseException as error:result.update(status='input_identity_refused',integrity_error=str(error),input_sources_unchanged=False)
        result.update(wall_seconds=clock()-started,global_budget_seconds=300)
        if result['wall_seconds']>300:result['status']='global_budget_exceeded'
    return result
def main():
    started=time.monotonic()
    planpath=HERE/'plan.json';digest=sha(planpath);plan=json.loads(planpath.read_text());verify(plan)
    if sys.argv[1:]==['--preflight']:
        print(json.dumps(dict(status='preflight_only_no_Docker',plan_sha256=digest,pins=len(plan['files_sha256']))));return 0
    assert not sys.argv[1:]
    require_GO(plan)
    helper=Path(plan['DockerCLI_source']);spec=importlib.util.spec_from_file_location('_existing_owned_DockerCLI',helper)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);backend=module.DockerCLI()
    signal.signal(signal.SIGTERM,backend.cancel);signal.signal(signal.SIGINT,backend.cancel)
    result=supervise(plan,backend,started=started);result['plan_sha256']=digest;result['caller_sha256']=sha(__file__)
    result['plan_unchanged']=sha(planpath)==digest
    if not result['plan_unchanged']:result['status']='plan_identity_refused'
    execution=Path(plan['execution_directory'])
    if not execution.exists():execution.mkdir()
    write(execution/'execution-receipt.json',result)
    print(json.dumps(dict(status=result['status'],container_removed=result['container_removed'],actual_container_exit_code=result['actual_container_exit_code'],receipt_sha256=sha(execution/'execution-receipt.json'))),flush=True)
    return 0 if result['status']=='joint_surface_checks_passed'and result['container_removed']else 1
if __name__=='__main__':raise SystemExit(main())
