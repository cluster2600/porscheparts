"""Strict whole-inverse arming of the byte-identical preserved-BREP Cut diagnostic."""
import copy,hashlib,json,os,time
from pathlib import Path
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[2]
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb')as f:
  for b in iter(lambda:f.read(1024**2),b''):h.update(b)
 return h.hexdigest()
def rel(p):return str(p.relative_to(ROOT))
def write(p,d):
 with p.open('x')as f:json.dump(d,f,indent=2,allow_nan=False);f.write('\n');f.flush();os.fsync(f.fileno())
start=time.monotonic();expected={'pending-plan.json':'74b86c6c37bc759e36babb2e6b0b2473484d73e2bec28a0372de550c735979b1','pending-launch-plan.json':'92599cdd816cd1e99509139f8449e92743a73687236ca9559d295d923685f010','diagnose.py':'b8f88331a204cd0910b1b951bb2cb87da2d9c59cfaa8b979a1eac0d8ede7b30c','root-review-GO-001.json':'8fe0e0085746f67e358cb5d5a6caa3d5357a4aada43f2e5d264940a0c0d289fb'}
assert {n:sha(HERE/n)for n in expected}==expected
old=json.loads((HERE/'pending-plan.json').read_text());oldlaunch=json.loads((HERE/'pending-launch-plan.json').read_text());go=json.loads((HERE/'root-review-GO-001.json').read_text());gkey=rel(HERE/'root-review-GO-001.json')
assert go['status']=='GO_one_byteexact_old_diagnostic_on_preserved_raw_only'and old['launch_ready']is False and old['root_GO']is None and oldlaunch['launch_ready']is False
assert go['pending_plan_sha256']==expected['pending-plan.json']and go['pending_launch_sha256']==expected['pending-launch-plan.json']
for k in ('output_directory','execution_directory'):
 p=ROOT/old[k];assert not p.exists()and not any(q.is_symlink()for q in [p,*p.parents])
plan=copy.deepcopy(old);plan['launch_ready']=True;plan['root_GO']=gkey;plan['root_GO_sha256']=expected['root-review-GO-001.json'];plan['files_sha256'][gkey]=expected['root-review-GO-001.json']
inverse=copy.deepcopy(plan);inverse['launch_ready']=False;inverse['root_GO']=None;del inverse['root_GO_sha256'];del inverse['files_sha256'][gkey];assert inverse==old
write(HERE/'plan.json',plan);psha=sha(HERE/'plan.json');launch=copy.deepcopy(oldlaunch);launch['launch_ready']=True
pkey=rel(HERE/'pending-plan.json');akey=rel(HERE/'plan.json');assert launch['inputs_sha256'].pop(pkey)==expected['pending-plan.json'];launch['inputs_sha256'][akey]=psha;launch['inputs_sha256'][gkey]=expected['root-review-GO-001.json']
inverse=copy.deepcopy(launch);inverse['launch_ready']=False;del inverse['inputs_sha256'][akey];del inverse['inputs_sha256'][gkey];inverse['inputs_sha256'][pkey]=expected['pending-plan.json'];assert inverse==oldlaunch
pins={**launch['inputs_sha256'],**launch['source_sha256']};assert {n:sha(ROOT/n)for n in pins}==pins
write(HERE/'launch-plan.json',launch);lsha=sha(HERE/'launch-plan.json');argv=[str(ROOT/'work/part-workflow/runtimes/geometry-standalone/bin/python'),'-I','-B',str(ROOT/'work/carrier-process-20261017/source010-exposure-preflight-003/supervise.py'),str(HERE/'launch-plan.json'),'--plan-sha256',lsha]
write(HERE/'command.json',dict(argv=argv,root_GO_sha256=expected['root-review-GO-001.json'],candidate_qualified=False))
write(HERE/'arming-assessment.json',dict(status='strict_whole_inverse_and_fresh_pins_PASS_no_native_run',source_byteidentical_SHA=expected['diagnose.py'],root_GO_sha256=expected['root-review-GO-001.json'],plan_sha256=psha,launch_sha256=lsha,command_sha256=sha(HERE/'command.json'),whole_plan_inverse_equal=True,whole_launch_inverse_equal=True,unique_pins=len(pins),all_pins_actual_equal=True,fresh_output_and_execution=True,arming_source_sha256=sha(__file__),elapsed_seconds=time.monotonic()-start))
print(json.dumps(dict(plan_sha256=psha,launch_sha256=lsha,command_sha256=sha(HERE/'command.json'),arming_sha256=sha(HERE/'arming-assessment.json'),unique_pins=len(pins))))
