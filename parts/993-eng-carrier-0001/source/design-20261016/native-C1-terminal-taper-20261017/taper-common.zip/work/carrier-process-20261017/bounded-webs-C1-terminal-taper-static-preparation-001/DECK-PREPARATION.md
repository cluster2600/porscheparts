# Pending owned deck preparation

These two commands are source-only proposals. They do not authorize execution.
The existing case plans, scientific driver and postprocess sources are unchanged.
Each command invokes the unchanged 4d18 supervisor, without `nice` on its parent.
The supervisor applies nice 10 and the three BLAS thread limits to its child.

The child runs the existing `run.py prepare` entry point through a standard-library
argv wrapper. Before loading that source, the wrapper sets CPU soft/hard limits
150/160 seconds and a 150-second alarm. The owned supervisor has a 180-second
global budget and unchanged 10+10-second cleanup grace. These are deck-preparation
bounds; the separate future solver keeps its existing 1800/1680-second contract.
There is one child, zero workers and no Docker operation in this stage. The
retained `prepare_execute` intercept must stop the original solve before execution.

The rigid and spring plans use separate fresh case outputs and separate fresh
`rigid-deck-supervision-001` and `spring-deck-supervision-001` directories. Their
commands are stored as exact argv arrays in `rigid-pending-prepare-command.json`
and `spring-pending-prepare-command.json`. No shell parsing is needed.

After ROOT GO, derive each armed case plan from its whole pending object. Change
only `launch_ready` to true, bind the actual ROOT GO path/hash, add that file to
`files_sha256`, and update `input_count`/`input_bytes` for this added file. Write
the new objects as `rigid-plan.json` and `spring-plan.json`, preserving both
pending files. Do not alter status labels, physics, rosters or scientific pins.

Derive each armed deck launch from its whole pending object: set `launch_ready`,
bind the same GO, replace only the case-plan path/hash in `command`, replace the
pending case-plan entry in `inputs_sha256` by the actual armed entry, and add the
GO pin. All other fields, including wrapper text, resource limits, paths and
source maps, must compare equal. Write `rigid-prepare-launch.json` and
`spring-prepare-launch.json`. Derive the two armed command objects by changing
only their readiness/GO metadata and their launch path/hash to these new files.

Before running either command, freshly hash every pin, check both output paths
and its supervision path absent, and reverse every declared change in memory.
The entire reversed case plan, launch plan and command must equal their frozen
pending objects. A field-by-field subset check is insufficient. Preserve the
derivation receipt with both whole hashes and the real GO hash. The source-only
arming fixture uses a labelled synthetic GO in memory only; it is not permission.

Collect each real supervisor handle separately to its actual return code, logs,
before/after pin maps and reaped empty owned group. A completed deck is not a
solver result. Review and bind its actual `case-plan.json`, deck and support/load
evidence before preparing any solver launch; do not invent their future hashes.
