"""Read all native radius laws after the same failed variable-radius corner build."""
import hashlib
import json
import math
from pathlib import Path
import resource
import signal
import sys
import time

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for data in iter(lambda: stream.read(1024*1024), b''):
            digest.update(data)
    return digest.hexdigest()


def run():
    started = time.monotonic()
    plan = json.loads((HERE/'plan.json').read_text())
    before = {p: sha(ROOT/p) for p in plan['files_sha256']}
    assert before == plan['files_sha256']
    output = ROOT/plan['output_directory']
    assert not output.exists() and not output.is_symlink()
    output.mkdir()
    signal.signal(signal.SIGALRM, lambda *_: (_ for _ in ()).throw(TimeoutError('Contour diagnostic wall budget')))
    signal.alarm(150)
    resource.setrlimit(resource.RLIMIT_CPU, (140,141))
    sys.path.insert(0, str(ROOT/plan['native_site']))
    from build123d import import_step
    from OCP.BRep import BRep_Tool
    from OCP.BRepAdaptor import BRepAdaptor_Curve
    from OCP.BRepBuilderAPI import BRepBuilderAPI_MakeVertex
    from OCP.BRepExtrema import BRepExtrema_DistShapeShape
    from OCP.BRepFilletAPI import BRepFilletAPI_MakeFillet
    from OCP.BRepCheck import BRepCheck_Analyzer
    from OCP.OSD import OSD_ThreadPool
    from OCP.gp import gp_Pnt
    OSD_ThreadPool.DefaultPool_s().Init(1)
    prior = json.loads((ROOT/plan['failed_assessment']).read_text())
    assert prior['failure']['message'] == 'Native variable R1-to-zero fillet did not complete'
    assert prior['radius_mm'] == 1. and prior['sources_unchanged'] and not prior['CAD_qualified']
    body = import_step(ROOT/plan['STEP'])
    assert body.is_valid and len(body.solids()) == 1
    edges, faces, vertices = list(body.edges()), list(body.faces()), list(body.vertices())
    edge_vertices = [list(edge.vertices()) for edge in edges]
    face_edges = [list(face.edges()) for face in faces]

    def vertex_info(v):
        if v.IsNull():
            return dict(null=True)
        ids = [i for i, candidate in enumerate(vertices) if v.IsSame(candidate.wrapped)]
        incident = [i for i, items in enumerate(edge_vertices) if any(v.IsSame(item.wrapped) for item in items)]
        return dict(null=False, baseline_vertex_indices=ids, point_mm=list(BRep_Tool.Pnt_s(v).Coord()),
                    native_tolerance_mm=BRep_Tool.Tolerance_s(v), incident_edge_indices_zero_based=incident,
                    distinct_edge_valence=len(incident))

    def edge_info(e):
        ids = [i for i, edge in enumerate(edges) if e.IsSame(edge.wrapped)]
        assert len(ids) == 1
        i = ids[0]
        curve = BRepAdaptor_Curve(e)
        adj = [j for j, items in enumerate(face_edges) if any(e.IsSame(item.wrapped) for item in items)]
        return dict(edge_index_zero_based=i, curve_type=str(curve.GetType()),
                    domain=[curve.FirstParameter(),curve.LastParameter()], orientation=str(e.Orientation()),
                    length_mm=edges[i].length, adjacent_faces_zero_based=adj,
                    vertices=[vertex_info(item.wrapped) for item in edge_vertices[i]])

    selected = []
    domain_rows = []
    for row in prior['selected_edges']:
        i = row['edge_index_zero_based']
        edge = edges[i]
        assert edge.length == row['length_mm']
        record = edge_info(edge.wrapped)
        record.update(mirror_X=row['mirror_X'],mirror_Y=row['mirror_Y'], expected_subarc_samples=[])
        for point in row['expected_mirrored_points_mm']:
            q = BRepExtrema_DistShapeShape(BRepBuilderAPI_MakeVertex(gp_Pnt(*point)).Shape(),edge.wrapped)
            q.SetMultiThread(False); q.Perform()
            assert q.IsDone() and q.NbSolution() > 0 and q.Value() <= row['native_sum_tolerance_mm']
            support = str(q.SupportTypeShape2(1))
            sample = dict(source_mirrored_point_mm=point, distance_mm=q.Value(), support_type=support,
                          closest_point_mm=list(q.PointOnShape2(1).Coord()))
            if support.endswith('IsOnEdge'):
                sample['native_parameter'] = q.ParOnEdgeS2(1)[0]
                sample['strictly_inside_parameter_domain'] = record['domain'][0] < sample['native_parameter'] < record['domain'][1]
            record['expected_subarc_samples'].append(sample)
        domain_rows.append(record)
        selected.append(edge)
    assert len(selected) == 4
    builder = BRepFilletAPI_MakeFillet(body.solids()[0].wrapped)
    for edge in selected:
        builder.Add(1.,edge.wrapped)

    def contours(after=False):
        result=[]
        for i in range(1,builder.NbContours()+1):
            row=dict(contour_index_one_based=i, native_NbEdges=builder.NbEdges(i),
                edges=[edge_info(builder.Edge(i,j)) for j in range(1,builder.NbEdges(i)+1)],
                first_vertex=vertex_info(builder.FirstVertex(i)),last_vertex=vertex_info(builder.LastVertex(i)),
                native_length_mm=builder.Length(i),closed=builder.Closed(i),closed_and_tangent=builder.ClosedAndTangent(i),
                radius_is_constant=builder.IsConstant(i))
            if row['radius_is_constant']:
                row['native_constant_radius_mm']=builder.Radius(i)
                assert row['native_constant_radius_mm']==1.
            if after:
                row['StripeStatus']=str(builder.StripeStatus(i))
            result.append(row)
        return result

    initial=contours()
    for ci in range(1,builder.NbContours()+1):
        for j in range(1,builder.NbEdges(ci)+1):
            builder.SetRadius(1.,ci,builder.Edge(ci,j))
    zero_assignments=[]
    for ci in range(1,builder.NbContours()+1):
        for label,v in [('FirstVertex',builder.FirstVertex(ci)),('LastVertex',builder.LastVertex(ci))]:
            ids=[i for i,vertex in enumerate(vertices) if v.IsSame(vertex.wrapped)]
            assert len(ids)==1
            if ids[0] in [row['vertex_index_zero_based'] for row in prior['native_zero_radius_vertices']]:
                builder.SetRadius(0.,ci,v)
                zero_assignments.append(dict(contour_index_one_based=ci,endpoint=label,
                    vertex_index_zero_based=ids[0],point_mm=list(BRep_Tool.Pnt_s(v).Coord()),
                    native_abscissa_mm=builder.Abscissa(ci,v),radius_mm=0.))
    assert zero_assignments==prior['native_zero_radius_vertices']
    assigned=contours()
    build_error=None
    try:
        builder.Build()
    except Exception as error:
        build_error=dict(type=type(error).__name__,message=str(error))
    final=contours(after=True)
    laws=[]
    for ci in range(1,builder.NbContours()+1):
        for j in range(1,builder.NbEdges(ci)+1):
            e=builder.Edge(ci,j)
            row=dict(contour_index_one_based=ci,edge_index_zero_based=edge_info(e)['edge_index_zero_based'],
                     native_orientation=str(e.Orientation()))
            try:
                row['is_constant']=builder.IsConstant(ci,e)
                if row['is_constant']:
                    row['constant_radius_mm']=builder.Radius(ci,e)
                else:
                    law=builder.GetLaw(ci,e)
                    lo,hi=law.Bounds()
                    row.update(native_law_type=type(law).__name__,native_law_bounds=[lo,hi],
                        native_endpoint_values=[law.Value(lo),law.Value(hi)],
                        native_endpoint_D1=[list(law.D1(lo)),list(law.D1(hi))])
                    curve=law.Curve()
                    row.update(native_degree=curve.Degree(),native_poles=[curve.Pole(k) for k in range(1,curve.NbPoles()+1)],
                        native_knots=[curve.Knot(k) for k in range(1,curve.NbKnots()+1)],
                        native_multiplicities=[curve.Multiplicity(k) for k in range(1,curve.NbKnots()+1)])
            except Exception as error:
                row['unavailable_reason']=dict(type=type(error).__name__,message=str(error))
            laws.append(row)
    has_result=builder.HasResult()
    bad_shape=None
    if has_result:
        bad=builder.BadShape()
        bad_shape=dict(null=bad.IsNull(),topological_type=str(bad.ShapeType()),
                       native_valid=False if bad.IsNull() else BRepCheck_Analyzer(bad).IsValid(),exported=False)
    after={p:sha(ROOT/p) for p in before}
    assert before==after
    report=dict(schema='same-failed-variable-R1-native-law-diagnostic-1',status='complete_readonly_diagnostic',
        exact_same_radius_and_edges=True, requested_radius_mm=1.,selected_edge_domains=domain_rows,
        initial_contours=initial,assigned_contours=assigned,zero_assignments=zero_assignments,native_laws=laws,all_laws_read=len(laws)==16 and all('unavailable_reason' not in row for row in laws),final_contours=final,native_fillet_shape=str(builder.GetFilletShape()),
        native_IsDone=builder.IsDone(),build_error=build_error,
        NbFaultyContours=builder.NbFaultyContours(),faulty_contour_indices_one_based=[builder.FaultyContour(i) for i in range(1,builder.NbFaultyContours()+1)],
        NbFaultyVertices=builder.NbFaultyVertices(),faulty_vertices=[vertex_info(builder.FaultyVertex(i)) for i in range(1,builder.NbFaultyVertices()+1)],
        HasResult=has_result,BadShape=bad_shape,CAD_exported=False,new_candidate=False,FEA_executed=False,
        input_sources_before=before,input_sources_after=after,sources_unchanged=True,elapsed_seconds=time.monotonic()-started,
        provenance=plan['primary_sources'])
    with (output/'assessment.json').open('x') as stream:
        json.dump(report,stream,indent=2,allow_nan=False);stream.write('\n')
    signal.alarm(0)
    print(json.dumps(dict(status=report['status'],native_IsDone=report['native_IsDone'],NbFaultyContours=report['NbFaultyContours'],
                         NbFaultyVertices=report['NbFaultyVertices'],HasResult=has_result,elapsed_seconds=report['elapsed_seconds'],assessment_sha256=sha(output/'assessment.json'))),flush=True)


if __name__=='__main__':
    run()
