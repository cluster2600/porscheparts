"""Small stdlib scope/refusal tests; no native import, Build or output geometry."""
import ast
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import tempfile
import time
import unittest

HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('_end_R1_stdlib',HERE/'close_end.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
def diagnostic():
    return dict(status='actual_C1_common_IP_native_diagnostic_complete',sources_unchanged=True,CAD_source=dict(sha256=m.MASTER),common_peak=dict(element_id=84037,IP_one_based=1),probes=[dict(nearest_edges=[dict(edge_index_zero_based=267,adjacent_faces_zero_based=[60,62],native_continuity='GeomAbs_Shape.GeomAbs_C0')])])
def gate_plan():return dict(minimum_xyz_mm=[-296.,-36.5,-22.],maximum_xyz_mm=[296.,36.5,30.],existing_bound_guard_mm=1e-6)

class Checks(unittest.TestCase):
    def test_nonarmed_before_native_or_output(self):
        with tempfile.TemporaryDirectory()as d:
            p=Path(d)/'plan.json';p.write_text(json.dumps(dict(launch_ready=False)))
            with self.assertRaisesRegex(ValueError,'NON-ARMED'):m.verify(p,hashlib.sha256(p.read_bytes()).hexdigest(),True)
    def test_plan_hash_refused(self):
        with tempfile.TemporaryDirectory()as d:
            p=Path(d)/'plan.json';p.write_text('{}')
            with self.assertRaisesRegex(ValueError,'Plan SHA'):m.verify(p,'0'*64)
    def test_measured_edge_selected(self):self.assertEqual(m.edge_record(diagnostic())['adjacent_faces_zero_based'],[60,62])
    def test_foreign_master_refused(self):
        d=diagnostic();d['CAD_source']['sha256']='0'*64
        with self.assertRaisesRegex(ValueError,'Foreign BREP'):m.edge_record(d)
    def test_foreign_peak_refused(self):
        d=diagnostic();d['common_peak']['element_id']=90371
        with self.assertRaisesRegex(ValueError,'coarse common IP'):m.edge_record(d)
    def test_foreign_adjacency_refused(self):
        d=diagnostic();d['probes'][0]['nearest_edges'][0]['adjacent_faces_zero_based']=[60,68]
        with self.assertRaisesRegex(ValueError,'adjacency'):m.edge_record(d)
    def test_missing_or_duplicate_edge_refused(self):
        for rows in [[],diagnostic()['probes'][0]['nearest_edges']*2]:
            d=diagnostic();d['probes'][0]['nearest_edges']=rows
            with self.assertRaisesRegex(ValueError,'One measured'):m.edge_record(d)
    def test_erosion_refused(self):
        with self.assertRaisesRegex(ValueError,'Baseline material removed'):m.local_gate_flags(dict(native_topologically_empty=False),True,1,1.26,[[-296,-36.5,-22],[296,36.5,30]],gate_plan())
    def test_invalid_or_multisolid_refused(self):
        for valid,n in [(False,1),(True,2)]:
            with self.assertRaisesRegex(ValueError,'valid Solid'):m.local_gate_flags(dict(native_topologically_empty=True),valid,n,1.26,[[-296,-36.5,-22],[296,36.5,30]],gate_plan())
    def test_mass_ceiling_and_nonfinite_refused(self):
        for mass in [1.3000001,float('nan'),0.]:
            with self.assertRaisesRegex(ValueError,'mass ceiling'):m.local_gate_flags(dict(native_topologically_empty=True),True,1,mass,[[-296,-36.5,-22],[296,36.5,30]],gate_plan())
    def test_global_bounds_refused(self):
        with self.assertRaisesRegex(ValueError,'global bounds'):m.local_gate_flags(dict(native_topologically_empty=True),True,1,1.26,[[-296,-36.5,-22],[297,36.5,30]],gate_plan())
    def test_nan_bounds_refused(self):
        with self.assertRaisesRegex(ValueError,'Nonfinite bounds'):m.local_gate_flags(dict(native_topologically_empty=True),True,1,1.26,[[float('nan'),-36.5,-22],[296,36.5,30]],gate_plan())
    def test_local_success_never_promotes_downstream(self):
        r=m.local_gate_flags(dict(native_topologically_empty=True),True,1,1.3,[[-296,-36.5,-22],[296,36.5,30]],gate_plan())
        self.assertFalse(r['candidate_qualified']);self.assertEqual(r['downstream_checks'],{k:'PENDING'for k in m.PENDING})
    def test_retained_raw_cut_helpers(self):
        path=m.ROOT/'work/carrier-process-20261017/bounded-webs-native-BREP-cut-preparation-001/diagnose.py';ns={};m.retain_cut_helpers(path,ns)
        self.assertEqual({n for n in ns if n!='__builtins__'},{'entities','bbox','summary'})
        run=next(n for n in ast.parse(path.read_text()).body if isinstance(n,ast.FunctionDef)and n.name=='run')
        for key in ['entities','bbox','summary']:
            expected=next(n for n in run.body if isinstance(n,ast.FunctionDef)and n.name==key)
            self.assertEqual(ns[key].__code__.co_firstlineno,expected.lineno)
    def test_one_build_and_one_strict_cut_no_clean(self):
        t=ast.parse((HERE/'close_end.py').read_text());calls=[n for n in ast.walk(t)if isinstance(n,ast.Call)and isinstance(n.func,ast.Attribute)]
        self.assertEqual(sum(n.func.attr=='Build'for n in calls),2)
        self.assertFalse(any(n.func.attr in ['Clean','clean','generate','check']for n in calls))
        fixed={n.func.attr:ast.literal_eval(n.args[0])for n in calls if n.func.attr in ['SetNonDestructive','SetRunParallel','SetFuzzyValue']}
        self.assertEqual(fixed,dict(SetNonDestructive=True,SetRunParallel=False,SetFuzzyValue=0.))
    def test_single_R1_no_radius_search(self):
        t=ast.parse((HERE/'close_end.py').read_text());calls=[n for n in ast.walk(t)if isinstance(n,ast.Call)and isinstance(n.func,ast.Attribute)and n.func.attr=='Add']
        self.assertEqual(len(calls),1);self.assertEqual(ast.literal_eval(calls[0].args[0]),1.)
        self.assertIn('actual==[267]',(HERE/'close_end.py').read_text())

if __name__=='__main__':
    started=time.monotonic();result=unittest.TextTestRunner(verbosity=1).run(unittest.defaultTestLoader.loadTestsFromTestCase(Checks))
    print(json.dumps(dict(status='PASS'if result.wasSuccessful()else'FAIL',tests=result.testsRun,elapsed_seconds=time.monotonic()-started,native_imports=False,Build=False)))
    raise SystemExit(0 if result.wasSuccessful()else 1)
