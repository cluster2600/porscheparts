"""Read-only Boolean quantification and unchanged-writer baseline control."""
import hashlib
import importlib.util
import json
from pathlib import Path
import resource
import shutil
import signal
import sys
import time
import traceback
from types import SimpleNamespace

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[2]


def sha(path):
    digest=hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda:stream.read(1024*1024),b''):digest.update(block)
    return digest.hexdigest()


def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    return module


def write(path,value):
    with Path(path).open('x') as stream:
        json.dump(value,stream,indent=2,allow_nan=False);stream.write('\n')


def run():
    started=time.monotonic()
    plan=json.loads((HERE/'plan.json').read_text())
    before={name:sha(ROOT/name) for name in plan['files_sha256']}
    assert before==plan['files_sha256']
    output=ROOT/plan['output_directory']
    assert not output.exists() and not output.is_symlink()
    output.mkdir()
    signal.signal(signal.SIGALRM,lambda *_:(_ for _ in ()).throw(TimeoutError('Serialization diagnostic wall budget')))
    signal.alarm(270);resource.setrlimit(resource.RLIMIT_CPU,(250,251))
    report=dict(schema='existing-C1-serialization-readonly-diagnostic-1',status='incomplete',differences={},
                sources_before=before,new_fillet_Build=False,new_candidate=False,FEA_executed=False,
                candidate_qualified=False,existing_candidate_refusal_preserved=True)
    try:
        sys.path.insert(0,str(ROOT/plan['native_site']))
        from build123d import import_step,import_brep,export_step
        from OCP.BRep import BRep_Tool
        from OCP.BRepAdaptor import BRepAdaptor_Surface
        from OCP.BRepBndLib import BRepBndLib
        from OCP.BRepCheck import BRepCheck_Analyzer
        from OCP.BRepGProp import BRepGProp
        from OCP.Bnd import Bnd_Box
        from OCP.GProp import GProp_GProps
        from OCP.OSD import OSD_ThreadPool
        from OCP.TopAbs import TopAbs_SOLID,TopAbs_FACE,TopAbs_EDGE,TopAbs_VERTEX
        from OCP.TopExp import TopExp
        from OCP.TopTools import TopTools_IndexedMapOfShape
        from OCP.TopoDS import TopoDS
        OSD_ThreadPool.DefaultPool_s().Init(1)
        volume=load('_serialization_precise_volume',ROOT/plan['volume_source'])

        def entities(raw,kind):
            mapping=TopTools_IndexedMapOfShape();TopExp.MapShapes_s(raw,kind,mapping)
            return [mapping.FindKey(i) for i in range(1,mapping.Extent()+1)]

        def bbox(raw):
            box=Bnd_Box();BRepBndLib.Add_s(raw,box,False)
            return None if box.IsVoid() else list(box.Get())

        def summary(shape):
            if shape is None or shape.wrapped.IsNull():
                return dict(native_null=True,counts=dict(solids=0,faces=0,edges=0,vertices=0),
                            material_solid_volume_mm3=0.,native_topologically_empty=True,bounds_mm=None)
            raw=shape.wrapped
            parts={name:entities(raw,kind) for name,kind in [('solids',TopAbs_SOLID),('faces',TopAbs_FACE),('edges',TopAbs_EDGE),('vertices',TopAbs_VERTEX)]}
            result=dict(native_null=False,native_type=str(raw.ShapeType()),native_valid=BRepCheck_Analyzer(raw).IsValid(),
                        counts={key:len(value) for key,value in parts.items()},bounds_mm=bbox(raw),solids=[],tolerances_mm={})
            for solid in parts['solids']:
                mass,error=volume.precise_volume(SimpleNamespace(wrapped=solid))
                result['solids'].append(dict(volume_mm3=mass,estimated_relative_integration_error=error,
                                             native_valid=BRepCheck_Analyzer(solid).IsValid(),bounds_mm=bbox(solid)))
            result['material_solid_volume_mm3']=sum(item['volume_mm3'] for item in result['solids'])
            result['sum_absolute_solid_volume_mm3']=sum(abs(item['volume_mm3']) for item in result['solids'])
            result['volume_scope']='BRepGProp adaptive integrals of each actual Solid only; no fictitious material volume integrated from an open face or edge residue.'
            casts={'faces':TopoDS.Face_s,'edges':TopoDS.Edge_s,'vertices':TopoDS.Vertex_s}
            for kind,cast in casts.items():
                tolerances=[BRep_Tool.Tolerance_s(cast(item)) for item in parts[kind]]
                result['tolerances_mm'][kind]=dict(count=len(tolerances),minimum=min(tolerances) if tolerances else None,
                                                maximum=max(tolerances) if tolerances else None)
            areas=[];types={}
            for face in parts['faces']:
                face=TopoDS.Face_s(face);props=GProp_GProps();BRepGProp.SurfaceProperties_s(face,props)
                areas.append(props.Mass());key=str(BRepAdaptor_Surface(face,True).GetType());types[key]=types.get(key,0)+1
            result['surface_area_sum_mm2']=sum(areas)
            result['surface_types']=types
            result['degenerated_edge_count']=sum(BRep_Tool.Degenerated_s(TopoDS.Edge_s(edge)) for edge in parts['edges'])
            result['native_topologically_empty']=all(not values for values in parts.values())
            result['highest_topological_dimension']=next((dim for name,dim in [('solids',3),('faces',2),('edges',1),('vertices',0)] if parts[name]),None)
            return result

        old=import_step(ROOT/plan['baseline_STEP'])
        brep=import_brep(ROOT/plan['candidate_BREP'])
        step=import_step(ROOT/plan['candidate_STEP'])
        models=dict(baseline=old,native_BREP=brep,STEP_readback=step)
        report['models']={name:summary(shape) for name,shape in models.items()}
        assert all(item['native_valid'] and item['counts']['solids']==1 for item in report['models'].values())
        write(output/'model-summaries.json',report['models'])
        for label,left,right in [('old-minus-BREP',old,brep),('old-minus-STEP',old,step),
                                 ('BREP-minus-STEP',brep,step),('STEP-minus-BREP',step,brep)]:
            at=time.monotonic();residue=left-right;row=summary(residue);row['elapsed_seconds']=time.monotonic()-at
            report['differences'][label]=row;write(output/(label+'.json'),row)
            print(json.dumps(dict(stage=label,counts=row['counts'],solid_volume_mm3=row['material_solid_volume_mm3'],elapsed_seconds=row['elapsed_seconds'])),flush=True)
        # Control only: same baseline, same unchanged exporter defaults, no new design.
        control_path=output/'unchanged-baseline-control.step'
        export_step(old,control_path)
        control=import_step(control_path)
        report['unchanged_baseline_control']=dict(export_sha256=sha(control_path),model=summary(control),
                                                 difference_old_minus_roundtrip=summary(old-control))
        write(output/'unchanged-baseline-control.json',report['unchanged_baseline_control'])
        copied=output/'protected-input';copied.mkdir()
        for name,key in [('carrier.step','candidate_STEP'),('carrier.stl','candidate_STL'),('study.json','study')]:
            source=ROOT/plan[key];target=copied/name
            with source.open('rb') as src,target.open('xb') as dst:shutil.copyfileobj(src,dst,1024*1024)
            assert sha(target)==plan['files_sha256'][plan[key]]
        checker=load('_serialization_existing_protected',ROOT/plan['protected_source'])
        try:
            protection=checker.check(copied)
            report['protected_checker']=dict(returned=True,report=protection)
        except Exception as error:
            report['protected_checker']=dict(returned=False,error=dict(type=type(error).__name__,message=str(error),traceback=traceback.format_exc()))
        if (copied/'inspection.json').is_file():
            inspection=json.loads((copied/'inspection.json').read_text())
            report['actual_inspection']=inspection
            report['current_mass_ceiling_1p3kg_pass']=inspection['nominal_mass_kg']<=1.3
        report['writer_static_settings']=plan['writer_static_settings']
        report['status']='complete_readonly_diagnostic'
    except BaseException as error:
        report['failure']=dict(type=type(error).__name__,message=str(error),traceback=traceback.format_exc())
    finally:
        signal.alarm(0)
        after={name:sha(ROOT/name) for name in before}
        report.update(sources_after=after,sources_unchanged=before==after,elapsed_seconds=time.monotonic()-started)
        if before!=after:report['status']='refused_input_drift'
        report['output_files_sha256']={str(path.relative_to(output)):sha(path) for path in output.rglob('*') if path.is_file()}
        write(output/'assessment.json',report)
    print(json.dumps(dict(status=report['status'],elapsed_seconds=report['elapsed_seconds'],assessment_sha256=sha(output/'assessment.json'))),flush=True)
    return 0 if report['status']=='complete_readonly_diagnostic' and report['sources_unchanged'] else 1


if __name__=='__main__':
    raise SystemExit(run())
