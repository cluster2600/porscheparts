"""Stdlib contract doubles only; no scientific package or native imports."""
import ast
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import struct
import tempfile
from types import SimpleNamespace
import unittest

HERE = Path(__file__).resolve().parent


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


helper = load('_chunk16_helper_checks', HERE/'contains_chunks.py')
factory = load('_chunk16_factory_checks', HERE/'factory.py')
caller = load('_chunk16_caller_checks', HERE/'run.py')


class Rows:
    dtype = SimpleNamespace(str='<f8')

    def __init__(self, values):
        self.values = values
        self.shape = (len(values), 3)

    def __len__(self):
        return len(self.values)

    def __getitem__(self, key):
        return Rows(self.values[key])

    def tobytes(self, order='C'):
        assert order == 'C'
        return b''.join(struct.pack('<3d', *v) for v in self.values)


class Bools:
    dtype = SimpleNamespace(kind='b', str='|b1')

    def __init__(self, values):
        self.values = values
        self.shape = (len(values),)

    def tolist(self):
        return self.values.copy()


class NP:
    bool_ = bool

    @staticmethod
    def asarray(values, dtype):
        assert dtype is bool
        return Bools(values.copy())


class Ray:
    pass


class Mesh:
    ray = Ray()

    def __init__(self, util, fail=None):
        self.util, self.fail, self.chunks = util, fail, []

    def contains(self, points):
        self.chunks.append(points.values.copy())
        if self.fail == 'random':
            self.util.random_generator()
        if self.fail == 'exception':
            raise RuntimeError('native-double refusal')
        if self.fail == 'cancel':
            raise KeyboardInterrupt()
        answer = Bools([int(p[0]) % 3 == 0 for p in points.values])
        if self.fail == 'shape':
            answer.shape = (len(points)+1,)
        if self.fail == 'integer':
            answer.dtype = SimpleNamespace(kind='i', str='<i8')
        if self.fail == 'binding':
            self.util.random_generator = lambda: None
        return answer


class Checks(unittest.TestCase):
    def setUp(self):
        self.generator = lambda: self.fail('Original random generator must not run')
        self.util = SimpleNamespace(random_generator=self.generator)
        self.contains, self.records = helper.make_contains(Ray, self.util, NP)
        self.points = Rows([(float(i), .25, -.5) for i in range(35)])

    def test_ordered_16_16_3_and_whole_exact_bool_bytes(self):
        mesh = Mesh(self.util)
        result = self.contains('carrier', mesh, self.points)
        expected = [i % 3 == 0 for i in range(35)]
        self.assertEqual(result.tolist(), expected)
        self.assertEqual([len(v) for v in mesh.chunks], [16, 16, 3])
        self.assertEqual(sum(mesh.chunks, []), self.points.values)
        row = self.records[0]
        self.assertEqual(row['whole_bool_values'], expected)
        self.assertEqual(row['whole_bool_bytes_sha256'], hashlib.sha256(bytes(expected)).hexdigest())
        self.assertEqual(row['probe_bytes_sha256'], hashlib.sha256(self.points.tobytes()).hexdigest())
        self.assertTrue(row['complete']); self.assertTrue(row['random_binding_restored'])

    def test_random_retry_refuses_and_restores_without_drawing(self):
        with self.assertRaisesRegex(ValueError, 'random fallback'):
            self.contains('carrier', Mesh(self.util, 'random'), self.points)
        self.assertIs(self.util.random_generator, self.generator)
        self.assertEqual(self.records[0]['random_fallback_attempts'], 1)
        self.assertFalse(self.records[0]['complete'])

    def test_exception_and_cancellation_restore_binding(self):
        for mode, exception in [('exception', RuntimeError), ('cancel', KeyboardInterrupt)]:
            with self.assertRaises(exception):
                self.contains('bracket', Mesh(self.util, mode), self.points)
            self.assertIs(self.util.random_generator, self.generator)
            self.assertTrue(self.records[-1]['random_binding_restored'])

    def test_wrong_backend_subclass_and_label_refuse_before_call(self):
        class OtherRay(Ray):
            pass
        mesh = Mesh(self.util); mesh.ray = OtherRay()
        with self.assertRaises(ValueError): self.contains('carrier', mesh, self.points)
        with self.assertRaises(ValueError): self.contains('foreign', Mesh(self.util), self.points)
        self.assertEqual(self.records, [])

    def test_bool_roster_and_guard_mutation_refuse(self):
        for mode in ['shape', 'integer', 'binding']:
            with self.assertRaises(ValueError): self.contains('carrier', Mesh(self.util, mode), self.points)
            self.assertIs(self.util.random_generator, self.generator)
            self.assertFalse(self.records[-1]['complete'])

    def test_prior_generator_drift_is_not_overwritten(self):
        other = lambda: None; self.util.random_generator = other
        with self.assertRaises(ValueError): self.contains('carrier', Mesh(self.util), self.points)
        self.assertIs(self.util.random_generator, other)

    def test_empty_array_and_separate_call_order(self):
        self.assertEqual(self.contains('carrier', Mesh(self.util), Rows([])).tolist(), [])
        self.contains('bracket', Mesh(self.util), self.points)
        self.assertEqual([r['mesh'] for r in self.records], ['carrier', 'bracket'])
        self.assertEqual([r['call'] for r in self.records], [0, 1])

    def test_whole_source_inverses_and_two_callsite_delta(self):
        for spec, target in [('candidate-changes.json', 'source/inspect_candidate_brep.py'),
                             ('factory-changes.json', 'factory.py'), ('run-changes.json', 'run.py')]:
            row = json.loads((HERE/spec).read_text())
            old = Path(row['original']).read_bytes(); restored = (HERE/target).read_text()
            self.assertEqual(hashlib.sha256(old).hexdigest(), row['original_sha256'])
            for delta in reversed(row['replacements']):
                self.assertEqual(restored.count(delta['after']), 1)
                restored = restored.replace(delta['after'], delta['before'], 1)
            self.assertEqual(restored.encode(), old)
        self.assertEqual(len(json.loads((HERE/'candidate-changes.json').read_text())['replacements']), 2)

    def test_protected_zones_and_all_non_contains_math_retained(self):
        old = HERE.parent/'bounded-webs-BREP-protected-comparator-preparation-002'
        self.assertEqual((HERE/'source/inspect_protected_brep.py').read_bytes(),
                         (old/'source/inspect_protected_brep.py').read_bytes())
        a = ast.parse((HERE/'source/inspect_candidate_brep.py').read_text())
        b = ast.parse((old/'source/inspect_candidate_brep.py').read_text())
        for name in ['intersection_volume', 'normalized_mesh']:
            get = lambda t: next(n for n in t.body if isinstance(n, ast.FunctionDef) and n.name == name)
            self.assertEqual(ast.dump(get(a), include_attributes=False), ast.dump(get(b), include_attributes=False))
        text = (HERE/'source/inspect_candidate_brep.py').read_text()
        for literal in ['np.arange(64)', 'np.linspace(-15.9,3.9,17)', 'trimesh.boolean.intersection',
                        'collision_volume<=1e-5', 'max(preserved.values())<=1e-5']:
            self.assertIn(literal, text)

    def test_no_GO_and_wrong_resources_refuse_without_native_import(self):
        with self.assertRaises(ValueError): caller.require_GO(dict(launch_ready=False, root_GO_sha256=None))
        with self.assertRaises(ValueError): caller.verify(dict(schema='wrong'))

    def test_legacy_mass_flag_is_not_overridden(self):
        value = dict(checker_returned=True, actual_inspection=dict(nominal_mass_kg=1.2624,
                     mass_ceiling_pass=False, study_assembly_screen_pass=True))
        self.assertTrue(caller.measured_flags(value))
        self.assertFalse(value['legacy_mass_flag_retained_without_override'])
        value['actual_inspection']['nominal_mass_kg'] = 1.3000001
        self.assertFalse(caller.measured_flags(value))

    def test_strict_new_containment_and_legacy_law_status(self):
        plan = dict(CAD_source=dict(format='brep', sha256=factory.MASTER,
                    filename='candidate-native.brep'), STL_sha256=factory.STL)
        terminal = dict(status='actual_owned_RC0_strict_native_empty_all_outputs_and_pins_verified',
            actual_tool_and_child_returncode=0, direct_child_reaped=True, owned_group_empty=True,
            all_current_pins_equal=True, timeout=False, cleanup_error=None,
            original_law_refusal_preserved=True, candidate_qualified=False,
            residue=dict(native_valid=True, native_topologically_empty=True,
                         counts=dict(solids=0, faces=0, edges=0, vertices=0), bounds_mm=None))
        factory.validate_binding(plan, terminal)
        for key, value in [('actual_tool_and_child_returncode', 1), ('owned_group_empty', False),
                           ('original_law_refusal_preserved', False), ('candidate_qualified', True)]:
            bad = copy.deepcopy(terminal); bad[key] = value
            with self.assertRaises(ValueError): factory.validate_binding(plan, bad)
        bad = copy.deepcopy(terminal); bad['residue']['counts']['vertices'] = 1
        with self.assertRaises(ValueError): factory.validate_binding(plan, bad)

    def test_closed_ROOT_reviews_cannot_cross_individually_valid_receipts(self):
        with tempfile.TemporaryDirectory() as name:
            directory = Path(name)
            paths = {k: directory/k for k in ['containment', 'joint', 'containment_root', 'joint_root']}
            paths['containment'].write_text('closed containment')
            paths['joint'].write_text('closed inverse')
            plan = dict(containment_terminal=str(paths['containment']), joint_surface_terminal=str(paths['joint']),
                        containment_root_review=str(paths['containment_root']), joint_root_review=str(paths['joint_root']))
            containment = dict(status='closed_actual_RC0_strict_baseline_minus_preserved_taper_topologically_empty',
                actual_tool_RC=0, terminal_sha256=caller.sha(paths['containment']), raw_candidate_BREP_sha256=caller.MASTER,
                all7_whole_files_and_logs_verified=True, fresh_owned_group_members=[], law_original_RC1_unchanged=True)
            inverse = dict(status='closed_actual_RC0_new_surface_topology_inverse_pass', actual_tool_RC=0,
                terminal_sha256=caller.sha(paths['joint']), whole_joint_sha256='joint-report',
                fresh_owned_container_absent=True, all7_whole_outputs_and_logs_matched=True,
                actual_triangles=637836, all_topology_defects_zero=True, self_intersection_pairs=0,
                law_RC1_retained=True, candidate_qualified=False)
            for key, value in [('containment_root', containment), ('joint_root', inverse)]:
                paths[key].write_text(json.dumps(value))
            caller.verify_closed_reviews(plan, dict(joint_audit_sha256='joint-report'))
            for key, record in [('containment_root', containment), ('joint_root', inverse)]:
                bad = copy.deepcopy(record); bad['terminal_sha256'] = 'different but individually valid receipt'
                paths[key].write_text(json.dumps(bad))
                with self.assertRaises(ValueError): caller.verify_closed_reviews(plan, dict(joint_audit_sha256='joint-report'))
                paths[key].write_text(json.dumps(record))


if __name__ == '__main__':
    unittest.main()
