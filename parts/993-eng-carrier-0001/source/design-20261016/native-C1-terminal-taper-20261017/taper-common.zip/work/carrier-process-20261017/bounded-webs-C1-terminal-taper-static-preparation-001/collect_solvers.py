"""Seal actual solver tool returns, owned-container closure and complete outputs."""
import copy
import hashlib
import json
import os
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]


def require(ok, message):
    if not ok:
        raise ValueError(message)


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


def main():
    go_path = HERE / 'root-solver-GO-001.json'
    go_sha = sha(go_path)
    require(go_sha == 'e3e11e99acad720d47f1e51b150acaca5b07979dc15c90ce8b47f1c4bc17e7a6', 'Actual solver GO differs')
    go = read(go_path)
    actual = {'rigid': (7438, 'f4e539', '0644e9'), 'spring': (8317, 'e9f0b8', 'e12d57')}
    report = dict(status='two_actual_linear_static_cases_closed_no_qualification', cases={},
                  root_solver_GO_sha256=go_sha, collector_sha256=sha(__file__), scientific_imports=False,
                  candidate_qualified=False, law_original_RC1_preserved=True,
                  convergence_or_strength_threshold_added=False, physical_validation=False)
    for case, (handle, initial, terminal) in actual.items():
        output = HERE / (case + '-001')
        command = read(HERE / (case + '-solver-command.json'))
        pending_path = HERE / (case + '-solver-pending-command.json')
        pending = read(pending_path)
        inverse = copy.deepcopy(command)
        for key in go['command_arming_changes_only']:
            inverse[key] = pending[key]
        require(inverse == pending and sha(pending_path) == go['cases'][case]['pending_command_sha256']
                and command['argv'] == go['cases'][case]['exact_argv'], 'Whole command inverse or original argv differs')
        plan_path = output / 'case-plan.json'
        plan = read(plan_path)
        require(sha(plan_path) == go['cases'][case]['case_plan_sha256'], 'Prepared case plan changed')
        current = {name: sha(ROOT / name) for name in plan['files_sha256']}
        require(current == plan['files_sha256'], 'Current frozen input/source/runtime differs')
        assessment = read(output / 'assessment.json')
        native = read(output / 'execution/native-receipt.json')
        native_plan = read(output / 'execution/native-plan.json')
        energy = read(output / 'energy-audit.json')
        peaks = read(output / 'global-peaks.json')
        require(assessment['status'] == 'actual_linear_static_and_independent_energy_completed'
                and assessment['plan_unchanged'] and assessment['within_case_budget']
                and assessment['sources_before'] == assessment['sources_after'] == current,
                'Actual numeric closeout or whole source maps differ')
        require(native['status'] == 'solver_executed_no_numeric_admission'
                and native['actual_container_exit_code'] == native['attach_cli_returncode'] == 0
                and native['container_removed'] and native['input_hashes_unchanged']
                and native['within_global_budget'] and native['global_admission'] is False
                and native['native_plan_sha256'] == sha(output / 'execution/native-plan.json')
                and native['helper_source_sha256'] == plan['helper_sha256'], 'Actual owned-container cleanup differs')
        require({n: sha(Path(n)) for n in native_plan['files_sha256']} == native_plan['files_sha256'], 'Actual solver input pins differ')
        identity = native['actual_container_before_start']
        require(identity['Name'] == '/' + plan['container_name'] and identity['Owner'] == plan['ownership_token']
                and identity['Id'] == native['container_id'] and identity['Image'] == plan['image']
                and identity['NanoCpus'] == 10**9 and identity['Memory'] == identity['MemorySwap'] == 6 * 1024**3
                and identity['NetworkMode'] == 'none', 'Actual container identity/resources differ')
        require(sha(output / 'execution/prepared-deck.inp') == go['cases'][case]['prepared_deck_sha256']
                and sha(output / 'execution/load-and-supports.json') == go['cases'][case]['prepared_load_support_sha256']
                and sha(output / 'energy-audit.json') == assessment['energy_audit_sha256']
                and sha(output / 'global-peaks.json') == assessment['global_peaks_sha256'], 'Whole diagnostic output binding differs')
        require(energy['energy_closure_pass'] and energy['tolerance'] == 1e-4
                and peaks['no_peak_excluded'] and len(peaks['all_global_maximum_ties']) == peaks['maximum_ties']
                and peaks['maximum_VM_MPa'] == assessment['native_result']['integration_point_VM_max_MPa']
                and assessment['candidate_qualified'] is False and assessment['law_original_RC1_preserved'], 'Energy/all-peak scope differs')
        files = [p for base in (output, HERE / (case + '-solver-host-001')) for p in base.rglob('*') if p.is_file()]
        require(not any(p.is_symlink() for p in files), 'Symbolic actual outputs refused')
        report['cases'][case] = dict(actual_tool_handle=handle, actual_initial_chunk=initial,
            actual_terminal_chunk=terminal, actual_tool_returncode=0, actual_container_returncode=0,
            attach_cli_returncode=0, owned_container_removed=True, native_container_id=native['container_id'],
            entire_command_inverse_equal=True, current_case_pin_count=len(current), all_current_pins_equal=True,
            case_plan_sha256=sha(plan_path), assessment_sha256=sha(output / 'assessment.json'),
            native_receipt_sha256=sha(output / 'execution/native-receipt.json'),
            whole_outputs_sha256={str(p.relative_to(ROOT)): sha(p) for p in sorted(files)},
            whole_output_bytes=sum(p.stat().st_size for p in files), actual_native_result=assessment['native_result'],
            independent_energy_audit=energy, all_global_peak_ties=peaks,
            interpretation='Actual new global7 mesh and retained assumed physics; no convergence, strength or manufacturing qualification')
    target = HERE / 'solver-terminal-collection.json'
    with target.open('x') as stream:
        json.dump(report, stream, indent=2, allow_nan=False)
        stream.write('\n'); stream.flush(); os.fsync(stream.fileno())
    print(json.dumps(dict(status=report['status'], terminal_sha256=sha(target), cases=list(report['cases']))))


if __name__ == '__main__':
    main()
