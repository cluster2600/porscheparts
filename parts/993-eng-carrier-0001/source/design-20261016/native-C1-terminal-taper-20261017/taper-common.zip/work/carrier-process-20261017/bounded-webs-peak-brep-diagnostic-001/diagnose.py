"""Read-only native BREP neighbourhood of the common two-case stress maximum."""
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import resource
import signal
import sys
import time

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def run():
    started = time.monotonic()
    plan = json.loads((HERE / 'plan.json').read_text())
    assert plan['bounds'] == dict(wall_seconds=150, CPU_seconds=140, CPU_hard_seconds=141, threads=1, workers=0)
    before = {name: sha(ROOT / name) for name in plan['files_sha256']}
    assert before == plan['files_sha256']
    output = ROOT / plan['output_directory']
    assert not output.exists() and not output.is_symlink()
    output.mkdir()
    signal.signal(signal.SIGALRM, lambda *_: (_ for _ in ()).throw(TimeoutError('Native diagnostic wall budget')))
    signal.alarm(150)
    resource.setrlimit(resource.RLIMIT_CPU, (140, 141))
    sys.path.insert(0, str(ROOT / plan['native_site']))
    import numpy as np
    from build123d import import_step
    from OCP.BRep import BRep_Tool
    from OCP.BRepAdaptor import BRepAdaptor_Curve, BRepAdaptor_Surface
    from OCP.BRepBuilderAPI import BRepBuilderAPI_MakeVertex
    from OCP.BRepExtrema import BRepExtrema_DistShapeShape
    from OCP.OSD import OSD_ThreadPool
    from OCP.Precision import Precision
    from OCP.gp import gp_Pnt
    OSD_ThreadPool.DefaultPool_s().Init(1)
    energy = load('_peak_energy', ROOT / plan['energy_source'])
    locate = load('_peak_location', ROOT / plan['location_source'])
    normals = load('_retained_boundary_normals', ROOT / plan['boundary_normal_source'])
    peaks = [json.loads((ROOT / name).read_text()) for name in plan['peak_files']]
    rows = [item['all_global_maximum_ties'] for item in peaks]
    assert all(len(row) == 1 for row in rows)
    common = rows[0][0]
    keys = ('element_id', 'IP_one_based', 'reference_undeformed_IP_xyz_mm')
    assert all(all(row[0][key] == common[key] for key in keys) for row in rows)
    tags, xyz, eids, conn = energy.read_mesh(ROOT / plan['mesh'])
    selected = np.flatnonzero(eids == common['element_id'])
    assert len(selected) == 1
    indices = conn[int(selected[0])]
    nodes = xyz[indices].tolist()
    point = locate.gauss_point(nodes, common['IP_one_based'])
    assert point == common['reference_undeformed_IP_xyz_mm']
    body = import_step(ROOT / plan['STEP'])
    assert body.is_valid and len(body.solids()) == 1
    faces, edges = list(body.faces()), list(body.edges())
    face_edges = [list(face.edges()) for face in faces]

    def query(p, shape):
        result = BRepExtrema_DistShapeShape(BRepBuilderAPI_MakeVertex(gp_Pnt(*p)).Shape(), shape.wrapped)
        result.SetMultiThread(False)
        result.Perform()
        assert result.IsDone() and result.NbSolution() > 0 and math.isfinite(result.Value())
        return result

    def bounds(shape):
        box = shape.bounding_box()
        return [list(box.min), list(box.max)]

    def surface_info(index):
        face = faces[index]
        native = BRepAdaptor_Surface(face.wrapped, True)
        kind = str(native.GetType())
        row = dict(face_index_zero_based=index, topological_type=str(face.wrapped.ShapeType()),
                   surface_type=kind, bounds_mm=bounds(face), area_mm2=face.area,
                   orientation=str(face.wrapped.Orientation()), tolerance_mm=BRep_Tool.Tolerance_s(face.wrapped))
        if kind.endswith('GeomAbs_Plane'):
            plane = native.Plane()
            row['plane'] = dict(location_mm=list(plane.Location().Coord()), normal=list(plane.Axis().Direction().Coord()))
        for suffix, method in [('Cylinder', 'Cylinder'), ('Sphere', 'Sphere')]:
            if kind.endswith('GeomAbs_' + suffix):
                row['radius_mm'] = getattr(native, method)().Radius()
        if kind.endswith('GeomAbs_Cone'):
            row['cone'] = dict(reference_radius_mm=native.Cone().RefRadius(), semi_angle_radians=native.Cone().SemiAngle())
        if kind.endswith('GeomAbs_Torus'):
            row['torus'] = dict(major_radius_mm=native.Torus().MajorRadius(), minor_radius_mm=native.Torus().MinorRadius())
        return row

    def edge_info(index, result):
        edge = edges[index]
        native = BRepAdaptor_Curve(edge.wrapped)
        kind = str(native.GetType())
        adjacent = [i for i, items in enumerate(face_edges) if any(edge.wrapped.IsSame(item.wrapped) for item in items)]
        row = dict(edge_index_zero_based=index, topological_type=str(edge.wrapped.ShapeType()), curve_type=kind,
                   bounds_mm=bounds(edge), length_mm=edge.length, tolerance_mm=BRep_Tool.Tolerance_s(edge.wrapped),
                   adjacent_faces_zero_based=adjacent, adjacent_surface_types=[surface_info(i)['surface_type'] for i in adjacent])
        if kind.endswith('GeomAbs_Circle'):
            row['radius_mm'] = native.Circle().Radius()
        if len(adjacent) == 2:
            row['native_continuity'] = str(BRep_Tool.Continuity_s(edge.wrapped, *(faces[i].wrapped for i in adjacent)))
            try:
                parameter = result.ParOnEdgeS2(1)[0]
                evaluated = [normals.boundary_normal(edge, faces[i], parameter) for i in adjacent]
                n = [item[0] for item in evaluated]
                row['boundary_normal_probe'] = dict(edge_parameter=parameter,
                    edge_point_mm=list(native.Value(parameter).Coord()), outward_normals=[v.tolist() for v in n],
                    normal_angle_degrees=math.degrees(math.atan2(float(np.linalg.norm(np.cross(*n))), float(n[0] @ n[1]))),
                    supports=[item[1] for item in evaluated])
            except (RuntimeError, ValueError) as error:
                row['boundary_normal_probe_error'] = str(error)
        return row

    probes = []
    for label, p in [('common_IP', point), *[(f'corner_{i}', p) for i, p in enumerate(nodes[:4])]]:
        face_queries = [(query(p, face), i) for i, face in enumerate(faces)]
        edge_queries = [(query(p, edge), i) for i, edge in enumerate(edges)]
        face_queries.sort(key=lambda pair: (pair[0].Value(), pair[1]))
        edge_queries.sort(key=lambda pair: (pair[0].Value(), pair[1]))
        fr, er = [], []
        # Nearest eight plus every exact float tie at the eighth distance; no geometric threshold.
        for result, i in face_queries:
            if len(fr) >= 8 and result.Value() != fr[7]['distance_mm']:
                break
            fr.append(dict(**surface_info(i), distance_mm=result.Value(),
                           closest_points_mm=[list(result.PointOnShape2(k).Coord()) for k in range(1, result.NbSolution()+1)]))
        for result, i in edge_queries:
            if len(er) >= 8 and result.Value() != er[7]['distance_mm']:
                break
            er.append(dict(**edge_info(i, result), distance_mm=result.Value(),
                           closest_points_mm=[list(result.PointOnShape2(k).Coord()) for k in range(1, result.NbSolution()+1)]))
        probes.append(dict(label=label, point_mm=p, face_queries=len(face_queries), edge_queries=len(edge_queries),
                           nearest_faces=fr, nearest_edges=er))
    after = {name: sha(ROOT / name) for name in before}
    assert before == after
    report = dict(schema='current-two-case-peak-native-BREP-diagnostic-1', status='complete_readonly_diagnostic',
        common_peak={key: common[key] for key in keys}, peak_VM_MPa_by_case={p['case']: p['maximum_VM_MPa'] for p in peaks},
        element_node_ids=tags[indices].tolist(), element_nodes_mm=nodes, STEP_faces=len(faces), STEP_edges=len(edges),
        native_confusion_mm=Precision.Confusion_s(), probes=probes, sources_before=before, sources_after=after,
        sources_unchanged=True, elapsed_seconds=time.monotonic()-started,
        native_distance_scope='OCCT BRepExtrema minimum-distance queries with default native deflection, single-threaded; not rational exact arithmetic.',
        normal_scope='Retained SameParameter pcurve/D1 evaluator, oriented outward normals at each reported nearest edge point. Native continuity flags are reported, not promoted to an all-parameter smoothness proof.',
        concavity_or_singularity_classification=None, CAD_changed=False, remeshed=False, FEA_executed=False,
        physical_validation=False, manufacturing_authorized=False)
    with (output / 'assessment.json').open('x') as stream:
        json.dump(report, stream, indent=2, allow_nan=False); stream.write('\n')
    signal.alarm(0)
    print(json.dumps(dict(status=report['status'], assessment_sha256=sha(output/'assessment.json'),
                          STEP_faces=len(faces), STEP_edges=len(edges), elapsed_seconds=report['elapsed_seconds'])), flush=True)


if __name__ == '__main__':
    run()
