# Immutable arming proposal — no execution

The original `plan.json`, `command.json` and all captured sources remain untouched. `../control-armed-001/run.py` is a byte-identical copy of the frozen caller. Its `HERE/plan.json` is deliberately absent, so there is no operational command or armed plan yet.

After a separate actual ROOT GO, derive the final plan from `plan-template.json`: change only status/preparation/readiness and actual GO path/SHA, and add the GO pin. The template adds only the copied caller pin. Keep all original 37 pins, original source directory, original fresh output/execution destinations and all resources unchanged. Write final plan/command exclusively; bind the command to the actual final plan SHA and the copied caller path.

Before any launch, remove the two added pins and restore the five declared values in memory; serialization must match the entire original plan bytes. Rehash every final pin and prove both frozen originals unchanged. `source-only-check.json` records only a sentinel JSON inverse fixture, not a real GO or an execution.
