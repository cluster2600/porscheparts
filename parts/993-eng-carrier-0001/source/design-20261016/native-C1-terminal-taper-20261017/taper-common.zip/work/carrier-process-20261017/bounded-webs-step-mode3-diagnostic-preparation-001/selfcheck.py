"""Stdlib-only restoration and scope tests; no native imports or STEP reading."""
import ast
from pathlib import Path
import unittest

HERE=Path(__file__).resolve().parent
SOURCE=HERE/'diagnose.py'
TREE=ast.parse(SOURCE.read_text())
NODE=next(n for n in TREE.body if isinstance(n,ast.FunctionDef)and n.name=='read_candidate_mode3')
NS={'MODE':'read.surfacecurve.mode'}
exec(compile(ast.fix_missing_locations(ast.Module(body=[NODE],type_ignores=[])),str(SOURCE),'exec'),NS)
READ=NS['read_candidate_mode3']

class Interface:
    def __init__(self,value=0,reject3=False,rejectrestore=False):
        self.value=value;self.reject3=reject3;self.rejectrestore=rejectrestore;self.calls=[]
    def IVal_s(self,key):return self.value
    def SetIVal_s(self,key,value):
        self.calls.append((key,value))
        if (value==3 and self.reject3)or(value==0 and self.rejectrestore):return False
        self.value=value;return True

class Restore(unittest.TestCase):
    def test_success_candidate_only_then_original(self):
        api=Interface();record={};sentinel=object()
        def importer(path):
            self.assertEqual(path,'existing-candidate.step');self.assertEqual(api.value,3);return sentinel
        self.assertIs(READ('existing-candidate.step',importer,api,record),sentinel)
        self.assertEqual(api.value,0);self.assertTrue(record['restored'])
        self.assertEqual([value for _,value in api.calls],[3,0])
    def test_import_failure_restores(self):
        api=Interface();record={}
        def importer(path):raise RuntimeError('native import refused')
        with self.assertRaisesRegex(RuntimeError,'native import refused'):READ('candidate',importer,api,record)
        self.assertEqual(api.value,0);self.assertTrue(record['restored'])
    def test_rejected_setting_and_failed_restore_refuse(self):
        api=Interface(reject3=True);record={}
        with self.assertRaisesRegex(ValueError,'not accepted'):READ('candidate',lambda p:None,api,record)
        self.assertEqual(api.value,0);self.assertTrue(record['restored'])
        api=Interface(rejectrestore=True);record={}
        with self.assertRaisesRegex(ValueError,'restoration failed'):READ('candidate',lambda p:None,api,record)
        self.assertFalse(record['restored'])
    def test_nonzero_initial_mode_not_changed(self):
        api=Interface(2)
        with self.assertRaisesRegex(ValueError,'must be0'):READ('candidate',lambda p:None,api,{})
        self.assertEqual(api.value,2);self.assertEqual(api.calls,[])
    def test_one_cut_no_writer_cast_or_fillet(self):
        calls=[n for n in ast.walk(TREE)if isinstance(n,ast.Call)]
        self.assertEqual(sum(isinstance(n.func,ast.Attribute)and n.func.attr=='Build'for n in calls),1)
        self.assertFalse(any(isinstance(n.func,ast.Attribute)and n.func.attr in ('cast','DSFiller','SetTolerance','SetFuzzy')for n in calls))
        self.assertFalse(any(isinstance(n.func,ast.Name)and n.func.id.startswith('export_')for n in calls))
        for n in ast.walk(TREE):
            if isinstance(n,ast.ImportFrom):self.assertFalse(any(v.name=='Solid'for v in n.names))
    def test_summary_math_AST_unchanged(self):
        old=HERE.with_name('bounded-webs-contour1-native-cut-diagnostic-003')/'diagnose_raw.py'
        def function(tree,name):return next(n for n in ast.walk(tree)if isinstance(n,ast.FunctionDef)and n.name==name)
        before=ast.parse(old.read_text())
        for name in ('summary','entities','bbox'):
            self.assertEqual(ast.dump(function(before,name),include_attributes=False),ast.dump(function(TREE,name),include_attributes=False))

if __name__=='__main__':unittest.main()
