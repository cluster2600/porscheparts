"""Strict whole-inverse arming of the one reviewed original-C1 scalar-terminal prototype."""
import copy,hashlib,importlib.util,json,os,time
from pathlib import Path
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[2]
def sha(path):
 h=hashlib.sha256()
 with Path(path).open('rb')as f:
  for b in iter(lambda:f.read(1024**2),b''):h.update(b)
 return h.hexdigest()
def write(name,value):
 with(HERE/name).open('x')as f:json.dump(value,f,indent=2,allow_nan=False);f.write('\n');f.flush();os.fsync(f.fileno())
def rel(p):return str(p.relative_to(ROOT))
start=time.monotonic();expected={'pending-plan.json':'c7cfe1c997d93a258c1aadb8c0499bc7d33e739217c5ca6f18e906b93e478fc8','pending-launch-plan.json':'7f94e8a4f83ff3d226ca960712655a44652a5bfc9ffd3ac42920779a5a2cabcb','build_taper.py':'0824f9f715210aa990703114abcbe8fe27310afdc17442646eb5799191b40ff1','root-review-GO-001.json':'6fabee80517ba4c4767c36a5a3f6597db3e83ac3b27ceaa06bcd7a4b6a1dc54c'}
assert {n:sha(HERE/n)for n in expected}==expected
original=json.loads((HERE/'pending-plan.json').read_text());oldlaunch=json.loads((HERE/'pending-launch-plan.json').read_text());go=json.loads((HERE/'root-review-GO-001.json').read_text())
assert go['status']=='GO_one_scalar_terminal_final_Build_and_local_gates' and go['source_sha256']==expected['build_taper.py'] and original['launch_ready']is False and original['root_GO']is None
for key in ['output_directory','execution_directory']:
 p=ROOT/original[key];assert not p.exists()and not any(q.is_symlink()for q in [p,*p.parents])
gkey=rel(HERE/'root-review-GO-001.json');plan=copy.deepcopy(original);plan['launch_ready']=True;plan['root_GO']=gkey;plan['root_GO_sha256']=expected['root-review-GO-001.json'];plan['files_sha256'][gkey]=expected['root-review-GO-001.json']
inverse=copy.deepcopy(plan);inverse['launch_ready']=False;inverse['root_GO']=None;del inverse['root_GO_sha256'];del inverse['files_sha256'][gkey];assert inverse==original
write('armed-plan.json',plan);psha=sha(HERE/'armed-plan.json')
launch=copy.deepcopy(oldlaunch);launch['launch_ready']=True;assert launch['command'][-2:]==[str(HERE/'pending-plan.json'),expected['pending-plan.json']]
launch['command'][-2:]=[str(HERE/'armed-plan.json'),psha];launch['inputs_sha256'][gkey]=expected['root-review-GO-001.json'];akey=rel(HERE/'armed-plan.json');launch['inputs_sha256'][akey]=psha
inverse=copy.deepcopy(launch);inverse['launch_ready']=False;inverse['command'][-2:]=oldlaunch['command'][-2:];del inverse['inputs_sha256'][gkey];del inverse['inputs_sha256'][akey];assert inverse==oldlaunch
pins={**launch['inputs_sha256'],**launch['source_sha256']};assert {n:sha(ROOT/n)for n in pins}==pins
spec=importlib.util.spec_from_file_location('_R1_arming_stdlib',HERE/'build_taper.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);checked,_,_=module.verify(HERE/'armed-plan.json',psha,native=True);assert checked==plan
write('launch-plan.json',launch);lsha=sha(HERE/'launch-plan.json');argv=[str(ROOT/'work/part-workflow/runtimes/geometry-standalone/bin/python'),'-I','-B',str(ROOT/'work/carrier-process-20261017/source010-exposure-preflight-003/supervise.py'),str(HERE/'launch-plan.json'),'--plan-sha256',lsha]
write('armed-command.json',dict(schema='one_owned_original_C1_scalar_terminal_taper_command',argv=argv,root_GO_sha256=expected['root-review-GO-001.json'],candidate_qualified=False))
write('arming-assessment.json',dict(status='strict_whole_inverse_and_fresh_pins_PASS_no_native_run',root_GO_sha256=expected['root-review-GO-001.json'],source_sha256=expected['build_taper.py'],arming_source_sha256=sha(__file__),plan_sha256=psha,launch_sha256=lsha,command_sha256=sha(HERE/'armed-command.json'),whole_plan_inverse_equal=True,whole_launch_inverse_equal=True,unique_pins=len(pins),all_pins_actual_equal=True,fresh_output_and_execution=True,elapsed_seconds=time.monotonic()-start))
print(json.dumps(dict(status='armed_no_native_run_yet',plan_sha256=psha,launch_sha256=lsha,unique_pins=len(pins),arming_sha256=sha(HERE/'arming-assessment.json'))))
