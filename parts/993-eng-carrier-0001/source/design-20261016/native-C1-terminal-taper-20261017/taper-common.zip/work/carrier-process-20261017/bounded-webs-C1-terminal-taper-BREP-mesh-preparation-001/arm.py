"""Strict full-inverse readiness/GO/path pin arming only; no mesh operation."""
import copy,hashlib,importlib.util,json,os,sys,time
from pathlib import Path
H=Path(__file__).resolve().parent;R=H.parents[2]
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(p,x):
 with p.open('x')as f:json.dump(x,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
rel=lambda p:str(p.relative_to(R));start=time.monotonic();expected={'run.py':'a9e1c2c65df3a45c0711b81b2f655352c348fa0d2054e9ed453e204e2771d00b','pending-plan.json':'825d1e6f59d9c6531f6be709e53e1589f22b320e5dd069c6c32a70cb54d1cb29','pending-launch-plan.json':'af4537eceaa30e90cdfffdc5109f6a034f23565a672ac6823e21c3e35539f733','root-review-GO-001.json':'964dbf258f3c9089e902ecdebd978d0767233c8f14cd25684b8776b6dcb732aa'}
assert {n:sha(H/n)for n in expected}==expected
old=json.loads((H/'pending-plan.json').read_text());ol=json.loads((H/'pending-launch-plan.json').read_text());assert old['launch_ready']is False and old['root_GO']is None and old['root_GO_sha256']is None and ol['launch_ready']is False
g=H/'root-review-GO-001.json';gk=rel(g);p=copy.deepcopy(old);p.update(launch_ready=True,root_GO=gk,root_GO_sha256=expected[g.name]);p['files_sha256'][gk]=expected[g.name]
inv=copy.deepcopy(p);inv.update(launch_ready=False,root_GO=None,root_GO_sha256=None);del inv['files_sha256'][gk];assert inv==old
write(H/'plan.json',p);ph=sha(H/'plan.json');l=copy.deepcopy(ol);l['launch_ready']=True;pk=rel(H/'pending-plan.json');ak=rel(H/'plan.json');assert l['inputs_sha256'].pop(pk)==expected['pending-plan.json'];l['inputs_sha256'][ak]=ph;l['inputs_sha256'][gk]=expected[g.name]
inv=copy.deepcopy(l);inv['launch_ready']=False;del inv['inputs_sha256'][ak];del inv['inputs_sha256'][gk];inv['inputs_sha256'][pk]=expected['pending-plan.json'];assert inv==ol
pins={**l['inputs_sha256'],**l['source_sha256']};assert {n:sha(R/n)for n in pins}==pins
s=importlib.util.spec_from_file_location('_T10_arm_stdlib_only',H/'run.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m);m.verify(True);assert not any(n.split('.')[0]in ['OCP','gmsh','numpy']for n in sys.modules)
assert not(R/p['execution_directory']).exists()
write(H/'launch-plan.json',l);sup=R/'work/carrier-process-20261017/source010-exposure-preflight-003/supervise.py';argv=[p['python_executable'],'-I','-B',str(sup),str(H/'launch-plan.json'),'--plan-sha256',sha(H/'launch-plan.json')]
write(H/'command.json',dict(argv=argv,root_GO_sha256=expected[g.name]));write(H/'arming-assessment.json',dict(status='strict_full_inverse_and_fresh_pins_PASS_before_mesh',source_sha256=expected['run.py'],plan_sha256=ph,launch_sha256=sha(H/'launch-plan.json'),command_sha256=sha(H/'command.json'),root_GO_sha256=expected[g.name],whole_plan_inverse_equal=True,whole_launch_inverse_equal=True,all_pins_actual_equal=True,unique_pins=len(pins),actual_stdlib_verify_master_PASS=True,no_scientific_imports=True,arming_source_sha256=sha(__file__),elapsed_seconds=time.monotonic()-start))
print(json.dumps(dict(plan_sha256=ph,launch_sha256=sha(H/'launch-plan.json'),command_sha256=sha(H/'command.json'),arming_sha256=sha(H/'arming-assessment.json'),pins=len(pins))))
