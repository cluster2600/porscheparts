"""Strict whole-inverse arming of the reviewed preserved-taper Gmsh surface stage."""
import copy,hashlib,importlib.util,json,os,time
from pathlib import Path
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[2]
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb')as f:
  for b in iter(lambda:f.read(1024**2),b''):h.update(b)
 return h.hexdigest()
def write(p,d):
 with p.open('x')as f:json.dump(d,f,indent=2,allow_nan=False);f.write('\n');f.flush();os.fsync(f.fileno())
rel=lambda p:str(p.relative_to(ROOT));start=time.monotonic()
expected={'pending-plan.json':'56d6c6449dda04fa250a1773c2bb1819970bf20fba658fb1d0754da33208999f','pending-launch-plan.json':'193f0efda8b09fc7e86b724843a4a5c03e821f01cecf115ea92993a2719dd2da','run_meshing.py':'d602fd5fc6eea740e191681abd6142e8beac7badeda7d55e4eef3046f3562003','root-review-GO-001.json':'25b36cbfb2589860886c50496dc7235a99f48eaa71ebf1ba5d86c4f43349c7d1'}
assert {n:sha(HERE/n)for n in expected}==expected
old=json.loads((HERE/'pending-plan.json').read_text());oldlaunch=json.loads((HERE/'pending-launch-plan.json').read_text());assert old['launch_ready']is False and old['root_GO']is None and old['root_GO_sha256']is None and oldlaunch['launch_ready']is False
for k in ('output_directory','execution_directory'):
 p=Path(old[k]);assert not p.exists()and not any(q.is_symlink()for q in [p,*p.parents])
go=HERE/'root-review-GO-001.json';plan=copy.deepcopy(old);plan['launch_ready']=True;plan['root_GO']=str(go);plan['root_GO_sha256']=expected['root-review-GO-001.json'];plan['files_sha256'][str(go)]=expected['root-review-GO-001.json']
inverse=copy.deepcopy(plan);inverse['launch_ready']=False;inverse['root_GO']=None;inverse['root_GO_sha256']=None;del inverse['files_sha256'][str(go)];assert inverse==old
write(HERE/'plan.json',plan);psha=sha(HERE/'plan.json');launch=copy.deepcopy(oldlaunch);launch['launch_ready']=True;pk=rel(HERE/'pending-plan.json');ak=rel(HERE/'plan.json');gk=rel(go);assert launch['inputs_sha256'].pop(pk)==expected['pending-plan.json'];launch['inputs_sha256'][ak]=psha;launch['inputs_sha256'][gk]=expected['root-review-GO-001.json']
inverse=copy.deepcopy(launch);inverse['launch_ready']=False;del inverse['inputs_sha256'][ak];del inverse['inputs_sha256'][gk];inverse['inputs_sha256'][pk]=expected['pending-plan.json'];assert inverse==oldlaunch
pins={**launch['inputs_sha256'],**launch['source_sha256']};assert {n:sha(ROOT/n)for n in pins}==pins
s=importlib.util.spec_from_file_location('_surface_stdlib_arm',HERE/'run_meshing.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m);m.verify(plan)
write(HERE/'launch-plan.json',launch);lsha=sha(HERE/'launch-plan.json');argv=[str(ROOT/'work/part-workflow/runtimes/geometry-standalone/bin/python'),'-I','-B',str(ROOT/'work/carrier-process-20261017/source010-exposure-preflight-003/supervise.py'),str(HERE/'launch-plan.json'),'--plan-sha256',lsha]
write(HERE/'command.json',dict(argv=argv,root_GO_sha256=expected['root-review-GO-001.json'],candidate_qualified=False))
write(HERE/'arming-assessment.json',dict(status='strict_whole_inverse_and_fresh_pins_PASS_no_native_run',root_GO_sha256=expected['root-review-GO-001.json'],source_sha256=expected['run_meshing.py'],arming_source_sha256=sha(__file__),plan_sha256=psha,launch_sha256=lsha,command_sha256=sha(HERE/'command.json'),whole_plan_inverse_equal=True,whole_launch_inverse_equal=True,unique_pins=len(pins),all_pins_actual_equal=True,fresh_output_and_execution=True,retained_Gmsh_threads=2,elapsed_seconds=time.monotonic()-start))
print(json.dumps(dict(plan_sha256=psha,launch_sha256=lsha,arming_sha256=sha(HERE/'arming-assessment.json'),command_sha256=sha(HERE/'command.json'),unique_pins=len(pins))))
