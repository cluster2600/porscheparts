"""Seal the actual forward sampled screen; no CAD or scientific module import."""
import ast,importlib.util,json,os,struct,time,zipfile
from pathlib import Path
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[2]
s=importlib.util.spec_from_file_location('_screen_terminal_stdlib',HERE/'run_brep_audit.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m);sha=m.sha
read=lambda p:json.loads(p.read_text());start=time.monotonic();p=read(HERE/'plan.json');launch=read(HERE/'launch-plan.json');sup=read(HERE/'execution-001/execution-receipt.json');a=read(HERE/'output-001/assessment.json');native=read(HERE/'output-001/native/brep-audit.json');whole=read(HERE/'output-001/whole-candidate-native-summary.json')
assert sha(HERE/'launch-plan.json')=='226b49db49cf92accbc3bf0c4808a8ffeaabc0ed70a7398e3ef01b55a3081b74'
assert sup['plan_sha256']==sha(HERE/'launch-plan.json')and sup['command']==launch['command']and sup['actual_returncode']==0 and sup['status']=='executed'
assert sup['direct_child_reaped']and sup['final_group_members']==[]and sup['no_non_zombie_group_members']and sup['cleanup_error']is None and sup['failure']is None and not sup['timeout']and not sup['interrupted']and sup['signals_to_owned_group_only']==[]
pins={**launch['inputs_sha256'],**launch['source_sha256']};assert sup['sources_before']==sup['sources_after']==pins and sup['sources_and_plan_unchanged']and {n:sha(ROOT/n)for n in pins}==pins
assert a['sources_runtime_before']==a['sources_runtime_after']==p['files_sha256']and a['inputs_runtime_plan_unchanged']
assert a['status']=='sampled_mesh_to_BREP_passed_pending_inverse_and_topology'and a['sampled_forward_chord_pass']is True and a['whole_candidate_native_summary']==whole
assert native['CAD_source']==dict(format='brep',sha256=p['master_sha256'],path=p['master_BREP'])and native['results']['candidate_STL']['sha256']==p['surface_sha256']and native['candidate_sampled_chord_screen_pass']is True and native['results']['candidate_STL']['maximum_distance_to_BREP_shell_mm']<=.06
assert whole['native_valid']is True and whole['counts']['solids']==whole['counts']['shells']==1
assert a['candidate_qualified']is False and a['law_status']=='original_post_Build_law_RC1_preserved'and all(v=='PENDING'for v in a['downstream_checks'].values())and a['FEA_executed']is False
for name,h in sup['logs_sha256'].items():assert sha(HERE/'execution-001'/name)==h
for name,row in a['outputs'].items():assert sha(HERE/'output-001/native'/name)==row['sha256']and(HERE/'output-001/native'/name).stat().st_size==row['bytes']
def shape(path,member):
 with zipfile.ZipFile(path)as z:
  with z.open(member+'.npy')as f:
   assert f.read(6)==b'\x93NUMPY';version=tuple(f.read(2));length=struct.unpack('<H'if version==(1,0)else'<I',f.read(2 if version==(1,0)else 4))[0];header=ast.literal_eval(f.read(length).decode('latin1'));return header['shape'],header['descr']
assert shape(HERE/'output-001/native/exact-CAD-surface-samples.npz','points_mm')==((native['exact_CAD_surface_samples'],3),'<f8')
assert shape(HERE/'output-001/native/candidate_STL-samples.npz','points')==((3072,3),'<f8')and shape(HERE/'output-001/native/candidate_STL-samples.npz','distances_mm')==((3072,),'<f8')
files={}
for directory in ('execution-001','output-001'):
 for f in sorted((HERE/directory).rglob('*')):
  if f.is_dir():continue
  assert f.is_file()and not f.is_symlink();files[str(f.relative_to(HERE))]=dict(bytes=f.stat().st_size,sha256=sha(f))
assert len(files)==9
r=dict(schema='closed-preserved-taper-native-forward-screen-1',status='sampled_mesh_to_BREP_passed_pending_inverse_and_topology',collector_source_sha256=sha(__file__),actual_session_id=8324,actual_initial_chunk='514d30',actual_terminal_chunk='4a6561',own_handle_collected=True,actual_outer_returncode=0,actual_child_returncode=0,direct_child_reaped=True,final_group_members=[],cleanup_error=None,timeout=False,interrupted=False,signals=[],supervisor_wall_seconds=sup['elapsed_seconds'],native_wall_seconds=a['wall_seconds'],native_CPU_seconds=a['CPU_seconds'],native_maxRSS_bytes=a['maxRSS_bytes_macos'],plan_sha256=sha(HERE/'plan.json'),launch_plan_sha256=sha(HERE/'launch-plan.json'),supervision_sha256=sha(HERE/'execution-001/execution-receipt.json'),assessment_sha256=sha(HERE/'output-001/assessment.json'),BREP_receipt_sha256=sha(HERE/'output-001/native/brep-audit.json'),master_BREP_sha256=p['master_sha256'],surface_STL_sha256=p['surface_sha256'],CAD_surface_points=native['exact_CAD_surface_samples'],CAD_surface_points_sha256=native['exact_CAD_surface_samples_sha256'],sample_count=3072,maximum_sampled_STL_to_BREP_mm=native['results']['candidate_STL']['maximum_distance_to_BREP_shell_mm'],distance_limit_mm=.06,adaptive_CAD_volume_mm3=native['exact_CAD_volume_mm3'],adaptive_CAD_volume_reported_error=native['CAD_volume_estimated_relative_error'],whole_candidate_native_summary=whole,whole_outputs=files,fresh_launch_unique_pins_verified=len(pins),all_current_equal=True,actual_native_module_paths=a['actual_native_module_paths'],candidate_qualified=False,original_law_RC1_preserved=True,downstream_checks=a['downstream_checks'],inverse_distance_executed=False,topology_executed=False,global_admission=False,FEA_executed=False,continuous_distance_bound=False,elapsed_collection_seconds=time.monotonic()-start)
with(HERE/'terminal-collection-001.json').open('x')as f:json.dump(r,f,indent=2,allow_nan=False);f.write('\n');f.flush();os.fsync(f.fileno())
print(json.dumps(dict(terminal_sha256=sha(HERE/'terminal-collection-001.json'),assessment_sha256=r['assessment_sha256'],supervision_sha256=r['supervision_sha256'],files=len(files),pins=len(pins),CAD_points=native['exact_CAD_surface_samples'])))
