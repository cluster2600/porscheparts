"""Private new-mesh provenance/observation adaptation; retain all solver/energy/peak maths."""
import difflib,hashlib,json
from pathlib import Path
H=Path(__file__).resolve().parent;R=H.parents[2];O=R/'work/carrier-process-20261017/bounded-webs-BREP-static-preparation-002';B=R/'work/carrier-process-20261017/bounded-webs-BREP-postprocess-bindings-preparation-001'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
for n in ['cad_binding.py','audit_energy_brep.py','locate_brep.py']:(H/'postprocess'/n).write_bytes((B/n).read_bytes())
new='''def verify_mesh(plan):
    terminal=json.loads((ROOT/plan['mesh_terminal']).read_text());assessment=json.loads((ROOT/plan['mesh_assessment']).read_text());supervision=json.loads((ROOT/plan['mesh_supervision']).read_text())
    require(plan['mesh_root_review_sha256']is not None and sha(ROOT/plan['mesh_root_review'])==plan['mesh_root_review_sha256'],'New-mesh ROOT closure remains pending')
    root=json.loads((ROOT/plan['mesh_root_review']).read_text())
    require(root['actual_tool_RC']==0 and root['terminal_sha256']==sha(ROOT/plan['mesh_terminal'])and root['supervision_sha256']==sha(ROOT/plan['mesh_supervision'])and root['BREP_sha256']==plan['BREP_sha256'],'New-mesh ROOT evidence crossed')
    require(terminal['actual_tool_returncode']==terminal['actual_child_returncode']==0 and terminal['all_pins_actual_equal']and terminal['whole_pending_inverse_equal']and terminal['assessment_sha256']==sha(ROOT/plan['mesh_assessment'])and terminal['supervision_sha256']==sha(ROOT/plan['mesh_supervision']),'Closed new native BREP mesh terminal differs')
    require(supervision['actual_returncode']==0 and supervision['direct_child_reaped']and not supervision['final_group_members']and supervision['sources_and_plan_unchanged']and supervision['sources_before']==supervision['sources_after'],'New mesh execution not closed')
    require(assessment['status']=='native_BREP_mesh_completed'and assessment['sources_unchanged']and assessment['sources_before']==assessment['sources_after']and assessment['quality']['finite']and assessment['quality']['nonpositive_elements']==0 and assessment['quality']['minimum_Jacobian']>0,'New native BREP mesh gates refused')
    imported=assessment['BREP_import'];observation=plan['expected_new_import_observation'];measured={k:imported[k]for k in observation}
    require(plan['import_observation_method']=='closed_new_taper_same_operator_observation_1'and measured==observation and root['BREP_import']==imported,'New imported-volume observation differs')
    require(imported['passed']and imported['historical_relative_guard']==1e-8 and imported['relative_volume_difference']==imported['OCC_imported_volume_mm3']/imported['nonadaptive_reference_volume_mm3']-1 and abs(imported['relative_volume_difference'])<1e-8 and imported['actual_import_options_before']==imported['actual_import_options_after']==plan['actual_import_options_required'],'Actual comparable-operator import/options differ')
    require(assessment['mesh_metadata']['CAD_source_format']=='BREP'and assessment['mesh_metadata']['BREP_sha256']==plan['BREP_sha256']and assessment['mesh_metadata']['bore_node_counts']==plan['expected_bore_node_counts'],'Actual new BREP/groups differ')


'''
root_guard='''def verify_protected_root(plan):
    require(plan['protected_root_review_sha256']is not None and sha(ROOT/plan['protected_root_review'])==plan['protected_root_review_sha256'],'New protected ROOT proof remains pending')
    root=json.loads((ROOT/plan['protected_root_review']).read_text())
    require(root['actual_tool_RC']==0 and root['terminal_sha256']==sha(ROOT/plan['protected_terminal'])and root['supervision_sha256']==sha(ROOT/plan['protected_supervision'])and root['inspection_sha256']==sha(ROOT/plan['inspection_report'])and root['protected_interfaces_sha256']==sha(ROOT/plan['protected_report']),'New protected ROOT joins differ')
    require(root['CAD_source']['sha256']==plan['BREP_sha256']and root['STL_sha256']==plan['protected_surface_STL_sha256']and root['candidate_qualified']is False and root['law_original_RC1_preserved']is True,'New protected ROOT operand/scope differs')


'''
s=(O/'run.py').read_text();a=s.index('def verify_mesh(plan):');b=s.index('def verify_protected(plan):',a);old=s[a:b]
changes=[('"""Two separately bounded linear CCX cases on the actual native-BREP global7 mesh."""','"""Two unqualified raw-taper T10 diagnostic cases; original solver/energy/peak maths."""'),(old,new+root_guard),("require(sha(plan_path) == expected_hash and plan['launch_ready'] is True, 'Plan not armed or changed')","require(sha(plan_path) == expected_hash and plan['launch_ready'] is True and plan['root_GO_sha256']is not None and sha(ROOT/plan['root_GO'])==plan['root_GO_sha256'], 'Plan not armed or changed')"),("work/carrier-process-20261017/bounded-webs-BREP-mesh-preparation-002/output-001/cad-BREP-master/mesh-7","work/carrier-process-20261017/bounded-webs-C1-terminal-taper-BREP-mesh-preparation-001/output-001/cad-BREP-master/mesh-7"),("terminal['actual_outer_returncode'] == terminal['actual_child_returncode'] == 0","terminal['actual_tool_returncode'] == terminal['actual_child_returncode'] == 0"),("    verify_protected(plan)\n","    verify_protected_root(plan);verify_protected(plan)\n"),("                  physical_validation=False, strength_allowable_added=False, convergence_threshold_added=False,","                  physical_validation=False, strength_allowable_added=False, convergence_threshold_added=False, candidate_qualified=False, law_original_RC1_preserved=True,")]
for before,after in changes:assert s.count(before)==1;s=s.replace(before,after,1)
(H/'run.py').write_text(s);inverse=s
for before,after in reversed(changes):assert inverse.count(after)==1;inverse=inverse.replace(after,before,1)
assert inverse==(O/'run.py').read_text();(H/'run-from-static002.diff').write_text(''.join(difflib.unified_diff((O/'run.py').read_text().splitlines(True),s.splitlines(True),fromfile='old_static002/run.py',tofile='new_raw_taper/run.py')))
(H/'source-changes.json').write_text(json.dumps(dict(old_caller=str((O/'run.py').relative_to(R)),old_caller_sha256=sha(O/'run.py'),new_caller_sha256=sha(H/'run.py'),replacements=[dict(before=x,after=y)for x,y in changes],whole_inverse_equal=True,unchanged_postprocess_sources={n:sha(H/'postprocess'/n)for n in ['cad_binding.py','audit_energy_brep.py','locate_brep.py']},observation_revision='old C1 exact observed ratio0 is replaced by exact new closed ratio -7.771561172376096e-16; strict1e-8 import criterion is unchanged'),indent=2)+'\n')
print(json.dumps(dict(source_sha256=sha(H/'run.py'),source_changes_sha256=sha(H/'source-changes.json'),whole_inverse_equal=True)))
