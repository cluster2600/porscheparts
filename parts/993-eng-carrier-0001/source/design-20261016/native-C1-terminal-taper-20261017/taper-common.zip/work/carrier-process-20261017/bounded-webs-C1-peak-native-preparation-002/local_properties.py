"""Explicit D2 upgrade and conservative local-chord qualification; no native import."""
import math

def curvature(properties,orientation):
    if not any(orientation.endswith(kind)for kind in ('TopAbs_FORWARD','TopAbs_REVERSED')):
        return dict(status='undefined_native_topological_orientation',orientation=orientation,normal_outward=None,local_chord=None)
    if not properties.IsNormalDefined() or not properties.IsCurvatureDefined():
        return dict(status='undefined_native_D2_properties',local_chord=None)
    support=list(properties.Normal().Coord());length=math.sqrt(sum(v*v for v in support))
    if not math.isfinite(length) or length<=0:raise ValueError('Undefined native surface normal')
    outward=[v/length*(-1 if orientation.endswith('TopAbs_REVERSED')else 1)for v in support]
    values=[properties.MinCurvature(),properties.MaxCurvature(),properties.MeanCurvature(),properties.GaussianCurvature()]
    if not all(math.isfinite(v)for v in values):raise ValueError('Nonfinite native D2 curvature')
    return dict(status='native_D2_at_reported_UV',normal_support=support,normal_outward=outward,
        minimum_curvature_per_mm=values[0],maximum_curvature_per_mm=values[1],mean_curvature_per_mm=values[2],
        Gaussian_curvature_per_mm2=values[3],curvature_sign_convention='native_support_parameterization_not_topological_orientation')

def qualify_chord(hits,source_face):
    """Accept only one interior start/in transition and a unique first interior out."""
    origin=[h for h in hits if h['coincident_with_start_native_tolerance']]
    other=sorted((h for h in hits if not h['coincident_with_start_native_tolerance']and h['W_mm']>0),key=lambda h:h['W_mm'])
    result=dict(status='unresolved_normal_chord',thickness_mm=None)
    if (len(origin)!=1 or origin[0]['face_index_zero_based']!=source_face or
            not origin[0]['state'].endswith('TopAbs_IN') or not origin[0]['transition'].endswith('IntCurveSurface_In')):
        return result
    if (not other or sum(h['W_mm']==other[0]['W_mm']for h in other)!=1 or
            not other[0]['state'].endswith('TopAbs_IN') or not other[0]['transition'].endswith('IntCurveSurface_Out')):
        return result
    return dict(status='unambiguous_first_native_in_out_normal_chord',thickness_mm=other[0]['W_mm'],
        target_face_index_zero_based=other[0]['face_index_zero_based'],scope='one_local_native_normal_chord_not_global_minimum_thickness')
