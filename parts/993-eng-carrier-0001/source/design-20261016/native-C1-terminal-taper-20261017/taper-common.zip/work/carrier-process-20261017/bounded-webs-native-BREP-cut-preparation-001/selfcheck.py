"""Stdlib control-flow checks for null and empty native Compound inputs."""
import ast
from pathlib import Path
from types import SimpleNamespace
import unittest

SOURCE=Path(__file__).with_name('diagnose.py')
TREE=ast.parse(SOURCE.read_text())
SUMMARY=next(node for node in ast.walk(TREE) if isinstance(node,ast.FunctionDef) and node.name=='summary')

class Raw:
    def __init__(self,null=False):self.null=null
    def IsNull(self):return self.null
    def ShapeType(self):return 'TopAbs_COMPOUND'

class RawFlow(unittest.TestCase):
    def summary(self,raw):
        namespace=dict(SimpleNamespace=SimpleNamespace,entities=lambda raw,kind:[],bbox=lambda raw:None,
            BRepCheck_Analyzer=lambda raw:SimpleNamespace(IsValid=lambda:True),
            TopAbs_SOLID='solid',TopAbs_FACE='face',TopAbs_EDGE='edge',TopAbs_VERTEX='vertex',
            TopoDS=SimpleNamespace(Face_s=lambda x:x,Edge_s=lambda x:x,Vertex_s=lambda x:x))
        module=ast.Module(body=[SUMMARY],type_ignores=[])
        exec(compile(ast.fix_missing_locations(module),str(SOURCE),'exec'),namespace)
        return namespace['summary'](raw)
    def test_null_raw(self):
        for raw in (None,Raw(True)):
            result=self.summary(raw)
            self.assertTrue(result['native_null'])
            self.assertTrue(result['native_topologically_empty'])
    def test_empty_compound_raw(self):
        result=self.summary(Raw())
        self.assertFalse(result['native_null'])
        self.assertTrue(result['native_topologically_empty'])
        self.assertEqual(result['counts'],dict(solids=0,faces=0,edges=0,vertices=0))
        self.assertEqual(result['material_solid_volume_mm3'],0)
        self.assertIsNone(result['highest_topological_dimension'])
    def test_no_cast_between_Shape_and_summary(self):
        calls=[node for node in ast.walk(TREE) if isinstance(node,ast.Call)]
        self.assertFalse(any(isinstance(node.func,ast.Attribute)and node.func.attr=='cast'for node in calls))
        self.assertTrue(any(isinstance(node.func,ast.Name)and node.func.id=='summary'and len(node.args)==1 and isinstance(node.args[0],ast.Name)and node.args[0].id=='raw'for node in calls))
        self.assertFalse(any(isinstance(node,ast.ImportFrom)and any(item.name=='Solid'for item in node.names)for node in ast.walk(TREE)))

    def test_right_input_is_native_BREP_only(self):
        run=next(node for node in TREE.body if isinstance(node,ast.FunctionDef)and node.name=='run')
        assignment=next(node for node in ast.walk(run)if isinstance(node,ast.Assign)and any(isinstance(t,ast.Name)and t.id=='right'for t in node.targets))
        self.assertIsInstance(assignment.value,ast.Call)
        self.assertIsInstance(assignment.value.func,ast.Name)
        self.assertEqual(assignment.value.func.id,'import_brep')
        self.assertIn('candidate_BREP',ast.unparse(assignment.value))
        self.assertNotIn('candidate_STEP',ast.unparse(run))

if __name__=='__main__':unittest.main()
