"""Seal non-armed revision002: raw-output preservation only, no native imports."""
import copy,hashlib,json,os,time
from pathlib import Path
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[2];OLD=HERE.with_name('bounded-webs-C1-endfillet-preparation-001')
def sha(path):
 h=hashlib.sha256()
 with Path(path).open('rb')as f:
  for b in iter(lambda:f.read(1024**2),b''):h.update(b)
 return h.hexdigest()
def write(name,value):
 with(HERE/name).open('x')as f:json.dump(value,f,indent=2,allow_nan=False);f.write('\n');f.flush();os.fsync(f.fileno())
def rel(path):return str(path.relative_to(ROOT))
started=time.monotonic()
assert sha(OLD/'pending-plan.json')=='7618d2636a8769e48ea42caf185b694b15f14f064bd4b32fb01e1cffadfd2b91'
assert sha(OLD/'pending-launch-plan.json')=='42cc5a527578254ad85473fd57208161fc29ae9142a66795ecec194afabc1188'
assert sha(OLD/'close_end.py')=='765dcb931f1e3959e9e88d376b7d9dc34a4aa3c6f6e50113f8437f912c301639'
oldsource=(OLD/'close_end.py').read_text();source=(HERE/'close_end.py').read_text()
a="        require(candidate.is_valid and len(candidate.solids())==1,'Exactly one valid candidate Solid required')\n"
changes=[dict(old=a,new=a+"        export_brep(candidate,out/'candidate-native.brep')\n        report.update(raw_native_candidate_preserved_before_admission=True,outputs_sha256={'candidate-native.brep':sha(out/'candidate-native.brep')})\n"),dict(old="        export_brep(candidate,out/'candidate-native.brep');write(out/'study.json',study)",new="        write(out/'study.json',study);report['outputs_sha256']['study.json']=sha(out/'study.json')"),dict(old=",outputs_sha256={'candidate-native.brep':sha(out/'candidate-native.brep'),'study.json':sha(out/'study.json')}",new='')]
forward=oldsource
for c in changes:assert forward.count(c['old'])==1;forward=forward.replace(c['old'],c['new'],1)
assert forward==source
inverse=source
for c in reversed(changes):
 if c['new']:
  assert inverse.count(c['new'])==1;inverse=inverse.replace(c['new'],c['old'],1)
 else:
  marker="report.update(status='native_R1_end_candidate_local_checks_complete_PENDING_downstream'";assert inverse.count(marker)==1;inverse=inverse.replace(marker,marker+c['old'],1)
assert inverse==oldsource
write('source-changes.json',dict(origin_source_sha256=sha(OLD/'close_end.py'),source_sha256=sha(HERE/'close_end.py'),replacements=changes,inverse_byteexact=True,math_or_bounds_changed=False))
original=json.loads((OLD/'pending-plan.json').read_text());plan=copy.deepcopy(original)
for key in ['output_directory','execution_directory']:plan[key]=plan[key].replace('preparation-001/','preparation-002/');assert not(ROOT/plan[key]).exists()
plan['revision']='002: raw BREP exported once immediately after valid one-Solid; all scientific guards and budgets unchanged'
plan['origin_pending_plan_sha256']=sha(OLD/'pending-plan.json')
newpaths=[HERE/n for n in ['close_end.py','selfcheck.py','README.md','prepare.py','close_end.py.diff','selfcheck.py.diff','source-changes.json']]+[OLD/n for n in ['pending-plan.json','pending-launch-plan.json','preflight-assessment.json','preparation-assessment.json']]
for path in newpaths:plan['files_sha256'][rel(path)]=sha(path)
inverse_plan=copy.deepcopy(plan);inverse_plan['output_directory']=original['output_directory'];inverse_plan['execution_directory']=original['execution_directory'];del inverse_plan['revision'];del inverse_plan['origin_pending_plan_sha256'];inverse_plan['files_sha256']=original['files_sha256'];assert inverse_plan==original
before={n:sha(ROOT/n)for n in plan['files_sha256']};assert before==plan['files_sha256']
write('pending-plan.json',plan);psha=sha(HERE/'pending-plan.json')
launch=copy.deepcopy(json.loads((OLD/'pending-launch-plan.json').read_text()))
launch['command'][3]=str(HERE/'close_end.py');launch['command'][-2:]=[str(HERE/'pending-plan.json'),psha]
launch['output_directory']=plan['output_directory'];launch['execution_directory']=plan['execution_directory']
del launch['source_sha256'][rel(OLD/'close_end.py')];launch['source_sha256'][rel(HERE/'close_end.py')]=sha(HERE/'close_end.py')
launch['inputs_sha256']={**plan['files_sha256'],rel(HERE/'pending-plan.json'):psha}
write('pending-launch-plan.json',launch);lsha=sha(HERE/'pending-launch-plan.json')
python=str(ROOT/'work/part-workflow/runtimes/geometry-standalone/bin/python');supervisor=str(ROOT/'work/carrier-process-20261017/source010-exposure-preflight-003/supervise.py')
write('command.json',dict(template_only=True,root_GO_required=True,argv=[python,'-I','-B',supervisor,str(HERE/'pending-launch-plan.json'),'--plan-sha256',lsha],native_executed=False))
write('preparation-assessment.json',dict(status='source_only_NONARMED_revision002_fresh_pins_PASS',source_sha256=sha(HERE/'close_end.py'),tests_sha256=sha(HERE/'selfcheck.py'),source_inverse_byteexact_to001=True,scientific_changes=False,actual_tests=17,actual_test_RC=0,actual_test_chunk='366d93',native_imports=False,Build=False,unique_launch_pins=len({**launch['source_sha256'],**launch['inputs_sha256']}),total_pin_bytes=sum((ROOT/n).stat().st_size for n in before),plan_sha256=psha,launch_sha256=lsha,all_fresh_pins_equal=True,output_and_execution_absent=True,elapsed_seconds=time.monotonic()-started))
print(json.dumps(dict(status='source_only_NONARMED',source_sha256=sha(HERE/'close_end.py'),tests_sha256=sha(HERE/'selfcheck.py'),plan_sha256=psha,launch_sha256=lsha,preparation_sha256=sha(HERE/'preparation-assessment.json'),unique_pins=len({**launch['source_sha256'],**launch['inputs_sha256']}))))
