"""Collect the actual owned raw-BREP Cut without importing any geometry module."""
import hashlib,json,os,time
from pathlib import Path
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[2]
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb')as f:
  for b in iter(lambda:f.read(1024**2),b''):h.update(b)
 return h.hexdigest()
def read(p):return json.loads(p.read_text())
start=time.monotonic();launch=read(HERE/'launch-plan.json');plan=read(HERE/'plan.json');sup=read(HERE/'execution-001/execution-receipt.json');actual=read(HERE/'output-001/assessment.json');residue=read(HERE/'output-001/residue.json')
assert sha(HERE/'launch-plan.json')=='71b80b74d0c1b3d3ab5cb0cc0be4841e86efc871d14c1678b53c4fe49cff07c9'
assert sup['plan_sha256']==sha(HERE/'launch-plan.json')and sup['command']==launch['command']and sup['actual_returncode']==0 and sup['status']=='executed'
assert sup['direct_child_reaped']and sup['no_non_zombie_group_members']and sup['final_group_members']==[]and sup['cleanup_error']is None and sup['failure']is None and not sup['timeout']and not sup['interrupted']and sup['signals_to_owned_group_only']==[]
pins={**launch['inputs_sha256'],**launch['source_sha256']};assert sup['sources_before']==sup['sources_after']==pins and sup['sources_and_plan_unchanged']and {n:sha(ROOT/n)for n in pins}==pins
assert actual['sources_before']==actual['sources_after']==plan['files_sha256']and actual['sources_unchanged']
assert actual['status']=='native_BREP_strict_native_empty_pass'and actual['IsDone']is True and actual['strict_native_empty']is True and actual['residue']==residue
assert residue['counts']==dict(solids=0,faces=0,edges=0,vertices=0)and residue['native_topologically_empty']is True and residue['bounds_mm']is None and residue['highest_topological_dimension']is None
assert actual['candidate_qualified']is False and actual['new_fillet_Build']is False and actual['new_candidate']is False and actual['FEA_executed']is False
for name,h in sup['logs_sha256'].items():assert sha(HERE/'execution-001'/name)==h
journal=[json.loads(x)for x in(HERE/'output-001/events.jsonl').read_text().splitlines()]
assert sum(r['event']=='before_Build'for r in journal)==sum(r['event']=='after_Build'for r in journal)==1
assert journal[-1]['event']=='assessment_written'and journal[-1]['sha256']==sha(HERE/'output-001/assessment.json')
files={}
for folder in ('execution-001','output-001'):
 for p in sorted((HERE/folder).iterdir()):
  assert p.is_file()and not p.is_symlink();files[str(p.relative_to(HERE))]=dict(bytes=p.stat().st_size,sha256=sha(p))
assert len(files)==7
receipt=dict(schema='owned-preserved-taper-raw-Cut-terminal-1',status='actual_owned_RC0_strict_native_empty_all_outputs_and_pins_verified',collector_source_sha256=sha(__file__),tool_handle=16619,tool_launch_chunk='44cd8d',tool_terminal_chunk='931ab4',actual_tool_and_child_returncode=0,own_handle_collected=True,supervision_sha256=sha(HERE/'execution-001/execution-receipt.json'),assessment_sha256=sha(HERE/'output-001/assessment.json'),started_sha256=sha(HERE/'execution-001/started.json'),direct_child_reaped=True,owned_group_empty=True,signals=[],timeout=False,cleanup_error=None,whole_output_files=files,unique_current_pins=len(pins),all_current_pins_equal=True,supervised_wall_seconds=sup['elapsed_seconds'],child_wall_seconds=actual['elapsed_seconds'],residue=residue,candidate_qualified=False,original_law_refusal_preserved=True,strict_containment_only=True,no_new_fillet_or_export=True,no_protected_audit_mesh_or_FEA=True,elapsed_collection_seconds=time.monotonic()-start)
with(HERE/'terminal-collection-001.json').open('x')as f:json.dump(receipt,f,indent=2,allow_nan=False);f.write('\n');f.flush();os.fsync(f.fileno())
print(json.dumps(dict(terminal_sha256=sha(HERE/'terminal-collection-001.json'),assessment_sha256=receipt['assessment_sha256'],supervision_sha256=receipt['supervision_sha256'],files=len(files),current_pins=len(pins))))
