"""Retained small roster/settings tests plus new actual-volume trust-boundary tests."""
import copy,hashlib,importlib.util,json,tempfile,unittest
from pathlib import Path
H=Path(__file__).resolve().parent;R=H.parents[2];O=R/'work/carrier-process-20261017/bounded-webs-BREP-mesh-preparation-002'
def load(n,p):
 s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
old=load('_retained_BREP_small_checks',O/'selfcheck.py');m=load('_new_taper_T10_trust_boundary',H/'run.py')
def bound():
 p=json.loads((H/'pending-plan.json').read_text());return json.loads((H/'brep-master.json').read_text()),p['files_sha256'],p
class Tests(old.Check):
 def test_master_format_and_real_volume_authority(self):
  master,before,plan=bound();rows=m.verify_master(master,before,plan);self.assertEqual(rows['methods'][0]['signed_mass_mm3'],285603.15679600753);self.assertEqual(rows['methods'][2]['signed_mass_mm3'],285602.88227244973);self.assertIsNone(master['new_Gmsh_getMass_mm3'])
 def test_whole_driver_diff_inverse_and_unchanged_mesh_helpers(self):
  d=json.loads((H/'source-changes.json').read_text());s=(H/'run.py').read_text()
  for row in reversed(d['replacements']):self.assertEqual(s.count(row['after']),1);s=s.replace(row['after'],row['before'],1)
  self.assertEqual(s,(O/'run.py').read_text())
  for n in ['mesh_brep.py','rosters.py']:self.assertEqual((H/n).read_bytes(),(O/n).read_bytes())
 def test_wrong_candidate_volume_or_profile_hash_refuses(self):
  for key,value in [('BREP_sha256','foreign'),('nonadaptive_import_volume_mm3',285602.88227244973),('profile_root_review_sha256','foreign'),('nonadaptive_volume_receipt_sha256','foreign')]:
   master,before,plan=bound();master[key]=value
   with self.assertRaises(AssertionError):m.verify_master(master,before,plan)
 def test_wrong_operator_cannot_alias_adaptive_to_import(self):
  master,before,plan=bound();master['nonadaptive_import_volume_operator']['arguments']=[1e-10,True,False]
  with self.assertRaises(AssertionError):m.verify_master(master,before,plan)
 def test_ready_guard_refuses_before_import_or_output(self):
  oldhere=m.HERE
  with tempfile.TemporaryDirectory()as d:
   d=Path(d);(d/'plan.json').write_text(json.dumps(dict(launch_ready=False)));m.HERE=d
   try:
    with self.assertRaises(AssertionError):m.verify(True)
    self.assertEqual(sorted(p.name for p in d.iterdir()),['plan.json'])
   finally:m.HERE=oldhere
if __name__=='__main__':unittest.main(verbosity=2)
