"""Small stdlib checks for the new prototype's trust and preservation boundaries."""
import ast,copy,hashlib,importlib.util,json,os,tempfile,time,unittest
from pathlib import Path
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[2]
s=importlib.util.spec_from_file_location('_taper_stdlib',HERE/'build_taper.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
OBS=json.loads((HERE.with_name('bounded-webs-C1-terminal-law-observation-preparation-001')/'output-001/assessment.json').read_text())
class Checks(unittest.TestCase):
    def args(self):return [copy.deepcopy(OBS['simulated_laws']),OBS,list(OBS['simulated_laws'][0]['native_law_bounds']),0.]
    def test_observed_native_law(self):self.assertEqual(m.validate_laws(*self.args()),OBS['attached_exact_law_proof'])
    def test_wrong_target_pole(self):
        a=self.args();a[0][0]['native_poles'][1]=.1
        with self.assertRaises(ValueError):m.validate_laws(*a)
    def test_wrong_physical_interval(self):
        a=self.args();a[2][1]=21.
        with self.assertRaises(ValueError):m.validate_laws(*a)
    def test_wrong_other_law(self):
        a=self.args();a[0][1]['constant_radius_mm']=.9
        with self.assertRaises(ValueError):m.validate_laws(*a)
    def test_missing_record(self):
        a=self.args();a[0].pop()
        with self.assertRaises(ValueError):m.validate_laws(*a)
    def test_wrong_orientation_record(self):
        a=self.args();a[0][-1]['native_orientation']='foreign'
        with self.assertRaises(ValueError):m.validate_laws(*a)
    def test_unavailable_law(self):
        a=self.args();a[0][0]['unavailable_reason']={'message':'not available'}
        with self.assertRaises(ValueError):m.validate_laws(*a)
    def test_nonarmed(self):
        with tempfile.TemporaryDirectory()as d:
            p=Path(d)/'plan.json';p.write_text(json.dumps(dict(launch_ready=False)))
            with self.assertRaisesRegex(ValueError,'NON-ARMED'):m.verify(p,m.sha(p),True)
    def test_one_final_Build_no_SetLaw_or_Simulate(self):
        tree=ast.parse((HERE/'build_taper.py').read_text());calls=[n for n in ast.walk(tree)if isinstance(n,ast.Call)]
        self.assertEqual(sum(isinstance(n.func,ast.Attribute)and ast.unparse(n.func)=='builder.Build'for n in calls),1)
        self.assertFalse(any(isinstance(n.func,ast.Attribute)and n.func.attr in ['Simulate','SetLaw','Clean','clean','export_step','export_stl']for n in calls))
        radii=[n for n in calls if isinstance(n.func,ast.Attribute)and n.func.attr=='SetRadius'];self.assertEqual(len(radii),1);self.assertEqual(ast.unparse(radii[0]),'builder.SetRadius(0.0, 1, zero)')
    def test_raw_survives_post_Build_law_refusal(self):
        source=(HERE/'build_taper.py').read_text();tree=ast.parse(source);run=next(n for n in tree.body if isinstance(n,ast.FunctionDef)and n.name=='run');body=next(n for n in run.body if isinstance(n,ast.Try)).body
        index=next(i for i,n in enumerate(body)if isinstance(n,ast.Expr)and isinstance(n.value,ast.Call)and ast.unparse(n.value.func)=='export_brep');nodes=body[index:index+2];self.assertLess(index,next(i for i,n in enumerate(body)if 'LAW.read_laws' in ast.unparse(n)))
        with tempfile.TemporaryDirectory()as d:
            out=Path(d);report=dict(candidate_qualified=False,downstream_checks={k:'PENDING'for k in m.GATE.PENDING})
            def exporter(candidate,path):path.write_bytes(b'raw valid one-Solid BREP fixture')
            env=dict(candidate=object(),out=out,report=report,export_brep=exporter,sha=m.sha);exec(compile(ast.Module(body=nodes,type_ignores=[]),'<actual raw-preservation statements>','exec'),env)
            try:raise ValueError('forced post-Build law refusal')
            except ValueError:pass
            self.assertTrue((out/'candidate-native.brep').is_file());self.assertEqual(report['outputs_sha256']['candidate-native.brep'],m.sha(out/'candidate-native.brep'));self.assertFalse(report['candidate_qualified']);self.assertTrue(all(x=='PENDING'for x in report['downstream_checks'].values()))
    def test_raw_cut_settings(self):
        source=(HERE/'build_taper.py').read_text();self.assertIn('cut.SetNonDestructive(True);cut.SetRunParallel(False);cut.SetFuzzyValue(0.)',source);self.assertIn("('baseline-minus-candidate',baseline,candidate),('candidate-minus-baseline',candidate,baseline)",source);self.assertIn("baseline=import_step(ROOT/p['baseline_STEP'])",source)
    def test_original_gate_not_weakened(self):
        p=dict(minimum_xyz_mm=[-1.,-1.,-1.],maximum_xyz_mm=[1.,1.,1.],existing_bound_guard_mm=0.);r=m.GATE.local_gate_flags(dict(native_topologically_empty=True),True,1,1.3,[[-1.]*3,[1.]*3],p);self.assertFalse(r['candidate_qualified'])
        for residue,mass in [(False,1.2),(True,1.30001)]:
            with self.assertRaises(ValueError):m.GATE.local_gate_flags(dict(native_topologically_empty=residue),True,1,mass,[[-1.]*3,[1.]*3],p)
    def test_helpers_are_frozen_sources(self):
        self.assertEqual(m.sha(Path(m.GATE.__file__)),'0277484749def5186818275e1df26e1cebe9d8f83954d751acd8b53d25b21d10');self.assertEqual(m.sha(Path(m.LAW.__file__)),'9d06beb7b7e4dee990d49acfb23cb9c88a570da495d19011d09f09b71c9a8f6a')
if __name__=='__main__':
    start=time.monotonic();r=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(Checks));record=dict(status='stdlib_tests_PASS'if r.wasSuccessful()else'stdlib_tests_FAIL',tests=r.testsRun,failures=len(r.failures),errors=len(r.errors),native_import_or_execution=False,elapsed_seconds=time.monotonic()-start,source_sha256=m.sha(HERE/'build_taper.py'),tests_sha256=m.sha(__file__))
    with(HERE/'selfcheck-assessment.json').open('x')as f:json.dump(record,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
    raise SystemExit(0 if r.wasSuccessful()else 1)
