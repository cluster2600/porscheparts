"""Fresh-import Boolean quantification, detached baseline control and independent protection."""
import hashlib
import importlib.util
import json
from pathlib import Path
import resource
import shutil
import signal
import sys
import time
import traceback
from types import SimpleNamespace

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[2]


def sha(path):
    digest=hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda:stream.read(1024*1024),b''):digest.update(block)
    return digest.hexdigest()


def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    return module


def write(path,value):
    with Path(path).open('x') as stream:
        json.dump(value,stream,indent=2,allow_nan=False);stream.write('\n')


def run():
    started=time.monotonic()
    plan=json.loads((HERE/'plan.json').read_text())
    before={name:sha(ROOT/name) for name in plan['files_sha256']}
    assert before==plan['files_sha256']
    output=ROOT/plan['output_directory']
    assert not output.exists() and not output.is_symlink()
    output.mkdir();snapshots=output/'native-snapshots';snapshots.mkdir()
    signal.signal(signal.SIGALRM,lambda *_:(_ for _ in ()).throw(TimeoutError('Serialization diagnostic wall budget')))
    signal.alarm(560);resource.setrlimit(resource.RLIMIT_CPU,(520,540))
    report=dict(schema='fresh-import-C1-serialization-readonly-diagnostic-2',status='incomplete',stages={},
                sources_before=before,new_fillet_Build=False,new_candidate=False,FEA_executed=False,
                candidate_qualified=False,existing_candidate_refusal_preserved=True)
    try:
        sys.path.insert(0,str(ROOT/plan['native_site']))
        from build123d import Solid,import_step,import_brep,export_step
        from OCP.BRep import BRep_Tool
        from OCP.BRepAdaptor import BRepAdaptor_Surface
        from OCP.BRepAlgoAPI import BRepAlgoAPI_Cut
        from OCP.BRepBndLib import BRepBndLib
        from OCP.BRepCheck import BRepCheck_Analyzer
        from OCP.BRepGProp import BRepGProp
        from OCP.BRepTools import BRepTools
        from OCP.Bnd import Bnd_Box
        from OCP.GProp import GProp_GProps
        from OCP.OSD import OSD_ThreadPool
        from OCP.TopAbs import TopAbs_SOLID,TopAbs_FACE,TopAbs_EDGE,TopAbs_VERTEX
        from OCP.TopExp import TopExp
        from OCP.TopTools import TopTools_IndexedMapOfShape,TopTools_ListOfShape,TopTools_FormatVersion_VERSION_1
        from OCP.TopoDS import TopoDS
        OSD_ThreadPool.DefaultPool_s().Init(1)
        volume=load('_serialization_precise_volume',ROOT/plan['volume_source'])

        def entities(raw,kind):
            mapping=TopTools_IndexedMapOfShape();TopExp.MapShapes_s(raw,kind,mapping)
            return [mapping.FindKey(i) for i in range(1,mapping.Extent()+1)]

        def bbox(raw):
            box=Bnd_Box();BRepBndLib.Add_s(raw,box,False)
            return None if box.IsVoid() else list(box.Get())

        def summary(shape):
            if shape is None or shape.wrapped.IsNull():
                return dict(native_null=True,counts=dict(solids=0,faces=0,edges=0,vertices=0),
                            material_solid_volume_mm3=0.,native_topologically_empty=True,bounds_mm=None)
            raw=shape.wrapped
            parts={name:entities(raw,kind) for name,kind in [('solids',TopAbs_SOLID),('faces',TopAbs_FACE),('edges',TopAbs_EDGE),('vertices',TopAbs_VERTEX)]}
            result=dict(native_null=False,native_type=str(raw.ShapeType()),native_valid=BRepCheck_Analyzer(raw).IsValid(),
                        counts={key:len(value) for key,value in parts.items()},bounds_mm=bbox(raw),solids=[],tolerances_mm={})
            for solid in parts['solids']:
                mass,error=volume.precise_volume(SimpleNamespace(wrapped=solid))
                result['solids'].append(dict(volume_mm3=mass,estimated_relative_integration_error=error,
                                             native_valid=BRepCheck_Analyzer(solid).IsValid(),bounds_mm=bbox(solid)))
            result['material_solid_volume_mm3']=sum(item['volume_mm3'] for item in result['solids'])
            result['sum_absolute_solid_volume_mm3']=sum(abs(item['volume_mm3']) for item in result['solids'])
            result['volume_scope']='BRepGProp adaptive integrals of each actual Solid only; no fictitious material volume integrated from an open face or edge residue.'
            casts={'faces':TopoDS.Face_s,'edges':TopoDS.Edge_s,'vertices':TopoDS.Vertex_s}
            for kind,cast in casts.items():
                tolerances=[BRep_Tool.Tolerance_s(cast(item)) for item in parts[kind]]
                result['tolerances_mm'][kind]=dict(count=len(tolerances),minimum=min(tolerances) if tolerances else None,
                                                maximum=max(tolerances) if tolerances else None)
            areas=[];types={}
            for face in parts['faces']:
                face=TopoDS.Face_s(face);props=GProp_GProps();BRepGProp.SurfaceProperties_s(face,props)
                areas.append(props.Mass());key=str(BRepAdaptor_Surface(face,True).GetType());types[key]=types.get(key,0)+1
            result['surface_area_sum_mm2']=sum(areas)
            result['surface_types']=types
            result['degenerated_edge_count']=sum(BRep_Tool.Degenerated_s(TopoDS.Edge_s(edge)) for edge in parts['edges'])
            result['native_topologically_empty']=all(not values for values in parts.values())
            result['highest_topological_dimension']=next((dim for name,dim in [('solids',3),('faces',2),('edges',1),('vertices',0)] if parts[name]),None)
            return result

        def snapshot(shape,name):
            path=snapshots/(name+'.brep')
            assert not path.exists()
            assert BRepTools.Write_s(shape.wrapped,str(path),False,False,TopTools_FormatVersion_VERSION_1)
            return dict(BREP_without_triangulation_sha256=sha(path),bytes=path.stat().st_size,
                        native_valid=BRepCheck_Analyzer(shape.wrapped).IsValid(),
                        counts={key:len(entities(shape.wrapped,kind)) for key,kind in
                                [('solids',TopAbs_SOLID),('faces',TopAbs_FACE),('edges',TopAbs_EDGE),('vertices',TopAbs_VERTEX)]})

        def fresh(key):
            path=ROOT/plan[key]
            return import_brep(path) if key=='candidate_BREP' else import_step(path)

        def difference(label,left,right,native=False):
            at=time.monotonic()
            row=dict(operand_before=dict(left=snapshot(left,label+'-left-before'),right=snapshot(right,label+'-right-before')))
            if native:
                cut=BRepAlgoAPI_Cut();args=TopTools_ListOfShape();tools=TopTools_ListOfShape()
                args.Append(left.wrapped);tools.Append(right.wrapped)
                cut.SetArguments(args);cut.SetTools(tools)
                cut.SetNonDestructive(True);cut.SetRunParallel(False);cut.SetFuzzyValue(0.)
                cut.Build()
                row['native_cut']=dict(IsDone=cut.IsDone(),NonDestructive=cut.NonDestructive(),
                                       RunParallel=cut.RunParallel(),FuzzyValue=cut.FuzzyValue(),
                                       HasErrors=None,HasWarnings=None,
                                       final_report_unavailable_reason='Installed OCP7.9.3 BRepAlgoAPI_Cut binding does not expose HasErrors/HasWarnings/GetReport.')
                try:
                    filler=cut.DSFiller()
                    row['native_cut']['DSFiller']=dict(HasErrors=filler.HasErrors(),HasWarnings=filler.HasWarnings(),
                                                       scope='Intersection filler only; not the unavailable final builder report.')
                except Exception as error:
                    row['native_cut']['DSFiller_unavailable']=dict(type=type(error).__name__,message=str(error))
                if not cut.IsDone():
                    row['residue']=None;row['refusal']='Native Cut did not complete'
                    row['operand_after']=dict(left=snapshot(left,label+'-left-after'),right=snapshot(right,label+'-right-after'))
                    return row
                residue=Solid.cast(cut.Shape())
            else:
                residue=left-right
            row['residue']=summary(residue)
            row['operand_after']=dict(left=snapshot(left,label+'-left-after'),right=snapshot(right,label+'-right-after'))
            row['operand_BREP_unchanged']={key:row['operand_before'][key]['BREP_without_triangulation_sha256']==row['operand_after'][key]['BREP_without_triangulation_sha256'] for key in ('left','right')}
            row['elapsed_seconds']=time.monotonic()-at
            return row

        def stage(label,operation):
            try:
                result=dict(completed=True,result=operation())
            except TimeoutError:raise
            except Exception as error:
                result=dict(completed=False,failure=dict(type=type(error).__name__,message=str(error),traceback=traceback.format_exc()))
            report['stages'][label]=result;write(output/(label+'.json'),result)
            print(json.dumps(dict(stage=label,completed=result['completed'])),flush=True)

        # First operation: unchanged STEP, unchanged writer settings, fresh root wrapper only.
        def baseline_control():
            old=fresh('baseline_STEP')
            assert len(entities(old.wrapped,TopAbs_SOLID))==1 and old.wrapped.ShapeType()==TopAbs_SOLID
            root=Solid(TopoDS.Solid_s(old.wrapped))
            assert root.wrapped.IsSame(old.wrapped) and root.wrapped.IsEqual(old.wrapped) and root.parent is None
            observation=dict(imported_parent_present=old.parent is not None,root_parent_absent=root.parent is None,
                             same_native_TShape_location_orientation=root.wrapped.IsEqual(old.wrapped),
                             wrapper_only_no_geometry_transform=True,before=snapshot(root,'baseline-export-before'))
            path=output/'unchanged-baseline-control.step'
            export_step(root,path)
            observation.update(after=snapshot(root,'baseline-export-after'),export_sha256=sha(path),
                               readback=summary(import_step(path)))
            observation['export_geometry_BREP_unchanged']=observation['before']['BREP_without_triangulation_sha256']==observation['after']['BREP_without_triangulation_sha256']
            observation['old_minus_roundtrip']=difference('baseline-control-old-minus-readback',fresh('baseline_STEP'),import_step(path))
            return observation
        stage('unchanged-baseline-control',baseline_control)

        # Independent original full interface checker, even if the writer-control stage refused.
        def protection():
            copied=output/'protected-input';copied.mkdir()
            for name,key in [('carrier.step','candidate_STEP'),('carrier.stl','candidate_STL'),('study.json','study')]:
                source=ROOT/plan[key];target=copied/name
                with source.open('rb') as src,target.open('xb') as dst:shutil.copyfileobj(src,dst,1024*1024)
                assert sha(target)==plan['files_sha256'][plan[key]]
            checker=load('_serialization_existing_protected',ROOT/plan['protected_source'])
            result={}
            try:result.update(returned=True,report=checker.check(copied))
            except Exception as error:
                result.update(returned=False,error=dict(type=type(error).__name__,message=str(error),traceback=traceback.format_exc()))
            for filename,key in [('inspection.json','actual_inspection'),('protected-interfaces.json','actual_protected_interfaces')]:
                if (copied/filename).is_file():result[key]=json.loads((copied/filename).read_text())
            if 'actual_inspection' in result:
                result['current_mass_ceiling_1p3kg_pass']=result['actual_inspection']['nominal_mass_kg']<=1.3
            return result
        stage('independent-protected-check',protection)
        for label,left,right in [('old-minus-BREP','baseline_STEP','candidate_BREP'),
                                 ('old-minus-STEP','baseline_STEP','candidate_STEP'),
                                 ('BREP-minus-STEP','candidate_BREP','candidate_STEP'),
                                 ('STEP-minus-BREP','candidate_STEP','candidate_BREP')]:
            stage(label,lambda label=label,left=left,right=right:difference(label,fresh(left),fresh(right)))
        stage('native-nondestructive-old-minus-STEP',lambda:difference('native-nondestructive-old-minus-STEP',fresh('baseline_STEP'),fresh('candidate_STEP'),native=True))
        report['status']='complete_readonly_diagnostic' if all(row['completed'] for row in report['stages'].values()) else 'incomplete_stages_preserved'
    except BaseException as error:
        report['failure']=dict(type=type(error).__name__,message=str(error),traceback=traceback.format_exc())
    finally:
        signal.alarm(0)
        after={name:sha(ROOT/name) for name in before}
        report.update(sources_after=after,sources_unchanged=before==after,elapsed_seconds=time.monotonic()-started)
        if before!=after:report['status']='refused_input_drift'
        report['output_files_sha256']={str(path.relative_to(output)):sha(path) for path in output.rglob('*') if path.is_file()}
        write(output/'assessment.json',report)
    print(json.dumps(dict(status=report['status'],elapsed_seconds=report['elapsed_seconds'],assessment_sha256=sha(output/'assessment.json'))),flush=True)
    return 0 if report['status']=='complete_readonly_diagnostic' and report['sources_unchanged'] else 1


if __name__=='__main__':
    raise SystemExit(run())
