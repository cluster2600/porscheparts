"""Stdlib tests of the one-export settings boundary; no native imports."""
import ast
from pathlib import Path
import unittest

HERE=Path(__file__).resolve().parent
TREE=ast.parse((HERE/'diagnose.py').read_text())
NODE=next(n for n in TREE.body if isinstance(n,ast.FunctionDef)and n.name=='export_without_pcurves')
NS={'WRITER_KEYS':('write.surfacecurve.mode','write.precision.mode')}
exec(compile(ast.fix_missing_locations(ast.Module(body=[NODE],type_ignores=[])),'export-boundary','exec'),NS)
EXPORT=NS['export_without_pcurves']

class Interface:
    def __init__(self,precision=0,rejectrestore=False):
        self.values={'write.surfacecurve.mode':1,'write.precision.mode':precision};self.rejectrestore=rejectrestore
    def IVal_s(self,key):return self.values[key]
    def SetIVal_s(self,key,value):
        if self.rejectrestore and key=='write.surfacecurve.mode'and value==1:return False
        self.values[key]=value;return True

class Boundary(unittest.TestCase):
    def writer(self,api,body,path,**kwargs):
        self.assertEqual((body,path),('native','fresh.step'));self.assertEqual(kwargs,{'write_pcurves':False})
        api.SetIVal_s('write.surfacecurve.mode',0);api.SetIVal_s('write.precision.mode',0);return True
    def test_one_option_and_restore(self):
        api=Interface();record={}
        self.assertTrue(EXPORT('native','fresh.step',lambda b,p,**kw:self.writer(api,b,p,**kw),api,record))
        self.assertTrue(record['restored']);self.assertEqual(api.values,{'write.surfacecurve.mode':1,'write.precision.mode':0})
    def test_failure_restores(self):
        api=Interface();record={}
        def fail(body,path,**kw):
            self.writer(api,body,path,**kw);raise RuntimeError('native writer refused')
        with self.assertRaisesRegex(RuntimeError,'native writer refused'):EXPORT('native','fresh.step',fail,api,record)
        self.assertTrue(record['restored']);self.assertEqual(api.values['write.surfacecurve.mode'],1)
    def test_unsuccessful_return_refuses(self):
        api=Interface();record={}
        with self.assertRaisesRegex(ValueError,'success'):EXPORT('native','fresh.step',lambda *a,**k:False,api,record)
        self.assertTrue(record['restored'])
    def test_failed_restore_refuses(self):
        api=Interface(rejectrestore=True);record={}
        with self.assertRaisesRegex(ValueError,'restoration failed'):
            EXPORT('native','fresh.step',lambda b,p,**kw:self.writer(api,b,p,**kw),api,record)
        self.assertFalse(record['restored'])
    def test_other_initial_precision_refuses(self):
        api=Interface(2)
        with self.assertRaisesRegex(ValueError,'defaults'):EXPORT('native','fresh.step',lambda *a,**kw:self.fail('must not export'),api,{})
        self.assertEqual(api.values['write.precision.mode'],2)
    def test_one_export_and_one_Cut_no_other_routes(self):
        calls=[n for n in ast.walk(TREE)if isinstance(n,ast.Call)]
        self.assertEqual(sum(isinstance(n.func,ast.Name)and n.func.id=='export_step'for n in calls),1)
        self.assertEqual(sum(isinstance(n.func,ast.Attribute)and n.func.attr=='Build'for n in calls),1)
        self.assertFalse(any(isinstance(n.func,ast.Attribute)and n.func.attr in ('SetRVal_s','DSFiller','cast')for n in calls))
        self.assertFalse(any(isinstance(n,ast.Name)and n.id=='BRepFilletAPI_MakeFillet'for n in ast.walk(TREE)))
    def test_raw_summary_AST_unchanged(self):
        old=HERE.with_name('bounded-webs-contour1-native-cut-diagnostic-003')/'diagnose_raw.py'
        before=ast.parse(old.read_text())
        def node(t,name):return next(n for n in ast.walk(t)if isinstance(n,ast.FunctionDef)and n.name==name)
        for name in ('entities','bbox','summary'):
            self.assertEqual(ast.dump(node(TREE,name),include_attributes=False),ast.dump(node(before,name),include_attributes=False))

if __name__=='__main__':unittest.main()
