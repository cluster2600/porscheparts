"""Small standard-library source/serialization-boundary tests; no native imports."""
import ast
import hashlib
import importlib.util
import json
from pathlib import Path
import unittest

HERE = Path(__file__).resolve().parent


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


caller = load('_new_taper_STEP_checks', HERE/'check_exchange.py')


class Interface:
    def __init__(self, restore=True):
        self.values = {'write.surfacecurve.mode': 1, 'write.precision.mode': 0}
        self.restore = restore

    def IVal_s(self, key):
        return self.values[key]

    def SetIVal_s(self, key, value):
        if self.restore: self.values[key] = value
        return self.restore


class Checks(unittest.TestCase):
    def test_single_default_export_has_exact_two_positional_arguments(self):
        body = object(); path = Path('never-written.step'); calls = []
        def exporter(*args, **kwargs):
            calls.append((args, kwargs)); return True
        interface = Interface(); record = {}
        caller.export_default(body, path, exporter, interface, record)
        self.assertEqual(calls, [((body, path), {})])
        self.assertTrue(record['restored']); self.assertEqual(record['export_keyword_arguments'], {})

    def test_export_exception_and_false_result_still_restore(self):
        for outcome in ['exception', 'false']:
            interface = Interface(); record = {}
            def exporter(*_args):
                interface.values['write.surfacecurve.mode'] = 0
                if outcome == 'exception': raise RuntimeError('writer double refused')
                return False
            with self.assertRaises((ValueError, RuntimeError)):
                caller.export_default(object(), Path('unused.step'), exporter, interface, record)
            self.assertEqual(interface.values, {'write.surfacecurve.mode': 1, 'write.precision.mode': 0})
            self.assertTrue(record['restored'])

    def test_unexpected_precision_change_refuses_and_restores(self):
        interface = Interface(); record = {}
        def exporter(*_args): interface.values['write.precision.mode'] = 1; return True
        with self.assertRaises(ValueError):
            caller.export_default(object(), Path('unused.step'), exporter, interface, record)
        self.assertTrue(record['restored'])

    def test_foreign_initial_defaults_refuse_without_export(self):
        interface = Interface(); interface.values['write.surfacecurve.mode'] = 0
        def exporter(*_args): self.fail('No export permitted on a foreign initial mode')
        with self.assertRaises(ValueError):
            caller.export_default(object(), Path('unused.step'), exporter, interface, {})

    def test_restoration_failure_is_not_hidden(self):
        interface = Interface(restore=False); record = {}
        with self.assertRaisesRegex(ValueError, 'restoration failed'):
            caller.export_default(object(), Path('unused.step'), lambda *_: True, interface, record)
        self.assertFalse(record['restored'])

    def test_all_three_raw_quantification_functions_AST_equal(self):
        origin = json.loads((HERE/'quantification-origin.json').read_text())
        original = Path(origin['original']); original.stat()
        self.assertEqual(hashlib.sha256(original.read_bytes()).hexdigest(), origin['original_sha256'])
        before = {n.name: n for n in ast.walk(ast.parse(original.read_text())) if isinstance(n, ast.FunctionDef)}
        after = {n.name: n for n in ast.parse((HERE/'quantification.py').read_text()).body if isinstance(n, ast.FunctionDef)}
        self.assertEqual(set(after), {'entities', 'bbox', 'summary'})
        for name in after:
            self.assertEqual(ast.dump(after[name], include_attributes=False), ast.dump(before[name], include_attributes=False))

    def test_null_raw_summary_requires_no_Solid_cast(self):
        quant = load('_raw_null_summary_no_native', HERE/'quantification.py')
        value = quant.summary(None)
        self.assertTrue(value['native_topologically_empty'])
        self.assertEqual(value['counts'], dict(solids=0, faces=0, edges=0, vertices=0))
        self.assertNotIn('Solid.cast', (HERE/'check_exchange.py').read_text()+(HERE/'quantification.py').read_text())

    def test_exact_two_difference_directions_one_loop_no_Build_of_fillet(self):
        tree = ast.parse((HERE/'check_exchange.py').read_text())
        loops = [n for n in ast.walk(tree) if isinstance(n, ast.For) and ast.unparse(n.target) == '(label, left_kind, right_kind)']
        self.assertEqual(len(loops), 1)
        self.assertEqual(ast.literal_eval(loops[0].iter),
            [('native-minus-STEP', 'native', 'STEP'), ('STEP-minus-native', 'STEP', 'native')])
        calls = [ast.unparse(n.func) for n in ast.walk(loops[0]) if isinstance(n, ast.Call)]
        self.assertEqual(calls.count('cut.Build'), 1)
        for name in ['cut.SetNonDestructive', 'cut.SetRunParallel', 'cut.SetFuzzyValue']:
            self.assertEqual(calls.count(name), 1)
        text = (HERE/'check_exchange.py').read_text()
        for forbidden in ['DSFiller', 'BRepFilletAPI', 'mesh.generate', '.clean(']: self.assertNotIn(forbidden, text)

    def test_NO_GO_and_wrong_resources_refuse_before_native_imports(self):
        with self.assertRaises(ValueError): caller.require_GO(dict(launch_ready=False, root_GO_sha256=None))
        with self.assertRaises(ValueError): caller.verify(dict(master_BREP_sha256='wrong'))


if __name__ == '__main__':
    unittest.main()
