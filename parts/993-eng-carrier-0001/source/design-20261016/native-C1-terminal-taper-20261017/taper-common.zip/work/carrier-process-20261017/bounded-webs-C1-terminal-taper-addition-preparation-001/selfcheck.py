"""Small standard-library trust-boundary checks; no CAD import or native run."""
import ast,copy,importlib.util,unittest
from pathlib import Path
P=Path(__file__).with_name('measure.py');s=importlib.util.spec_from_file_location('_taper_addition_boundary_checks',P);m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
def fixture():
 files={'old-launch':'L','old-sup':'S','old-assessment':'A'};plan=dict(candidate_BREP='candidate',baseline_STEP='baseline',files_sha256=files,retention_launch='old-launch',retention_supervision='old-sup',retention_assessment='old-assessment')
 old=dict(candidate_BREP='candidate',baseline_STEP='baseline',files_sha256={'candidate':'C','baseline':'B'});launch=dict(inputs_sha256={'x':'X'},source_sha256={'y':'Y'});residue=dict(native_topologically_empty=True,counts=dict(solids=0,faces=0,edges=0,vertices=0),highest_topological_dimension=None)
 assessment=dict(status='native_BREP_strict_native_empty_pass',strict_native_empty=True,IsDone=True,residue=copy.deepcopy(residue),sources_before=old['files_sha256'].copy(),sources_after=old['files_sha256'].copy(),sources_unchanged=True)
 sup=dict(plan_sha256='L',actual_returncode=0,direct_child_reaped=True,final_group_members=[],no_non_zombie_group_members=True,cleanup_error=None,timeout=False,interrupted=False,sources_before={'x':'X','y':'Y'},sources_after={'x':'X','y':'Y'},sources_and_plan_unchanged=True)
 terminal=dict(actual_tool_and_child_returncode=0,owned_group_empty=True,supervision_sha256='S',assessment_sha256='A')
 return [plan,assessment,residue,terminal,sup,old,launch]
class Tests(unittest.TestCase):
 def test_valid_closed_retention(self):
  x=fixture();self.assertIs(m.retention_records(*x),x[2])
 def test_foreign_candidate(self):
  x=fixture();x[5]['candidate_BREP']='other'
  with self.assertRaises(ValueError):m.retention_records(*x)
 def test_nonempty_residue(self):
  x=fixture();x[2]['counts']['edges']=1;x[1]['residue']=copy.deepcopy(x[2])
  with self.assertRaises(ValueError):m.retention_records(*x)
 def test_failed_actual_RC(self):
  x=fixture();x[4]['actual_returncode']=1
  with self.assertRaises(ValueError):m.retention_records(*x)
 def test_unclosed_group(self):
  x=fixture();x[4]['final_group_members']=[{'pid':3}]
  with self.assertRaises(ValueError):m.retention_records(*x)
 def test_runtime_drift(self):
  x=fixture();x[4]['sources_after']['x']='Z'
  with self.assertRaises(ValueError):m.retention_records(*x)
 def test_foreign_terminal(self):
  x=fixture();x[3]['assessment_sha256']='other'
  with self.assertRaises(ValueError):m.retention_records(*x)
 def test_only_one_Boolean_Build_no_fillet_or_export(self):
  t=ast.parse(P.read_text());calls=[n for n in ast.walk(t)if isinstance(n,ast.Call)]
  self.assertEqual([ast.unparse(n.func)for n in calls if isinstance(n.func,ast.Attribute)and n.func.attr=='Build'],['cut.Build'])
  self.assertFalse(any(isinstance(n,ast.ImportFrom)and any(a.name in ('BRepFilletAPI_MakeFillet','export_brep','export_step')for a in n.names)for n in ast.walk(t)))
 def test_exact_original_mass_ceiling_and_unqualified(self):
  p=dict(minimum_xyz_mm=[-1.,-1.,-1.],maximum_xyz_mm=[1.,1.,1.],existing_bound_guard_mm=1e-6);result=m.GATE.local_gate_flags(dict(native_topologically_empty=True),True,1,1.3,[[-1.,-1.,-1.],[1.,1.,1.]],p)
  self.assertFalse(result['candidate_qualified']);self.assertTrue(all(v=='PENDING'for v in result['downstream_checks'].values()))
  for mass in (1.3000000000000003,float('nan')):
   with self.assertRaises(ValueError):m.GATE.local_gate_flags(dict(native_topologically_empty=True),True,1,mass,[[-1.,-1.,-1.],[1.,1.,1.]],p)
if __name__=='__main__':unittest.main(verbosity=2)
