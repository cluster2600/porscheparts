"""Actual closed T10 output/pin/header collection; no Gmsh/NumPy/FEA import."""
import ast,copy,hashlib,importlib.util,json,os,struct,subprocess,time,zipfile
from pathlib import Path
H=Path(__file__).resolve().parent;R=H.parents[2];began=time.monotonic()
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb')as f:
  for b in iter(lambda:f.read(1024**2),b''):h.update(b)
 return h.hexdigest()
def read(p):return json.loads(p.read_text())
p=read(H/'plan.json');l=read(H/'launch-plan.json');s=read(H/'execution-001/execution-receipt.json');a=read(H/'output-001/assessment.json');pins={**l['inputs_sha256'],**l['source_sha256']}
assert s['actual_returncode']==0 and s['direct_child_reaped']and s['final_group_members']==[]and s['cleanup_error']is None and s['signals_to_owned_group_only']==[]and not s['timeout']and not s['interrupted']and s['pid']==44713
assert s['command']==l['command']and s['plan_sha256']==sha(H/'launch-plan.json')and s['sources_before']==s['sources_after']==pins and {n:sha(R/n)for n in pins}==pins
assert a['sources_before']==a['sources_after']==p['files_sha256']and a['sources_unchanged']and a['status']=='native_BREP_mesh_completed'
gk=p['root_GO'];inverse=copy.deepcopy(p);inverse.update(launch_ready=False,root_GO=None,root_GO_sha256=None);del inverse['files_sha256'][gk];assert inverse==read(H/'pending-plan.json')
inverse=copy.deepcopy(l);inverse['launch_ready']=False;ak=str((H/'plan.json').relative_to(R));pk=str((H/'pending-plan.json').relative_to(R));del inverse['inputs_sha256'][ak];del inverse['inputs_sha256'][gk];inverse['inputs_sha256'][pk]=sha(H/'pending-plan.json');assert inverse==read(H/'pending-launch-plan.json')
spec=importlib.util.spec_from_file_location('_actual_T10_authority_stdlib',H/'run.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);master=read(H/'brep-master.json');m.verify_master(master,p['files_sha256'],p)
source=read(H/'source-changes.json');text=(H/'run.py').read_text()
for row in reversed(source['replacements']):assert text.count(row['after'])==1;text=text.replace(row['after'],row['before'],1)
assert hashlib.sha256(text.encode()).hexdigest()==source['original_run_sha256']
for n,h in source['unchanged'].items():assert sha(H/n)==h
out=H/'output-001';folder=out/'cad-BREP-master/mesh-7';meta=read(folder/'mesh.json');quality=read(folder/'quality.json');imp=read(folder/'BREP-import.json');rosters=read(out/'six-group-rosters-vs-EF7.json')
assert a['mesh_metadata']==meta and a['quality']==quality and a['BREP_import']==imp
assert meta['nodes']<=p['maximum_nodes']and meta['C3D10_elements']<=p['maximum_elements']and meta['element_order']==2 and meta['straight_midsides']and meta['global_mesh_size_factor']==7/8
assert quality['finite']and quality['nonpositive_elements']==0 and quality['minimum_Jacobian']>0 and quality['elements']==meta['C3D10_elements']
assert imp['passed']and imp['historical_relative_guard']==1e-8 and imp['nonadaptive_reference_volume_mm3']==master['nonadaptive_import_volume_mm3']and abs(imp['OCC_imported_volume_mm3']/master['nonadaptive_import_volume_mm3']-1)<1e-8
assert imp['actual_import_options_before']==imp['actual_import_options_after']==p['actual_import_options_required']and imp['adaptive_master_volume_mm3']==master['native_volume_mm3']
assert meta['mesh_volume_mm3']/master['native_volume_mm3']-1==meta['volume_relative_error']and meta['BREP_sha256']==master['BREP_sha256']
headers={}
with zipfile.ZipFile(folder/'mesh.npz')as z:
 for name in z.namelist():
  with z.open(name)as f:
   assert f.read(6)==b'\x93NUMPY';version=f.read(2);width=2 if version==b'\x01\x00'else 4;n=int.from_bytes(f.read(width),'little');headers[name]=ast.literal_eval(f.read(n).decode('latin1').strip())
assert headers['tags.npy']['shape']==(meta['nodes'],)and headers['xyz.npy']['shape']==(meta['nodes'],3)
assert set(rosters)==set(meta['bore_node_counts'])=={'bolt0','bolt1','bolt2','bolt3','end0','end1'}
assert all(headers[name+'.npy']['shape']==(meta['bore_node_counts'][name],)and rosters[name]['new_count']==meta['bore_node_counts'][name]for name in rosters)
mode=None;nodecount=elementcount=0
with(folder/'mesh.inp').open()as f:
 for line in f:
  line=line.strip()
  if not line or line.startswith('**'):continue
  if line.startswith('*'):mode='nodes'if line.upper().startswith('*NODE')else'elements'if line.upper().startswith('*ELEMENT')and'TYPE=C3D10'in line.upper().replace(' ','')else None;continue
  if mode=='nodes':nodecount+=1
  elif mode=='elements':assert len(line.split(','))==11;elementcount+=1
assert nodecount==meta['nodes']and elementcount==meta['C3D10_elements']
for name,h in a['outputs_sha256'].items():assert sha(out/name)==h
assert read(out/'runtime-before.json')==read(out/'runtime-after.json')
r=subprocess.run(['/bin/ps','-g','44713','-o','pid=,ppid=,pgid=,stat='],capture_output=True,text=True,timeout=2);assert r.returncode==1 and not r.stdout.strip()and not r.stderr.strip()
artifacts={str(q.relative_to(H)):dict(bytes=q.stat().st_size,sha256=sha(q))for root in [out,H/'execution-001']for q in sorted(root.rglob('*'))if q.is_file()}
report=dict(schema='preserved_taper_T10_actual_terminal_1',status='actual_owned_RC0_T10_mesh_no_FEA_no_qualification',actual_tool_session=59468,actual_tool_launch_chunk='f68cb8',actual_tool_terminal_chunk='91a8ce',actual_tool_returncode=0,actual_child_returncode=0,pid=44713,pgid=44713,parent_pid=44709,started_sha256=sha(H/'execution-001/started.json'),supervision_sha256=sha(H/'execution-001/execution-receipt.json'),assessment_sha256=sha(out/'assessment.json'),plan_sha256=sha(H/'plan.json'),launch_sha256=sha(H/'launch-plan.json'),root_GO_sha256=sha(R/p['root_GO']),direct_child_reaped=True,final_group_members=[],fresh_PGID_absent=True,signals=[],timeout=False,cleanup_error=None,unique_pins=len(pins),all_pins_actual_equal=True,whole_pending_inverse_equal=True,mesh_body_and_rosters_byte_exact=True,whole_outputs=artifacts,mesh_metadata=meta,quality=quality,BREP_import=imp,NPZ_headers=headers,INP_node_count=nodecount,INP_C3D10_count=elementcount,six_roster_summary=a['roster_summary'],roster_identity_claimed=False,supervision_seconds=s['elapsed_seconds'],child_seconds=a['elapsed_seconds'],native_maxRSS_bytes=a['maximum_RSS_bytes_macos'],candidate_qualified=False,law_original_RC1_preserved=True,protected_interfaces_pending=True,FEA_executed=False,collector_source_sha256=sha(__file__),collector_seconds=time.monotonic()-began)
with(H/'terminal-collection.json').open('x')as f:json.dump(report,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
print(json.dumps(dict(status=report['status'],terminal_sha256=sha(H/'terminal-collection.json'),nodes=meta['nodes'],C3D10=meta['C3D10_elements'],getMass=imp['OCC_imported_volume_mm3'],import_relative_error=imp['relative_volume_difference'],mesh_volume_error=meta['volume_relative_error'],minimum_Jacobian=quality['minimum_Jacobian'],outputs=len(artifacts),pins=len(pins))))
