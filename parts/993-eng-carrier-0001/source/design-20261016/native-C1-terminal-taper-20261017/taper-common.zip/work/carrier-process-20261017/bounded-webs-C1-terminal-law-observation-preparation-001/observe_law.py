"""Observe one original C1 terminal law; Simulate is explicit, final Build forbidden."""
import hashlib,json,math,os,resource,signal,sys,time,traceback
from fractions import Fraction as Q
from pathlib import Path
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[2]
IDS=[431,293,292,291,290,289,161]
def require(ok,message):
    if not ok:raise ValueError(message)
def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb')as f:
        for b in iter(lambda:f.read(1024**2),b''):h.update(b)
    return h.hexdigest()
def write(path,value):
    with Path(path).open('x')as f:json.dump(value,f,indent=2,allow_nan=False);f.write('\n');f.flush();os.fsync(f.fileno())
def event(out,stage,state):
    with(out/'stages.jsonl').open('a')as f:f.write(json.dumps(dict(stage=stage,state=state))+'\n');f.flush();os.fsync(f.fileno())
def proof(poles,knots,mults,degree,physical,zero):
    require(degree==3 and type(degree)is int and mults==[4,4] and len(poles)==4 and len(knots)==2,'Only the explicit cubic two-knot law is accepted')
    require(all(type(x)is float and math.isfinite(x)for x in [*poles,*knots,*physical,zero]),'Finite native doubles required')
    require(knots==physical and knots[0]<knots[1] and zero in knots,'Law must span the actual edge endpoints')
    expected=[0.,0.,1.,1.]if zero==knots[0]else[1.,1.,0.,0.]
    require(poles==expected,'Terminal orientation or explicit poles differ')
    lo,hi=map(Q,knots)
    return dict(method='exact_cubic_Bernstein_smoothstep_on_physical_edge_1',physical_interval_Q=[str(lo),str(hi)],zero_at_native_abscissa_Q=str(Q(zero)),poles_Q=list(map(lambda x:str(Q(x)),poles)),normalized_polynomial='3*t^2-2*t^3'if zero==knots[0]else'1-3*t^2+2*t^3',bound_Q=['0','1'],derivative_factorization='6*t*(1-t)/(hi-lo)'if zero==knots[0]else'-6*t*(1-t)/(hi-lo)',endpoint_derivatives_Q=['0','0'],strict_interior_bounds=True,scope='law_only_not_solid_geometry_or_strength')
def read_laws(builder,edges):
    rows=[]
    for i in IDS:
        e=edges[i].wrapped;row=dict(edge_index_zero_based=i,native_orientation=str(e.Orientation()))
        try:
            row['is_constant']=bool(builder.IsConstant(1,e))
            if row['is_constant']:row['constant_radius_mm']=builder.Radius(1,e)
            else:
                law=builder.GetLaw(1,e);lo,hi=law.Bounds();curve=law.Curve()
                row.update(native_law_type=type(law).__name__,native_law_bounds=[lo,hi],native_endpoint_values=[law.Value(lo),law.Value(hi)],native_endpoint_D1=[list(law.D1(lo)),list(law.D1(hi))],native_degree=curve.Degree(),native_poles=[curve.Pole(k)for k in range(1,curve.NbPoles()+1)],native_knots=[curve.Knot(k)for k in range(1,curve.NbKnots()+1)],native_multiplicities=[curve.Multiplicity(k)for k in range(1,curve.NbKnots()+1)],native_rational=bool(curve.IsRational()),native_periodic=bool(curve.IsPeriodic()))
        except Exception as error:row['unavailable_reason']=dict(type=type(error).__name__,message=str(error))
        rows.append(row)
    return rows
def other_six(rows):
    require([r['edge_index_zero_based']for r in rows]==IDS,'Complete ordered seven-edge law table required')
    require(all(r.get('is_constant')is True and r.get('constant_radius_mm')==1. and 'unavailable_reason'not in r for r in rows if r['edge_index_zero_based']!=431),'Every other original contour edge must remain R1')
def verify(path,expected,native=False):
    require(sha(path)==expected,'Plan hash differs');p=json.loads(Path(path).read_text())
    if native:require(p['launch_ready']is True,'NON-ARMED: ROOT review/GO required')
    require(p['schema']=='C1-original-terminal-smoothstep-law-observation-1'and p['contour']==IDS and p['terminal_edge']==431 and p['zero_vertex']==302,'Original single terminal scope required')
    require(p['bounds']==dict(outer=180,inner=150,CPU=[140,141],threads=1,workers=0),'Observation bounds differ')
    before={k:sha(ROOT/k)for k in p['files_sha256']};require(before==p['files_sha256'],'Input/source/runtime drift')
    out=ROOT/p['output_directory'];require(not out.exists()and not any(x.is_symlink()for x in [out,*out.parents]),'Fresh nonsymlink output required')
    if not native:require(not(ROOT/p['execution_directory']).exists(),'Fresh supervision required at preflight')
    return p,before,out
def run(path,expected):
    started=time.monotonic();p,before,out=verify(path,expected,True);out.mkdir();code=1
    report=dict(schema='C1-original-terminal-smoothstep-native-law-observation-1',status='incomplete_law_observation',method='original_C1_Simulate_then_one_explicit_Law_BSpFunc_SetLaw_1',sources_before=before,candidate_qualified=False,final_Build_called=False,Shape_called=False,Cut_called=False,shape_exported=False,FEA_executed=False,law_persistence_through_future_Build=None)
    signal.signal(signal.SIGALRM,lambda *_:(_ for _ in ()).throw(TimeoutError('150s terminal-law observation bound')));signal.alarm(150);resource.setrlimit(resource.RLIMIT_CPU,(140,141))
    try:
        require(os.getpriority(os.PRIO_PROCESS,0)==10,'nice10 child required');sys.path.insert(0,str(ROOT/p['native_site']))
        from build123d import import_step
        from OCP.BRep import BRep_Tool
        from OCP.BRepAdaptor import BRepAdaptor_Curve
        from OCP.BRepFilletAPI import BRepFilletAPI_MakeFillet
        from OCP.Law import Law_BSpline,Law_BSpFunc
        from OCP.TColStd import TColStd_Array1OfReal,TColStd_Array1OfInteger
        from OCP.OSD import OSD_ThreadPool
        OSD_ThreadPool.DefaultPool_s().Init(1)
        report['actual_binding_docs']={name:obj.__doc__ for name,obj in [('Law_BSpline',Law_BSpline.__init__),('Law_BSpFunc',Law_BSpFunc.__init__),('SetLaw',BRepFilletAPI_MakeFillet.SetLaw),('Simulate',BRepFilletAPI_MakeFillet.Simulate)]}
        body=import_step(ROOT/p['STEP']);faces,edges,vertices=list(body.faces()),list(body.edges()),list(body.vertices());require(body.is_valid and len(body.solids())==1 and len(faces)==240 and len(edges)==733,'Actual original baseline topology required')
        prior=json.loads((ROOT/p['contour_diagnostic']).read_text())['initial_contours'][0];require([r['edge_index_zero_based']for r in prior['edges']]==IDS,'Closed original contour differs')
        face_edges=[list(f.edges())for f in faces]
        for row in prior['edges']:
            i=row['edge_index_zero_based'];e=edges[i];curve=BRepAdaptor_Curve(e.wrapped);adj=[j for j,es in enumerate(face_edges)if any(e.wrapped.IsSame(x.wrapped)for x in es)]
            require(e.length==row['length_mm']and str(curve.GetType())==row['curve_type']and[curve.FirstParameter(),curve.LastParameter()]==row['domain']and adj==row['adjacent_faces_zero_based'],'Original contour edge geometry differs')
            actual=sorted(tuple(BRep_Tool.Pnt_s(v.wrapped).Coord())for v in e.vertices());wanted=sorted(tuple(r['point_mm'])for r in row['vertices']);require(actual==wanted,'Original contour endpoint coordinates differ')
        require(edges[431].length==21.430826650472525,'The whole measured original edge431 is required')
        builder=BRepFilletAPI_MakeFillet(body.solids()[0].wrapped)
        for i in IDS:builder.Add(1.,edges[i].wrapped)
        ids=[next(i for i,e in enumerate(edges)if e.wrapped.IsSame(builder.Edge(1,j)))for j in range(1,builder.NbEdges(1)+1)]
        require(builder.NbContours()==1 and ids==IDS,'Only the original seven-edge contour is allowed')
        def endpoints():
            return [[i for i,v in enumerate(vertices)if v.wrapped.IsSame(x)]for x in [builder.FirstVertex(1),builder.LastVertex(1)]]
        require(endpoints()==[[302],[125]],'Actual original contour endpoint identities differ')
        zero=vertices[302].wrapped;require(list(BRep_Tool.Pnt_s(zero).Coord())==[82.202665223312,-14.18196820123,12.756757217282],'Actual window endpoint differs')
        physical=[]
        for i in IDS:
            vs=list(edges[i].vertices());pairs=[]
            for v in vs:
                vid=[j for j,w in enumerate(vertices)if w.wrapped.IsSame(v.wrapped)];require(len(vid)==1,'Unique original vertex identity required');pairs.append(dict(vertex_index_zero_based=vid[0],point_mm=list(BRep_Tool.Pnt_s(v.wrapped).Coord()),native_contour_abscissa_mm=builder.Abscissa(1,v.wrapped)))
            require(len(pairs)==2,'Two whole physical edge endpoints required');pairs.sort(key=lambda r:r['native_contour_abscissa_mm']);physical.append(dict(edge_index_zero_based=i,endpoints_in_abscissa_order=pairs,native_edge_length_mm=edges[i].length))
        report.update(native_physical_edge_abscissae=physical,native_contour_length_mm=builder.Length(1),initial_laws=read_laws(builder,edges));other_six(report['initial_laws'])
        require(all(r.get('is_constant')is True and r.get('constant_radius_mm')==1. for r in report['initial_laws']),'Initial full contour must be R1')
        builder.SetRadius(0.,1,zero);report['provisional_setup_laws']=read_laws(builder,edges);other_six(report['provisional_setup_laws'])
        report['stage']='before_preparatory_Simulate';write(out/'setup-before-Simulate.json',report)
        report['stage']='preparatory_Simulate';event(out,'preparatory_Simulate','begin')
        try:builder.Simulate(1)
        except Exception as error:report['Simulate_error']=dict(type=type(error).__name__,message=str(error));report['simulated_laws']=read_laws(builder,edges);raise
        event(out,'preparatory_Simulate','returned');report['simulated_surface_count']=builder.NbSurf(1);report['simulated_sections_scope']='provisional_automatic_law_before_explicit_SetLaw';report['simulated_laws']=read_laws(builder,edges);other_six(report['simulated_laws']);require('unavailable_reason'not in report['simulated_laws'][0],'Simulate did not make target elementary law accessible')
        target=physical[0]['endpoints_in_abscissa_order'];lo,hi=[r['native_contour_abscissa_mm']for r in target];z=builder.Abscissa(1,zero);poles=[0.,0.,1.,1.]if z==lo else[1.,1.,0.,0.];report['requested_exact_law_proof']=proof(poles,[lo,hi],[4,4],3,[lo,hi],z)
        def array(cls,values):
            result=cls(1,len(values))
            for i,x in enumerate(values,1):result.SetValue(i,x)
            return result
        curve=Law_BSpline(array(TColStd_Array1OfReal,poles),array(TColStd_Array1OfReal,[lo,hi]),array(TColStd_Array1OfInteger,[4,4]),3,False);law=Law_BSpFunc(curve,lo,hi)
        report['stage']='explicit_one_edge_SetLaw';event(out,'explicit_one_edge_SetLaw','begin');builder.SetLaw(1,edges[431].wrapped,law);event(out,'explicit_one_edge_SetLaw','returned')
        rows=read_laws(builder,edges);report['explicit_laws']=rows;other_six(rows);r=rows[0];require('unavailable_reason'not in r and not r['is_constant']and r['native_rational']is False and r['native_periodic']is False,'Explicit nonrational target law required')
        report['attached_exact_law_proof']=proof(r['native_poles'],r['native_knots'],r['native_multiplicities'],r['native_degree'],[lo,hi],z);require(r['native_law_bounds']==[lo,hi]and r['native_endpoint_values']==[poles[0],poles[-1]],'Attached law endpoints/bounds differ')
        require(endpoints()==[[302],[125]]and builder.Length(1)==report['native_contour_length_mm'],'Contour endpoints/length changed');report.update(status='explicit_terminal_law_observed_no_final_Build',stage='complete_law_observation',all_seven_laws_observed=True,other_six_constant_R1=True,opposite_endpoint_unchanged=True,explicit_SetLaw_edge=431,Simulate_calls=1,Simulate_sections_not_recomputed_after_SetLaw=True);code=0
    except BaseException as error:report['failure']=dict(type=type(error).__name__,message=str(error),traceback=traceback.format_exc())
    finally:
        signal.alarm(0);after={k:sha(ROOT/k)for k in before};report.update(sources_after=after,sources_unchanged=before==after,elapsed_seconds=time.monotonic()-started)
        if before!=after:report['status']='refused_input_drift';code=1
        write(out/'assessment.json',report)
    print(json.dumps(dict(status=report['status'],assessment_sha256=sha(out/'assessment.json'),final_Build_called=False)),flush=True);return code
if __name__=='__main__':
    mode,path,expected=sys.argv[1:]
    if mode=='preflight':p,_,_=verify(path,expected);print(json.dumps(dict(status='stdlib_preflight_no_native',armed=p['launch_ready'])))
    elif mode=='run':raise SystemExit(run(path,expected))
    else:raise ValueError('Use preflight or run PLAN SHA')
