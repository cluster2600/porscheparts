"""Read-only actual C1 peak: retained neighbourhood functions, explicit D2 and section."""
import ast
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import resource
import signal
import sys
import time

HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[2]
def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb')as f:
        for block in iter(lambda:f.read(1024**2),b''):h.update(block)
    return h.hexdigest()
def write(path,value):
    with Path(path).open('x')as f:json.dump(value,f,indent=2,allow_nan=False);f.write('\n');f.flush();os.fsync(f.fileno())
def load(name,path):
    s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
def verify(plan_path,expected,native=False):
    if sha(plan_path)!=expected:raise ValueError('Plan identity differs')
    p=json.loads(Path(plan_path).read_text())
    if native and p['launch_ready']is not True:raise ValueError('NON-ARMED: no CAD kernel before root review')
    if p['schema']!='actual-C1-common-IP-native-plan-1' or p['bounds']!=dict(outer=180,inner=150,CPU=[140,141],threads=1,workers=0):raise ValueError('Fixed diagnostic bounds differ')
    pins={name:sha(ROOT/name)for name in p['files_sha256']}
    if pins!=p['files_sha256']:raise ValueError('A pinned input/source/runtime differs')
    output=ROOT/p['output_directory']
    if output.exists()or any(q.is_symlink()for q in [output,*output.parents]):raise ValueError('Fresh nonsymlink output required')
    return p,pins,output
def retained_namespace(path,namespace):
    tree=ast.parse(Path(path).read_text());run=next(n for n in tree.body if isinstance(n,ast.FunctionDef)and n.name=='run')
    names=('query','bounds','surface_info','edge_info');nodes=[next(n for n in run.body if isinstance(n,ast.FunctionDef)and n.name==name)for name in names]
    exec(compile(ast.Module(body=nodes,type_ignores=[]),str(path),'exec'),namespace)
    return namespace

def run(plan_path,expected):
    started=time.monotonic();p,before,out=verify(plan_path,expected,True);out.mkdir();report=dict(status='incomplete_native_diagnostic',probes=[]);code=1
    signal.signal(signal.SIGALRM,lambda *_:(_ for _ in ()).throw(TimeoutError('150s C1 native diagnostic bound')))
    signal.alarm(150);resource.setrlimit(resource.RLIMIT_CPU,(140,141))
    try:
        if os.getpriority(os.PRIO_PROCESS,0)!=10:raise ValueError('nice10 child required')
        sys.path.insert(0,str(ROOT/p['native_site']))
        import numpy as np
        from build123d import import_brep,Edge
        from OCP.BRep import BRep_Tool
        from OCP.BRepAdaptor import BRepAdaptor_Curve,BRepAdaptor_Surface
        from OCP.BRepBuilderAPI import BRepBuilderAPI_MakeVertex
        from OCP.BRepExtrema import BRepExtrema_DistShapeShape
        from OCP.BRepLProp import BRepLProp_SLProps
        from OCP.BRepAlgoAPI import BRepAlgoAPI_Section
        from OCP.IntCurvesFace import IntCurvesFace_ShapeIntersector
        from OCP.OSD import OSD_ThreadPool
        from OCP.Precision import Precision
        from OCP.Standard import Standard_Failure
        from OCP.TopAbs import TopAbs_EDGE
        from OCP.TopExp import TopExp_Explorer
        from OCP.TopoDS import TopoDS
        from OCP.gp import gp_Pnt,gp_Dir,gp_Pln,gp_Lin
        OSD_ThreadPool.DefaultPool_s().Init(1)
        energy=load('_C1_retained_energy',ROOT/p['energy_source']);locate=load('_C1_retained_IP',ROOT/p['location_source'])
        normals=load('_C1_retained_normal',ROOT/p['boundary_normal_source']);local=load('_C1_explicit_D2',HERE/'local_properties.py')
        binding=load('_C1_closed_BREP_binding',ROOT/p['binding_source']);metadata=json.loads((ROOT/p['mesh_metadata']).read_text())
        source=binding.verify((ROOT/p['mesh']).parent,metadata)
        if source['sha256']!=p['BREP_sha256']:raise ValueError('Actual C1 BREP authority differs')
        peaks=[json.loads((ROOT/n).read_text())for n in p['peak_files']];ties=[r['all_global_maximum_ties']for r in peaks]
        closed=json.loads((ROOT/p['root_cases']).read_text())
        if closed['status']!='root_closed_two_actual_C1_BREP_linear_cases_energy_PASS_all_peaks_preserved':raise ValueError('Actual two-case root closure missing')
        for role,name,peak in zip(('rigid','spring'),('combined-rigid-static','combined-spring-1000-static'),peaks):
            if (peak['case']!=name or peak['CAD_source']['sha256']!=source['sha256'] or
                    closed['cases'][role]['all_global_peak_ties']!=peak['all_global_maximum_ties']):raise ValueError('Foreign CAD/case/global peak')
        if any(len(r)!=1 for r in ties):raise ValueError('Review all actual global ties before choosing a common probe')
        common=ties[0][0];keys=('element_id','IP_one_based','reference_undeformed_IP_xyz_mm')
        if any(any(r[0][k]!=common[k]for k in keys)for r in ties):raise ValueError('Actual C1 common peak differs across cases')
        tags,xyz,eids,conn=energy.read_mesh(ROOT/p['mesh']);selected=np.flatnonzero(eids==common['element_id'])
        if len(selected)!=1:raise ValueError('Actual peak element missing or duplicate')
        indices=conn[int(selected[0])];nodes=xyz[indices].tolist();point=locate.gauss_point(nodes,common['IP_one_based'])
        if point!=p['point_mm'] or point!=common['reference_undeformed_IP_xyz_mm']:raise ValueError('Recomputed current T10 IP differs')
        body=import_brep(ROOT/p['BREP'])
        if not body.is_valid or len(body.solids())!=1:raise ValueError('One valid native BREP solid required')
        faces,edges=list(body.faces()),list(body.edges());face_edges=[list(f.edges())for f in faces]
        ns=retained_namespace(ROOT/p['neighbourhood_source'],dict(np=np,math=math,faces=faces,edges=edges,face_edges=face_edges,normals=normals,
            BRep_Tool=BRep_Tool,BRepAdaptor_Surface=BRepAdaptor_Surface,BRepAdaptor_Curve=BRepAdaptor_Curve,
            BRepBuilderAPI_MakeVertex=BRepBuilderAPI_MakeVertex,BRepExtrema_DistShapeShape=BRepExtrema_DistShapeShape,gp_Pnt=gp_Pnt,Standard_Failure=Standard_Failure))
        tolerance=max(Precision.Confusion_s(),*(BRep_Tool.Tolerance_s(f.wrapped)for f in faces));box=ns['bounds'](body);diagonal=math.dist(*box)
        if not math.isfinite(diagonal)or diagonal<=0:raise ValueError('Finite native body bound required')
        def properties(index,result):
            count=result.NbSolution()
            if count!=1:return dict(status='unresolved_native_multiple_closest_supports',closest_solution_count=count,local_chord=None)
            row=dict(status='closest_support_not_face_interior',support_type=str(result.SupportTypeShape2(1)),local_chord=None)
            if not row['support_type'].endswith('IsInFace'):return row
            u,v=result.ParOnFaceS2(1);face=faces[index]
            props=BRepLProp_SLProps(BRepAdaptor_Surface(face.wrapped,True),u,v,2,tolerance)
            row.update(local.curvature(props,str(face.wrapped.Orientation())),UV=[u,v],kernel_resolution_mm=tolerance)
            if row['status']!='native_D2_at_reported_UV':return row
            start=list(result.PointOnShape2(1).Coord());row['point_mm']=start
            if any(not a<=c<=b for a,c,b in zip(box[0],start,box[1])):row['local_chord']=dict(status='point_outside_native_box',thickness_mm=None);return row
            shells=list(body.shells())
            if len(shells)!=1:row['local_chord']=dict(status='unresolved_native_multiple_shells',shell_count=len(shells),thickness_mm=None);return row
            ray=IntCurvesFace_ShapeIntersector();ray.Load(shells[0].wrapped,tolerance)
            ray.Perform(gp_Lin(gp_Pnt(*start),gp_Dir(*[-v for v in row['normal_outward']])),0.,diagonal)
            if not ray.IsDone():raise ValueError('Native normal-line intersection incomplete')
            hits=[]
            for k in range(1,ray.NbPnt()+1):
                faceids=[j for j,f in enumerate(faces)if f.wrapped.IsSame(ray.Face(k))]
                if len(faceids)!=1:raise ValueError('Native ray face identity is not unique')
                q=list(ray.Pnt(k).Coord());w=ray.WParameter(k)
                if not all(math.isfinite(x)for x in [*q,w]):raise ValueError('Nonfinite normal-line intersection')
                hits.append(dict(W_mm=w,point_mm=q,face_index_zero_based=faceids[0],state=str(ray.State(k)),transition=str(ray.Transition(k)),
                    coincident_with_start_native_tolerance=math.dist(q,start)<=tolerance))
            row.update(normal_line_bound_mm=[0.,diagonal],normal_line_intersections=hits,local_chord=local.qualify_chord(hits,index))
            return row
        for label,probe in [('common_IP',point),*[(f'corner_{i}',q)for i,q in enumerate(nodes[:4])]]:
            fq=sorted(((ns['query'](probe,f),i)for i,f in enumerate(faces)),key=lambda r:(r[0].Value(),r[1]))
            eq=sorted(((ns['query'](probe,e),i)for i,e in enumerate(edges)),key=lambda r:(r[0].Value(),r[1]));fr=[];er=[]
            for result,i in fq:
                if len(fr)>=8 and result.Value()!=fr[7]['distance_mm']:break
                row=dict(**ns['surface_info'](i),distance_mm=result.Value(),closest_points_mm=[list(result.PointOnShape2(k).Coord())for k in range(1,result.NbSolution()+1)])
                try:row['local_properties']=properties(i,result)
                except (RuntimeError,ValueError,Standard_Failure)as error:row['local_properties']=dict(status='unresolved_native_properties',reason=str(error),local_chord=None)
                fr.append(row)
            for result,i in eq:
                if len(er)>=8 and result.Value()!=er[7]['distance_mm']:break
                er.append(dict(**ns['edge_info'](i,result),distance_mm=result.Value(),closest_points_mm=[list(result.PointOnShape2(k).Coord())for k in range(1,result.NbSolution()+1)]))
            report['probes'].append(dict(label=label,point_mm=probe,all_face_distances_mm=[[i,r.Value()]for r,i in fq],all_edge_distances_mm=[[i,r.Value()]for r,i in eq],nearest_faces=fr,nearest_edges=er))
        section=BRepAlgoAPI_Section(body.wrapped,gp_Pln(gp_Pnt(point[0],0.,0.),gp_Dir(1.,0.,0.)),False);section.Approximation(False);section.Build()
        if not section.IsDone():raise ValueError('Native exact-plane section incomplete')
        explorer=TopExp_Explorer(section.Shape(),TopAbs_EDGE);curves=[]
        while explorer.More():
            edge=TopoDS.Edge_s(explorer.Current());curve=BRepAdaptor_Curve(edge);kind=str(curve.GetType())
            row=dict(index=len(curves),curve_type=kind,length_mm=Edge(edge).length,parameter_domain=[curve.FirstParameter(),curve.LastParameter()],native_tolerance_mm=BRep_Tool.Tolerance_s(edge))
            if kind.endswith('GeomAbs_Circle'):row['native_radius_mm']=curve.Circle().Radius()
            curves.append(row);explorer.Next()
        if not curves:raise ValueError('Empty actual-IP native section')
        report.update(status='actual_C1_common_IP_native_diagnostic_complete',CAD_source=source,common_peak={k:common[k]for k in keys},element_node_ids=tags[indices].tolist(),element_nodes_mm=nodes,
            BREP_faces=len(faces),BREP_edges=len(edges),native_tolerance_mm=tolerance,section=dict(X_mm=point[0],Approximation=False,edges=curves),role_assignment=None,
            scope='Native local geometric measurements only; no all-parameter continuity/global minimum thickness/stress convergence claim',CAD_changed=False,FEA_executed=False)
        code=0
    except BaseException as error:report['failure']=dict(type=type(error).__name__,message=str(error))
    finally:
        signal.alarm(0);after={name:sha(ROOT/name)for name in before};report.update(sources_before=before,sources_after=after,sources_unchanged=before==after,elapsed_seconds=time.monotonic()-started)
        if before!=after:code=1;report['status']='refused_sources_changed'
        write(out/'assessment.json',report)
    print(json.dumps(dict(status=report['status'],assessment_sha256=sha(out/'assessment.json'),elapsed_seconds=report['elapsed_seconds'])));return code

if __name__=='__main__':
    plan=HERE/'pending-plan.json'
    if sys.argv[1]=='preflight':p,_,_=verify(plan,sys.argv[2]);print(json.dumps(dict(status='source_and_inputs_checked_no_native_import',armed=p['launch_ready'])))
    elif sys.argv[1]=='run':raise SystemExit(run(Path(sys.argv[2]),sys.argv[3]))
    else:raise ValueError('Use preflight SHA or run ARMED_PLAN SHA')
