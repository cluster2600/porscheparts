"""Seal the actual owned Gmsh surface result; no mesh or CAD recomputation."""
import hashlib,importlib.util,json,os,time
from pathlib import Path
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[2]
s=importlib.util.spec_from_file_location('_surface_terminal_stdlib',HERE/'run_meshing.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m);sha=m.sha
read=lambda p:json.loads(p.read_text());start=time.monotonic();p=read(HERE/'plan.json');launch=read(HERE/'launch-plan.json');sup=read(HERE/'execution-001/execution-receipt.json');a=read(HERE/'output-001/assessment.json');g=read(HERE/'output-001/surface/meshing.json')
assert sha(HERE/'launch-plan.json')=='950436c7c4379b925d6d88d0a09b94bc9b16b2adf3adad7445fde2c1458c0f3e'
assert sup['plan_sha256']==sha(HERE/'launch-plan.json')and sup['command']==launch['command']and sup['actual_returncode']==0 and sup['status']=='executed'
assert sup['direct_child_reaped']and sup['no_non_zombie_group_members']and sup['final_group_members']==[]and sup['cleanup_error']is None and sup['failure']is None and not sup['timeout']and not sup['interrupted']and sup['signals_to_owned_group_only']==[]
pins={**launch['inputs_sha256'],**launch['source_sha256']};assert sup['sources_before']==sup['sources_after']==pins and sup['sources_and_plan_unchanged']and {n:sha(ROOT/n)for n in pins}==pins
assert a['sources_and_runtime_before']==a['sources_and_runtime_after']==p['files_sha256']and a['inputs_runtime_plan_unchanged']
assert a['status']=='surface_generated_not_yet_audited'and a['candidate_qualified']is False and a['law_status']=='original_post_Build_law_RC1_preserved'and a['surface_audit_completed']is False
assert g['CAD_source']==a['CAD_source']==p['CAD_source']and g['gmsh_version']=='4.15.2'and g['source_CAD_changed']is False
assert g['options']==dict(MeshSizeMin=.25,MeshSizeMax=3,MeshSizeFromCurvature=96,Algorithm=6,ElementOrder=1,Smoothing=0)
stl=HERE/'output-001/surface/carrier-remeshed.stl';assert g['candidate_STL_sha256']==sha(stl);count=m.binary_count(stl);assert a['triangles']==count
for n,h in sup['logs_sha256'].items():assert sha(HERE/'execution-001'/n)==h
files={}
for folder in ('execution-001','output-001'):
 for f in sorted((HERE/folder).rglob('*')):
  if f.is_dir():continue
  assert f.is_file()and not f.is_symlink();files[str(f.relative_to(HERE))]=dict(bytes=f.stat().st_size,sha256=sha(f))
assert len(files)==8
r=dict(schema='closed-preserved-taper-surface-generation-1',status='surface_generated_not_yet_audited',collector_source_sha256=sha(__file__),actual_session_id=25165,actual_initial_chunk='3493c1',actual_terminal_chunk='43c781',own_handle_collected=True,actual_outer_returncode=0,actual_child_returncode=0,supervisor_wall_seconds=sup['elapsed_seconds'],native_wall_seconds=a['wall_seconds'],native_CPU_seconds=a['CPU_seconds'],native_maxRSS_bytes=a['maxRSS_bytes'],direct_child_reaped=True,final_group_members=[],cleanup_error=None,timeout=False,interrupted=False,signals=[],plan_sha256=sha(HERE/'plan.json'),launch_plan_sha256=sha(HERE/'launch-plan.json'),supervision_sha256=sha(HERE/'execution-001/execution-receipt.json'),assessment_sha256=sha(HERE/'output-001/assessment.json'),started_sha256=sha(HERE/'execution-001/started.json'),fresh_launch_unique_pins_verified=len(pins),all_current_equal=True,master_BREP_sha256=p['CAD_source']['sha256'],triangles=count,source_CAD_changed=False,Gmsh_native_thread_setting=2,Python_workers=0,outputs=files,sampled_distance_audit_executed=False,volume_fidelity_audit_executed=False,topology_audit_executed=False,candidate_qualified=False,law_status=a['law_status'],downstream_checks=a['downstream_checks'],global_admission=False,FEA_started=False,elapsed_collection_seconds=time.monotonic()-start)
with(HERE/'terminal-collection-001.json').open('x')as f:json.dump(r,f,indent=2,allow_nan=False);f.write('\n');f.flush();os.fsync(f.fileno())
print(json.dumps(dict(terminal_sha256=sha(HERE/'terminal-collection-001.json'),assessment_sha256=r['assessment_sha256'],supervision_sha256=r['supervision_sha256'],whole_files=len(files),current_pins=len(pins),triangles=count,STL_sha256=sha(stl))))
