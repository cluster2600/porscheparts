"""Small stdlib doubles only; no Docker, mesh loader or native library imports."""
import copy
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

HERE=Path(__file__).resolve().parent
def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
caller=load('_joint_caller_tests',HERE/'run.py');worker=load('_joint_worker_tests',HERE/'source/worker.py')
CID='a'*64
class Fake:
    def __init__(self,plan,mode='normal'):self.plan=plan;self.mode=mode;self.calls=[];self.started=False
    def data(self):
        p=self.plan
        return dict(Id=CID,Name='/'+p['container_name'],Owner=p['ownership_token'],Image=p['image'],User=p['user'],
            NanoCpus=10**9,Memory=4*1024**3,MemorySwap=4*1024**3,PidsLimit=64,NetworkMode='none',ReadonlyRootfs=True,
            Tmpfs={'/tmp':'rw,size=128m'},Entrypoint=['/usr/bin/timeout'],Cmd=p['container_command'],WorkingDir='/output',
            Mounts=[dict(Type='bind',Source=p[k],Destination=d,RW=rw)for k,d,rw in [('source_directory','/source',False),('STL','/input/carrier.stl',False),('BREP_receipt','/input/brep-audit.json',False),('CAD_samples','/input/exact-CAD-surface-samples.npz',False),('output_directory','/output',True)]],
            Running=False,ExitCode=7 if self.mode=='exit7'and self.started else 0,OOMKilled=False,StateError='')
    def invoke(self,args,timeout,log=None,ignore_cancel=False):
        self.calls.append(args);stdout='';rc=0;timed=False
        if args[:2]==['image','inspect']:stdout=json.dumps(dict(Id=self.plan['image'],Architecture='arm64',Os='linux'))
        elif args[0]=='create':stdout='unknown'if self.mode=='unknown'else CID
        elif args[:2]==['container','inspect']:
            if self.mode=='query_error':rc=1
            else:stdout=json.dumps(self.data())
        elif args[0]=='start':
            self.started=True
            if self.mode=='timeout':timed=True;rc=-9
            else:
                if self.mode=='exit7':rc=7
                output=Path(self.plan['output_directory'])
                for n in ['runtime-before.json','runtime-after.json']:(output/n).write_text('{}')
                (output/'joint').mkdir();(output/'joint/cad-mesh-audit.json').write_text(json.dumps(dict(status='passed',failures=[],candidate_STL_sha256=self.plan['STL_sha256'],BRep_receipt_sha256=self.plan['BREP_receipt_sha256'],exact_CAD_surface_samples_sha256=self.plan['CAD_samples_sha256'])))
                (output/'assessment.json').write_text(json.dumps(dict(status='joint_surface_checks_passed',STL_sha256=self.plan['STL_sha256'],BREP_receipt_sha256=self.plan['BREP_receipt_sha256'],CAD_samples_sha256=self.plan['CAD_samples_sha256'],input_sources_unchanged=True,runtime_unchanged=True)))
        return dict(returncode=rc,stdout=stdout,stderr='',timed_out=timed,cancelled=False)
class Checks(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup);p=Path(self.tmp.name)
        (p/'source').mkdir();(p/'source/expected-runtime.json').write_text('{}')
        self.plan=dict(container_name='new-test-only',ownership_token='test-token',image='sha256:'+'b'*64,user='503:20',
            source_directory=str(p/'source'),STL=str(p/'input.stl'),STL_sha256='c'*64,BREP_receipt=str(p/'receipt.json'),BREP_receipt_sha256='d'*64,CAD_samples=str(p/'samples.npz'),CAD_samples_sha256='e'*64,
            output_directory=str(p/'output'),execution_directory=str(p/'execution'),container_command=['test'],files_sha256={})
    def run_fake(self,mode):
        backend=Fake(self.plan,mode)
        with patch.object(caller,'verify',lambda _:None):result=caller.supervise(self.plan,backend)
        return result,backend
    def test_normal_actual_rc_and_cleanup(self):
        r,b=self.run_fake('normal');self.assertEqual(r['status'],'joint_surface_checks_passed');self.assertEqual(r['actual_container_exit_code'],0);self.assertTrue(r['container_removed'])
    def test_nonzero_actual_rc_is_preserved(self):
        r,b=self.run_fake('exit7');self.assertEqual(r['actual_container_exit_code'],7);self.assertEqual(r['attach_cli_returncode'],7);self.assertNotEqual(r['status'],'joint_surface_checks_passed');self.assertTrue(r['container_removed'])
    def test_timeout_still_removes_only_owned(self):
        r,b=self.run_fake('timeout');self.assertNotEqual(r['status'],'joint_surface_checks_passed');self.assertIn(['rm','--force',CID],b.calls)
    def test_unknown_create_resolves_name_identity(self):
        r,b=self.run_fake('unknown');self.assertTrue(r['container_removed']);self.assertIn(['rm','--force',CID],b.calls);self.assertNotEqual(r['status'],'joint_surface_checks_passed')
    def test_query_error_does_not_prove_absence_or_authorize_rm(self):
        r,b=self.run_fake('query_error');self.assertEqual(r['status'],'cleanup_unconfirmed');self.assertFalse(r['container_removed']);self.assertFalse(any(a[0]=='rm'for a in b.calls))
    def test_foreign_owner_refused(self):
        d=Fake(self.plan).data();d['Owner']='foreign'
        with self.assertRaises(ValueError):caller.identity(d,self.plan)
    def test_changed_id_refused(self):
        with self.assertRaises(ValueError):caller.identity(Fake(self.plan).data(),self.plan,'d'*64)
    def test_readonly_input_and_memory_are_checked(self):
        d=Fake(self.plan).data();caller.isolation(d,self.plan);d['Mounts'][1]['RW']=True
        with self.assertRaises(ValueError):caller.isolation(d,self.plan)
        d=Fake(self.plan).data();d['MemorySwap']+=1
        with self.assertRaises(ValueError):caller.isolation(d,self.plan)
    def test_receipt_bindings_and_forward_failure(self):
        p=dict(master_BREP_sha256='a',STL_sha256='b',CAD_samples_sha256='c')
        v=dict(CAD_source=dict(format='brep',sha256='a'),results=dict(candidate_STL=dict(sha256='b',maximum_distance_to_BREP_shell_mm=.01)),candidate_sampled_chord_screen_pass=True,exact_CAD_surface_samples_sha256='c',exact_CAD_surface_samples=8638,exact_CAD_volume_mm3=1.,exact_CAD_bounds_mm=[[0,0,0],[1,1,1]])
        worker.validate_receipt(p,v)
        for mutation in [lambda w:w.update(candidate_sampled_chord_screen_pass=False),lambda w:w.update(exact_CAD_surface_samples=8620),lambda w:w['CAD_source'].update(sha256='wrong'),lambda w:w['results']['candidate_STL'].update(maximum_distance_to_BREP_shell_mm=float('nan')),lambda w:w.update(exact_CAD_volume_mm3=0.)]:
            w=copy.deepcopy(v);mutation(w)
            with self.assertRaises(AssertionError):worker.validate_receipt(p,w)
    def test_frozen_math_helpers_are_byte_identical(self):
        root=HERE.parents[2]
        for name in ['audit.py','cad_mesh_brep_audit.py']:
            self.assertEqual((HERE/'source'/name).read_bytes(),(root/'work/carrier-process-20261017/bounded-webs-BREP-surface-remesh-preparation-001/source'/name).read_bytes())
    def test_exactly_one_intersection_operator_and_no_repeated_native(self):
        import ast
        tree=ast.parse((HERE/'source/cad_mesh_brep_audit.py').read_text());calls=[ast.unparse(n.func)for n in ast.walk(tree)if isinstance(n,ast.Call)]
        self.assertEqual(calls.count('igl.predicates.find_self_intersections'),1)
        tree=ast.parse((HERE/'source/worker.py').read_text());calls=[ast.unparse(n.func)for n in ast.walk(tree)if isinstance(n,ast.Call)]
        self.assertEqual(calls.count('joint.run'),1);self.assertNotIn('igl.predicates.find_self_intersections',calls)
    def test_readonly_actual_receipt_and_points_mounts(self):
        for i in [2,3]:
            d=Fake(self.plan).data();d['Mounts'][i]['RW']=True
            with self.assertRaises(ValueError):caller.isolation(d,self.plan)
class TaperBindings(unittest.TestCase):
    def test_missing_inverse_GO_refuses_before_backend(self):
        with self.assertRaises(ValueError):caller.require_GO(dict(launch_ready=False,root_GO=None,root_GO_sha256=None))
    def test_forward_root_join_and_law_status_are_required(self):
        plan={'native_terminal_sha256':'joined'}
        root=dict(status='closed_actual_RC0_forward_sampled_screen_only',actual_tool_RC=0,terminal_sha256='joined',all9_whole_outputs_and_logs_matched=True,fresh_owned_group_members=[],native_CAD_samples=8638,whole_native_counts={'solids':1,'shells':1},whole_degenerated_edges=0,law_RC1_retained=True,candidate_qualified=False,global_admission=False)
        caller.validate_forward_root(plan,root)
        for key,value in [('terminal_sha256','other'),('law_RC1_retained',False),('native_CAD_samples',8621),('actual_tool_RC',1)]:
            bad=dict(root);bad[key]=value
            with self.assertRaises(AssertionError):caller.validate_forward_root(plan,bad)
if __name__=='__main__':unittest.main()
