"""Retained small callback/deck fixtures and new mesh-observation binding guards."""
import copy,hashlib,importlib.util,json,unittest
from pathlib import Path
H=Path(__file__).resolve().parent;R=H.parents[2];O=R/'work/carrier-process-20261017/bounded-webs-BREP-static-preparation-002'
def load(n,p):
 s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
previous=load('_retained_static002_complete_fixtures',O/'selfcheck_v3.py');old=previous.baseline;m=load('_new_taper_static_source_only',H/'run.py')
class NewTests(unittest.TestCase):
 def plan(self):return json.loads((H/'rigid-pending-plan.json').read_text())
 def test_full_caller_inverse_and_all_postprocess_bodies_exact(self):
  d=json.loads((H/'source-changes.json').read_text());s=(H/'run.py').read_text()
  for x in reversed(d['replacements']):self.assertEqual(s.count(x['after']),1);s=s.replace(x['after'],x['before'],1)
  self.assertEqual(s,(O/'run.py').read_text())
  B=R/'work/carrier-process-20261017/bounded-webs-BREP-postprocess-bindings-preparation-001'
  for n in d['unchanged_postprocess_sources']:self.assertEqual((H/'postprocess'/n).read_bytes(),(B/n).read_bytes())
 def test_actual_new_mesh_and_nonzero_observation_bind(self):
  p=self.plan();m.verify_mesh(p);self.assertEqual(p['expected_new_import_observation']['relative_volume_difference'],-7.771561172376096e-16);self.assertEqual(p['import_observation_method'],'closed_new_taper_same_operator_observation_1')
 def test_wrong_old_zero_or_volume_alias_refuses(self):
  for key,value in [('relative_volume_difference',0.),('OCC_imported_volume_mm3',285602.88227244973),('nonadaptive_reference_volume_mm3',285602.88227244973)]:
   p=self.plan();p['expected_new_import_observation'][key]=value
   with self.assertRaisesRegex(ValueError,'observation'):m.verify_mesh(p)
 def test_pending_protected_proof_refuses_before_any_read(self):
  p=self.plan();p.update(protected_terminal=None,protected_assessment=None,protected_supervision=None,protected_report=None,inspection_report=None)
  with self.assertRaisesRegex(ValueError,'remains pending'):m.verify_protected(p)
 def test_actual_new_protected_whole_reports_and_ROOT_join(self):
  p=self.plan();m.verify_protected(p);m.verify_protected_root(p)
 def test_new_binding_authority_joins_actual_metadata(self):
  b=load('_new_taper_plain_binding',H/'postprocess/cad_binding.py');p=self.plan();folder=R/p['mesh_source'];meta=json.loads((folder/'mesh.json').read_text());answer=b.verify(folder,meta);self.assertEqual(answer['sha256'],p['BREP_sha256']);self.assertFalse(answer['STEP_exchange_qualified'])
 def test_new_eyes_distribute_K1000_without_old_rosters(self):
  p=json.loads((H/'spring-pending-plan.json').read_text());c=p['planned_support_contract'];self.assertEqual(c['eye_node_counts'],[2274,2278]);self.assertEqual(c['SPRING1_elements'],3*(2274+2278));self.assertEqual(c['K_per_node_by_eye_N_mm'],[1000/2274,1000/2278]);self.assertIsNotNone(p['protected_terminal'])
if __name__=='__main__':
 suite=unittest.TestSuite([unittest.defaultTestLoader.loadTestsFromTestCase(old.retained.Checks),unittest.defaultTestLoader.loadTestsFromTestCase(old.NewChecks),unittest.defaultTestLoader.loadTestsFromTestCase(previous.NewChecks),unittest.defaultTestLoader.loadTestsFromTestCase(NewTests)])
 raise SystemExit(not unittest.TextTestRunner(verbosity=2).run(suite).wasSuccessful())
