"""Ordered resource-only containment batching; ambiguous random retries refuse."""
import hashlib

CHUNK_POINTS = 16


def make_contains(ray_class, random_util, np):
    original_generator = random_util.random_generator
    records = []

    def contains(label, mesh, points):
        if label not in ('carrier', 'bracket') or type(mesh.ray) is not ray_class:
            raise ValueError('Reviewed ray_triangle backend and mesh label required')
        if random_util.random_generator is not original_generator:
            raise ValueError('Random-generator binding changed before containment')
        if len(points.shape) != 2 or points.shape[1] != 3:
            raise ValueError('Containment probes must have three coordinates')
        record = dict(call=len(records), mesh=label, points=len(points),
                      probe_dtype=points.dtype.str, probe_shape=list(points.shape),
                      probe_bytes_sha256=hashlib.sha256(points.tobytes(order='C')).hexdigest(),
                      chunk_points=CHUNK_POINTS, chunks=[], complete=False,
                      random_fallback_attempts=0, random_binding_restored=False)
        records.append(record)
        whole = []

        def refuse_random(*_args, **_kwargs):
            record['random_fallback_attempts'] += 1
            raise ValueError('Ambiguous containment requested random fallback')

        try:
            random_util.random_generator = refuse_random
            for start in range(0, len(points), CHUNK_POINTS):
                stop = min(start + CHUNK_POINTS, len(points))
                record['active_chunk'] = [start, stop]
                result = mesh.contains(points[start:stop])
                if result.shape != (stop-start,) or result.dtype.kind != 'b':
                    raise ValueError('Containment returned a different bool roster')
                values = result.tolist()
                if any(type(v) is not bool for v in values):
                    raise ValueError('Containment did not return exact bool values')
                whole.extend(values)
                record['chunks'].append(dict(start=start, stop=stop,
                    bool_bytes_sha256=hashlib.sha256(bytes(values)).hexdigest()))
            if random_util.random_generator is not refuse_random:
                raise ValueError('Random-generator interception changed during containment')
            answer = np.asarray(whole, dtype=np.bool_)
            if answer.shape != (len(points),) or answer.dtype.kind != 'b':
                raise ValueError('Whole containment bool roster changed')
            record.update(whole_bool_values=whole,
                          whole_bool_bytes_sha256=hashlib.sha256(bytes(whole)).hexdigest(),
                          whole_bool_dtype=answer.dtype.str, whole_bool_shape=list(answer.shape),
                          complete=True)
            return answer
        except BaseException as error:
            record['error'] = dict(type=type(error).__name__, message=str(error))
            raise
        finally:
            random_util.random_generator = original_generator
            record['random_binding_restored'] = random_util.random_generator is original_generator

    return contains, records
