"""NON-ARMED local addition/mass/bounds check of the already preserved taper BREP."""
import importlib.util,json,math,os,resource,signal,sys,time,traceback
from pathlib import Path
from types import SimpleNamespace
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[2]
def load(name,path):
 s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
GATE=load('_retained_taper_local_gates',HERE.with_name('bounded-webs-C1-endfillet-preparation-002')/'close_end.py')
require,sha,write=GATE.require,GATE.sha,GATE.write
CANDIDATE='dde710a2f318545ec99b066bbeddc71af0b526066eed97f8220ae2f61b3a75fb'
def retention_records(plan,assessment,residue,terminal,supervision,prior_plan,prior_launch):
 require(prior_plan['candidate_BREP']==plan['candidate_BREP']and prior_plan['baseline_STEP']==plan['baseline_STEP'],'Foreign retained operands')
 require(assessment['status']=='native_BREP_strict_native_empty_pass'and assessment['strict_native_empty']is True and assessment['IsDone']is True and assessment['residue']==residue,'Actual strict retained Cut required')
 require(residue['native_topologically_empty']is True and residue['counts']==dict(solids=0,faces=0,edges=0,vertices=0)and residue['highest_topological_dimension']is None,'Retained Cut must have no dimensional residue')
 require(assessment['sources_before']==assessment['sources_after']==prior_plan['files_sha256']and assessment['sources_unchanged'],'Retained child source identities differ')
 require(supervision['plan_sha256']==plan['files_sha256'][plan['retention_launch']]and supervision['actual_returncode']==0 and supervision['direct_child_reaped']is True and supervision['final_group_members']==[]and supervision['no_non_zombie_group_members']is True and supervision['cleanup_error']is None and not supervision['timeout']and not supervision['interrupted'],'Retained actual RC0/closed group required')
 require(supervision['sources_before']==supervision['sources_after']=={**prior_launch['inputs_sha256'],**prior_launch['source_sha256']}and supervision['sources_and_plan_unchanged'],'Retained supervisor identities differ')
 require(terminal['actual_tool_and_child_returncode']==0 and terminal['owned_group_empty']is True and terminal['supervision_sha256']==plan['files_sha256'][plan['retention_supervision']]and terminal['assessment_sha256']==plan['files_sha256'][plan['retention_assessment']],'Retained terminal joins differ')
 return residue

def verify(path,expected,native=False):
 require(sha(path)==expected,'Plan SHA differs');p=json.loads(Path(path).read_text())
 if native:require(p['launch_ready']is True and p['root_GO_sha256']is not None,'NON-ARMED: ROOT review/GO required')
 require(p['schema']=='preserved-C1-taper-addition-local-plan-1'and p['bounds']==dict(outer=600,inner=560,CPU=[520,540],threads=1,workers=0),'Reviewed local scope/resources differ')
 require(p['files_sha256'][p['candidate_BREP']]==CANDIDATE and p['files_sha256'][p['baseline_STEP']]==GATE.BASELINE,'Preserved raw candidate/original baseline identity differs')
 require(p['retention_root_review_sha256']is not None and p['files_sha256'][p['retention_root_review']]==p['retention_root_review_sha256'],'Closed ROOT containment authority required')
 before={n:sha(ROOT/n)for n in p['files_sha256']};require(before==p['files_sha256'],'Source/input/runtime drift')
 out=ROOT/p['output_directory'];require(not out.exists()and not any(x.is_symlink()for x in [out,*out.parents]),'Fresh nonsymlink output required')
 if not native:require(not(ROOT/p['execution_directory']).exists(),'Fresh supervision required at preflight')
 return p,before,out

def run(path,expected):
 started=time.monotonic();p,before,out=verify(path,expected,True);out.mkdir();code=1
 report=dict(schema='preserved-C1-taper-addition-local-measurement-1',status='refused_or_incomplete',method='one_candidate_minus_baseline_Cut_then_original_local_gates_1',candidate_qualified=False,law_status='original_post_Build_law_RC1_preserved',downstream_checks={k:'PENDING'for k in GATE.PENDING},new_fillet_Build=False,no_Simulate=True,no_SetLaw=True,no_geometry_export=True,FEA_executed=False,sources_before=before)
 signal.signal(signal.SIGALRM,lambda *_:(_ for _ in ()).throw(TimeoutError('560s preserved-taper local diagnostic bound')));signal.alarm(560);resource.setrlimit(resource.RLIMIT_CPU,(520,540))
 events=(out/'events.jsonl').open('x')
 def event(name,**values):events.write(json.dumps(dict(event=name,seconds=time.monotonic()-started,**values),allow_nan=False)+'\n');events.flush();os.fsync(events.fileno())
 try:
  records={k:json.loads((ROOT/p[k]).read_text())for k in ('retention_assessment','retention_residue','retention_terminal','retention_supervision','retention_plan','retention_launch')}
  retained=retention_records(p,*[records[k]for k in ('retention_assessment','retention_residue','retention_terminal','retention_supervision','retention_plan','retention_launch')]);report['retention_authority']={k:dict(path=p[k],sha256=before[p[k]])for k in ('retention_assessment','retention_residue','retention_terminal','retention_supervision','retention_root_review')}
  require(os.getpriority(os.PRIO_PROCESS,0)==10,'nice10 child required');sys.path.insert(0,str(ROOT/p['native_site']))
  from build123d import import_step,import_brep
  from OCP.BRep import BRep_Tool
  from OCP.BRepAdaptor import BRepAdaptor_Surface
  from OCP.BRepAlgoAPI import BRepAlgoAPI_Cut
  from OCP.BRepBndLib import BRepBndLib
  from OCP.BRepCheck import BRepCheck_Analyzer
  from OCP.BRepGProp import BRepGProp
  from OCP.Bnd import Bnd_Box
  from OCP.GProp import GProp_GProps
  from OCP.OSD import OSD_ThreadPool
  from OCP.TopAbs import TopAbs_SOLID,TopAbs_FACE,TopAbs_EDGE,TopAbs_VERTEX
  from OCP.TopExp import TopExp
  from OCP.TopTools import TopTools_IndexedMapOfShape,TopTools_ListOfShape
  from OCP.TopoDS import TopoDS
  OSD_ThreadPool.DefaultPool_s().Init(1)
  volume=load('_retained_taper_precise_volume',ROOT/p['volume_source']);candidate=import_brep(ROOT/p['candidate_BREP']);baseline=import_step(ROOT/p['baseline_STEP'])
  require(candidate.is_valid and baseline.is_valid and len(candidate.solids())==len(baseline.solids())==1,'Fresh operands must be one valid Solid')
  summary=GATE.retain_cut_helpers(ROOT/p['strict_cut_source'],dict(TopTools_IndexedMapOfShape=TopTools_IndexedMapOfShape,TopExp=TopExp,Bnd_Box=Bnd_Box,BRepBndLib=BRepBndLib,TopAbs_SOLID=TopAbs_SOLID,TopAbs_FACE=TopAbs_FACE,TopAbs_EDGE=TopAbs_EDGE,TopAbs_VERTEX=TopAbs_VERTEX,BRepCheck_Analyzer=BRepCheck_Analyzer,volume=volume,SimpleNamespace=SimpleNamespace,TopoDS=TopoDS,BRep_Tool=BRep_Tool,GProp_GProps=GProp_GProps,BRepGProp=BRepGProp,BRepAdaptor_Surface=BRepAdaptor_Surface))
  cut=BRepAlgoAPI_Cut();args=TopTools_ListOfShape();tools=TopTools_ListOfShape();args.Append(candidate.wrapped);tools.Append(baseline.wrapped);cut.SetArguments(args);cut.SetTools(tools);cut.SetNonDestructive(True);cut.SetRunParallel(False);cut.SetFuzzyValue(0.)
  event('before_one_candidate_minus_baseline_Cut',NonDestructive=True,RunParallel=False,FuzzyValue=0.);cut.Build();event('after_one_candidate_minus_baseline_Cut',IsDone=cut.IsDone());require(cut.IsDone(),'Native addition Cut incomplete')
  added=summary(cut.Shape());write(out/'candidate-minus-baseline.json',added);report['added_material']=added
  require(not added['native_topologically_empty']and added.get('native_valid')is True and added['material_solid_volume_mm3']>0 and all(r['native_valid']and r['volume_mm3']>0 for r in added.get('solids',[])),'Strict positive valid added material required')
  native_volume,error=volume.precise_volume(candidate);baseline_volume,baseline_error=volume.precise_volume(baseline);require(native_volume>baseline_volume,'Native candidate volume must exceed the baseline')
  study=json.loads((ROOT/p['study']).read_text());require(study['material']['density_tonne_mm3']==p['original_density_tonne_mm3'],'Original study density differs');mass=native_volume*study['material']['density_tonne_mm3']*1000;box=candidate.bounding_box();bounds=[list(box.min),list(box.max)]
  report.update(GATE.local_gate_flags(retained,candidate.is_valid,len(candidate.solids()),mass,bounds,p),native_volume_mm3=native_volume,native_volume_estimated_relative_error=error,baseline_volume_mm3=baseline_volume,baseline_volume_estimated_relative_error=baseline_error,delta_from_baseline_volume_mm3=native_volume-baseline_volume,mass_kg=mass,bounds_mm=bounds)
  write(out/'study.json',study);report.update(status='preserved_taper_addition_mass_bounds_local_complete_PENDING_downstream',no_Clean_or_shape_healing_called=True,baseline_retention_Cut_repeated=False);code=0
 except BaseException as error:report['failure']=dict(type=type(error).__name__,message=str(error),traceback=traceback.format_exc())
 finally:
  signal.alarm(0);after={k:sha(ROOT/k)for k in before};report.update(sources_after=after,sources_unchanged=before==after,elapsed_seconds=time.monotonic()-started)
  if before!=after:report['status']='refused_input_drift';code=1
  write(out/'assessment.json',report);event('assessment_written',sha256=sha(out/'assessment.json'));events.close()
 print(json.dumps(dict(status=report['status'],candidate_qualified=False,assessment_sha256=sha(out/'assessment.json'))),flush=True);return code
if __name__=='__main__':
 mode,path,expected=sys.argv[1:]
 if mode=='preflight':p,_,_=verify(path,expected);print(json.dumps(dict(status='stdlib_only_preflight_no_native',armed=p['launch_ready'])))
 elif mode=='run':raise SystemExit(run(path,expected))
 else:raise ValueError('Use preflight or run PLAN SHA')
