# Two prepared cases, no solver authorization

Both actual deck preparations closed with RC0 in separate owned groups. Their
complete outputs and original serialized card checks are sealed in
`deck-preparation-terminal-collection.json`. The collector reuses the original
`blocks` and `deck_contract` function ASTs, reads both complete actual NPZ end
rosters, and reproduces the stored force/moment evidence exactly with stdlib.
It does not import NumPy, CAD, Gmsh, the solver or the scientific module bodies.

`rigid-run-command-awaiting-GO.json` and
`spring-run-command-awaiting-GO.json` are separate source-only proposals derived
from the original static002 command protocol. Each names its actual prepared
case plan, retained deck and load/support evidence. ROOT's independent deck
closure and a separate solver GO remain null. Do not execute these proposals.

After those two actual proofs exist, bind their exact paths and SHA values in
new command copies. Reverse only these readiness/GO/closure metadata changes
and require whole equality with each pending command. The scientific argv and
prepared case-plan/deck hashes remain unchanged. Recheck every actual case pin
and require no solver prestart/assessment before running one command per case.

The retained execution protocol uses the unchanged owned Docker helper: 1800
seconds per case including a 60-second cleanup reserve, solver timeout1680,
one CPU, 6 GiB RAM and total memory+swap6 GiB, network none. Each scientific CLI
is nice10/BLAS1. As in static002, no new host CPU cap or outer alarm interrupts
the helper's reserved cleanup; the existing postprocess alarm starts only after
the owned container has closed. No new 3600-second wrapper is added. Run and
collect the two cases separately with their exact original cancellation and
cleanup protocol; preserve true solver codes and refusals.

The actual serialized force is [1.1997225912371845e-11,
-1.3001101931142678e-13, -4000.00000000063] N, and moment is
[-2.1755495919059664e-08, 850000.0000000182,
-8.196853612529864e-11] Nmm for each case. These measured decimal-card resultants
are evidence, not adjusted targets or new acceptance thresholds. Both cases
retain the original unrounded load checks, independent energy1e-4 and complete
global stress maxima/ties. The candidate keeps its post-Build law RC1 and is
unqualified. No FEA, convergence, strength or manufacturing claim is made.
