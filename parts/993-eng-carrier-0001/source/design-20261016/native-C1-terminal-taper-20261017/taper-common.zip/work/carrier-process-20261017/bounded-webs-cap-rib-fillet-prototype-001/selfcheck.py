"""Tiny stdlib trust-boundary checks; no native CAD or fictitious geometry run."""
import importlib.util
from pathlib import Path
import tempfile
import unittest

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('_postfillet_tests', HERE/'postfillet.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)


class BoundaryChecks(unittest.TestCase):
    def test_single_radius(self):
        m.verify_radius(1., {'radius_mm': 1.})
        for radius in (0., 2., float('nan'), float('inf'), True):
            with self.assertRaises(ValueError):
                m.verify_radius(radius, {'radius_mm': 1.})

    def test_lower_dimensional_residue_is_not_empty(self):
        class Empty:
            wrapped = type('Native', (), {'IsNull': lambda _: False})()
            solids = faces = edges = vertices = lambda _: []
        self.assertTrue(m.native_empty(None))
        self.assertTrue(m.native_empty(Empty()))
        residue = Empty()
        residue.vertices = lambda: ['one vertex']
        self.assertFalse(m.native_empty(residue))

    def test_hash_multiblock_and_drift(self):
        with tempfile.TemporaryDirectory() as name:
            path = Path(name)/'input.bin'
            path.write_bytes(b'abcd'*(300*1024))
            before = m.sha(path)
            m.verify_pins({str(path): before})
            with path.open('ab') as stream:
                stream.write(b'!')
            with self.assertRaises(ValueError):
                m.verify_pins({str(path): before})


if __name__ == '__main__':
    unittest.main()
