"""Private native-BREP input adapter; preserve both complete original comparators."""
import hashlib
import importlib.util
import json
from pathlib import Path
from types import SimpleNamespace

HERE=Path(__file__).resolve().parent
MASTER='dde710a2f318545ec99b066bbeddc71af0b526066eed97f8220ae2f61b3a75fb'
STL='7ef349d6d8256f0ccf55e926411a52fb1bbb288be9b37164b7fcd5d520214293'
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def verify(plan):
    for path,digest in plan['files_sha256'].items():
        p=Path(path)
        if not p.is_file()or p.is_symlink()or sha(p)!=digest:raise ValueError('Frozen comparator input changed: '+str(p))
def validate_binding(plan,terminal):
    source=plan['CAD_source']
    if source['format']!='brep'or source['sha256']!=MASTER or source['filename']!='candidate-native.brep' or plan['STL_sha256']!=STL:
        raise ValueError('Wrong native BREP/STL identity')
    residue=terminal['residue']
    if (terminal['status']!='actual_owned_RC0_strict_native_empty_all_outputs_and_pins_verified' or
        terminal['actual_tool_and_child_returncode']!=0 or terminal['direct_child_reaped']is not True or
        terminal['owned_group_empty']is not True or terminal['all_current_pins_equal']is not True or
        terminal['timeout']is not False or terminal['cleanup_error']is not None or
        terminal['original_law_refusal_preserved']is not True or terminal['candidate_qualified']is not False or
        residue['native_valid']is not True or residue['native_topologically_empty']is not True or
        residue['counts']!={'solids':0,'faces':0,'edges':0,'vertices':0} or residue['bounds_mm']is not None):
        raise ValueError('Preserved taper containment is not the closed strict-empty native result')
def fresh_case(folder,plan):
    folder=Path(folder)
    for name in ['inspection.json','inspection-source.py','protected-interfaces.json','carrier-normalized.stl','bracket-intersection.stl','contains-chunks.json']:
        p=folder/name
        if p.exists()or p.is_symlink():raise FileExistsError('Preserve prior comparator output: '+name)
    case_inputs(folder,plan)
def case_inputs(folder,plan):
    folder=Path(folder)
    for name,digest in [('candidate-native.brep',MASTER),('carrier.stl',STL),('study.json',plan['study_sha256'])]:
        p=folder/name
        if not p.is_file()or p.is_symlink()or sha(p)!=digest:raise ValueError('Fresh case input differs: '+name)
def _load(name,path,injected=None):
    spec=importlib.util.spec_from_file_location(name,path);module=importlib.util.module_from_spec(spec)
    module.__dict__.update(injected or {});spec.loader.exec_module(module);return module
def load(plan_path):
    """Loading imports the scientific runtime; call only inside a reviewed bounded caller."""
    plan_path=Path(plan_path);plan_sha=sha(plan_path);plan=json.loads(plan_path.read_text());verify(plan)
    terminal=json.loads(Path(plan['containment_terminal']).read_text());validate_binding(plan,terminal)
    corrected=_load('_BREP_comparator_corrected_private',plan['corrected_cad_source'])
    producer=dict(adapter_source_sha256=sha(__file__),adapter_plan_sha256=plan_sha,
        comparator_sources_sha256={n:sha(HERE/'source'/n)for n in ['inspect_candidate_brep.py','inspect_protected_brep.py']},
        historical_sources_sha256=plan['historical_sources_sha256'],scope='Native BREP input; complete original comparison maths, zones and thresholds.')
    injected=dict(_corrected=corrected,_CAD_SOURCE=plan['CAD_source'],_PRODUCER=producer)
    candidate=_load('_BREP_candidate_comparator_private',HERE/'source/inspect_candidate_brep.py',injected)
    chunks=_load('_ordered_contains_private',HERE/'contains_chunks.py')
    from trimesh.ray import ray_triangle, ray_util
    contains, records=chunks.make_contains(ray_triangle.RayMeshIntersector, ray_util.util, candidate.np)
    candidate._contains_chunks=contains
    producer['contains_resource_policy']=dict(chunk_points=16, random_fallback='REFUSE',
        helper_sha256=sha(HERE/'contains_chunks.py'), ray_backend='trimesh.ray.ray_triangle.RayMeshIntersector')
    protected=_load('_BREP_protected_comparator_private',HERE/'source/inspect_protected_brep.py',dict(injected,
        _candidate=candidate,_original_source_directory=Path(plan['original_protected_source']).parent))
    def check(folder):
        verify(plan);fresh_case(folder,plan)
        if sha(plan_path)!=plan_sha:raise ValueError('Comparator plan changed')
        returned=False
        try:
            result=protected.check(folder)
            if len(records)!=8 or [r['mesh']for r in records]!=['carrier','bracket']*4 or any(
                r['points']!=3264 or r['complete']is not True or r['random_fallback_attempts']!=0 or
                r['random_binding_restored']is not True for r in records):
                raise ValueError('Whole original eight containment rosters were not completed')
            returned=True
            return result
        finally:
            with(Path(folder)/'contains-chunks.json').open('x')as stream:
                json.dump(dict(schema='ordered-full-containment-rosters-1',chunk_points=16,
                    whole_comparators_returned=returned,records=records,candidate_qualified=False),stream,indent=2,allow_nan=False)
                stream.write('\n');stream.flush();__import__('os').fsync(stream.fileno())
            verify(plan);case_inputs(folder,plan)
            if sha(plan_path)!=plan_sha:raise ValueError('Comparator plan changed')
    return SimpleNamespace(check=check,provenance=producer)
