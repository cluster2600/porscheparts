"""One default STEP export of the preserved taper; two fresh, strict raw differences."""
import faulthandler
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import resource
import signal
import sys
import time
import traceback

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
MASTER = 'dde710a2f318545ec99b066bbeddc71af0b526066eed97f8220ae2f61b3a75fb'
WRITER_KEYS = ('write.surfacecurve.mode', 'write.precision.mode')


def sha(path):
    value = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024*1024), b''):
            value.update(block)
    return value.hexdigest()


def write(path, value):
    with Path(path).open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write('\n'); stream.flush(); os.fsync(stream.fileno())


def load(name, path, injected=None):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    module.__dict__.update(injected or {})
    spec.loader.exec_module(module)
    return module


def export_default(body, path, exporter, interface, record):
    original = {key: interface.IVal_s(key) for key in WRITER_KEYS}
    if original != {'write.surfacecurve.mode': 1, 'write.precision.mode': 0}:
        raise ValueError('Unchanged installed writer defaults required')
    record.update(original=original, export_keyword_arguments={}, restored=False)
    try:
        returned = exporter(body, path)
        record.update(export_returned=returned,
                      observed_after_export={key: interface.IVal_s(key) for key in WRITER_KEYS})
        if returned is not True or record['observed_after_export'] != original:
            raise ValueError('Default STEP export refused or changed writer defaults')
    finally:
        restored = {key: bool(interface.SetIVal_s(key, value)) for key, value in original.items()}
        actual = {key: interface.IVal_s(key) for key in WRITER_KEYS}
        record.update(restoration_SetIVal_results=restored, observed_after_restore=actual,
                      restored=all(restored.values()) and actual == original)
        if not record['restored']:
            raise ValueError('Original writer settings restoration failed')


def verify(plan, fresh=True):
    if (plan['master_BREP_sha256'] != MASTER or plan['outer_wall_seconds'] != 600 or
            plan['inner_wall_seconds'] != 560 or plan['CPU_seconds'] != [520, 540] or
            plan['workers'] != 0 or plan['threads'] != 1):
        raise ValueError('Reviewed source or resource contract changed')
    for path, digest in plan['files_sha256'].items():
        p = Path(path)
        if (not p.is_file() or (p.is_symlink() and str(p) not in plan['runtime_aliases']) or
                sha(p) != digest):
            raise ValueError('Frozen exchange input/source/runtime changed: '+str(p))
    for alias, target in plan['runtime_aliases'].items():
        if str(Path(alias).resolve()) != target:
            raise ValueError('Reviewed existing Python runtime alias changed')
    containment = json.loads(Path(plan['containment_root_review']).read_text())
    forward = json.loads(Path(plan['forward_root_review']).read_text())
    inverse = json.loads(Path(plan['inverse_root_review']).read_text())
    protected = json.loads(Path(plan['protected_root_review']).read_text())
    for root, key, status in [
            (containment, 'containment_terminal', 'closed_actual_RC0_strict_baseline_minus_preserved_taper_topologically_empty'),
            (forward, 'forward_terminal', 'closed_actual_RC0_forward_sampled_screen_only'),
            (inverse, 'inverse_terminal', 'closed_actual_RC0_new_surface_topology_inverse_pass'),
            (protected, 'protected_terminal', 'closed_actual_RC0_new_taper_complete_protected_pass')]:
        if root['status'] != status or root['actual_tool_RC'] != 0 or root['terminal_sha256'] != sha(plan[key]):
            raise ValueError('A closed new-taper ROOT/terminal join differs')
    if (containment['actual_tool_RC'] != 0 or containment['raw_candidate_BREP_sha256'] != MASTER or
            containment['native_residue']['native_topologically_empty'] is not True or
            containment['law_original_RC1_unchanged'] is not True or containment['fresh_owned_group_members'] != []):
        raise ValueError('Closed native taper containment is not bound')
    if (forward['actual_tool_RC'] != 0 or forward['whole_native_counts']['solids'] != 1 or
            forward['whole_degenerated_edges'] != 0 or forward['law_RC1_retained'] is not True or
            inverse['actual_tool_RC'] != 0 or inverse['actual_triangles'] != 637836 or
            inverse['all_topology_defects_zero'] is not True or inverse['law_RC1_retained'] is not True):
        raise ValueError('Closed new-taper geometry/surface context is not bound')
    if (protected['CAD_source']['sha256'] != MASTER or protected['current_1p3kg_pass'] is not True or
            protected['law_original_RC1_preserved'] is not True or protected['candidate_qualified'] is not False):
        raise ValueError('Complete new-taper protected context is not bound')
    if sha(plan['master_BREP']) != MASTER:
        raise ValueError('Wrong preserved raw BREP')
    out = Path(plan['output_directory'])
    if fresh and (out.exists() or out.is_symlink()):
        raise FileExistsError('Preserve prior STEP diagnostic')


def require_GO(plan):
    if (plan['launch_ready'] is not True or plan['root_GO_sha256'] is None or
            sha(plan['root_GO']) != plan['root_GO_sha256']):
        raise ValueError('NOT ARMED: new-taper STEP diagnostic ROOT GO required')


def run():
    planpath = HERE/'plan.json'; plan_sha = sha(planpath); plan = json.loads(planpath.read_text())
    require_GO(plan); verify(plan)
    started = time.monotonic(); faulthandler.enable(all_threads=True)
    output = Path(plan['output_directory']); output.mkdir()
    events = (output/'events.jsonl').open('x')
    def event(name, **fields):
        events.write(json.dumps(dict(event=name, elapsed_seconds=time.monotonic()-started,
                                    **fields), allow_nan=False)+'\n')
        events.flush(); os.fsync(events.fileno())
        print(json.dumps(dict(event=name)), flush=True)
    signal.signal(signal.SIGALRM, lambda *_: (_ for _ in ()).throw(TimeoutError('560s STEP diagnostic cap')))
    signal.alarm(560); resource.setrlimit(resource.RLIMIT_CPU, (520, 540))
    report = dict(schema='preserved-taper-default-STEP-diagnostic-1', status='incomplete',
                  plan_sha256=plan_sha,
                  original_law_RC1_preserved=True, candidate_qualified=False, geometry_rebuilt=False,
                  FEA_executed=False, global_admission=False, differences={})
    settings = original = None
    try:
        if os.getpriority(os.PRIO_PROCESS, 0) != 10 or any(os.environ.get(k) != '1' for k in
                ['OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS']):
            raise ValueError('Reviewed nice10/BLAS1 child required')
        sys.path.insert(0, plan['native_site']); event('before_native_imports')
        from build123d import import_brep, import_step, export_step
        from OCP.BRep import BRep_Tool
        from OCP.BRepAdaptor import BRepAdaptor_Surface
        from OCP.BRepAlgoAPI import BRepAlgoAPI_Cut
        from OCP.BRepBndLib import BRepBndLib
        from OCP.BRepCheck import BRepCheck_Analyzer
        from OCP.BRepGProp import BRepGProp
        from OCP.BRepTools import BRepTools
        from OCP.Bnd import Bnd_Box
        from OCP.GProp import GProp_GProps
        from OCP.Interface import Interface_Static
        from OCP.OSD import OSD_ThreadPool
        from OCP.STEPControl import STEPControl_Controller
        from OCP.TopAbs import TopAbs_SOLID, TopAbs_FACE, TopAbs_EDGE, TopAbs_VERTEX
        from OCP.TopExp import TopExp
        from OCP.TopTools import TopTools_IndexedMapOfShape, TopTools_ListOfShape
        from OCP.TopoDS import TopoDS
        OSD_ThreadPool.DefaultPool_s().Init(1); STEPControl_Controller.Init_s()
        volume = load('_unchanged_signed_volume', plan['volume_source'])
        evaluate = load('_unchanged_three_volume_operators', plan['volume_operators_source']).evaluate
        namespace = dict(locals())
        quant = load('_unchanged_raw_exchange_quantification', HERE/'quantification.py', namespace)
        def settings():
            integers = ['read.surfacecurve.mode', 'read.precision.mode', 'read.maxprecision.mode',
                        'read.stdsameparameter.mode', 'write.precision.mode', 'write.surfacecurve.mode']
            reals = ['read.precision.val', 'read.maxprecision.val', 'read.encoderegularity.angle', 'write.precision.val']
            return dict(integer={k: Interface_Static.IVal_s(k) for k in integers},
                        real={k: Interface_Static.RVal_s(k) for k in reals})
        original = settings(); report['settings_before'] = original
        if original['integer']['read.surfacecurve.mode'] != 0:
            raise ValueError('Unchanged default reader mode0 required')
        native = import_brep(plan['master_BREP'])
        if native.parent is not None or native.wrapped.ShapeType() != TopAbs_SOLID or not native.is_valid:
            raise ValueError('One independent valid native Solid export root required')
        report['native_before_export'] = quant.summary(native.wrapped)
        write(output/'native-before-export.json', report['native_before_export'])
        path = output/'carrier-default.step'; event('before_sole_default_export')
        record = {}; report['sole_export'] = record
        export_default(native, path, export_step, Interface_Static, record)
        report['STEP_sha256'] = sha(path); event('after_sole_default_export', sha256=report['STEP_sha256'])
        if settings() != original:
            raise ValueError('An original read/write precision setting changed')
        event('before_default_readback'); readback = import_step(path); event('after_default_readback')
        report['readback'] = quant.summary(readback.wrapped); write(output/'readback.json', report['readback'])
        for name, body in [('native', native), ('STEP', readback)]:
            solids = quant.entities(body.wrapped, TopAbs_SOLID)
            if len(solids) != 1 or not BRepCheck_Analyzer(body.wrapped).IsValid():
                raise ValueError('Native and reloaded STEP must each contain one valid Solid')
            rows = evaluate(TopoDS.Solid_s(solids[0]), BRepGProp, GProp_GProps)
            report[name+'_volume_methods'] = rows; write(output/(name+'-volume-methods.json'), rows)
        relative = report['STEP_volume_methods'][2]['signed_mass_mm3']/report['native_volume_methods'][2]['signed_mass_mm3']-1
        report.update(adaptive_relative_volume_difference=relative,
                      unchanged_adaptive_volume_guard_1e8_pass=abs(relative) < 1e-8)
        for label, left_kind, right_kind in [('native-minus-STEP', 'native', 'STEP'),
                                             ('STEP-minus-native', 'STEP', 'native')]:
            row = dict(status='incomplete', fresh_imports=True, NonDestructive=True, RunParallel=False, FuzzyValue=0.)
            report['differences'][label] = row
            try:
                def fresh(kind):
                    return import_brep(plan['master_BREP']) if kind == 'native' else import_step(path)
                left, right = fresh(left_kind), fresh(right_kind)
                cut = BRepAlgoAPI_Cut(); args = TopTools_ListOfShape(); tools = TopTools_ListOfShape()
                args.Append(left.wrapped); tools.Append(right.wrapped)
                cut.SetArguments(args); cut.SetTools(tools); cut.SetNonDestructive(True)
                cut.SetRunParallel(False); cut.SetFuzzyValue(0.)
                event(label+'_before_Build'); cut.Build(); event(label+'_after_Build')
                row['IsDone'] = cut.IsDone()
                if not row['IsDone']: raise ValueError('Native difference did not complete')
                event(label+'_before_Shape'); raw = cut.Shape(); event(label+'_after_Shape')
                if not raw.IsNull():
                    rawpath = output/(label+'.brep')
                    returned = BRepTools.Write_s(raw, str(rawpath))
                    row['raw_BREP_write_returned'] = returned
                    if returned is not None and returned is not True:
                        raise ValueError('Raw difference BREP preservation refused')
                    row['raw_BREP_sha256'] = sha(rawpath)
                else: row['raw_BREP_not_exported_reason'] = 'Native null shape; raw summary retained'
                event(label+'_before_quantification'); row['raw_summary'] = quant.summary(raw)
                event(label+'_after_quantification')
                row.update(status='complete', strict_native_empty=row['raw_summary']['native_topologically_empty'])
            except (TimeoutError, KeyboardInterrupt):
                raise
            except Exception as error:
                row['failure'] = dict(type=type(error).__name__, message=str(error), traceback=traceback.format_exc())
            finally:
                write(output/(label+'.json'), row)
        report['settings_after'] = settings()
        if report['settings_after'] != original:
            raise ValueError('Readback or native differences changed global settings')
        complete = (report['unchanged_adaptive_volume_guard_1e8_pass'] and
                    all(row.get('status') == 'complete' and row['strict_native_empty']
                        for row in report['differences'].values()) and len(report['differences']) == 2)
        report['status'] = 'new_taper_default_STEP_strict_roundtrip_pass' if complete else 'refused_new_taper_default_STEP_roundtrip'
    except BaseException as error:
        report['failure'] = dict(type=type(error).__name__, message=str(error), traceback=traceback.format_exc())
    finally:
        signal.alarm(0)
        try:
            verify(plan, fresh=False); report['sources_unchanged'] = sha(planpath) == plan_sha
            if not report['sources_unchanged']: report['status'] = 'refused_input_drift'
        except BaseException as error:
            report.update(status='refused_input_drift', sources_unchanged=False, integrity_failure=str(error))
        if settings is not None and original is not None:
            try:
                report['settings_final'] = settings()
                report['captured_settings_unchanged'] = report['settings_final'] == original
                if not report['captured_settings_unchanged']: report['status'] = 'refused_global_settings_drift'
            except BaseException as error:
                report.update(status='refused_global_settings_capture', settings_failure=str(error))
        event('before_assessment_publication', status=report['status']); events.close()
        report.update(elapsed_seconds=time.monotonic()-started,
                      outputs={str(p.relative_to(output)): dict(bytes=p.stat().st_size, sha256=sha(p))
                               for p in output.iterdir() if p.is_file()})
        write(output/'assessment.json', report)
        print(json.dumps(dict(status=report['status'], assessment_sha256=sha(output/'assessment.json'))), flush=True)
    return 0 if report['status'] == 'new_taper_default_STEP_strict_roundtrip_pass' and report['sources_unchanged'] else 1


if __name__ == '__main__':
    raise SystemExit(run())
