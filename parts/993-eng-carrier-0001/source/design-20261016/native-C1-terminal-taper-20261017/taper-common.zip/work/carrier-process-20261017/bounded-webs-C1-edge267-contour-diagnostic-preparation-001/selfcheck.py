"""Small source-only observation tests; no native imports or CAD operations."""
import ast
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import tempfile
import time
import unittest

HERE=Path(__file__).resolve().parent
s=importlib.util.spec_from_file_location('_Add_only_tests',HERE/'observe.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
class Builder:
    rows=[[267,271,272],[80,268]]
    def NbContours(self):return len(self.rows)
    def NbEdges(self,i):return len(self.rows[i-1])
    def Edge(self,i,j):return self.rows[i-1][j-1]
    def IsConstant(self,i):return i==1
    def Radius(self,i):
        if i==2:raise ValueError('nonconstant native contour fixture')
        return 1.
class Checks(unittest.TestCase):
    def test_full_contours_preserve_native_order(self):
        rows=m.contours(Builder(),lambda i:dict(edge_index_zero_based=i))
        self.assertEqual([r['edge_indices_in_native_order']for r in rows],Builder.rows)
        self.assertEqual([r['edge_count']for r in rows],[3,2])
    def test_constant_radius_observed(self):
        r=m.contours(Builder(),lambda i:dict(edge_index_zero_based=i))[0]
        self.assertTrue(r['IsConstant']);self.assertEqual(r['Radius_mm'],1.);self.assertIsNone(r['Radius_error'])
    def test_nonconstant_radius_failure_not_fabricated(self):
        r=m.contours(Builder(),lambda i:dict(edge_index_zero_based=i))[1]
        self.assertFalse(r['IsConstant']);self.assertIsNone(r['Radius_mm']);self.assertEqual(r['Radius_error']['type'],'ValueError')
    def test_unknown_native_edge_refused(self):
        def bad(i):raise ValueError('unknown edge fixture')
        with self.assertRaisesRegex(ValueError,'unknown edge'):m.contours(Builder(),bad)
    def test_zero_contours_recorded_without_fake_shape(self):
        b=Builder();b.rows=[];self.assertEqual(m.contours(b,lambda i:None),[])
    def test_nonarmed_before_native_import(self):
        with tempfile.TemporaryDirectory(dir=HERE)as d:
            p=Path(d)/'pending.json';p.write_text(json.dumps(dict(launch_ready=False)))
            with self.assertRaisesRegex(ValueError,'NON-ARMED'):m.verify(p,hashlib.sha256(p.read_bytes()).hexdigest(),True)
        self.assertNotIn('OCP',sys.modules);self.assertNotIn('build123d',sys.modules)
    def test_foreign_seed_scope_refused(self):
        with tempfile.TemporaryDirectory(dir=HERE)as d:
            p=Path(d)/'plan.json';p.write_text(json.dumps(dict(launch_ready=False,schema='C1-edge267-R1-native-Add-only-plan-1',seed_edge=268,radius_mm=1.)))
            with self.assertRaisesRegex(ValueError,'Only seed267'):m.verify(p,hashlib.sha256(p.read_bytes()).hexdigest())
    def test_exactly_one_existing_R1_seed_no_Build_Cut_export(self):
        t=ast.parse((HERE/'observe.py').read_text());calls=[n for n in ast.walk(t)if isinstance(n,ast.Call)]
        attrs=[n.func.attr for n in calls if isinstance(n.func,ast.Attribute)]
        self.assertFalse(set(attrs)&{'Build','Shape','Clean','clean','SetFuzzyValue','export_brep','export_step','export_stl'})
        adds=[n for n in calls if isinstance(n.func,ast.Attribute)and n.func.attr=='Add'];self.assertEqual(len(adds),1);self.assertEqual(ast.literal_eval(adds[0].args[0]),1.)
        self.assertNotIn('BRepAlgoAPI_Cut',(HERE/'observe.py').read_text())
    def test_original_prototype_strict_guard_unchanged(self):
        p=HERE.with_name('bounded-webs-C1-endfillet-preparation-002')/'close_end.py'
        self.assertEqual(hashlib.sha256(p.read_bytes()).hexdigest(),'0277484749def5186818275e1df26e1cebe9d8f83954d751acd8b53d25b21d10')
        self.assertIn('actual==[267]',p.read_text())

if __name__=='__main__':
    started=time.monotonic();r=unittest.TextTestRunner(verbosity=1).run(unittest.defaultTestLoader.loadTestsFromTestCase(Checks))
    print(json.dumps(dict(status='PASS'if r.wasSuccessful()else'FAIL',tests=r.testsRun,elapsed_seconds=time.monotonic()-started,native_imports=False)))
    raise SystemExit(0 if r.wasSuccessful()else 1)
