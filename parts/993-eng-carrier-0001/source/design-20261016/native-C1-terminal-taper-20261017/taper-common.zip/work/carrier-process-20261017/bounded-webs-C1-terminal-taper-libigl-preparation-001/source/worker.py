"""Run the unchanged complete sampled surface audit once, with frozen BREP provenance."""
import hashlib
import importlib.util
from importlib import metadata
import json
import math
import os
from pathlib import Path
import platform
import resource
import signal
import sys
import time
import traceback

SOURCE=Path('/source');OUTPUT=Path('/output');STL=Path('/input/carrier.stl')
RECEIPT=Path('/input/brep-audit.json');SAMPLES=Path('/input/exact-CAD-surface-samples.npz')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(name,value):
    with (OUTPUT/name).open('x')as f:json.dump(value,f,indent=2,allow_nan=False);f.write('\n');f.flush();os.fsync(f.fileno())
def runtime():
    names=['numpy','scipy','libigl','trimesh','rtree'];files={}
    for name in names:
        distribution=metadata.distribution(name)
        for item in distribution.files or []:
            if str(item).endswith(('.so','.dylib','/METADATA','/WHEEL','/RECORD')):
                path=Path(distribution.locate_file(item));files[name+'/'+str(item)]={'sha256':sha(path),'bytes':path.stat().st_size}
    return dict(versions={n:metadata.version(n)for n in names},python_version=platform.python_version(),
        architecture=platform.machine(),python_abi=sys.implementation.cache_tag,artifacts=files)
def validate_receipt(plan,receipt):
    assert receipt['CAD_source']['format']=='brep' and receipt['CAD_source']['sha256']==plan['master_BREP_sha256']
    assert receipt['results']['candidate_STL']['sha256']==plan['STL_sha256']
    assert receipt['candidate_sampled_chord_screen_pass'] is True
    d=receipt['results']['candidate_STL']['maximum_distance_to_BREP_shell_mm'];assert math.isfinite(d) and 0<=d<=.06
    assert receipt['exact_CAD_surface_samples_sha256']==plan['CAD_samples_sha256'] and receipt['exact_CAD_surface_samples']==8638
    assert math.isfinite(receipt['exact_CAD_volume_mm3']) and receipt['exact_CAD_volume_mm3']>0
    bounds=receipt['exact_CAD_bounds_mm'];assert len(bounds)==2 and all(len(row)==3 and all(math.isfinite(v)for v in row)for row in bounds)
    assert all(bounds[0][i]<=bounds[1][i] for i in range(3))
def load_module(name,path):
    spec=importlib.util.spec_from_file_location(name,path);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module
def main():
    started=time.monotonic();CPU=time.process_time();plan=json.loads((SOURCE/'native-inputs.json').read_text());expected=json.loads((SOURCE/'expected-runtime.json').read_text())
    before={name:sha(SOURCE/name)for name in plan['source_sha256']};assert before==plan['source_sha256']
    input_paths={'STL':STL,'BREP_receipt':RECEIPT,'CAD_samples':SAMPLES}
    assert all(sha(p)==plan[k+'_sha256'] for k,p in input_paths.items()) and plan['faces']==637836
    validate_receipt(plan,json.loads(RECEIPT.read_text()))
    assert all(os.environ.get(k)=='1'for k in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS'])
    assert not list(OUTPUT.iterdir())
    signal.signal(signal.SIGALRM,lambda *_:(_ for _ in ()).throw(TimeoutError('220s joint surface worker wall cap')))
    signal.alarm(220);resource.setrlimit(resource.RLIMIT_CPU,(200,210))
    report=dict(schema='preserved-taper-new-STL-joint-sampled-audit-1',status='incomplete',candidate_qualified=False,original_law_RC1_preserved=True,
        **{k+'_sha256':plan[k+'_sha256']for k in input_paths},master_BREP_sha256=plan['master_BREP_sha256'],
        source_sha256=before,continuous_distance_bound=False,full_audit=False,geometry_modified=False,manufacturing_admission=False)
    rb=ra=None;sentinel=object();prior_audit=sys.modules.get('audit',sentinel)
    try:
        rb=runtime();write('runtime-before.json',rb);assert rb==expected,'Installed immutable-image runtime differs'
        audit=load_module('audit',SOURCE/'audit.py');sys.modules['audit']=audit
        joint=load_module('_unchanged_BREP_cad_mesh_audit',SOURCE/'cad_mesh_brep_audit.py')
        original_load=joint.load
        def checked_load(path):
            vertices,faces=original_load(path)
            import numpy as np
            assert vertices.ndim==2 and vertices.shape[1]==3 and np.isfinite(vertices).all()
            assert faces.shape==(637836,3) and faces.dtype.kind in 'iu' and faces.min()>=0 and faces.max()<len(vertices)
            report['array_identities']={n:dict(dtype=a.dtype.str,shape=list(a.shape),sha256=hashlib.sha256(np.ascontiguousarray(a)).hexdigest())for n,a in [('vertices',vertices),('faces',faces)]}
            return vertices,faces
        joint.load=checked_load
        try:complete=joint.run(STL,RECEIPT,SAMPLES,OUTPUT/'joint',plan['CAD_samples_sha256'])
        finally:joint.load=original_load
        report['joint_audit_status']=complete['status'];report['failures']=complete['failures']
        report['status']='joint_surface_checks_passed' if complete['status']=='passed' and not complete['failures'] else 'rejected_joint_surface_audit'
    except BaseException as error:
        report['error']=dict(type=type(error).__name__,message=str(error),traceback=traceback.format_exc())
    finally:
        if prior_audit is sentinel:sys.modules.pop('audit',None)
        else:sys.modules['audit']=prior_audit
        signal.alarm(0)
        try:
            ra=runtime();write('runtime-after.json',ra)
            intact=before=={n:sha(SOURCE/n)for n in before} and all(sha(p)==plan[k+'_sha256'] for k,p in input_paths.items()) and rb==ra==expected
        except BaseException as error:intact=False;report['integrity_error']=dict(type=type(error).__name__,message=str(error))
        report.update(runtime_unchanged=rb==ra==expected,input_sources_unchanged=intact,wall_seconds=time.monotonic()-started,
            CPU_seconds=time.process_time()-CPU,maxRSS_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024)
        if not intact:report['status']='refused_input_or_runtime_changed'
        write('assessment.json',report)
    print(json.dumps({k:report.get(k)for k in ['status','failures','error','wall_seconds']}))
    return 0 if report['status']=='joint_surface_checks_passed' and report['input_sources_unchanged'] else 1
if __name__=='__main__':raise SystemExit(main())
