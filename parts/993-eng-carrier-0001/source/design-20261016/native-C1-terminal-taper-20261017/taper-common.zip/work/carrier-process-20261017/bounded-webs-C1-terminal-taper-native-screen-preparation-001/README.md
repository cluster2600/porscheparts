# Preserved taper: sampled native CAD screen

Source-only preparation. The input is the actual dde710… raw taper BREP and the NEW7ef349… surface generated from it, with637836 triangles. This is a diagnostic variant, not the former C1 geometry. Its original post-Build law refusal remains RC1, candidate_qualified remains false, and inverse distance/topology, protected interfaces, STEP exchange and FEA remain pending. No CAD Build, shape repair, new surface generation or geometry export is performed here.

The sampled worker is BYTE IDENTICAL to the previous native-BREP audit. It classifies the fixed7x7 UV grid on each trimmed face, and measures512 STL vertices,512 centroids and2048 area-weighted points, random seed9931016, against the native shell. The same0.06mm sampled criterion remains. The worker also records actual CAD sample count, adaptive native volume/error and bounds. No former8621 sample count is assumed. These finite samples do not establish a continuous Hausdorff distance bound.

The small wrapper first imports the WHOLE preserved candidate independently and records its actual validity, Solid/shell/face/edge/vertex counts, degenerated-edge count and native tolerance extrema. It writes this complete topology summary before the sampled distance call, then releases that first shape. The unchanged worker imports the same hash-bound BREP for its own distances and volume. Nothing infers whole-candidate topology from the added-material residue, and no counts or values transfer from the former C1 audit.

The driver diff and declared replacements reproduce the prior wrapper byte for byte on inversion. Changes are limited to actual candidate/STL identities, explicit diagnostic scope and ROOT-GO/generation-closure guards, and the whole-candidate native measurement. All three worker dependencies are byte-identical copies. Nine small standard-library source/binding tests pass without scientific imports; six original tests are retained.

ROOT must review the actual new generation closure, source, plan and launch before a single native execution. Resources stay600s outer,560s inner, CPU520/540, OSD1,0workers, nice10 child and10+10s owned cleanup under unchanged4d18. Prior old-C1 native screening used69.75s wall/846.2MBRSS; this is context rather than a timing promise. No full28GB protected comparator is imported.

Generation alone was not an audit. This stage alone cannot supply inverse-distance, topology/intersection, strength or manufacturing admission. All outputs must be closed and rebound before any later stage.
