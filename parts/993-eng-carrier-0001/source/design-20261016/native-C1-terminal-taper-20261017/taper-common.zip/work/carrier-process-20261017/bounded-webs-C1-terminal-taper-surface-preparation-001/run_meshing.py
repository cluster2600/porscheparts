"""NON-ARMED triangulation of the preserved raw taper; its law refusal remains unchanged."""
import hashlib
import importlib.util
import json
from pathlib import Path
import resource
import signal
import struct
import sys
import time
import traceback

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[2]
def sha(p):
    h=hashlib.sha256()
    with Path(p).open('rb')as f:
        for block in iter(lambda:f.read(8*1024*1024),b''):h.update(block)
    return h.hexdigest()
def verify(plan,fresh=True):
    if plan['minimum_size_mm']!=.25 or plan['inner_wall_seconds']!=560 or plan['CPU_seconds']!=[520,540]or plan['outer_wall_seconds']!=600:raise ValueError('Reviewed surface settings/resources changed')
    if plan['CAD_source']['format']!='brep'or plan['CAD_source']['sha256']!='dde710a2f318545ec99b066bbeddc71af0b526066eed97f8220ae2f61b3a75fb':raise ValueError('Wrong preserved raw taper BREP')
    for name,digest in plan['files_sha256'].items():
        if sha(name)!=digest:raise ValueError('Source/input/runtime changed: '+name)
    terminal=json.loads(Path(plan['containment_terminal']).read_text());context=json.loads(Path(plan['containment_plan']).read_text())
    if (terminal['status']!='actual_owned_RC0_strict_native_empty_all_outputs_and_pins_verified'or terminal['actual_tool_and_child_returncode']!=0 or terminal['owned_group_empty']is not True or terminal['all_current_pins_equal']is not True or terminal['strict_containment_only']is not True or terminal['residue']['counts']!=dict(solids=0,faces=0,edges=0,vertices=0)or terminal['residue']['native_topologically_empty']is not True):raise ValueError('Actual closed empty containment required')
    if str(ROOT/context['candidate_BREP'])!=plan['master_BREP']or context['files_sha256'][context['candidate_BREP']]!=plan['CAD_source']['sha256']:raise ValueError('Foreign contained candidate')
    if plan['containment_root_review_sha256']is None or sha(plan['containment_root_review'])!=plan['containment_root_review_sha256']or plan['addition_root_review_sha256']is None or sha(plan['addition_root_review'])!=plan['addition_root_review_sha256']:raise ValueError('Actual closed ROOT containment/addition authorities required')
    output=Path(plan['output_directory'])
    if fresh and(output.exists()or any(p.is_symlink()for p in [output,*output.parents])):raise FileExistsError('Fresh nonsymlink surface output required')
def binary_count(path):
    with Path(path).open('rb')as f:header=f.read(84)
    if len(header)!=84:raise ValueError('Truncated STL')
    count=struct.unpack('<I',header[80:])[0]
    if count<1 or Path(path).stat().st_size!=84+50*count:raise ValueError('Nonempty exact-length binary STL required')
    return count
def main():
    planpath=HERE/'plan.json';digest=sha(planpath);plan=json.loads(planpath.read_text())
    if sys.argv[1:]==['--preflight']:
        verify(plan);print(json.dumps(dict(status='preflight_only_no_Gmsh',pins=len(plan['files_sha256']),plan_sha256=digest)));return 0
    assert not sys.argv[1:]
    if plan['launch_ready']is not True or plan['root_GO_sha256']is None or sha(plan['root_GO'])!=plan['root_GO_sha256']:raise ValueError('NON-ARMED: ROOT review and GO required')
    started=time.monotonic();CPU=time.process_time();signal.signal(signal.SIGALRM,lambda *_:(_ for _ in ()).throw(TimeoutError('Surface meshing 560s wall budget')))
    signal.alarm(560);resource.setrlimit(resource.RLIMIT_CPU,(520,540));verify(plan)
    output=Path(plan['output_directory']);output.mkdir()
    before={p:sha(p)for p in plan['files_sha256']}
    report=dict(schema='preserved-taper-dedicated-surface-meshing-1',status='incomplete',candidate_qualified=False,law_status='original_post_Build_law_RC1_preserved',downstream_checks=plan['downstream_checks'],CAD_source=plan['CAD_source'],
        plan_sha256=digest,source_sha256=sha(__file__),sources_and_runtime_before=before,
        actual_workers=0,Gmsh_native_thread_setting=2,FEA_started=False,global_admission=False,surface_audit_completed=False)
    try:
        spec=importlib.util.spec_from_file_location('_BREP_surface_mesher_private',HERE/'source/gmsh_brep_remesh.py')
        module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
        module.run(plan['master_BREP'],output/'surface',plan['CAD_source']['sha256'],plan['minimum_size_mm'])
        receipt=json.loads((output/'surface/meshing.json').read_text())
        assert receipt['CAD_source']==dict(format='brep',sha256=plan['CAD_source']['sha256'],path=plan['master_BREP'])
        assert receipt['gmsh_version']=='4.15.2'and receipt['source_CAD_changed']is False
        stl=output/'surface/carrier-remeshed.stl';assert sha(stl)==receipt['candidate_STL_sha256']
        report.update(status='surface_generated_not_yet_audited',triangles=binary_count(stl),
            outputs={p.name:dict(sha256=sha(p),bytes=p.stat().st_size)for p in (output/'surface').iterdir()})
    except BaseException as error:report['failure']=dict(type=type(error).__name__,message=str(error),traceback=traceback.format_exc())
    finally:
        signal.alarm(0)
        try:
            after={p:sha(p)for p in before};intact=before==after and sha(planpath)==digest;verify(plan,fresh=False)
        except BaseException as error:after={};intact=False;report['integrity_failure']=str(error)
        report.update(sources_and_runtime_after=after,inputs_runtime_plan_unchanged=intact,wall_seconds=time.monotonic()-started,
            CPU_seconds=time.process_time()-CPU,maxRSS_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss)
        if not intact:report['status']='refused_input_runtime_plan_drift'
        with(output/'assessment.json').open('x')as f:json.dump(report,f,indent=2,allow_nan=False);f.write('\n')
    print(json.dumps({k:report.get(k)for k in ['status','triangles','wall_seconds','CPU_seconds','maxRSS_bytes']}),flush=True)
    return 0 if report['status']=='surface_generated_not_yet_audited'and report['inputs_runtime_plan_unchanged']else 1
if __name__=='__main__':raise SystemExit(main())
