"""Collect the one actual, closed default-STEP diagnostic; no native import."""
import copy,hashlib,importlib.util,json,os,stat
from pathlib import Path
H=Path(__file__).resolve().parent;R=H.parents[2]
def sha(p):
 v=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(1024**2),b''):v.update(b)
 return v.hexdigest()
def read(p,cap=8*1024**2):
 assert p.stat().st_size<=cap
 return json.loads(p.read_text())
def write(p,v):
 with p.open('x')as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n');f.flush();os.fsync(f.fileno())
def whole(p):
 a=p.lstat();assert stat.S_ISREG(a.st_mode)and not p.is_symlink();v=sha(p);b=p.lstat()
 fields=lambda s:(s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns,s.st_ctime_ns)
 assert fields(a)==fields(b)
 return dict(bytes=b.st_size,sha256=v)
p=read(H/'plan.json');l=read(H/'launch-plan.json');c=read(H/'command.json');s=read(H/'execution-001/execution-receipt.json');a=read(H/'output-001/assessment.json')
assert sha(H/'launch-plan.json')=='e1b8e7b24fbe7818dc7692d15284d305d82bd966364a4cc114ec7b5bf9b6d949'
expected={}
for m in [l['source_sha256'],l['inputs_sha256']]:
 for n,v in m.items():assert n not in expected or expected[n]==v;expected[n]=v
assert s['sources_before']==expected==s['sources_after']
fresh={n:sha(R/n)for n in expected};assert fresh==expected
assert s['actual_returncode']==1 and s['direct_child_reaped']and s['final_group_members']==[]and s['no_non_zombie_group_members']
assert not s['timeout']and not s['interrupted']and s['failure']is None and s['cleanup_error']is None and s['signals_to_owned_group_only']==[]
assert s['plan_sha256']==sha(H/'launch-plan.json')and s['sources_and_plan_unchanged']
sp=R/'work/carrier-process-20261017/source010-exposure-preflight-003/supervise.py';spec=importlib.util.spec_from_file_location('_closed_STEP_owned_group_query',sp);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);members=m.members(s['pid']);assert members==[]
assert a['status']=='refused_new_taper_default_STEP_roundtrip'and a['sources_unchanged']and a['captured_settings_unchanged']
assert a['sole_export']['restored']and a['sole_export']['export_keyword_arguments']=={}and a['sole_export']['export_returned']
assert a['settings_before']==a['settings_after']==a['settings_final']
assert a['unchanged_adaptive_volume_guard_1e8_pass']and set(a['differences'])=={'native-minus-STEP','STEP-minus-native'}
assert all(row['status']=='complete'and row['IsDone']and not row['strict_native_empty']for row in a['differences'].values())
outputs={q.name:whole(q)for q in sorted((H/'output-001').iterdir())};assert set(outputs)==set(a['outputs'])|{'assessment.json'}
assert {n:v for n,v in outputs.items()if n!='assessment.json'}==a['outputs']
for n,row in a['differences'].items():
 assert read(H/'output-001'/(n+'.json'))==row
 assert row['raw_BREP_sha256']==outputs[n+'.brep']['sha256']
assert a['STEP_sha256']==outputs['carrier-default.step']['sha256']
logs={n:whole(H/'execution-001'/n)for n in ['stdout.log','stderr.log','started.json','execution-receipt.json']}
assert {n:logs[n]['sha256']for n in s['logs_sha256']}==s['logs_sha256']
p0=read(H/'pending-plan.json');l0=read(H/'pending-launch-plan.json');c0=read(H/'pending-command.json');go=str(H/'root-GO-001.json')
x=copy.deepcopy(p);x['files_sha256'].pop(go)
for k in ['status','preparation_only','launch_ready','root_GO','root_GO_sha256']:x[k]=p0[k]
y=copy.deepcopy(l);y['inputs_sha256'].pop(str(H/'plan.json'));y['inputs_sha256'].pop(go);y['inputs_sha256'][str(H/'pending-plan.json')]=sha(H/'pending-plan.json')
for k in ['status','launch_ready','diagnostic_plan_sha256','actual_final_plan_sha256']:y[k]=l0[k]
for k in ['root_GO','root_GO_sha256']:y.pop(k)
z=copy.deepcopy(c)
for k in ['status','launch_ready','root_GO_sha256','actual_final_plan_sha256','actual_final_launch_sha256']:z[k]=c0[k]
z.pop('root_GO');z['argv_template']=c0['argv_template']
for value,original,name in [(x,p0,'pending-plan.json'),(y,l0,'pending-launch-plan.json'),(z,c0,'pending-command.json')]:
 assert value==original and (json.dumps(value,indent=2)+'\n').encode()==(H/name).read_bytes()
tool=dict(actual_session_id=5082,initial_chunk_id='449ae0',terminal_chunk_id='ddb6d6',actual_tool_returncode=1,actual_stdout='{"status": "refused_or_interrupted", "actual_returncode": 1, "no_non_zombie_group_members": true, "elapsed_seconds": 46.074113165959716}\n',retry=False)
write(H/'actual-tool-terminal-001.json',tool)
r=dict(schema='closed-new-taper-default-STEP-diagnostic-1',status='closed_actual_RC1_default_STEP_strict_roundtrip_refused',actual_tool_returncode=1,actual_child_returncode=1,actual_session_id=5082,terminal_chunk_id='ddb6d6',supervision_sha256=sha(H/'execution-001/execution-receipt.json'),assessment_sha256=sha(H/'output-001/assessment.json'),actual_tool_terminal_sha256=sha(H/'actual-tool-terminal-001.json'),collector_sha256=sha(__file__),plan_sha256=sha(H/'plan.json'),launch_sha256=sha(H/'launch-plan.json'),command_sha256=sha(H/'command.json'),root_GO_sha256=sha(H/'root-GO-001.json'),whole_pending_objects_and_bytes_inverses=True,fresh_source_input_map_entries=len(expected),source_input_maps_before_after_fresh_equal=True,whole_outputs=outputs,whole_output_count=len(outputs),whole_execution_files=logs,fresh_owned_group_members=members,direct_child_reaped=True,elapsed_seconds=s['elapsed_seconds'],child_elapsed_seconds=a['elapsed_seconds'],timeout=False,signals_to_owned_group_only=[],settings_before_after_final_equal=True,writer_IVal_restored=True,sole_default_export_keyword_arguments={},adaptive_volume_relative_difference=a['adaptive_relative_volume_difference'],adaptive_volume_guard_pass=True,differences={n:dict(strict_native_empty=row['strict_native_empty'],native_valid=row['raw_summary']['native_valid'],counts=row['raw_summary']['counts'],signed_solid_volume_mm3=row['raw_summary']['material_solid_volume_mm3'],raw_BREP_sha256=row['raw_BREP_sha256'])for n,row in a['differences'].items()},original_law_RC1_preserved=True,candidate_qualified=False,physical_erosion_inferred=False,geometry_rebuilt=False,FEA_executed=False,automatic_retry=False)
write(H/'terminal-collection-001.json',r)
print(json.dumps(dict(status=r['status'],terminal_sha256=sha(H/'terminal-collection-001.json'),assessment_sha256=r['assessment_sha256'],supervision_sha256=r['supervision_sha256'],whole_output_count=len(outputs),fresh_map_entries=len(expected),owned_group_empty=True)))
