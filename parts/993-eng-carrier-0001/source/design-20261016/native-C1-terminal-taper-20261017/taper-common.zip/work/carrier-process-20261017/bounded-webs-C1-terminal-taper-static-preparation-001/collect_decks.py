"""Close the two actual deck-only handles; stdlib, no solver or science import."""
import ast
import hashlib
import json
import math
import os
from pathlib import Path
import struct
import subprocess
import zipfile

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]


def require(ok, message):
    if not ok:
        raise ValueError(message)


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


def original_function(path, name, namespace):
    node = next(n for n in ast.parse(Path(path).read_text()).body
                if isinstance(n, ast.FunctionDef) and n.name == name)
    exec(compile(ast.Module(body=[node], type_ignores=[]), str(path), 'exec'), namespace)
    return namespace[name]


def end_roster(archive, name, count):
    raw = archive.read(name + '.npy')
    require(raw[:8] == b'\x93NUMPY\x01\x00', 'Expected actual NPY version1 roster')
    length = int.from_bytes(raw[8:10], 'little')
    header = ast.literal_eval(raw[10:10 + length].decode('latin1'))
    require(header == dict(descr='<i8', fortran_order=False, shape=(count,)), 'Actual roster dtype/shape differs')
    values = raw[10 + length:]
    require(len(values) == 8 * count, 'Roster payload length differs')
    return [row[0] for row in struct.iter_unpack('<q', values)]


def main():
    namespace = dict(Path=Path, math=math, require=require)
    blocks = original_function(HERE / 'postprocess/audit_energy_brep.py', 'blocks', namespace)
    contract = original_function(HERE / 'run.py', 'deck_contract', namespace)
    provenance = {'rigid': (10142, 'cf4fb5'), 'spring': (1411, '33d4fe')}
    report = dict(status='two_actual_decks_closed_no_FEA', actual_scientific_imports=False,
                  original_blocks_and_deck_contract_AST_executed=True, cases={},
                  candidate_qualified=False, law_original_RC1_preserved=True, Docker_started=False, FEA_started=False)
    for case, (handle, chunk) in provenance.items():
        launch_path = HERE / (case + '-prepare-launch.json')
        launch = json.loads(launch_path.read_text())
        execution = ROOT / launch['execution_directory']
        supervision = json.loads((execution / 'execution-receipt.json').read_text())
        require(supervision['actual_returncode'] == 0 and supervision['direct_child_reaped']
                and supervision['no_non_zombie_group_members'] and supervision['final_group_members'] == []
                and not supervision['timeout'] and not supervision['interrupted']
                and supervision['failure'] is supervision['cleanup_error'] is None
                and supervision['signals_to_owned_group_only'] == [], 'Actual owned preparation did not close successfully')
        pins = {**launch['source_sha256'], **launch['inputs_sha256']}
        require(supervision['sources_before'] == supervision['sources_after'] == pins
                and supervision['sources_and_plan_unchanged']
                and supervision['plan_sha256'] == sha(launch_path)
                and {n: sha(ROOT / n) for n in pins} == pins, 'Whole preparation maps or current pins differ')
        query = subprocess.run(['/bin/ps', '-g', str(supervision['pid']), '-o', 'pid=,ppid=,pgid=,stat='],
                               capture_output=True, text=True, timeout=2)
        require(query.returncode == 1 and not query.stdout.strip() and not query.stderr.strip(), 'Owned group absence not freshly confirmed')
        output = ROOT / launch['output_directory']
        prep = json.loads((output / 'preparation.json').read_text())
        plan_path = output / 'case-plan.json'
        plan = json.loads(plan_path.read_text())
        evidence_path = output / 'execution/load-and-supports.json'
        deck = output / 'execution/prepared-deck.inp'
        require(prep['status'] == 'actual_original_solve_deck_prepared_no_FEA' and prep['FEA_started'] is False
                and prep['sources_unchanged'] and prep['case_plan_sha256'] == sha(plan_path)
                and prep['prepared_deck_sha256'] == plan['prepared_deck_sha256'] == sha(deck)
                and prep['load_support_evidence_sha256'] == plan['prepared_load_support_sha256'] == sha(evidence_path),
                'Actual deck evidence binding differs')
        with zipfile.ZipFile(output / 'cad/mesh-7/mesh.npz') as archive:
            rosters = [end_roster(archive, 'end0', 2274), end_roster(archive, 'end1', 2278)]
        cards = blocks(deck)
        load_ids = {int(row.split(',')[0]) for key, rows in cards if key == '*CLOAD' for row in rows}
        positions = {int(row.split(',')[0]): [float(v) for v in row.split(',')[1:]]
                     for key, rows in blocks(output / 'cad/mesh-7/mesh.inp') if key == '*NODE'
                     for row in rows if int(row.split(',')[0]) in load_ids}
        evidence = json.loads(evidence_path.read_text())
        require(contract(cards, rosters, plan['support_N_mm'], positions, [0, 0, -4000], [0, 850000, 0]) == evidence,
                'Whole rosters or exact serialized resultant evidence differs')
        require(not (output / 'assessment.json').exists() and not (output / 'execution/ccx.prestart').exists(), 'Unexpected solver output')
        files = [p for root in (output, execution) for p in root.rglob('*') if p.is_file()]
        require(not any(p.is_symlink() for p in files), 'Symlink output refused')
        report['cases'][case] = dict(actual_tool_handle=handle, actual_terminal_chunk=chunk,
            actual_tool_returncode=0, actual_child_returncode=0, direct_child_reaped=True,
            owned_group_freshly_absent=True, PID_PGID=supervision['pid'],
            elapsed_seconds=supervision['elapsed_seconds'], supervision_sha256=sha(execution / 'execution-receipt.json'),
            case_plan_sha256=sha(plan_path), prepared_deck_sha256=sha(deck),
            full_load_support_evidence=evidence, whole_rosters_compared=True,
            whole_serialized_resultants_recomputed_equal=True, current_pins=len(pins),
            sources_before_after_actual_equal=True,
            whole_outputs_sha256={str(p.relative_to(ROOT)): sha(p) for p in sorted(files)})
    report['collector_sha256'] = sha(__file__)
    target = HERE / 'deck-preparation-terminal-collection.json'
    with target.open('x') as stream:
        json.dump(report, stream, indent=2, allow_nan=False)
        stream.write('\n'); stream.flush(); os.fsync(stream.fileno())
    print(json.dumps(dict(status=report['status'], terminal_sha256=sha(target), cases=list(report['cases']))))


if __name__ == '__main__':
    main()
