"""Seal source-only plans; no native imports, kernel or scientific job."""
import difflib,hashlib,json,os,time
from pathlib import Path
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[2]
def sha(path):
 h=hashlib.sha256()
 with Path(path).open('rb')as f:
  for b in iter(lambda:f.read(1024**2),b''):h.update(b)
 return h.hexdigest()
def write(name,v):
 with(HERE/name).open('x')as f:json.dump(v,f,indent=2,allow_nan=False);f.write('\n');f.flush();os.fsync(f.fileno())
def rel(p):return str(p.relative_to(ROOT))
start=time.monotonic();old=ROOT/'work/carrier-process-20261017/bounded-webs-cap-rib-contour1-prototype-002'
p=json.loads((old/'plan.json').read_text());pins=dict(p['files_sha256'])
paths=[old/'postfillet.py',old/'plan.json',old/'output-001/candidate-native.brep',old/'output-001/assessment.json',HERE/'close_end.py',HERE/'selfcheck.py',HERE/'README.md',HERE/'prepare.py']
paths += [HERE/'history/initial-stdlib-refusal-001'/n for n in ['close_end.py','selfcheck.py','receipt.json']]
base=ROOT/'work/carrier-process-20261017/bounded-webs-C1-peak-native-preparation-002'
paths += [base/n for n in ['diagnose.py','local_properties.py','output-001/assessment.json','terminal-collection-001.json','root-terminal-review-001.json']]
cut=ROOT/'work/carrier-process-20261017/bounded-webs-native-BREP-cut-preparation-001';paths += [cut/n for n in ['diagnose.py','terminal-collection.json','root-terminal-review-001.json']]
protected=ROOT/'work/carrier-process-20261017/bounded-webs-BREP-protected-comparator-preparation-002/root-terminal-review-001.json';paths.append(protected)
supervisor=ROOT/'work/carrier-process-20261017/source010-exposure-preflight-003/supervise.py';paths.append(supervisor)
for path in paths:
 key=rel(path);h=sha(path)
 if key in pins:assert pins[key]==h,(key,'historical frozen source changed')
 pins[key]=h
assert sha(old/'postfillet.py')=='4652baf7ca78becaef65d38bff13b928bf69ba95027cdd7cb5ce4fc38cb99436'
assert sha(base/'output-001/assessment.json')=='616d69d5e60627cf3c877d6094818482ed92c2604ca86fba07301b6a57b295ff'
assert sha(base/'root-terminal-review-001.json')=='04b82cebf7c635f44943cc916f48d71b076cac9571235ecbc9c03aba81305d57'
assert sha(supervisor)=='4d18d747b5db84725b4c3da50cc12b7eb41c6ce9c9a9239a34f3e130b8980a37'
observed={n:sha(ROOT/n)for n in pins};assert observed==pins
plan=dict(schema='single-C1-window-end-R1-plan-1',launch_ready=False,root_GO_required=True,root_GO=None,radius_mm=1.,edge_index=267,adjacent_faces=[60,62],bounds=dict(outer=180,inner=150,CPU=[140,141],threads=1,workers=0),native_site=p['native_site'],postfillet_source=rel(old/'postfillet.py'),strict_cut_source=rel(cut/'diagnose.py'),volume_source=p['volume_source'],C1_BREP=rel(old/'output-001/candidate-native.brep'),baseline_STEP=p['STEP'],study=p['study'],diagnostic=rel(base/'output-001/assessment.json'),diagnostic_root_review=rel(base/'root-terminal-review-001.json'),output_directory=rel(HERE/'output-001'),execution_directory=rel(HERE/'execution-001'),minimum_xyz_mm=p['minimum_xyz_mm'],maximum_xyz_mm=p['maximum_xyz_mm'],existing_bound_guard_mm=p['existing_bound_guard_mm'],candidate_qualified=False,downstream_checks={k:'PENDING'for k in ['protected_interfaces','surface_topology_and_distance','STEP_exchange','FEA']},full_protected_checker_imported=False,original_postfillet_plan_sha256=sha(old/'plan.json'),files_sha256=pins)
for key in ['output_directory','execution_directory']:assert not(ROOT/plan[key]).exists()
write('pending-plan.json',plan);psha=sha(HERE/'pending-plan.json')
python=ROOT/'work/part-workflow/runtimes/geometry-standalone/bin/python';command=[str(python),'-I','-B',str(HERE/'close_end.py'),'run',str(HERE/'pending-plan.json'),psha]
launch=dict(schema='single-C1-end-R1-nonarmed-supervision-1',launch_ready=False,root_GO_required=True,cwd=str(ROOT),command=command,total_wall_budget_seconds=180,cleanup_grace_seconds=[10,10],section_workers=1,maximum_pending_layers=2,actual_section_workers=0,actual_processes=1,output_directory=plan['output_directory'],execution_directory=plan['execution_directory'],source_sha256={rel(q):sha(q)for q in [supervisor,HERE/'close_end.py']},inputs_sha256={**pins,rel(HERE/'pending-plan.json'):psha})
write('pending-launch-plan.json',launch)
write('command.json',dict(template_only=True,root_GO_required=True,argv=[str(python),'-I','-B',str(supervisor),str(HERE/'pending-launch-plan.json'),'--plan-sha256',sha(HERE/'pending-launch-plan.json')],native_executed=False))
(HERE/'postfillet-to-endfillet.diff').write_text(''.join(difflib.unified_diff((old/'postfillet.py').read_text().splitlines(True),(HERE/'close_end.py').read_text().splitlines(True),fromfile='postfillet4652.py',tofile='close_end.py')))
write('preparation-assessment.json',dict(status='source_only_nonarmed_all_fresh_pins_PASS',source_sha256=sha(HERE/'close_end.py'),tests_sha256=sha(HERE/'selfcheck.py'),selfchecks_actual_chunk='d48502',selfchecks_actual_returncode=0,selfchecks=16,native_imports=False,Build=False,files_sha256=pins,unique_launch_pins=len({**launch['inputs_sha256'],**launch['source_sha256']}),total_pin_bytes=sum((ROOT/n).stat().st_size for n in pins),plan_sha256=psha,launch_sha256=sha(HERE/'pending-launch-plan.json'),full_comparator_or_FEA_imported=False,output_and_execution_absent=True,elapsed_seconds=time.monotonic()-start))
print(json.dumps(dict(status='source_only_pending',source_sha256=sha(HERE/'close_end.py'),plan_sha256=psha,launch_sha256=sha(HERE/'pending-launch-plan.json'),unique_launch_pins=len({**launch['inputs_sha256'],**launch['source_sha256']}),preparation_sha256=sha(HERE/'preparation-assessment.json'))))
