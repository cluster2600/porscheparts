# Original C1 terminal taper — non-armed prototype

This distinct prototype rebuilds the original seven-edge negative-Y C1 blend
from baseline STEP `de0e55…`. It makes one scalar assignment,
`SetRadius(0., 1, vertex302)`, before one final fillet Build. There is no
Simulate, SetLaw, current-C1 window-contour fillet, radius search or retry.
The whole original edge 431 supplies the transition extent. All six other
edges retain R1; the opposite original endpoint 125 remains unchanged.

The closed law observer and ROOT review `c6293f25…` establish the exact intended
automatic law: degree 3, poles `[0,0,1,1]`, knots
`[0,21.430826650472575]`, multiplicities `[4,4]`, nonrational and nonperiodic.
The physical endpoint abscissae remain distinct from the separately measured
edge length, 21.430826650472525 mm. This caller must read every post-Build law
and match the closed coefficients and physical interval exactly. It does not
assume that an earlier explicit SetLaw survives a later Build.

## Preservation and local checks

The unchanged `4652` helper recursively unwraps the native result and permits
exactly one valid Solid. Immediately after that check, the caller exports its
raw BREP once and records its SHA, **before** the law, containment, addition,
mass or bounds gates. A later ordinary refusal retains that unqualified shape
and its provenance. A failed or invalid Build is not promoted into a candidate.

The original baseline is freshly imported again after Build, independently
of the shape supplied to the fillet builder. The exact frozen raw-Cut helpers
then summarize both directions using non-destructive, serial, fuzzy-zero
Booleans, without Clean or healing:

- baseline minus candidate must contain no solid, face, edge or vertex;
- candidate minus baseline must contain positive valid solid material;
- candidate volume must exceed baseline volume;
- the original mass ceiling of 1.30 kg and original global bounds remain.

The existing adaptive precise-volume helper and local gate function are
reused directly. No allowance for a small nonempty removal is introduced.
The raw shape is not overwritten after the gates. The study copy is written
only after all local checks pass; `candidate_qualified` remains false.

## Scope and execution boundary

Returning the blend radius to zero reaches an original sharp baseline
vertex. A smooth radius polynomial does not establish a smooth solid corner,
better local thickness or lower stress. All stress peaks and both support
cases remain applicable. Complete protected-interface checks, surface
topology/distance, STEP exchange and FEA stay explicitly pending, even after
a local RC0. The earlier C1 acceptance does not transfer.

Proposed bounds are 180 s outer, 150 s inner, CPU 140–141 s, OSD/BLAS one
thread, nice10 child, zero workers and owned cleanup 10+10 s under unchanged
4d18. This stage contains one fillet Build and two directional Cut operations.
Its actual time and memory are unknown. It does not import the full protected
comparator that previously required about 28 GB; that remains a separately
reviewed stage. All frozen inputs, sources and runtime files are hashed
before and after. Fresh outputs and strict whole-plan inverse arming are
required before execution.

Thirteen small stdlib checks passed without importing scientific/native
modules. They include wrong law/interval/other-edge records, non-armed refusal,
the single-Build/no-Simulate/no-SetLaw boundary, unchanged local gates, and
execution of the actual early-export statements followed by a forced law
refusal to verify raw-BREP preservation. This preparation is non-armed: no
Build, Cut, export, mesh or FEA has run.
