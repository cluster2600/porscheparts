"""Seal Add-only observation plans without a scientific import or native execution."""
import copy,hashlib,json,os,time
from pathlib import Path
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[2];OLD=HERE.with_name('bounded-webs-C1-endfillet-preparation-002')
def sha(path):
 h=hashlib.sha256()
 with Path(path).open('rb')as f:
  for b in iter(lambda:f.read(1024**2),b''):h.update(b)
 return h.hexdigest()
def rel(path):return str(path.relative_to(ROOT))
def write(name,value):
 with(HERE/name).open('x')as f:json.dump(value,f,indent=2,allow_nan=False);f.write('\n');f.flush();os.fsync(f.fileno())
start=time.monotonic();original=json.loads((OLD/'pending-plan.json').read_text());pins=dict(original['files_sha256'])
assert sha(OLD/'close_end.py')=='0277484749def5186818275e1df26e1cebe9d8f83954d751acd8b53d25b21d10'
assert sha(OLD/'terminal-collection-001.json')=='71a7a0c9062ff9f98891b0374698d566e4b943f0fb035f25c02bf6304fa4c30c'
assert sha(OLD/'root-terminal-review-001.json')=='5b2c4b19d8fdbd5b5c7d2eb75459286d67e02b2782259e736142caa1abc51fd2'
paths=[HERE/n for n in ['observe.py','selfcheck.py','README.md','prepare.py']]+[OLD/n for n in ['close_end.py','pending-plan.json','pending-launch-plan.json','root-review-GO-001.json','armed-plan.json','launch-plan.json','terminal-collection-001.json','root-terminal-review-001.json','execution-001/execution-receipt.json','execution-001/stdout.log','execution-001/stderr.log','output-001/assessment.json','output-001/events.jsonl']]
for path in paths:
 key=rel(path);value=sha(path)
 if key in pins:assert pins[key]==value
 pins[key]=value
assert {n:sha(ROOT/n)for n in pins}==pins
plan=dict(schema='C1-edge267-R1-native-Add-only-plan-1',launch_ready=False,root_GO_required=True,root_GO=None,seed_edge=267,radius_mm=1.,bounds=dict(outer=180,inner=150,CPU=[140,141],threads=1,workers=0),native_site=original['native_site'],prototype_source=rel(OLD/'close_end.py'),diagnostic=original['diagnostic'],C1_BREP=original['C1_BREP'],prior_refusal_terminal=rel(OLD/'terminal-collection-001.json'),prior_refusal_root_review=rel(OLD/'root-terminal-review-001.json'),output_directory=rel(HERE/'output-001'),execution_directory=rel(HERE/'execution-001'),candidate_qualified=False,native_Build_authorized=False,native_Cut_authorized=False,shape_export_authorized=False,original_prototype_guard_unchanged=True,files_sha256=pins)
for key in ['output_directory','execution_directory']:assert not(ROOT/plan[key]).exists()
write('pending-plan.json',plan);psha=sha(HERE/'pending-plan.json');supervisor=ROOT/'work/carrier-process-20261017/source010-exposure-preflight-003/supervise.py';python=ROOT/'work/part-workflow/runtimes/geometry-standalone/bin/python'
assert sha(supervisor)=='4d18d747b5db84725b4c3da50cc12b7eb41c6ce9c9a9239a34f3e130b8980a37'
launch=dict(schema='C1-edge267-Add-only-nonarmed-owned-plan-1',launch_ready=False,root_GO_required=True,cwd=str(ROOT),command=[str(python),'-I','-B',str(HERE/'observe.py'),'run',str(HERE/'pending-plan.json'),psha],total_wall_budget_seconds=180,cleanup_grace_seconds=[10,10],section_workers=1,maximum_pending_layers=2,actual_section_workers=0,actual_processes=1,output_directory=plan['output_directory'],execution_directory=plan['execution_directory'],source_sha256={rel(q):sha(q)for q in [supervisor,HERE/'observe.py']},inputs_sha256={**pins,rel(HERE/'pending-plan.json'):psha})
write('pending-launch-plan.json',launch);lsha=sha(HERE/'pending-launch-plan.json')
write('command.json',dict(template_only=True,root_GO_required=True,argv=[str(python),'-I','-B',str(supervisor),str(HERE/'pending-launch-plan.json'),'--plan-sha256',lsha],native_executed=False))
write('preparation-assessment.json',dict(status='source_only_NONARMED_no_native_execution',source_sha256=sha(HERE/'observe.py'),tests_sha256=sha(HERE/'selfcheck.py'),actual_stdlib_tests=9,actual_test_RC=0,actual_test_chunk='4260f3',all_fresh_pins_equal=True,unique_launch_pins=len({**launch['source_sha256'],**launch['inputs_sha256']}),total_pin_bytes=sum((ROOT/n).stat().st_size for n in pins),plan_sha256=psha,launch_sha256=lsha,original_prototype_unchanged=True,native_Build_authorized=False,output_and_execution_absent=True,elapsed_seconds=time.monotonic()-start))
print(json.dumps(dict(status='source_only_NONARMED',source_sha256=sha(HERE/'observe.py'),plan_sha256=psha,launch_sha256=lsha,preparation_sha256=sha(HERE/'preparation-assessment.json'),unique_pins=len({**launch['source_sha256'],**launch['inputs_sha256']}))))
