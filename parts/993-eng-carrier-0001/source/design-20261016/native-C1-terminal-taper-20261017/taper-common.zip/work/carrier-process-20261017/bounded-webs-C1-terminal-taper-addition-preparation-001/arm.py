"""Strict whole-inverse arming of the one preserved-taper local addition diagnostic."""
import copy,importlib.util,json,os,time
from pathlib import Path
HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[2]
s=importlib.util.spec_from_file_location('_taper_addition_stdlib_arm',HERE/'measure.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m);sha,write=m.sha,m.write
rel=lambda p:str(p.relative_to(ROOT));start=time.monotonic()
expected={'pending-plan.json':'a1ae14a1a764d0fa97b384caeb02be8837cba81912b0fda688d6f66f20e8818f','pending-launch-plan.json':'f5c3ec2f5aaaec0d363ff21dba0c69ee147af50de398dbabb9233a924653416c','measure.py':'bd258ce1237f819c54e2e9afc872f20f6dc2f47e491d44a4f077d3aeb324b797','root-review-GO-001.json':'22eab893ab0e576992756e9499e22c69d5bcdb918731b55a2c4ab0fc2e3cc90f'}
assert {n:sha(HERE/n)for n in expected}==expected
old=json.loads((HERE/'pending-plan.json').read_text());oldlaunch=json.loads((HERE/'pending-launch-plan.json').read_text());go=json.loads((HERE/'root-review-GO-001.json').read_text());gkey=rel(HERE/'root-review-GO-001.json')
assert go['status']=='GO_one_strict_addition_Cut_and_original_local_mass_bounds'and old['launch_ready']is False and old['root_GO']is None and old['root_GO_sha256']is None and oldlaunch['launch_ready']is False
assert go['pending_plan_sha256']==expected['pending-plan.json']and go['pending_launch_sha256']==expected['pending-launch-plan.json']
plan=copy.deepcopy(old);plan['launch_ready']=True;plan['root_GO']=gkey;plan['root_GO_sha256']=expected['root-review-GO-001.json'];plan['files_sha256'][gkey]=expected['root-review-GO-001.json']
inverse=copy.deepcopy(plan);inverse['launch_ready']=False;inverse['root_GO']=None;inverse['root_GO_sha256']=None;del inverse['files_sha256'][gkey];assert inverse==old
write(HERE/'armed-plan.json',plan);psha=sha(HERE/'armed-plan.json');launch=copy.deepcopy(oldlaunch);launch['launch_ready']=True;assert launch['command'][-2:]==[str(HERE/'pending-plan.json'),expected['pending-plan.json']]
launch['command'][-2:]=[str(HERE/'armed-plan.json'),psha];akey=rel(HERE/'armed-plan.json');launch['inputs_sha256'][akey]=psha;launch['inputs_sha256'][gkey]=expected['root-review-GO-001.json']
inverse=copy.deepcopy(launch);inverse['launch_ready']=False;inverse['command'][-2:]=oldlaunch['command'][-2:];del inverse['inputs_sha256'][akey];del inverse['inputs_sha256'][gkey];assert inverse==oldlaunch
pins={**launch['inputs_sha256'],**launch['source_sha256']};assert {n:sha(ROOT/n)for n in pins}==pins
checked,_,_=m.verify(HERE/'armed-plan.json',psha,True);assert checked==plan
keys=('retention_assessment','retention_residue','retention_terminal','retention_supervision','retention_plan','retention_launch');m.retention_records(plan,*[json.loads((ROOT/plan[k]).read_text())for k in keys])
write(HERE/'launch-plan.json',launch);lsha=sha(HERE/'launch-plan.json');argv=[str(ROOT/'work/part-workflow/runtimes/geometry-standalone/bin/python'),'-I','-B',str(ROOT/'work/carrier-process-20261017/source010-exposure-preflight-003/supervise.py'),str(HERE/'launch-plan.json'),'--plan-sha256',lsha]
write(HERE/'command.json',dict(argv=argv,root_GO_sha256=expected['root-review-GO-001.json'],candidate_qualified=False))
write(HERE/'arming-assessment.json',dict(status='strict_whole_inverse_and_fresh_pins_PASS_no_native_run',root_GO_sha256=expected['root-review-GO-001.json'],source_sha256=expected['measure.py'],arming_source_sha256=sha(__file__),plan_sha256=psha,launch_sha256=lsha,command_sha256=sha(HERE/'command.json'),whole_plan_inverse_equal=True,whole_launch_inverse_equal=True,unique_pins=len(pins),all_pins_actual_equal=True,fresh_output_and_execution=True,retention_semantic_join_actual=True,elapsed_seconds=time.monotonic()-start))
print(json.dumps(dict(plan_sha256=psha,launch_sha256=lsha,arming_sha256=sha(HERE/'arming-assessment.json'),command_sha256=sha(HERE/'command.json'),unique_pins=len(pins))))
